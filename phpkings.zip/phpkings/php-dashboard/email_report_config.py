"""Local settings for Vector DB metadata report emails."""

EMAIL_API_URL = "http://192.168.62.225:5026/api/send-email"
EMAIL_API_KEY = "xxxx"

EMAIL_TO = [] #
EMAIL_CC = [] #
EMAIL_BCC = []
EMAIL_REPLY_TO = []

EMAIL_SUBJECT = "PHP Flow Scanner metadata report - {taxyear}"
EMAIL_CONTENT = (
    "Attached is a ZIP containing the PHP Flow Scanner metadata reports for {taxyear}. "
    "Each workbook in the ZIP contains the files requiring the configured folder review."
    
)
EMAIL_IS_HTML = False
EMAIL_TIMEOUT_SECONDS = 120
