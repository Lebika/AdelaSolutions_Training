from __future__ import annotations
import hashlib
import json
import logging
import math
import shutil
import time
from pathlib import Path
import os
import re
import uuid
from dataclasses import dataclass, field
from datetime import datetime
from typing import Callable, Dict, Iterable, List, Optional, Set, Tuple

# Configuration (override via environment variables for local/dev testing)

REPO_ROOT = Path(__file__).resolve().parents[2]

PHPDATA_ROOT = REPO_ROOT / "phpdata"
SITE_ASP_BASE = Path(r"E:\online-taxes\site-asp")
QDRANT_BASE = PHPDATA_ROOT / "SQL"

logger = logging.getLogger("phphelper.query_chunk_scanner")

# Only .php and .html are scanned/counted right now.
SOURCE_EXTENSIONS = {".php", ".html"}

# Regexes driving the chunk state machine

FRESH_QUERY_RE = re.compile(r"\$query\w*\s*=(?!=)(?!\s*\.=)")
APPEND_QUERY_RE = re.compile(r"\$query\w*\s*\.=")
ANY_QUERY_ASSIGN_RE = re.compile(r"\$query\w*\s*\.?=(?!=)")

# Extensibility point: the functions that actually "execute" a query (the anchor we scan backward from), and the helper-function prefixes that count as "related" to a query block.
ANCHOR_FUNCTIONS = ["db_sql_query", "db_wfi_query"]
FALLBACK_ANCHOR_FUNCTIONS = ["db_sql_paramformat", "db_wfi_paramformat"]
RELATED_FUNCTION_PREFIXES = ["db_sql_", "db_wfi_"]


def _alternation(names: List[str]) -> str:
    return "|".join(re.escape(n) for n in names)


# The "execution" call that marks the *end* of a logical query block.
ANCHOR_QUERY_RE = re.compile(r"(?:" + _alternation(ANCHOR_FUNCTIONS) + r")\s*\(", re.I)
ANCHOR_PARAMFORMAT_RE = re.compile(r"(?:" + _alternation(FALLBACK_ANCHOR_FUNCTIONS) + r")\s*\(", re.I)

# The variable actually passed into db_sql_query(array($var...)) db_sql_paramformat($var...) -- not always $query, e.g. $qc, $qt1.
ANCHOR_VAR_RE = re.compile(
    r"(?:" + _alternation(ANCHOR_FUNCTIONS + FALLBACK_ANCHOR_FUNCTIONS) + r")"
    r"\s*\(\s*(?:array\s*\(\s*)?(\$[A-Za-z_][A-Za-z0-9_]*)",
    re.I,
)

# db_sql_query(array("select ...")) / db_sql_query(array('select ...')) the SQL text is an inline literal right in the call, no variable at all.
_ANCHOR_CALL_ALT = _alternation(ANCHOR_FUNCTIONS)
INLINE_LITERAL_DQ_RE = re.compile(r"(?:" + _ANCHOR_CALL_ALT + r")\s*\(\s*array\s*\(\s*\"((?:[^\"\\]|\\.)*)\"", re.I)
INLINE_LITERAL_SQ_RE = re.compile(r"(?:" + _ANCHOR_CALL_ALT + r")\s*\(\s*array\s*\(\s*'((?:[^'\\]|\\.)*)'", re.I)

# Base tokens that are always "related" to a query block regardless of which variable name is used to hold the SQL text.
BASE_RELATED_RE = re.compile(
    r"(?:" + _alternation(RELATED_FUNCTION_PREFIXES) + r")"
    r"|_SQL_DataArray"
    r"|_SQL_ParamsArray"
    r"|_SQL_FieldClause"
    r"|_SQL_ValueClause"
    r"|\$out_sqlparm"
)

# Kept for backward compatibility / as the default when no anchor variable could be determined at all.
RELATED_RE = re.compile(BASE_RELATED_RE.pattern + r"|\$query\b")


def _related_pattern(var_name: Optional[str]) -> "re.Pattern[str]":
    """Related-line pattern for one anchor: the base tokens, plus whichever variable this particular anchor actually uses to hold its SQL text ($query, $qc, $qt1, """
    if var_name:
        return re.compile(BASE_RELATED_RE.pattern + "|" + re.escape(var_name) + r"\b")
    return RELATED_RE


def _extract_inline_literal(line: str) -> Optional[str]:
    m = INLINE_LITERAL_DQ_RE.search(line) or INLINE_LITERAL_SQ_RE.search(line)
    if not m:
        return None
    text = re.sub(r"\s+", " ", m.group(1)).strip()
    return text or None

# MS-SQL keywords that mark the top of an actual SQL statement.
QUERY_KEYWORD_RE = re.compile(
    r"\bIF\s+NOT\s+EXISTS\b"
    r"|\bIF\s+EXISTS\b"
    r"|\bSELECT\b"
    r"|\bINSERT\s+INTO\b"
    r"|\bUPDATE\b"
    r"|\bDELETE\s+FROM\b"
    r"|\bCREATE\s+TABLE\b"
    r"|\bDROP\s+TABLE\b"
    r"|\bEXISTS\b",
    re.I,
)

# Lines that are never part of a query block even if they happen to fall inside the scanned range (e.g. an include() sitting between two chunks).
EXCLUDE_LINE_RE = re.compile(r"^\s*(include|require)(_once)?\s*\(", re.I)

# Conditional-branch structure that commonly wraps the pieces of a dynamic SQL build
# (e.g. an if/else choosing which columns/params go into $_SQL_DataArray, or which
# WHERE clause a query uses). These lines carry no SQL text themselves, but dropping
# them breaks both the chunk's readability and the reconstructed query, so they need
# to be treated as "transparent" during the chunk walk and still kept in chunk_text.
CONTROL_IF_RE = re.compile(r"^\s*\}?\s*(?:else\s*)?if\s*\(.*\)\s*\{?\s*$", re.I)
CONTROL_ELSE_RE = re.compile(r"^\s*\}?\s*else\s*\{?\s*$", re.I)
# elseif / "else if" specifically -- continues the *same* branch group (another alternative), rather than opening a brand-new one.
CONTROL_ELSEIF_RE = re.compile(r"^\s*\}?\s*else\s*if\s*\(.*\)\s*\{?\s*$", re.I)


def _is_control_flow_line(line: str) -> bool:
    """True for a line that is *only* if/elseif/else/brace structure -- no SQL-building content of its own."""
    stripped = line.strip()
    if not stripped:
        return False
    if stripped in ("{", "}"):
        return True
    if CONTROL_IF_RE.match(line):
        return True
    if CONTROL_ELSE_RE.match(line):
        return True
    return False


def _brace_pairs(lines: List[str]) -> Tuple[Dict[int, int], Dict[int, int]]:
    """Return line-level brace pairs while ignoring comments and quoted strings."""
    open_to_close: Dict[int, int] = {}
    close_to_open: Dict[int, int] = {}
    stack: List[int] = []
    in_block_comment = False
    quote: Optional[str] = None
    escaped = False

    for line_idx, line in enumerate(lines):
        idx = 0
        while idx < len(line):
            char = line[idx]
            next_char = line[idx + 1] if idx + 1 < len(line) else ""

            if in_block_comment:
                if char == "*" and next_char == "/":
                    in_block_comment = False
                    idx += 2
                else:
                    idx += 1
                continue

            if quote:
                if escaped:
                    escaped = False
                elif char == "\\":
                    escaped = True
                elif char == quote:
                    quote = None
                idx += 1
                continue

            if char == "/" and next_char == "*":
                in_block_comment = True
                idx += 2
                continue
            if char == "/" and next_char == "/":
                break
            if char == "#":
                break
            if char in ('"', "'"):
                quote = char
                idx += 1
                continue
            if char == "{":
                stack.append(line_idx)
            elif char == "}" and stack:
                open_idx = stack.pop()
                open_to_close[open_idx] = line_idx
                close_to_open[line_idx] = open_idx
            idx += 1

    return open_to_close, close_to_open


def _previous_nonblank(lines: List[str], idx: int) -> Optional[int]:
    idx -= 1
    while idx >= 0:
        if lines[idx].strip():
            return idx
        idx -= 1
    return None


def _next_nonblank(lines: List[str], idx: int) -> Optional[int]:
    idx += 1
    while idx < len(lines):
        if lines[idx].strip():
            return idx
        idx += 1
    return None


def _if_branch_span_before_else(
    lines: List[str],
    anchor_idx: int,
    open_to_close: Dict[int, int],
) -> Optional[Tuple[int, int]]:
    """Find an enclosing ``if`` branch whose closing brace is followed by ``else``.

    This is the useful display boundary for a query followed by non-query branch
    work: the query chunk must retain the complete first branch instead of ending
    at the execution call and making the following ``else`` appear detached.
    """
    candidates: List[Tuple[int, int, int]] = []
    for open_idx, close_idx in open_to_close.items():
        if not (open_idx < anchor_idx < close_idx):
            continue
        else_idx = _next_nonblank(lines, close_idx)
        if else_idx is None or not CONTROL_ELSE_RE.match(lines[else_idx]):
            continue
        header_idx = open_idx if CONTROL_IF_RE.match(lines[open_idx]) else _previous_nonblank(lines, open_idx)
        if header_idx is None or not CONTROL_IF_RE.match(lines[header_idx]):
            continue
        # Do not absorb another executed query after this query in the same branch.
        if any(ANCHOR_QUERY_RE.search(lines[i]) for i in range(anchor_idx + 1, close_idx)):
            continue
        candidates.append((close_idx - open_idx, header_idx, close_idx))

    if not candidates:
        return None
    _, start_idx, end_idx = min(candidates)
    return start_idx, end_idx


def _else_branch_start(lines: List[str], start_idx: int, anchor_idx: int) -> Optional[int]:
    """Drop a sibling branch's closing brace accidentally pulled into an else chunk."""
    if lines[start_idx].strip() != "}":
        return None
    else_idx = _next_nonblank(lines, start_idx)
    if else_idx is None or else_idx > anchor_idx or not CONTROL_ELSE_RE.match(lines[else_idx]):
        return None
    return else_idx

# Commented-out query blocks (e.g. a whole "/* ...
_LEADING_COMMENT_MARKER_RE = re.compile(r"^(\s*)(?:/\*+|<!--+|//|#)\s?")
_TRAILING_COMMENT_MARKER_RE = re.compile(r"\s?(?:\*+/|--+>)(\s*)$")


def _strip_comment_markers(line: str) -> str:
    """Remove comment delimiters from the start/end of one chunk line without touching anything else on it"""
    cleaned = _LEADING_COMMENT_MARKER_RE.sub(r"\1", line)
    cleaned = _TRAILING_COMMENT_MARKER_RE.sub(r"\1", cleaned)
    return cleaned


# Overall cap on how far back the strict walk will ever look for one chunk (keeps pathological files from ballooning a chunk).
MAX_LOOKBACK = 300

# How far above the point where the strict contiguous walk stops we'll look for a separated bound-parameter setup block ($_SQL_DataArray db_sql_paramformat / db_sql_BuildParamArray / $out_sqlparm).
PARAM_SETUP_LOOKAHEAD = 10

QUOTED_STRING_RE = re.compile(r'"([^"\\]*(?:\\.[^"\\]*)*)"|\'([^\'\\]*(?:\\.[^\'\\]*)*)\'')

BUILD_PARAM_ARRAY_RE = re.compile(
    r"""(?:""" + _alternation(RELATED_FUNCTION_PREFIXES) + r""")BuildParamArray\s*\(\s*(\$[A-Za-z0-9_]+)\s*,\s*["']([^"']+)["']"""
)

SQL_DATA_ARRAY_ENTRY_RE = re.compile(
    r"""["']key["']\s*=>\s*["']?(\$?[A-Za-z0-9_]+)["']?"""
)

# Ordered so more specific phrases are matched before their generic prefix (e.g. "IF NOT EXISTS" before a bare "EXISTS").
QUERY_TYPE_PATTERNS = [
    ("IF NOT EXISTS", re.compile(r"\bIF\s+NOT\s+EXISTS\b", re.I)),
    ("IF EXISTS", re.compile(r"\bIF\s+EXISTS\b", re.I)),
    ("SELECT", re.compile(r"\bSELECT\b", re.I)),
    ("INSERT", re.compile(r"\bINSERT\s+INTO\b", re.I)),
    ("UPDATE", re.compile(r"\bUPDATE\b", re.I)),
    ("DELETE", re.compile(r"\bDELETE\s+FROM\b", re.I)),
    ("CREATE TABLE", re.compile(r"\bCREATE\s+TABLE\b", re.I)),
    ("DROP TABLE", re.compile(r"\bDROP\s+TABLE\b", re.I)),
    ("EXISTS", re.compile(r"\bEXISTS\b", re.I)),
]

DYNAMIC_FIELD_TOKEN_RE = re.compile(r"_SQL_FieldClause")
DYNAMIC_VALUE_TOKEN_RE = re.compile(r"_SQL_ValueClause")
PHP_INTERP_RE = re.compile(r"""\.\s*\$[A-Za-z0-9_\[\]'"]+\s*\.|\{\$[^}]+\}""")

# State detection mirrors php_flow_scanner.state_for_name: the "st_xx_" naming convention is checked first (e.g. st_oh_cityWN_seca -> OH), then a bare 2-letter state prefix directly on a table/file name (e.g. ar_1000.php -> AR, al_something -> AL) is checked as a fallback -- both only trusted when the 2-letter code is a real US state abbreviation.
STATES = {
    "AL", "AK", "AZ", "AR", "CA", "CO", "CT", "DE", "DC", "FL", "GA", "HI",
    "ID", "IL", "IN", "IA", "KS", "KY", "LA", "ME", "MD", "MA", "MI", "MN",
    "MS", "MO", "MT", "NE", "NV", "NH", "NJ", "NM", "NY", "NC", "ND", "OH",
    "OK", "OR", "PA", "RI", "SC", "SD", "TN", "TX", "UT", "VT", "VA", "WA",
    "WV", "WI", "WY",
}
STATE_TOKEN_RE = re.compile(r"\bst_([a-z]{2})_", re.I)
# Bare 2-letter state-code prefix, e.g. "ar_1000" (Arkansas) or "az_140.php" (Arizona) -- only trusted when immediately followed by an underscore + digit, and only when the code is a real state abbreviation.
STATE_PREFIX_RE = re.compile(r"(?:^|[^a-z0-9])([a-z]{2})_(?=\d)", re.I)


# Discovery helpers (drive the front-end dropdowns)

def discover_tax_years() -> List[str]:
    """Year folders directly under SITE_ASP_BASE, e.g. 2023, 2024, 2025."""
    years: List[str] = []
    if not os.path.isdir(SITE_ASP_BASE):
        return years
    for name in os.listdir(SITE_ASP_BASE):
        full = os.path.join(SITE_ASP_BASE, name)
        if os.path.isdir(full) and re.fullmatch(r"\d{4}", name):
            years.append(name)
    return sorted(years, reverse=True)


def discover_folders(taxyear: str) -> List[str]:
    """Sub-folders under SITE_ASP_BASE/<taxyear>, e.g. oltproc, oltweb..."""
    root = os.path.join(SITE_ASP_BASE, taxyear)
    folders: List[str] = []
    if not os.path.isdir(root):
        return folders
    for name in os.listdir(root):
        full = os.path.join(root, name)
        if os.path.isdir(full) and not name.startswith("."):
            folders.append(name)
    return sorted(folders)


def _walk_log_errors(err: OSError) -> None:
    # os.walk's default behavior on hitting a directory it can't read (permissions, a broken junction/symlink, etc) is to silently skip it -- every file inside just vanishes from the count with zero trace.
    logger.warning("Could not read directory while scanning (files inside were skipped): %s", err)


def _iter_source_files(root: str) -> Iterable[str]:
    for dirpath, _dirnames, filenames in os.walk(root, onerror=_walk_log_errors):
        for fname in filenames:
            ext = os.path.splitext(fname)[1].lower()
            if ext in SOURCE_EXTENSIONS:
                yield os.path.join(dirpath, fname)


def _count_all_files(root: str) -> int:
    """Every file under root, any extension -- used to report how many files (text, images, PDFs, etc.) exist alongside the PHP/HTML source files but aren't candidates for query-chunk scanning at all"""
    total = 0
    for _dirpath, _dirnames, filenames in os.walk(root, onerror=_walk_log_errors):
        total += len(filenames)
    return total


# Metadata extraction

def _derive_state(chunk_text: str, file_path: str) -> str:
    """'st_xx_' convention first (e.g. st_oh_cityWN_seca -> OH), then a bare 2-letter state prefix directly on a table/file name (e.g. ar_1000.php -> AR, al_something -> AL) -- only when that prefix is a real US state abbreviation"""
    for source in (chunk_text, os.path.basename(file_path)):
        match = STATE_TOKEN_RE.search(source)
        if match:
            abbr = match.group(1).upper()
            if abbr in STATES:
                return abbr
    for source in (chunk_text, os.path.basename(file_path)):
        for cand in STATE_PREFIX_RE.findall(source):
            abbr = cand.upper()
            if abbr in STATES:
                return abbr
    return "FED"


def _extract_query_types(query_lines: List[str]) -> List[str]:
    text = " ".join(query_lines)
    found: List[str] = []
    for label, pattern in QUERY_TYPE_PATTERNS:
        if pattern.search(text):
            # avoid EXISTS duplicating IF EXISTS / IF NOT EXISTS
            if label == "EXISTS" and any(f in ("IF EXISTS", "IF NOT EXISTS") for f in found):
                continue
            found.append(label)
    return found


def _normalize_dynamic(fragment: str) -> str:
    if DYNAMIC_FIELD_TOKEN_RE.search(fragment):
        return "<dynamic_fields>"
    if DYNAMIC_VALUE_TOKEN_RE.search(fragment):
        return "<dynamic_values>"
    return "<dynamic>"


def _assign_token_re(var_name: Optional[str]) -> "re.Pattern[str]":
    if var_name and var_name != "$query":
        return re.compile(re.escape(var_name) + r"\s*(\.?=)(?!=)")
    # Legacy default: matches $query, $query2, $queryStr, ...
    return re.compile(r"\$query\w*\s*(\.?=)(?!=)")


def _find_statement_end(text: str, start: int) -> int:
    """Index of the top-level ';' that closes the assignment RHS starting at `start` (or len(text) if the chunk was truncated before it)"""
    depth = 0
    in_quote = False
    i = start
    n = len(text)
    while i < n:
        ch = text[i]
        if in_quote:
            if ch == "\\":
                i += 2
                continue
            if ch == '"':
                in_quote = False
        else:
            if ch == '"':
                in_quote = True
            elif ch in "([":
                depth += 1
            elif ch in ")]":
                depth -= 1
            elif ch == ";" and depth <= 0:
                return i
        i += 1
    return n


def _split_literal_and_dynamic(rhs: str) -> List[str]:
    """Split a $query RHS into literal SQL fragments and normalized <dynamic_*> tokens for everything else (variables, concatenation)"""
    parts: List[str] = []
    dyn_buf: List[str] = []
    i = 0
    n = len(rhs)

    def flush_dyn():
        if dyn_buf:
            joined = "".join(dyn_buf)
            if joined.strip(" .;\n\t"):
                parts.append(_normalize_dynamic(joined))
            dyn_buf.clear()

    while i < n:
        ch = rhs[i]
        if ch == '"':
            flush_dyn()
            j = i + 1
            lit_chars: List[str] = []
            while j < n:
                c = rhs[j]
                if c == "\\" and j + 1 < n:
                    lit_chars.append(rhs[j + 1])
                    j += 2
                    continue
                if c == '"':
                    j += 1
                    break
                lit_chars.append(c)
                j += 1
            parts.append("".join(lit_chars))
            i = j
        else:
            dyn_buf.append(ch)
            i += 1
    flush_dyn()
    return parts


def _render_branch_segments(segments: List) -> str:
    """Render a list of segments (plain str fragments, or ['BRANCH', [alt_segment_lists...]] nodes) back into one SQL string, turning mutually-exclusive if/else concatenations into a '(a | b)' alternation instead of silently mashing both branches together."""
    parts: List[str] = []
    for seg in segments:
        if isinstance(seg, list) and seg and seg[0] == "BRANCH":
            alt_lists = seg[1]
            rendered_alts = []
            for alt in alt_lists:
                rendered = _render_branch_segments(alt).strip()
                if rendered and rendered not in rendered_alts:
                    rendered_alts.append(rendered)
            if len(rendered_alts) == 1:
                parts.append(rendered_alts[0] + " ")
            elif rendered_alts:
                parts.append("(" + " OR ".join(rendered_alts) + ") ")
        else:
            parts.append(seg)
    text = "".join(parts)
    text = re.sub(r"\s+", " ", text).strip()
    return text


def _extract_raw_queries_branch_aware(chunk_lines: List[str], var_name: Optional[str] = None) -> List[str]:
    """Same job as _extract_raw_queries, but tracks if/elseif/else structure so that concatenations coming from different (mutually exclusive) branches are rendered as an alternation, e.g. '(ai_qt_user_id=(?) | qt_user_id=(?))', instead of being flattened into one impossible statement with both branches' text run together."""
    assign_re = _assign_token_re(var_name)
    statements: List[str] = []

    root: List = []
    stack: List[List] = [root]          # stack of currently-active segment lists
    branch_stack: List[List] = []       # stack of ['BRANCH', [alt_lists...]] nodes currently open
    # True right after a closing '}' whose branch might still continue via an else/elseif
    # on a later line -- the branch isn't finalized (popped off branch_stack) until we
    # either see that else/elseif, or see something else that proves it isn't coming.
    awaiting_else = False

    def finalize_pending_branch():
        nonlocal awaiting_else
        if awaiting_else and branch_stack:
            branch_stack.pop()
        awaiting_else = False

    for raw_line in chunk_lines:
        line = raw_line
        if EXCLUDE_LINE_RE.match(line):
            continue

        if CONTROL_ELSEIF_RE.match(line):
            if awaiting_else and branch_stack:
                new_alt: List = []
                branch_stack[-1][1].append(new_alt)
                stack.append(new_alt)
                awaiting_else = False
            continue

        if CONTROL_ELSE_RE.match(line):
            if awaiting_else and branch_stack:
                new_alt = []
                branch_stack[-1][1].append(new_alt)
                stack.append(new_alt)
                awaiting_else = False
            continue

        if CONTROL_IF_RE.match(line):
            finalize_pending_branch()  # an unrelated prior branch that turned out to have no else
            branch_node = ["BRANCH", []]
            stack[-1].append(branch_node)
            first_alt: List = []
            branch_node[1].append(first_alt)
            branch_stack.append(branch_node)
            stack.append(first_alt)
            continue

        stripped = line.strip()
        if stripped == "{":
            continue
        if stripped == "}":
            if len(stack) > 1:
                stack.pop()
                awaiting_else = True
            continue

        m = assign_re.search(line)
        if not m:
            finalize_pending_branch()
            continue

        finalize_pending_branch()

        op = m.group(1)
        rhs = line[m.end():]
        semi = _find_statement_end(rhs, 0)
        rhs = rhs[:semi]
        parts = _split_literal_and_dynamic(rhs)

        if op == "=" and stack[-1] is root and root:
            # a fresh assignment at top level starts a new statement -- flush the previous one.
            statements.append(_render_branch_segments(root))
            root.clear()

        stack[-1].extend(parts)

    finalize_pending_branch()
    while len(stack) > 1:
        # unbalanced braces (chunk got truncated) -- don't lose the content, fold it back to root.
        stack.pop()

    if root:
        statements.append(_render_branch_segments(root))

    return [s for s in statements if s.strip()]


def _extract_raw_queries(chunk_lines: List[str], var_name: Optional[str] = None, inline_literal: Optional[str] = None) -> List[str]:
    """Rebuild the SQL text for this chunk"""
    if inline_literal is not None:
        return [inline_literal] if inline_literal.strip() else []

    if any(_is_control_flow_line(l) for l in chunk_lines):
        return _extract_raw_queries_branch_aware(chunk_lines, var_name=var_name)

    text = "".join(chunk_lines)
    statements: List[str] = []
    current_parts: List[str] = []
    assign_re = _assign_token_re(var_name)

    for m in assign_re.finditer(text):
        op = m.group(1)
        rhs_start = m.end()
        rhs_end = _find_statement_end(text, rhs_start)
        rhs = text[rhs_start:rhs_end]

        if op == "=" and current_parts:
            statements.append(_join_query_parts(current_parts))
            current_parts = []

        current_parts.extend(_split_literal_and_dynamic(rhs))

    if current_parts:
        statements.append(_join_query_parts(current_parts))

    return [s for s in statements if s.strip()]


def _join_query_parts(parts: List[str]) -> str:
    text = "".join(parts)
    text = re.sub(r"\s+", " ", text).strip()
    return text


TABLE_TOKEN_RE = re.compile(r"\b(?:FROM|INTO|UPDATE|TABLE)\s+([A-Za-z_][A-Za-z0-9_]*)", re.I)

# Matches a PHP variable embedded directly in a SQL string, e.g. "...where qt_user_id='$qt_user_id'" -- the convention used by files (like the poc/oltprocs2 style) that build queries via string interpolation instead of the db_sql_BuildParamArray/(?) placeholder convention.
INTERPOLATED_VAR_RE = re.compile(r"\$[A-Za-z_][A-Za-z0-9_]*(?:\[[^\]]*\])?")


def _query_tables(raw_query: List[str]) -> Set[str]:
    """Table names actually referenced in this chunk's own reconstructed SQL (FROM/INTO/UPDATE/TABLE <name>)"""
    tables: Set[str] = set()
    for q in raw_query:
        for m in TABLE_TOKEN_RE.finditer(q):
            tables.add(m.group(1).lower())
    return tables


def _extract_interpolated_params(raw_query: List[str]) -> List[Dict[str, str]]:
    """Fallback for queries that never call db_sql_BuildParamArray build a $_SQL_DataArray at all -- they embed PHP variables straight into the SQL string instead (e.g. "...='$qt_user_id'")"""
    params: List[Dict[str, str]] = []
    seen = set()
    for q in raw_query:
        for m in INTERPOLATED_VAR_RE.finditer(q):
            var = m.group(0)
            if var in seen:
                continue
            seen.add(var)
            params.append({"var": var, "mapping": None, "source": "interpolated"})
    return params


def _extract_params(chunk_lines: List[str], raw_query: Optional[List[str]] = None) -> List[Dict[str, str]]:
    """Bound params for one chunk"""
    params: List[Dict[str, str]] = []
    seen = set()
    text = "\n".join(chunk_lines)
    query_tables = _query_tables(raw_query) if raw_query else set()

    build_matches = BUILD_PARAM_ARRAY_RE.findall(text)
    if query_tables:
        scoped = [(v, m) for v, m in build_matches if m.split("::", 1)[0].strip().lower() in query_tables]
        if scoped:
            build_matches = scoped

    for var, mapping in build_matches:
        key = (var, mapping)
        if key in seen:
            continue
        seen.add(key)
        params.append({"var": var, "mapping": mapping, "source": "variable"})

    # Fall back to $_SQL_DataArray[] entries when no explicit db_sql_BuildParamArray call was present for a given key.
    for key_var in SQL_DATA_ARRAY_ENTRY_RE.findall(text):
        already = any(p["var"].lstrip("$") == key_var.lstrip("$") for p in params)
        if not already:
            params.append({"var": key_var if key_var.startswith("$") else f"${key_var}",
                            "mapping": None, "source": "data_array"})

    # Neither convention produced anything -- this query most likely embeds PHP variables directly in the SQL string instead.
    if not params and raw_query:
        params = _extract_interpolated_params(raw_query)

    return params


# Chunk extraction (the state machine described in the module docstring)

@dataclass
class QueryChunk:
    file: str
    file_path: str
    state: Optional[str]
    start_line: int
    end_line: int
    query_type: List[str] = field(default_factory=list)
    raw_query: List[str] = field(default_factory=list)
    params: List[Dict[str, str]] = field(default_factory=list)
    chunk_text: str = ""
    # Assigned once, right here at extraction time -- NOT re-rolled at persist time.
    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    chunk_hash: str = ""

    def __post_init__(self):
        if not self.chunk_hash:
            self.chunk_hash = _compute_chunk_hash(self.file, self.start_line, self.end_line, self.chunk_text)

    def to_metadata(self) -> Dict:
        return {
            "id": self.id,
            "chunk_hash": self.chunk_hash,
            "file": self.file,
            "file_path": self.file_path,
            "state": self.state,
            "start_line": self.start_line,
            "end_line": self.end_line,
            "query_type": self.query_type,
            "raw_query": self.raw_query,
            "params": self.params,
        }

    def to_chunk_index_entry(self) -> Dict:
        """The lightweight record written to chunks.json -- just enough to identify a chunk and detect whether it made it into storage, per the schema: id, file, start_line, end_line, query_type, chunk_hash"""
        return {
            "id": self.id,
            "file": self.file,
            "start_line": self.start_line,
            "end_line": self.end_line,
            "query_type": self.query_type,
            "chunk_hash": self.chunk_hash,
        }


def extract_query_chunks(file_path: str, root: str) -> List[QueryChunk]:
    """Algorithm: 1"""
    try:
        with open(file_path, "r", encoding="utf-8", errors="ignore") as fh:
            lines = fh.readlines()
    except OSError:
        return []

    # Relative to the folder root (not just the bare filename) -- folders can have nested subfolders, and if two of them each contain e.g. "index.php", basename-only identity would silently collapse both into a single record, undercounting files-on-disk and corrupting delete/update-by-file (it would touch chunks from every same-named file across every subfolder at once).
    rel_file = os.path.relpath(file_path, root).replace(os.sep, "/")
    n = len(lines)
    open_to_close, _ = _brace_pairs(lines)

    anchor_idxs = [i for i in range(n) if ANCHOR_QUERY_RE.search(lines[i])]
    if not anchor_idxs:
        anchor_idxs = [i for i in range(n) if ANCHOR_PARAMFORMAT_RE.search(lines[i])]
    if not anchor_idxs:
        return []

    chunks: List[QueryChunk] = []
    lower_bound = 0  # 0-based; chunks can't reach back past the previous chunk's end

    for anchor_idx in anchor_idxs:
        if anchor_idx < lower_bound:
            continue  # already consumed as part of the previous chunk's window

        # Chunk ends at the execution call itself -- db_free_result(...) is just cleanup, not part of the query, so it's not included.
        end_idx = anchor_idx

        # figure out what this anchor actually passes in: an inline string literal, a specific variable ($qc, $qt1, $query, ...), or neither (fall back to the legacy...
        anchor_line = lines[anchor_idx]
        inline_literal = _extract_inline_literal(anchor_line)
        var_match = None if inline_literal else ANCHOR_VAR_RE.search(anchor_line)
        var_name = var_match.group(1) if var_match else None
        related_re = _related_pattern(var_name)

        # pass 1: walk upward collecting the strictly contiguous related run.
        collected: List[int] = []
        idx = anchor_idx
        steps = 0
        while idx >= lower_bound and steps <= MAX_LOOKBACK:
            line = lines[idx]
            if EXCLUDE_LINE_RE.match(line):
                break
            if related_re.search(line):
                collected.append(idx)
                idx -= 1
                steps += 1
                continue
            if _is_control_flow_line(line):
                # if/elseif/else/brace wrapping the SQL-building lines -- keep walking
                # through it (and keep it), don't treat it as the end of the block.
                collected.append(idx)
                idx -= 1
                steps += 1
                continue
            break

        # pass 2: bounded lookahead for gap-separated related blocks above where pass 1 stopped, e.g.: $query = "if not exists (select ..."; $query .= " ...(?))"; db_sql_BuildParamArray($x, "..."); <- blank line here $_SQL_DataArray[] = array(...); $out_sqlparm = db_sql_paramformat($_SQL_DataArray); <- blank line here $query .= "insert into ..."; db_wfi_query(...); This repeats -- each time a gap-separated related block is found and bridged, it looks again from the new position for another one further up -- so multiple concat/setup blocks stacked with blank lines between them all merge into a single chunk.
        while True:
            scan_idx = idx
            scanned = 0
            found_setup = False
            while scan_idx >= lower_bound and scanned < PARAM_SETUP_LOOKAHEAD:
                line = lines[scan_idx]
                if ANCHOR_QUERY_RE.search(line):
                    break  # previous chunk's execution call -- stop, don't cross
                if related_re.search(line) and not EXCLUDE_LINE_RE.match(line):
                    # found a related block -- it may itself span several lines, so resume a normal contiguous walk from here.
                    while scan_idx >= lower_bound:
                        line2 = lines[scan_idx]
                        if ANCHOR_QUERY_RE.search(line2):
                            break
                        if related_re.search(line2) and not EXCLUDE_LINE_RE.match(line2):
                            collected.append(scan_idx)
                            scan_idx -= 1
                            continue
                        if _is_control_flow_line(line2):
                            collected.append(scan_idx)
                            scan_idx -= 1
                            continue
                        break
                    found_setup = True
                    break
                scan_idx -= 1
                scanned += 1
            if not found_setup:
                break  # nothing more to bridge -- pass 2 is done
            idx = scan_idx  # try bridging another gap from the new position

        collected.sort()
        start_idx = min(collected) if collected else anchor_idx

        chunk_line_list = [
            lines[i] for i in range(start_idx, end_idx + 1)
            if (related_re.search(lines[i]) or _is_control_flow_line(lines[i]))
            and not EXCLUDE_LINE_RE.match(lines[i])
        ]
        if not chunk_line_list:
            lower_bound = end_idx + 1
            continue

        # Cosmetic only: strips a wrapping /* */, //, #, or <!-- --> off each line now that we know which lines belong to this chunk.
        chunk_line_list = [_strip_comment_markers(l) for l in chunk_line_list]

        # Keep query reconstruction scoped to this execution call, but expand the
        # displayed source when it is the query in the first half of an if/else.
        # Otherwise the first chunk stops at db_sql_query(...) and the next chunk
        # misleadingly begins with the first branch's closing brace.
        display_start_idx = start_idx
        display_end_idx = end_idx
        branch_span = _if_branch_span_before_else(lines, anchor_idx, open_to_close)
        if branch_span:
            display_start_idx, display_end_idx = branch_span
            display_line_list = lines[display_start_idx : display_end_idx + 1]
        else:
            else_start_idx = _else_branch_start(lines, start_idx, anchor_idx)
            if else_start_idx is not None:
                display_start_idx = else_start_idx
                display_line_list = lines[display_start_idx : display_end_idx + 1]
            else:
                display_line_list = chunk_line_list

        chunk_text = "".join(display_line_list)
        state = _derive_state(chunk_text, file_path)
        query_type = _extract_query_types(chunk_line_list)
        raw_query = _extract_raw_queries(chunk_line_list, var_name=var_name, inline_literal=inline_literal)
        params = _extract_params(chunk_line_list, raw_query)

        chunks.append(
            QueryChunk(
                file=rel_file,
                file_path=file_path,
                state=state,
                start_line=display_start_idx + 1,
                end_line=display_end_idx + 1,
                query_type=query_type,
                raw_query=raw_query,
                params=params,
                chunk_text=chunk_text.rstrip("\n"),
            )
        )
        lower_bound = end_idx + 1

    return chunks


# Deterministic vectors (no embedding model / network download required mirrors php_flow_scanner.stable_vector so Qdrant storage works fully offline, same as the...

def _stable_vector(text: str, size: int = 64) -> List[float]:
    digest = hashlib.sha256(text.encode("utf-8")).digest()
    values: List[float] = []
    while len(values) < size:
        for byte in digest:
            values.append((byte / 127.5) - 1.0)
            if len(values) == size:
                break
        digest = hashlib.sha256(digest).digest()
    norm = math.sqrt(sum(v * v for v in values)) or 1.0
    return [v / norm for v in values]


def _point_id_for(record_id: str) -> int:
    return int(hashlib.md5(record_id.encode("utf-8")).hexdigest()[:15], 16)


def _compute_chunk_hash(file: str, start_line: int, end_line: int, chunk_text: str) -> str:
    """Deterministic content fingerprint for one chunk -- same file + line-range + text always produces the same hash, on this run and on every future rebuild"""
    raw = f"{file}:{start_line}:{end_line}:{chunk_text}"
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


# Qdrant persistence -- ONE build directory PER FOLDER, flat under a single "sql_query" root, keyed only by folder name (no date/timestamp in the path).

BUILD_ROOT_NAME = "sql_query"


def storage_dir(taxyear: str) -> str:
    return os.path.join(QDRANT_BASE, taxyear)


def base_dir(taxyear: str) -> str:
    """Root directory that holds every folder's build for this tax year."""
    return os.path.join(storage_dir(taxyear), BUILD_ROOT_NAME)


def build_dirname(folder: str) -> str:
    return f"{folder}"


def build_dir(taxyear: str, folder: str) -> str:
    """The single build directory for this folder"""
    return os.path.join(storage_dir(taxyear), build_dirname(folder))


def collection_name(taxyear: str, folder: str) -> str:
    """One shared collection name per tax year"""
    return f"sql_chunks_{taxyear}"


# Reserved -- not used by any active feature.
MERGE_FOLDER_NAME = "vectordb"


def folder_already_built(taxyear: str, folder: str) -> bool:
    """True if this folder already has a stored build -- used by the UI to switch the Create button to Update"""
    meta_path = os.path.join(build_dir(taxyear, folder), "metadata.json")
    return os.path.isfile(meta_path)


def _iter_build_dirs(taxyear: str):
    """Yield (folder, dir_path) for every build directory that exists under this tax year's build root"""
    root = storage_dir(taxyear)
    if not os.path.isdir(root):
        return
    for name in os.listdir(root):
        full = os.path.join(root, name)
        if not os.path.isdir(full):
            continue
        yield name, full


def _all_known_folders(taxyear: str) -> Set[str]:
    """Every folder name that has ever been built, unioned with whatever folders currently exist on disk -- so a folder whose source was since removed still shows up in build listings"""
    folders: Set[str] = set(discover_folders(taxyear))
    for folder, dir_path in _iter_build_dirs(taxyear):
        if folder == MERGE_FOLDER_NAME:
            continue
        if os.path.isfile(os.path.join(dir_path, "metadata.json")):
            folders.add(folder)
    return folders


# In-memory cache for metadata.json reads, keyed by path, invalidated by mtime.
_METADATA_READ_CACHE: Dict[str, tuple] = {}  # path -> (mtime, doc)


def _read_folder_metadata(taxyear: str, folder: str) -> Optional[Dict]:
    meta_path = os.path.join(build_dir(taxyear, folder), "metadata.json")
    try:
        mtime = os.path.getmtime(meta_path)
    except OSError:
        return None
    cached = _METADATA_READ_CACHE.get(meta_path)
    if cached and cached[0] == mtime:
        return cached[1]
    try:
        with open(meta_path, "r", encoding="utf-8") as fh:
            doc = json.load(fh)
    except (OSError, json.JSONDecodeError):
        return None
    _METADATA_READ_CACHE[meta_path] = (mtime, doc)
    return doc


def _write_folder_metadata(taxyear: str, folder: str, doc: Dict) -> None:
    folder_dir = build_dir(taxyear, folder)
    os.makedirs(folder_dir, exist_ok=True)
    meta_path = os.path.join(folder_dir, "metadata.json")
    with open(meta_path, "w", encoding="utf-8") as fh:
        json.dump(doc, fh, indent=2)
    _METADATA_READ_CACHE.pop(meta_path, None)


# chunks.json -- the ground-truth record of what extract_query_chunks() actually produced for a build, written the moment chunk generation finishes and BEFORE anything is handed to the embedding/upsert step.

def _chunks_index_path(taxyear: str, folder: str) -> str:
    return os.path.join(build_dir(taxyear, folder), "chunks.json")


def _write_chunks_index(taxyear: str, folder: str, chunks: List["QueryChunk"]) -> None:
    folder_dir = build_dir(taxyear, folder)
    os.makedirs(folder_dir, exist_ok=True)
    entries = [c.to_chunk_index_entry() for c in chunks]
    with open(_chunks_index_path(taxyear, folder), "w", encoding="utf-8") as fh:
        json.dump(entries, fh, indent=2)


def _read_chunks_index(taxyear: str, folder: str) -> List[Dict]:
    path = _chunks_index_path(taxyear, folder)
    if not os.path.isfile(path):
        return []
    try:
        with open(path, "r", encoding="utf-8") as fh:
            data = json.load(fh)
        return data if isinstance(data, list) else []
    except (OSError, json.JSONDecodeError):
        return []


class BuildCancelled(Exception):
    """Raised when a running build/embedding job is cancelled by the user."""
    pass


def _upsert_query_chunks(
    taxyear: str,
    folder: str,
    qdrant_path: str,
    records: List[Dict],
    replace: bool = False,
    embed_progress: Optional[Callable[[int, int], None]] = None,
    cancel_check: Optional[Callable[[], bool]] = None,
) -> Dict:
    """Persist chunk records into this folder's own local Qdrant collection using stable, deterministic (hash-based) vectors -- no embedding model download, no network access required"""
    try:
        from qdrant_client import QdrantClient
        from qdrant_client.models import Distance, PointStruct, VectorParams
    except Exception as exc:  # pragma: no cover - environment dependent
        return {"stored": 0, "collection_path": qdrant_path, "error": f"qdrant-client is not installed: {exc}"}

    target_collection = collection_name(taxyear, folder)
    client = QdrantClient(path=qdrant_path)
    try:
        exists = client.collection_exists(target_collection)
        if replace and exists:
            client.delete_collection(target_collection)
            exists = False
        if not exists:
            client.create_collection(target_collection, vectors_config=VectorParams(size=64, distance=Distance.COSINE))

        points = []
        total = len(records)
        processed = 0
        BATCH_SIZE = 500  # embed_progress already fires per-record below, so a
        # bigger batch doesn't cost live-count smoothness -- it just cuts the number of Qdrant upsert round trips (100 was a 5x throughput hit for no real UI benefit) Progress is tracked purely from our own Python loop counters below (processed / total) -- we never re-query Qdrant to check what was inserted, that would mean a round trip per record for no reason.
        for record in records:
            if cancel_check and cancel_check():
                raise BuildCancelled("Build cancelled during embedding")
            text = " ".join([
                record.get("file", ""),
                record.get("folder", ""),
                " ".join(record.get("query_type") or []),
                (record.get("chunk_text") or "")[:500],
            ])
            point_id = _point_id_for(record["id"])
            points.append(PointStruct(id=point_id, vector=_stable_vector(text), payload=record))
            processed += 1
            if len(points) >= BATCH_SIZE:
                client.upsert(collection_name=target_collection, points=points)
                points = []
            if embed_progress:
                # live count: 1/100, 2/100, ...
                embed_progress(processed, total)
        if points:
            client.upsert(collection_name=target_collection, points=points)
            if embed_progress:
                embed_progress(processed, total)
    finally:
        close = getattr(client, "close", None)
        if callable(close):
            close()
    return {"stored": len(records), "collection": target_collection, "collection_path": qdrant_path}


def _delete_qdrant_points(qdrant_path: str, taxyear: str, folder: str, point_ids: List[int]) -> None:
    if not point_ids or not os.path.isdir(qdrant_path):
        return
    try:
        from qdrant_client import QdrantClient
    except Exception:
        return
    target_collection = collection_name(taxyear, folder)
    client = QdrantClient(path=qdrant_path)
    try:
        if client.collection_exists(target_collection):
            client.delete(collection_name=target_collection, points_selector=point_ids)
    finally:
        close = getattr(client, "close", None)
        if callable(close):
            close()


def build_query_chunk_store(
    taxyear: str,
    folder: str,
    progress: Optional[Callable[[str, int, int, int], None]] = None,
    embed_progress: Optional[Callable[[int, int], None]] = None,
    cancel_check: Optional[Callable[[], bool]] = None,
) -> Dict:
    """Walk <SITE_ASP_BASE>/<taxyear>/<folder>, extract every query chunk, store them in that folder's own local Qdrant collection (deterministic vectors, no embedding model) plus its own metadata.json, and return a summary dict"""
    root = os.path.join(SITE_ASP_BASE, taxyear, folder)
    if not os.path.isdir(root):
        raise FileNotFoundError(f"Folder not found: {root}")

    file_paths = list(_iter_source_files(root))
    seen_paths = set()
    deduped_paths = []
    dropped_dupes = []
    for p in file_paths:
        key = os.path.normcase(os.path.abspath(p))
        if key in seen_paths:
            dropped_dupes.append(p)
            continue
        seen_paths.add(key)
        deduped_paths.append(p)
    if dropped_dupes:
        # Should be rare (same physical file reachable via two walked paths, e.g. a symlink/junction) -- logged rather than silently dropped so a count mismatch is always traceable to a real cause.
        logger.warning("Deduped %d file path(s) resolving to an already-seen file in %s: %s",
                        len(dropped_dupes), root, dropped_dupes)
    file_paths = deduped_paths
    total_files = len(file_paths)
    all_chunks: List[QueryChunk] = []
    files_scanned = 0
    folder_dir = build_dir(taxyear, folder)
    # Decided BEFORE anything on disk is touched -- this is also what decides cancel behavior below: a fresh Create has nothing worth keeping if cancelled, but an Update is touching a folder that already has a good, working build sitting in folder_dir, and cancelling must never destroy that.
    is_rebuild = os.path.isfile(os.path.join(folder_dir, "metadata.json"))
    backup_dir = folder_dir + ".backup"
    try:
        for idx, file_path in enumerate(file_paths, start=1):
            if cancel_check and cancel_check():
                raise BuildCancelled("Build cancelled during file scan")
            file_chunks = extract_query_chunks(file_path, root)
            all_chunks.extend(file_chunks)
            files_scanned += 1
            if progress:
                progress(os.path.basename(file_path), idx, total_files, len(all_chunks))
    except BuildCancelled:
        # Nothing on disk has been touched yet at this point (see below folder_dir isn't created/backed up until after this loop), so for an Update the existing build is simply untouched.
        if not is_rebuild and os.path.isdir(folder_dir):
            shutil.rmtree(folder_dir, ignore_errors=True)
        raise

    qdrant_path = folder_dir
    if is_rebuild:
        # Updating an existing folder: move the current, working build aside before writing anything new, so a cancel from here on can restore it untouched instead of leaving the folder half-written or (worse) gone.
        if os.path.isdir(backup_dir):
            shutil.rmtree(backup_dir, ignore_errors=True)
        shutil.move(folder_dir, backup_dir)
    os.makedirs(qdrant_path, exist_ok=True)

    try:
        # chunks.json written now, straight from the in-memory extraction result -- this is the ground truth used by verification, captured before the upsert step below gets any chance to fail silently.
        _write_chunks_index(taxyear, folder, all_chunks)

        metadata_records = []
        for chunk in all_chunks:
            record = chunk.to_metadata()
            record["chunk_text"] = chunk.chunk_text
            record["taxyear"] = taxyear
            record["folder"] = folder
            record["created_at"] = datetime.now().isoformat(timespec="seconds")
            metadata_records.append(record)

        if progress:
            progress("__embedding__", total_files, total_files, len(metadata_records))
        qdrant_info = _upsert_query_chunks(
            taxyear, folder, qdrant_path, metadata_records, replace=is_rebuild,
            embed_progress=embed_progress, cancel_check=cancel_check,
        )
    except BuildCancelled:
        # Discard whatever partial new build was in progress...
        if os.path.isdir(folder_dir):
            shutil.rmtree(folder_dir, ignore_errors=True)
        # ...and for an Update, restore the old build exactly as it was cancelling an update must never leave the folder empty or lose the previous data, only the new build attempt is thrown away.
        if is_rebuild and os.path.isdir(backup_dir):
            shutil.move(backup_dir, folder_dir)
        raise

    created_at = datetime.now().isoformat(timespec="seconds")
    # scanned_files is the full list of every file that was actually walked in this build, REGARDLESS of whether it produced a chunk.
    scanned_file_names = sorted(
        os.path.relpath(p, root).replace(os.sep, "/") for p in file_paths
    )
    doc = {
        "taxyear": taxyear,
        "folder": folder,
        "created_at": created_at,
        "files_scanned": files_scanned,
        "chunk_count": len(metadata_records),
        "records": metadata_records,
        "scanned_files": scanned_file_names,
    }
    _write_folder_metadata(taxyear, folder, doc)

    # Build succeeded -- the backup of the old build is no longer needed.
    if is_rebuild and os.path.isdir(backup_dir):
        shutil.rmtree(backup_dir, ignore_errors=True)

    summary = {
        "files_scanned": files_scanned,
        "chunks_created": len(metadata_records),
        "created_at": created_at,
        "collection_path": qdrant_path,
    }

    return {"summary": summary, "qdrant": qdrant_info}


def update_query_chunk_file(taxyear: str, folder: str, file_name: str) -> Dict:
    """Re-scan a single file and merge its chunks into an EXISTING folder build, without touching any other file's records"""
    doc = _read_folder_metadata(taxyear, folder)
    if doc is None:
        raise FileNotFoundError(f"No build found for {taxyear}/{folder}")

    file_name = file_name.replace("\\", "/")
    file_path = os.path.join(SITE_ASP_BASE, taxyear, folder, file_name)
    if not os.path.isfile(file_path):
        raise FileNotFoundError(f"Source file not found: {file_path}")

    qdrant_path = build_dir(taxyear, folder)

    old_records = doc.get("records", [])
    old_for_file = [r for r in old_records if r.get("file") == file_name]
    old_point_ids = [_point_id_for(r["id"]) for r in old_for_file if r.get("id")]
    _delete_qdrant_points(qdrant_path, taxyear, folder, old_point_ids)

    kept_records = [r for r in old_records if r.get("file") != file_name]
    root = os.path.join(SITE_ASP_BASE, taxyear, folder)
    new_chunks = extract_query_chunks(file_path, root)
    new_records = []
    for chunk in new_chunks:
        record = chunk.to_metadata()
        record["chunk_text"] = chunk.chunk_text
        record["taxyear"] = taxyear
        record["folder"] = folder
        record["created_at"] = datetime.now().isoformat(timespec="seconds")
        new_records.append(record)

    # chunks.json: drop this file's old entries, splice in the freshly extracted ones -- same merge shape as metadata.json's records above, kept in sync so verification always compares against what was just generated, not a stale snapshot from the original build.
    old_index_entries = _read_chunks_index(taxyear, folder)
    kept_index_entries = [e for e in old_index_entries if e.get("file") != file_name]
    new_index_entries = [c.to_chunk_index_entry() for c in new_chunks]
    with open(_chunks_index_path(taxyear, folder), "w", encoding="utf-8") as fh:
        json.dump(kept_index_entries + new_index_entries, fh, indent=2)

    qdrant_info = _upsert_query_chunks(taxyear, folder, qdrant_path, new_records)

    doc["records"] = kept_records + new_records
    doc["chunk_count"] = len(doc["records"])
    # Mark this file as scanned even if it produced zero chunks -- otherwise a chunkless file re-scanned here still shows up as "new" on the next folder-level Update click (see scanned_files note in build_query_chunk_store).
    scanned_files = set(doc.get("scanned_files", []))
    scanned_files.add(file_name)
    doc["scanned_files"] = sorted(scanned_files)
    doc["updated_at"] = datetime.now().isoformat(timespec="seconds")
    _write_folder_metadata(taxyear, folder, doc)

    return {
        "taxyear": taxyear, "folder": folder, "file_name": file_name,
        "chunks_for_file": len(new_records), "chunk_count": doc["chunk_count"], "qdrant": qdrant_info,
    }


def update_query_chunk_folder(taxyear: str, folder: str) -> Dict:
    """Scan the actual data folder on disk (SITE_ASP_BASE/<taxyear>/<folder>) and add ONLY the files that aren't part of the existing build yet existing files' chunk records/Qdrant points are left completely untouched"""
    doc = _read_folder_metadata(taxyear, folder)
    if doc is None:
        raise FileNotFoundError(f"No build found for {taxyear}/{folder}")

    root = os.path.join(SITE_ASP_BASE, taxyear, folder)
    if not os.path.isdir(root):
        raise FileNotFoundError(f"Folder not found: {root}")

    qdrant_path = build_dir(taxyear, folder)

    old_records = doc.get("records", [])

    # "known" must include every file ever WALKED, not just files that produced a chunk record.
    known_files: Set[str] = set(doc.get("scanned_files", []))
    if not known_files:
        known_files = {r.get("file") for r in old_records if r.get("file")}

    # Actual data path on disk is the source of truth for what's "new" same relative-path convention (root-relative, forward slashes) used everywhere else in this module for the "file" field.
    disk_files = {
        os.path.relpath(p, root).replace(os.sep, "/"): p
        for p in _iter_source_files(root)
    }
    new_file_paths = [path for rel, path in disk_files.items() if rel not in known_files]
    new_rel_names = [rel for rel, path in disk_files.items() if rel not in known_files]

    new_chunks: List[QueryChunk] = []
    for file_path in new_file_paths:
        new_chunks.extend(extract_query_chunks(file_path, root))

    new_records: List[Dict] = []
    for chunk in new_chunks:
        record = chunk.to_metadata()
        record["chunk_text"] = chunk.chunk_text
        record["taxyear"] = taxyear
        record["folder"] = folder
        record["created_at"] = datetime.now().isoformat(timespec="seconds")
        new_records.append(record)

    # partial update: keep every existing chunks.json entry, splice in only the new files' freshly extracted ones.
    old_index_entries = _read_chunks_index(taxyear, folder)
    new_index_entries = [c.to_chunk_index_entry() for c in new_chunks]
    with open(_chunks_index_path(taxyear, folder), "w", encoding="utf-8") as fh:
        json.dump(old_index_entries + new_index_entries, fh, indent=2)

    # partial update: only the new files' chunks get upserted -- existing Qdrant points for already-built files are never touched (replace stays False, unlike the old full-folder rebuild).
    qdrant_info = _upsert_query_chunks(taxyear, folder, qdrant_path, new_records)

    doc["records"] = old_records + new_records
    doc["chunk_count"] = len(doc["records"])
    doc["files_scanned"] = doc.get("files_scanned", 0) + len(new_file_paths)
    # Remember EVERY file just walked (chunk or no chunk) so it's never re-offered as "new" on a future update.
    doc["scanned_files"] = sorted(known_files | set(new_rel_names))
    doc["updated_at"] = datetime.now().isoformat(timespec="seconds")
    _write_folder_metadata(taxyear, folder, doc)

    return {
        "taxyear": taxyear, "folder": folder,
        "files_scanned": len(new_file_paths), "chunk_count": doc["chunk_count"], "qdrant": qdrant_info,
    }


# Read / filter helpers for the View tab

def delete_query_chunk_build(taxyear: str, folder: str) -> Dict:
    """Remove a folder's entire stored build."""
    folder_dir = build_dir(taxyear, folder)
    removed = os.path.isdir(folder_dir)
    if removed:
        shutil.rmtree(folder_dir, ignore_errors=True)

    return {
        "taxyear": taxyear, "folder": folder,
        "removed_dirs": [folder_dir] if removed else [],
        "remaining": folder_already_built(taxyear, folder),
    }


def delete_query_chunk_file(taxyear: str, folder: str, file_name: str) -> Dict:
    """Remove a single file's chunk records from this folder's build matched exactly (folder + relative file path), never by substring or basename, so it can never touch another file's or another folder's records"""
    doc = _read_folder_metadata(taxyear, folder)
    if doc is None:
        raise FileNotFoundError(f"No build found for {taxyear}/{folder}")

    file_name = file_name.replace("\\", "/")

    qdrant_path = build_dir(taxyear, folder)
    old_records = doc.get("records", [])
    to_remove = [r for r in old_records if r.get("file") == file_name]

    scanned_files = set(doc.get("scanned_files", []))
    was_tracked = file_name in scanned_files
    scanned_files.discard(file_name)

    if to_remove or was_tracked:
        if to_remove:
            point_ids = [_point_id_for(r["id"]) for r in to_remove if r.get("id")]
            _delete_qdrant_points(qdrant_path, taxyear, folder, point_ids)
            doc["records"] = [r for r in old_records if r.get("file") != file_name]
            doc["chunk_count"] = len(doc["records"])

        doc["scanned_files"] = sorted(scanned_files)

        # chunks.json must stay in sync too -- otherwise verification keeps comparing against a ground truth that still has this file's (now-deleted) chunks in it.
        old_index_entries = _read_chunks_index(taxyear, folder)
        kept_index_entries = [e for e in old_index_entries if e.get("file") != file_name]
        if len(kept_index_entries) != len(old_index_entries):
            with open(_chunks_index_path(taxyear, folder), "w", encoding="utf-8") as fh:
                json.dump(kept_index_entries, fh, indent=2)

        doc["updated_at"] = datetime.now().isoformat(timespec="seconds")
        _write_folder_metadata(taxyear, folder, doc)

    return {
        "taxyear": taxyear, "folder": folder, "file_name": file_name,
        "removed_chunks": len(to_remove), "chunk_count": doc.get("chunk_count", 0),
    }


def delete_query_chunk_taxyear(taxyear: str) -> Dict:
    """Remove every build directory for an entire tax year."""
    root = storage_dir(taxyear)
    removed = os.path.isdir(root)
    if removed:
        shutil.rmtree(root, ignore_errors=True)
    return {"taxyear": taxyear, "removed": removed}


def list_query_chunk_dbs(taxyear: str) -> List[Dict]:
    """One row per folder: its stored build (there is only ever one)."""
    builds: List[Dict] = []
    for folder in sorted(_all_known_folders(taxyear)):
        doc = _read_folder_metadata(taxyear, folder)
        if doc is None:
            continue
        builds.append({
            "folder": folder,
            "created_at": doc.get("created_at"),
            "chunk_count": doc.get("chunk_count", 0),
            "files_scanned": doc.get("files_scanned", 0),
            "dir_name": build_dirname(folder),
        })

    builds.sort(key=lambda b: b.get("created_at") or "", reverse=True)
    return builds


def _latest_build_per_folder(taxyear: str) -> Dict[str, Dict]:
    latest: Dict[str, Dict] = {}
    for build in list_query_chunk_dbs(taxyear):
        folder = build["folder"]
        if folder not in latest:
            latest[folder] = build
    return latest


def build_query_chunk_summary(taxyear: str) -> Dict:
    """Page-level snapshot for the stat cards, built from each folder's (only) stored build"""
    builds = list_query_chunk_dbs(taxyear)

    total_chunks = sum(b.get("chunk_count", 0) for b in builds)
    total_files = sum(b.get("files_scanned", 0) for b in builds)
    last_build_at = max((b.get("created_at") for b in builds if b.get("created_at")), default=None)

    # files_scanned on each build is a SNAPSHOT captured the moment that build ran.
    files_not_scanned = 0
    total_files_now = 0
    stale_folders = []
    for b in builds:
        folder = b.get("folder")
        if not folder:
            continue
        root = os.path.join(SITE_ASP_BASE, taxyear, folder)
        all_files = _count_all_files(root)
        eligible_files_now = sum(1 for _ in _iter_source_files(root))
        total_files_now += eligible_files_now
        files_not_scanned += max(0, all_files - eligible_files_now)
        scanned_at_build = b.get("files_scanned", 0)
        if eligible_files_now != scanned_at_build:
            stale_folders.append({
                "folder": folder,
                "files_scanned": scanned_at_build,
                "files_on_disk_now": eligible_files_now,
                "delta": eligible_files_now - scanned_at_build,
            })

    return {
        "taxyear": taxyear,
        "folders_built": len(builds),
        "folder_names": [b.get("folder") for b in builds if b.get("folder")],
        "total_chunks": total_chunks,
        "total_files_scanned": total_files,
        "total_files_now": total_files_now,
        "last_build_at": last_build_at,
        "files_not_scanned": files_not_scanned,
        "stale_folders": stale_folders,
    }


def _scroll_one_folder(taxyear: str, folder: str) -> List[Dict]:
    try:
        from qdrant_client import QdrantClient
    except Exception:
        return []

    collection_dir = build_dir(taxyear, folder)
    if not os.path.isdir(collection_dir):
        return []

    target_collection = collection_name(taxyear, folder)
    client = QdrantClient(path=collection_dir)
    try:
        if not client.collection_exists(target_collection):
            return []
        records: List[Dict] = []
        scroll_offset = None
        while True:
            points, scroll_offset = client.scroll(
                collection_name=target_collection,
                limit=1000,
                offset=scroll_offset,
                with_payload=True,
                with_vectors=False,
            )
            records.extend(point.payload for point in points if point.payload)
            if scroll_offset is None:
                break
        return records
    finally:
        close = getattr(client, "close", None)
        if callable(close):
            close()


def _scroll_qdrant_records(taxyear: str, folder: Optional[str]) -> List[Dict]:
    """Read chunk records straight from each folder's local Qdrant collection"""
    if folder:
        return _scroll_one_folder(taxyear, folder)
    records: List[Dict] = []
    for f in _all_known_folders(taxyear):
        records.extend(_scroll_one_folder(taxyear, f))
    return records


def load_query_chunk_metadata(
    taxyear: str,
    folder: Optional[str] = None,
    query_type: Optional[str] = None,
    state: Optional[str] = None,
    search: Optional[str] = None,
    limit: int = 500,
    offset: int = 0,
) -> Dict:
    """Load chunk records for a tax year straight from Qdrant (optionally scoped to one folder), each folder's own (only) stored build is read"""
    records: List[Dict] = []

    latest_builds = _latest_build_per_folder(taxyear)
    folders_to_load = [folder] if folder else list(latest_builds.keys())
    for f in folders_to_load:
        if f not in latest_builds:
            continue
        records.extend(_scroll_qdrant_records(taxyear, f))

    if query_type:
        records = [r for r in records if query_type in (r.get("query_type") or [])]
    if state:
        records = [r for r in records if (r.get("state") or "FED").lower() == state.lower()]
    if search:
        needle = search.lower()
        records = [
            r
            for r in records
            if needle in (r.get("file") or "").lower()
            or any(needle in q.lower() for q in (r.get("raw_query") or []))
        ]

    counts_by_type: Dict[str, int] = {}
    counts_by_state: Dict[str, int] = {}
    counts_by_folder: Dict[str, int] = {}
    for r in records:
        for qt in r.get("query_type") or ["UNCLASSIFIED"]:
            counts_by_type[qt] = counts_by_type.get(qt, 0) + 1
        st = r.get("state") or "FED"
        counts_by_state[st] = counts_by_state.get(st, 0) + 1
        fo = r.get("folder") or "unknown"
        counts_by_folder[fo] = counts_by_folder.get(fo, 0) + 1

    total = len(records)
    page = records[offset : offset + limit]

    return {
        "taxyear": taxyear,
        "folders_loaded": folders_to_load,
        "available_builds": list(_latest_build_per_folder(taxyear).values()),
        "total_filtered": total,
        "counts_by_type": counts_by_type,
        "counts_by_state": counts_by_state,
        "counts_by_folder": counts_by_folder,
        "records": page,
        "offset": offset,
        "limit": limit,
        "has_next": offset + limit < total,
        "has_prev": offset > 0,
    }


# Reports tab: per-folder reconciliation between what's on disk and what's stored in each folder's latest build -- file counts, chunk counts, and a breakdown of *why* a file has no chunks: either it's a genuine 0-byte "dead" file, or it's a real file that simply has no db_sql_/db_wfi_ query calls in it ("no queries found").

_REPORT_CACHE: Dict[str, Dict] = {}
REPORT_CACHE_TTL_SECONDS = 120


def missing_sql_files_report_path(taxyear: str) -> str:
    """Dedicated report file for the query-chunk scanner's Reports tab, stored under sql_query/ so it never collides with php_flow_scanner's own missing_files_report.json in the tax-year root"""
    return os.path.join(storage_dir(taxyear), "missing_sql_files_report.json")


def load_missing_sql_files_report(taxyear: str) -> Optional[Dict]:
    """Freshness-checked read of the persisted report -- mirrors php_flow_scanner.load_missing_files_report()"""
    path = missing_sql_files_report_path(taxyear)
    if not os.path.exists(path):
        return None
    report_mtime = os.path.getmtime(path)
    scanner_mtime = os.path.getmtime(__file__)
    manifest_mtimes = []
    for folder in discover_folders(taxyear):
        meta_path = os.path.join(build_dir(taxyear, folder), "metadata.json")
        if os.path.exists(meta_path):
            manifest_mtimes.append(os.path.getmtime(meta_path))
    if report_mtime < max([scanner_mtime, *manifest_mtimes], default=scanner_mtime):
        return None
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except (OSError, json.JSONDecodeError):
        return None


def get_query_chunk_report(taxyear: str, refresh: bool = False) -> List[Dict]:
    """Entry point for the /report route: serves the persisted file when it's still fresh, otherwise falls back to a full rebuild -- same read-first pattern as php_flow_scanner's /missing_files route"""
    if not refresh:
        loaded = load_missing_sql_files_report(taxyear)
        if loaded is not None:
            return loaded.get("folders", [])
    return build_query_chunk_report(taxyear, use_cache=not refresh)


def build_query_chunk_report(taxyear: str, use_cache: bool = True) -> List[Dict]:
    """One row per folder: files on disk, files scanned in a build, chunks created, and a breakdown of files with zero chunks into dead (0 KB) files vs. files that simply have no queries in them"""
    now = time.time()
    cache_key = taxyear
    if use_cache:
        cached = _REPORT_CACHE.get(cache_key)
        if cached and (now - cached["ts"]) < REPORT_CACHE_TTL_SECONDS:
            return cached["data"]

    report: List[Dict] = []

    latest_builds = _latest_build_per_folder(taxyear)
    folders_and_builds = sorted(
        ((folder, build) for folder, build in latest_builds.items() if build),
        key=lambda item: item[0]
    )

    for folder, build in folders_and_builds:
        root = os.path.join(SITE_ASP_BASE, taxyear, folder)
        # Relative paths, not bare basenames -- a folder can have nested subfolders, and two of them can easily contain a same-named file (e.g. "legacy/index.php" and "index.php").
        disk_files: Set[str] = {os.path.relpath(p, root).replace(os.sep, "/") for p in _iter_source_files(root)}

        chunk_count = 0
        scanned_files = 0
        last_build_at = None
        files_with_chunks: Set[str] = set()

        if build:
            doc = _read_folder_metadata(taxyear, folder)
            if doc:
                chunk_count = doc.get("chunk_count", 0)
                scanned_files = doc.get("files_scanned", 0)
                last_build_at = build.get("created_at") or doc.get("created_at")
                files_with_chunks = {rec.get("file") for rec in doc.get("records", []) if rec.get("file")}

        no_query_files: List[str] = []
        dead_files: List[str] = []
        for name in sorted(disk_files - files_with_chunks):
            full_path = os.path.join(root, name)
            try:
                is_dead = os.path.getsize(full_path) == 0
            except OSError:
                is_dead = False
            (dead_files if is_dead else no_query_files).append(name)

        # "Extra" = the build still references a file that's no longer on disk (source was moved/deleted since that build ran).
        extra_files = sorted(files_with_chunks - disk_files)

        report.append({
            "folder": folder,
            "files_on_disk": len(disk_files),
            "files_scanned": scanned_files,
            "chunks_created": chunk_count,
            "no_query_count": len(no_query_files),
            "no_query_files": no_query_files[:200],
            "dead_count": len(dead_files),
            "dead_files": dead_files[:200],
            "extra_count": len(extra_files),
            "extra_files": extra_files[:200],
            "last_build_at": last_build_at,
        })

    _REPORT_CACHE[cache_key] = {"ts": now, "data": report}

    try:
        os.makedirs(storage_dir(taxyear), exist_ok=True)
        with open(missing_sql_files_report_path(taxyear), "w", encoding="utf-8") as f:
            json.dump({"taxyear": taxyear, "updated_at": datetime.now().isoformat(timespec="seconds"),
                       "folders": report}, f, indent=2)
    except OSError:
        pass  # persistence is best-effort; the in-memory cache above still serves the Reports tab

    return report


def list_files_for_build(taxyear: str, folder: str) -> List[str]:
    """Sorted unique file names for a folder -- used by the Update/Delete tabs' file pickers"""
    root = os.path.join(SITE_ASP_BASE, taxyear, folder)
    if not os.path.isdir(root):
        return []
    return sorted(
        os.path.relpath(p, root).replace(os.sep, "/")
        for p in _iter_source_files(root)
    )


# Verification tab: for each folder's latest build, confirm every chunk that was recorded in that build's metadata.json actually made it into the Qdrant collection.

def build_query_chunk_verification(taxyear: str, folder: Optional[str] = None) -> List[Dict]:
    """One row per folder, checked across three checkpoints instead of two: chunks.json -- what extract_query_chunks() actually produced (ground truth, written before storage is attempted) metadata.json -- what the build believes it stored (written unconditionally after the Qdrant upsert call, whether or not that upsert actually succeeded) Qdrant -- what's actually retrievable right now A chunk can go missing at either hop, and the two failures mean different things: in chunks.json but NOT in metadata.json ("not_recorded") chunking finished but the build never got as far as writing the record (e.g. the process died mid-build)"""
    report: List[Dict] = []
    latest_builds = _latest_build_per_folder(taxyear)
    folders_to_check = [folder] if folder else discover_folders(taxyear)

    for folder_name in folders_to_check:
        build = latest_builds.get(folder_name)
        built = bool(build)
        created_at = build.get("created_at") if build else None
        doc_for_meta = _read_folder_metadata(taxyear, folder_name) if built else None

        if not built or doc_for_meta is None:
            report.append({
                "folder": folder_name,
                "last_build_at": None,
                "total_chunks": 0,
                "stored_chunks": 0,
                "missing_count": 0,
                "missing_chunks": [],
                "status": "not_built",
            })
            continue

        meta_records: List[Dict] = (doc_for_meta or {}).get("records", [])
        chunk_index: List[Dict] = _read_chunks_index(taxyear, folder_name)

        meta_by_hash: Dict[str, Dict] = {r["chunk_hash"]: r for r in meta_records if r.get("chunk_hash")}

        if chunk_index:
            # chunks.json exists -- it's the real ground truth.
            expected = {e["chunk_hash"]: e for e in chunk_index if e.get("chunk_hash")}
        else:
            # Pre-chunks.json build: fall back to metadata.json as ground truth, same as the old logic, so nothing regresses.
            expected = meta_by_hash

        qdrant_records = _scroll_qdrant_records(taxyear, folder_name)
        qdrant_hashes: Set[str] = {rec.get("chunk_hash") for rec in qdrant_records if rec.get("chunk_hash")}

        missing_chunks: List[Dict] = []
        for chunk_hash, entry in expected.items():
            if chunk_hash not in meta_by_hash:
                missing_chunks.append({
                    "id": entry.get("id"),
                    "chunk_hash": chunk_hash,
                    "file": entry.get("file"),
                    "start_line": entry.get("start_line"),
                    "end_line": entry.get("end_line"),
                    "query_type": entry.get("query_type") or [],
                    "stage": "not_recorded",
                    "reason": "Chunk was extracted but never made it into metadata.json (build likely stopped early).",
                })
                continue
            if chunk_hash not in qdrant_hashes:
                rec = meta_by_hash[chunk_hash]
                missing_chunks.append({
                    "id": rec.get("id"),
                    "chunk_hash": chunk_hash,
                    "file": rec.get("file"),
                    "start_line": rec.get("start_line"),
                    "end_line": rec.get("end_line"),
                    "query_type": rec.get("query_type") or [],
                    "stage": "not_stored",
                    "reason": "Chunk was recorded but is not retrievable from Qdrant (vector upsert likely failed).",
                })

        total_chunks = len(expected)
        missing_count = len(missing_chunks)
        report.append({
            "folder": folder_name,
            "last_build_at": created_at,
            "total_chunks": total_chunks,
            "stored_chunks": total_chunks - missing_count,
            "missing_count": missing_count,
            "missing_chunks": missing_chunks[:500],
            "status": "ok" if missing_count == 0 else "missing",
        })

    return report
