from __future__ import annotations
import re
from typing import Dict, List, Optional, Tuple

from query_chunk_scanner import MO_FOLDERS, _query_tables, _read_folder_metadata

# Analyse pages only ever look at the MO tax year for this check.
MO_TAXYEAR = "MO"


MO_BUSINESS_FOLDERS: Tuple[str, ...] = MO_FOLDERS

# Signals that mark a query as "business logic" rather than a plain
# parameterised CRUD statement: derived/temp result sets, XML-based string
# aggregation, window functions, old-style comma joins, and queries that
# nest several SELECTs together.
_FOR_XML_PATH_RE = re.compile(r"FOR\s+XML\s+PATH", re.IGNORECASE)
_STUFF_RE = re.compile(r"\bSTUFF\s*\(", re.IGNORECASE)
_ROW_NUMBER_OVER_RE = re.compile(r"\bROW_NUMBER\s*\(\s*\)\s*OVER\s*\(", re.IGNORECASE)
_WINDOW_OVER_RE = re.compile(r"\bOVER\s*\(\s*(?:PARTITION\s+BY|ORDER\s+BY)", re.IGNORECASE)
_DERIVED_TABLE_RE = re.compile(r"\)\s*[A-Za-z_][A-Za-z0-9_]*\s*(?:WHERE|ORDER|GROUP|$)", re.IGNORECASE)
_COMMA_JOIN_RE = re.compile(
    r"\bFROM\s+[A-Za-z_][A-Za-z0-9_]*(?:\s+[A-Za-z_][A-Za-z0-9_]*)?\s*,\s*[A-Za-z_][A-Za-z0-9_]*",
    re.IGNORECASE,
)
_UNION_RE = re.compile(r"\bUNION\b", re.IGNORECASE)
_SELECT_RE = re.compile(r"\bSELECT\b", re.IGNORECASE)
_EXISTS_RE = re.compile(r"\bEXISTS\s*\(", re.IGNORECASE)
_CASE_WHEN_RE = re.compile(r"\bCASE\b.*?\bWHEN\b.*?\bTHEN\b", re.IGNORECASE | re.DOTALL)
_CONVERT_RE = re.compile(r"\bCONVERT\s*\(", re.IGNORECASE)
_CAST_RE = re.compile(r"\bCAST\s*\(", re.IGNORECASE)
_ISNULL_RE = re.compile(r"\bISNULL\s*\(", re.IGNORECASE)
_RTRIM_RE = re.compile(r"\bRTRIM\s*\(", re.IGNORECASE)
_SUBSTRING_RE = re.compile(r"\bSUBSTRING\s*\(", re.IGNORECASE)
_FORMAT_RE = re.compile(r"\bFORMAT\s*\(", re.IGNORECASE)
_LEN_RE = re.compile(r"\bLEN\s*\(", re.IGNORECASE)
_COALESCE_RE = re.compile(r"\bCOALESCE\s*\(", re.IGNORECASE)
_NOT_IN_RE = re.compile(r"\bNOT\s+IN\s*\(", re.IGNORECASE)

# Matches "<operand> <operator> <operand>" so each side can be checked against
# a SQL-keyword blacklist below -- a plain regex on its own also matches
# "SELECT * FROM ..." (the column wildcard, not multiplication)
_MATH_FORMULA_TOKEN_RE = re.compile(
    r"\b([A-Za-z_][A-Za-z0-9_]*)\s*([*/+-])\s*(\d+(?:\.\d+)?|[A-Za-z_][A-Za-z0-9_]*)\b",
)
_SQL_KEYWORD_OPERANDS = {
    "select", "distinct", "top", "from", "where", "and", "or", "not", "as", "on",
    "set", "into", "values", "join", "left", "right", "inner", "outer", "full",
    "group", "order", "by", "having", "union", "all", "exists", "case", "when",
    "then", "else", "end", "is", "null", "like", "in", "between", "asc", "desc",
    "with", "over", "partition",
}


def _has_math_formula(query_text: str) -> bool:
    """True if the query contains real arithmetic between two operands (a
    multiplier, percentage, or a `field +/-/*// field-or-number` formula) --
    not just a `SELECT *` column wildcard or other SQL syntax that happens to
    contain +/-/*// characters."""
    for match in _MATH_FORMULA_TOKEN_RE.finditer(query_text):
        lhs, rhs = match.group(1).lower(), match.group(3).lower()
        if lhs in _SQL_KEYWORD_OPERANDS or rhs in _SQL_KEYWORD_OPERANDS:
            continue
        return True
    return False


# Any single one of these is a strong-enough signal on its own.
_STRONG_SIGNALS = (_FOR_XML_PATH_RE, _STUFF_RE, _ROW_NUMBER_OVER_RE, _WINDOW_OVER_RE, _CASE_WHEN_RE)


def _business_query_reasons(query_text: str) -> List[str]:
    reasons: List[str] = []
    if _FOR_XML_PATH_RE.search(query_text):
        reasons.append("FOR XML PATH string aggregation")
    if _STUFF_RE.search(query_text):
        reasons.append("STUFF() concatenation")
    if _ROW_NUMBER_OVER_RE.search(query_text):
        reasons.append("ROW_NUMBER() OVER window function")
    elif _WINDOW_OVER_RE.search(query_text):
        reasons.append("OVER() window function")
    if _COMMA_JOIN_RE.search(query_text):
        reasons.append("comma-style multi-table join")
    if _UNION_RE.search(query_text):
        reasons.append("UNION of result sets")
    if _EXISTS_RE.search(query_text) and len(_SELECT_RE.findall(query_text)) >= 3:
        reasons.append("correlated EXISTS subquery")
    if len(_SELECT_RE.findall(query_text)) >= 4:
        reasons.append("multiple nested SELECT statements")
    if _CASE_WHEN_RE.search(query_text):
        reasons.append("CASE / WHEN / THEN / ELSE conditional business rule")
    if _has_math_formula(query_text):
        reasons.append("mathematical/financial formula (multiplier, percentage, or calculation)")
    if _CONVERT_RE.search(query_text):
        reasons.append("CONVERT() type/format conversion")
    if _CAST_RE.search(query_text):
        reasons.append("CAST() type conversion")
    if _ISNULL_RE.search(query_text):
        reasons.append("ISNULL() null-handling default")
    if _RTRIM_RE.search(query_text):
        reasons.append("RTRIM() trimming")
    if _SUBSTRING_RE.search(query_text):
        reasons.append("SUBSTRING() string extraction")
    if _FORMAT_RE.search(query_text):
        reasons.append("FORMAT() value formatting")
    if _LEN_RE.search(query_text):
        reasons.append("LEN() length check")
    if _COALESCE_RE.search(query_text):
        reasons.append("COALESCE() fallback value")
    if _NOT_IN_RE.search(query_text):
        reasons.append("NOT IN (...) exclusion logic")
    return reasons


def _is_business_query(raw_query: List[str]) -> List[str]:
    """Returns the list of reasons a chunk's reconstructed SQL was flagged as
    a business query (empty list if it isn't one)."""
    if not raw_query:
        return []
    query_text = " ".join(str(q) for q in raw_query)
    if any(pattern.search(query_text) for pattern in _STRONG_SIGNALS) or _has_math_formula(query_text):
        return _business_query_reasons(query_text)
    # Without a strong signal, require at least two weaker signals together
    # (e.g. a comma join plus several nested selects) to avoid flagging
    # ordinary queries.
    reasons = _business_query_reasons(query_text)
    return reasons if len(reasons) >= 2 else []


def _mo_business_chunks(records: List[Dict]) -> List[Dict]:
    issues: List[Dict] = []
    for rec in records:
        raw_query = rec.get("raw_query") or []
        reasons = _is_business_query(raw_query)
        if not reasons:
            continue
        issues.append({
            "file": rec.get("file"),
            "file_path": rec.get("file_path"),
            "start_line": rec.get("start_line"),
            "end_line": rec.get("end_line"),
            "query_type": rec.get("query_type") or [],
            "tables": sorted(_query_tables(raw_query)),
            "raw_query": raw_query,
            "chunk_text": rec.get("chunk_text") or "",
            "reasons": reasons,
        })
    return issues


def build_mo_business_analysis(folder: Optional[str] = None) -> List[Dict]:
    """One row per MO folder (reading the latest build's persisted
    metadata.json -- no rescan): total chunks checked and the business
    queries flagged among them."""
    report: List[Dict] = []
    folders = [folder] if folder else list(MO_BUSINESS_FOLDERS)

    for folder_name in folders:
        doc = _read_folder_metadata(MO_TAXYEAR, folder_name)
        if not doc:
            continue

        records = doc.get("records", [])
        issues = _mo_business_chunks(records)

        report.append({
            "folder": folder_name,
            "total_chunks": len(records),
            "issue_count": len(issues),
            "issue_chunks": issues,
        })

    return report


def _shorten_site_asp_path(path: Optional[str]) -> str:
    if not path:
        return ""
    normalized = str(path).replace("/", "\\")
    marker = "\\site-asp\\"
    idx = normalized.lower().find(marker)
    return normalized[idx + len(marker):] if idx >= 0 else normalized


def _format_file_display(file: Optional[str], file_path: Optional[str]) -> str:
    if file_path:
        return "\\" + _shorten_site_asp_path(file_path)
    return file or "unknown"


def _format_line_range(start: Optional[int], end: Optional[int]) -> str:
    if start is None:
        return "\u2014"
    if end is not None and end != start:
        return f"{start}-{end}"
    return str(start)


def build_mo_business_export_rows(folder: Optional[str] = None) -> Tuple[List[str], List[List]]:
    columns = ["Folder", "File", "Line(s)", "Table(s)", "Reason(s)", "Reconstructed SQL"]
    rows: List[List] = []
    for entry in build_mo_business_analysis(folder):
        chunks = entry.get("issue_chunks") or []
        if not chunks:
            rows.append([entry["folder"], "", "", "", "", ""])
            continue
        for chunk in chunks:
            rows.append([
                entry["folder"],
                _format_file_display(chunk.get("file"), chunk.get("file_path")),
                _format_line_range(chunk.get("start_line"), chunk.get("end_line")),
                ", ".join(chunk.get("tables") or []),
                ", ".join(chunk.get("reasons") or []),
                " | ".join(str(q) for q in (chunk.get("raw_query") or [])),
            ])
    return columns, rows