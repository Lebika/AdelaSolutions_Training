#!/usr/bin/env python3

import shutil
from pathlib import Path

# ==========================
# Configuration
# ==========================

TXT_FILE = r"files.txt"
SOURCE_FOLDER = r"E:\online-taxes\site-asp\2025\Staffolt_1"
DESTINATION_FOLDER = r"E:\online-taxes\site-asp\2025\Staffolt"

# ==========================
# Main
# ==========================

source_root = Path(SOURCE_FOLDER)
dest_root = Path(DESTINATION_FOLDER)
dest_root.mkdir(parents=True, exist_ok=True)

copied = 0
missing = 0
duplicates = 0

# Build filename index for fast lookup
file_index = {}

for file in source_root.rglob("*"):
    if file.is_file():
        file_index.setdefault(file.name.lower(), []).append(file)

with open(TXT_FILE, "r", encoding="utf-8") as f:
    for line in f:
        line = line.strip()

        if not line:
            continue

        filename = Path(line).name.lower()

        matches = file_index.get(filename)

        if not matches:
            print(f"[MISSING] {filename}")
            missing += 1
            continue

        if len(matches) > 1:
            print(f"[DUPLICATE] {filename} ({len(matches)} matches)")
            duplicates += 1

        src = matches[0]
        dst = dest_root / src.name

        shutil.copy2(src, dst)
        print(f"[COPIED] {src} -> {dst}")

        copied += 1

print("\n========== Summary ==========")
print(f"Copied    : {copied}")
print(f"Missing   : {missing}")
print(f"Duplicates: {duplicates}")