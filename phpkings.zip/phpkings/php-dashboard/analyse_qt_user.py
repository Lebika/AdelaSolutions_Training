from __future__ import annotations
import re
from functools import lru_cache
from typing import Dict, List, Optional, Set, Tuple

from query_chunk_scanner import (
    SITE_ASP_BASE,
    _query_tables,
    _all_known_folders,
    _read_folder_metadata,
)


QT_USER_ID_ALWAYS_EXEMPT_TABLES = [
    "ref_",
    "biz_",
    "oltpro_",
    "sys*",
    "staffip",
    "syscolumns",
    "taxtable",
    "eictable",
    "city_supp ", "state_supp",
    "dcn_pro",
    "dats_api_transactions",
    "pmt_resp",
    "mef_errors_solution",
    "state_zip",
    "st_err_code",
    "ext_errorcode",
    "irs_errorcode",
    "dcn_",
    "ind_OLTPRO_Mail",
    "err_prod_calculation_issue",
    "payment_prob_",
    "sbatmp_",
    "marketing*",
    "*_tpg",
    "oltpro_additionalcharges",
    "oltpro_discounts",
    "error20",
]

SCHEMA_ROOT = SITE_ASP_BASE / "Schema"
DYNAMIC_TABLE_RE = re.compile(
    r"\b(?:FROM|INTO|UPDATE|TABLE)\s+(?:\{\s*)?\$[A-Za-z_][A-Za-z0-9_]*",
    re.IGNORECASE,
)
MALFORMED_WHERE_BOUNDARY_RE = re.compile(
    r"(?<![$\w])WHERE(?=[A-Za-z_])",
    re.IGNORECASE,
)

# These tables may use either qt_user_id or user_name in the WHERE clause.
QT_USER_ID_OWNERSHIP_EXEMPT_TABLES = [
    "master_auth",
    "auth_access",
]

OWNERSHIP_COLUMN_RE = re.compile(r"\buser_name\b", re.IGNORECASE)
OWNERSHIP_VAR_RE = re.compile(r"\buser_name\b", re.IGNORECASE)
OWNERSHIP_WHERE_COLUMN_RE = re.compile(
    r"(?<![$\w])(?:[A-Za-z_][A-Za-z0-9_]*\.)?(?:qt_user_id|user_name)\b"
    r"\s*(?:=|<>|!=|<=|>=|<|>|\bIN\b|\bIS\b|\bLIKE\b)",
    re.IGNORECASE,
)
QT_USER_ID_WHERE_COLUMN_RE = re.compile(
    r"(?<![$\w])(?:[A-Za-z_][A-Za-z0-9_]*\.)?(?:bak_)?qt_user_id\b"
    r"\s*(?:=|<>|!=|<=|>=|<|>|\bIN\b|\bIS\b|\bLIKE\b)",
    re.IGNORECASE,
)
ACC_USER_ID_WHERE_COLUMN_RE = re.compile(
    r"(?<![$\w])(?:[A-Za-z_][A-Za-z0-9_]*\.)?acc_user_id\b"
    r"\s*(?:=|<>|!=|<=|>=|<|>|\bIN\b|\bIS\b|\bLIKE\b)",
    re.IGNORECASE,
)
MASTER_AUTH_ID_WHERE_COLUMN_RE = re.compile(
    r"(?<![$\w])(?:[A-Za-z_][A-Za-z0-9_]*\.)?mast_auth_id\b"
    r"\s*(?:=|<>|!=|<=|>=|<|>|\bIN\b|\bIS\b|\bLIKE\b)",
    re.IGNORECASE,
)
OLTPRO_MASTER_ID_WHERE_COLUMN_RE = re.compile(
    r"(?<![$\w])(?:[A-Za-z_][A-Za-z0-9_]*\.)?OLTPRO_masterID\b"
    r"\s*(?:=|<>|!=|<=|>=|<|>|\bIN\b|\bIS\b|\bLIKE\b|"
    r"\$OLTPRO_masterID_List(?:\b|(?=and\b)))",
    re.IGNORECASE,
)
OLTPRO_FIRM_EFIN_WHERE_COLUMN_RE = re.compile(
    r"(?<![$\w])(?:[A-Za-z_][A-Za-z0-9_]*\.)?firmEFIN\b"
    r"\s*(?:=|<>|!=|<=|>=|<|>|\bIN\b|\bIS\b|\bLIKE\b)",
    re.IGNORECASE,
)
MO_MASTER_ID_WHERE_COLUMN_RE = re.compile(
    r"(?<![$\w])(?:[A-Za-z_][A-Za-z0-9_]*\.)?MO_masterID\b"
    r"\s*(?:=|<>|!=|<=|>=|<|>|\bIN\b|\bIS\b|\bLIKE\b)",
    re.IGNORECASE,
)
OLT_DT_USER_ID_WHERE_COLUMN_RE = re.compile(
    r"(?<![$\w])(?:[A-Za-z_][A-Za-z0-9_]*\.)?olt_dt_user_id\b"
    r"\s*(?:=|<>|!=|<=|>=|<|>|\bIN\b|\bIS\b|\bLIKE\b)",
    re.IGNORECASE,
)
AMENDED_USER_ID_WHERE_COLUMN_RE = re.compile(
    r"(?<![$\w])(?:[A-Za-z_][A-Za-z0-9_]*\.)?"
    r"(?:bak_qt_user_id|prev_qt_user_id|qt_user_id)\b"
    r"\s*(?:=|<>|!=|<=|>=|<|>|\bIN\b|\bIS\b|\bLIKE\b)",
    re.IGNORECASE,
)
AUTH_ACCESS_INDEXVAL1_RE = re.compile(
    r"(?<![$\w])(?:[A-Za-z_][A-Za-z0-9_]*\.)?Indexval1\b"
    r"\s*(?:=|<>|!=|<=|>=|<|>|\bIN\b|\bIS\b|\bLIKE\b)",
    re.IGNORECASE,
)

# Chunk-text keyword exceptions -- if any of these (case-insensitive) appear
# anywhere in the chunk, the query is exempt from qt_user_id entirely,
# regardless of which table(s) it touches (or whether any table was even
# recognized). Covers queries that aren't user-data at all, e.g. date-only
# calculations or generic country/reference lookups. Add more as needed.
QT_USER_ID_EXEMPT_KEYWORDS = [
    "datediff",
    "noofdays",
    "country_name",
    "country_cd",
]

OLTPRO_DATE_FUNCTION_RE = re.compile(r"\b(?:DATEADD|DATEDIFF)\s*\(", re.IGNORECASE)
OLTPRO_GROUP_BY_RE = re.compile(r"\bGROUP\s+BY\b", re.IGNORECASE)


def _qt_user_id_content_is_exempt(chunk_text: str) -> bool:
    t = chunk_text.lower()
    return any(kw.lower() in t for kw in QT_USER_ID_EXEMPT_KEYWORDS)


QT_USER_ID_MISSING_SKIP_FILES = [
    "ti123.php",
]

WHERE_BARE_VARIABLE_RE = re.compile(r"^\s*\$([A-Za-z_][A-Za-z0-9_]*)\s*$")
WHERE_BARE_VARIABLE_ISSUE_NAMES = {"qt_user_id", "bak_qt_user_id"}


def _where_starts_with_bare_variable(raw_query: List[str], chunk_text: str) -> bool:
    query_texts = [str(query) for query in raw_query if str(query).strip()]
    reconstructed = _reconstruct_query_text(chunk_text)
    if reconstructed and reconstructed not in query_texts:
        query_texts.append(reconstructed)
    for query_text in query_texts:
        conditions = _extract_where_conditions_from_query_text(query_text)
        if not conditions:
            continue
        m = WHERE_BARE_VARIABLE_RE.match(conditions[0])
        if m and m.group(1).lower() not in WHERE_BARE_VARIABLE_ISSUE_NAMES:
            return True
    return False


def _qt_user_id_missing_file_is_skipped(rec: Dict) -> bool:
    skip = {name.lower() for name in QT_USER_ID_MISSING_SKIP_FILES}
    for value in (rec.get("file"), rec.get("file_path")):
        if not value:
            continue
        base = str(value).replace("\\", "/").rsplit("/", 1)[-1].strip().lower()
        if base in skip:
            return True
    return False


def _is_oltpro_folder(folder: str) -> bool:
    return str(folder).strip().lower() == "oltpro"


def _qt_user_id_table_exemption(table: str) -> Optional[str]:
    """Classifies a table:
    - "reference"  -- always exempt (QT_USER_ID_ALWAYS_EXEMPT_TABLES), no user-scoping expected at all.
    - "ownership"  -- exempt from qt_user_id specifically, but still needs an ownership-column stand-in.
    - None         -- not exempt; qt_user_id is required.
    """
    t = table.lower()

    def _matches(entries):
        for entry in entries:
            e = entry.strip().lower()
            if (
                (e.startswith("*") and t.endswith(e[1:]))
                or (e.endswith("*") and t.startswith(e[:-1]))
                or (e.endswith("_") and t.startswith(e))
                or (not e.startswith("*") and not e.endswith(("*", "_")) and t == e)
            ):
                return True
        return False

    if _matches(QT_USER_ID_ALWAYS_EXEMPT_TABLES):
        return "reference"
    if _matches(QT_USER_ID_OWNERSHIP_EXEMPT_TABLES):
        return "ownership"
    return None


def _qt_user_id_tables_exemption(tables: List[str]) -> Optional[str]:
    """Same classification as _qt_user_id_table_exemption, but for every table a query touches.
    Only exempt if EVERY touched table is exempt; "reference" only if ALL are always-exempt
    tables, otherwise "ownership" (i.e. at least one table needs the ownership-column stand-in).
    Returns None (not exempt / qt_user_id required) if any touched table isn't exempt at all.
    """
    if not tables:
        return None
    kinds = [_qt_user_id_table_exemption(t) for t in tables]
    if any(k is None for k in kinds):
        return None
    return "reference" if all(k == "reference" for k in kinds) else "ownership"


def _auth_access_scope_applies_to_tables(tables: List[str]) -> bool:
    """Allow auth_access ownership scope alongside only always-exempt tables."""
    normalized_tables = {str(table).strip().lower() for table in tables}
    return "auth_access" in normalized_tables and all(
        table == "auth_access" or _qt_user_id_table_exemption(table) == "reference"
        for table in normalized_tables
    )


def _chunk_has_dynamic_table(raw_query: List[str], chunk_text: str) -> bool:
    return any(DYNAMIC_TABLE_RE.search(str(query)) for query in raw_query) or bool(
        DYNAMIC_TABLE_RE.search(chunk_text)
    )


def _chunk_has_malformed_where_boundary(raw_query: List[str], chunk_text: str) -> bool:
    """Return True when WHERE is glued to the following identifier."""
    reconstructed = _reconstruct_query_text(chunk_text)
    # Prefer source-backed reconstruction when available. Persisted raw_query
    # may have been produced by an older scanner that stripped a significant
    # leading space from a conditional append (``where`` + `` field``).
    query_texts = (
        [reconstructed]
        if reconstructed
        else [str(query) for query in raw_query if str(query).strip()]
    )
    for query in query_texts:
        source = re.search(r"\b(?:FROM|UPDATE|DELETE\s+FROM)\b", query, re.IGNORECASE)
        if source and MALFORMED_WHERE_BOUNDARY_RE.search(query, source.end()):
            return True
    return False


def _chunk_is_insert(rec: Dict) -> bool:
    query_types = {str(item).upper() for item in (rec.get("query_type") or [])}
    if "INSERT" in query_types:
        return True
    return any(
        re.search(r"\bINSERT\s+INTO\b", str(query), re.IGNORECASE)
        for query in (rec.get("raw_query") or [])
    )


@lru_cache(maxsize=4096)
def _schema_has_qt_user_id(taxyear: str, table: str) -> bool:
    """Return whether the table schema declares SQLTYPE_<TABLE>_QT_USER_ID."""
    table = str(table).strip()
    year = str(taxyear).strip()
    if not table or not year:
        return False

    short_year = year[-2:] if year.isdigit() and len(year) == 4 else year
    schema_directory = SCHEMA_ROOT / f"{short_year}CLIENT"
    schema_file = schema_directory / table[0].upper() / f"{table}.php"
    if not schema_file.is_file() and schema_file.parent.is_dir():
        schema_file = next(
            (
                item
                for item in schema_file.parent.iterdir()
                if item.is_file() and item.name.lower() == f"{table}.php".lower()
            ),
            schema_file,
        )
    if not schema_file.is_file():
        return False

    schema_text = schema_file.read_text(encoding="utf-8", errors="ignore")
    global_name = f"SQLTYPE_{table}_QT_USER_ID"
    return bool(re.search(
        rf'["\']{re.escape(global_name)}["\']\s*\]\s*=\s*["\']',
        schema_text,
        re.IGNORECASE,
    ))


def _qt_user_id_missing_chunks(
    records: List[Dict], taxyear: str = "", folder: str = ""
) -> List[Dict]:
    issues: List[Dict] = []
    for rec in records:
        if _chunk_is_insert(rec):
            continue

        if _qt_user_id_missing_file_is_skipped(rec):
            continue  

        raw_query = rec.get("raw_query") or []
        tables = _query_tables(raw_query)
        chunk_text = rec.get("chunk_text") or ""

        exemption = _qt_user_id_tables_exemption(tables)

        if exemption == "reference":
            continue  # ref_ and other pure reference tables never require qt_user_id

        # A glued token such as ``whereqt_user_id`` is not a valid WHERE clause.
        # Report it as missing even when dynamic table names prevent a schema lookup.
        if (
            _chunk_has_malformed_where_boundary(raw_query, chunk_text)
            and not _qt_user_id_is_in_where(raw_query, chunk_text)
            and not _oltpro_master_id_is_in_where(raw_query, chunk_text)
        ):
            issues.append({
                "file": rec.get("file"),
                "file_path": rec.get("file_path"),
                "start_line": rec.get("start_line"),
                "end_line": rec.get("end_line"),
                "query_type": rec.get("query_type") or [],
                "tables": sorted(tables),
                "raw_query": raw_query,
                "chunk_text": chunk_text,
            })
            continue

        if _chunk_has_dynamic_table(raw_query, chunk_text):
            continue  # dynamic table names are deferred until they can be resolved

        if any("_trans_" in str(table).lower() for table in tables):
            continue  # transaction-family tables are excluded from the missing check

        if _qt_user_id_content_is_exempt(chunk_text):
            continue  # chunk text matches an exempt keyword (datediff, country_name, ...) -- not user data

        if _is_oltpro_folder(folder) and OLTPRO_DATE_FUNCTION_RE.search(chunk_text):
            continue  # OLTPRO date-calculation queries are not user-owned data lookups

        if _is_oltpro_folder(folder) and _oltpro_has_group_by(raw_query, chunk_text):
            continue  # grouped OLTPRO queries are excluded from the missing check

        if _oltpro_master_id_is_in_where(raw_query, chunk_text):
            continue  # OLTPRO_masterID is an accepted ownership key
        if _where_starts_with_bare_variable(raw_query, chunk_text):
            continue  
        if (
            _is_oltpro_folder(folder)
            and _oltpro_alternative_scope_is_in_where(tables, raw_query, chunk_text)
        ):
            continue  # OLTPRO table families use their own accepted ownership keys
        if (
            tables
            and all(table.startswith("amended_") for table in tables)
            and _amended_user_id_is_in_where(raw_query, chunk_text)
        ):
            continue  # amended_* tables accept bak_, prev_, or regular qt_user_id
        if exemption == "ownership":
            if _ownership_scope_is_in_where(raw_query, chunk_text):
                continue  # ownership-exempt table is scoped by qt_user_id or user_name in WHERE
            if (
                _auth_access_scope_applies_to_tables(tables)
                and _auth_access_indexval1_is_in_where(raw_query, chunk_text)
            ):
                continue  # auth_access may instead be scoped by Indexval1
            if tables == {"master_auth"} and _master_auth_id_is_in_where(raw_query, chunk_text):
                continue  # master_auth may instead be scoped by mast_auth_id
        elif _qt_user_id_is_in_where(raw_query, chunk_text):
            continue  # qt_user_id scopes this query in WHERE (may still be "rearranged")

        if not any(_schema_has_qt_user_id(taxyear, table) for table in tables):
            continue  # no resolved table schema declares qt_user_id

        issues.append({
            "file": rec.get("file"),
            "file_path": rec.get("file_path"),
            "start_line": rec.get("start_line"),
            "end_line": rec.get("end_line"),
            "query_type": rec.get("query_type") or [],
            "tables": sorted(tables),
            "raw_query": rec.get("raw_query") or [],
            "chunk_text": chunk_text,
        })
    return issues


# ---------------------------------------------------------------------------
# WHERE-clause text extraction for the "rearranged" check.
#
# Chunks build SQL by concatenating PHP string literals onto a query
# variable, e.g.:
#     $query  = "delete from w2 where ";
#     $query .= "w2_id=(?) ";
#     $query .= "and qt_user_id=(?) ";
# or, without any params array at all:
#     $check_query = "Select qt_user_id from $table_name where qt_user_id=$qt_user_id";
#
# We reconstruct the query text by concatenating (in source order) every
# string literal assigned/appended to a variable whose name looks like a
# query variable (contains "query" or "sql"), then isolate the WHERE clause
# and split it into top-level conditions (respecting parentheses) to
# determine which condition comes first.
# ---------------------------------------------------------------------------

_QUERY_VAR_NAME_RE = re.compile(
    r"(query|sql|qry|update|insert|delete)", re.IGNORECASE
)

# Start of a statement that assigns/appends onto a query-looking variable,
# e.g. "$query =" / "$query_ai .=" / "$queryclause[0] .=". Matched against
# each ';'-delimited statement, not the whole chunk -- see _reconstruct_query_text.
_QUERY_ASSIGNMENT_START_RE = re.compile(
    r"(?:^|[\r\n])\s*\$(\w+)(?:\[[^\]]*\])?\s*(?:\.=|=)\s*"
)

# Any quoted-string literal, used to pull ALL literals out of a matched
# statement -- not just the one immediately after '=', so that chains like
# `$var = "SET " . $dynamic . " WHERE";` capture both "SET " and " WHERE".
_STRING_LITERAL_RE = re.compile(
    r"\"((?:[^\"\\]|\\.)*)\"|'((?:[^'\\]|\\.)*)'"
)

_TRAILING_CLAUSE_RE = re.compile(
    r"\b(order\s+by|group\s+by|having|limit)\b", re.IGNORECASE
)
WHERE_START_RE = re.compile(
    r"\bWHERE\b|where(?=\s+(?:[A-Za-z_][A-Za-z0-9_]*\.)?[A-Za-z_])",
    re.IGNORECASE,
)


def _reconstruct_query_text(chunk_text: str) -> Optional[str]:
    """Concatenates (in source order) every quoted-string literal found in a PHP
    statement that assigns/appends onto a query-looking variable ($query, $query_ai,
    $actionsql, $check_query, ...). Statements are split naively on ';', which is
    fine here since these are single-line PHP assignment statements. A statement
    like `$var = "a" . $x . "b";` contributes both "a" and "b", in order, so
    multi-literal concatenations (e.g. a dynamic SET clause sandwiched between two
    literal fragments) are still captured correctly. Returns None if no
    query-variable assignment statement was found at all.
    """
    parts: List[str] = []
    found_any = False
    for statement in chunk_text.split(";"):
        m = _QUERY_ASSIGNMENT_START_RE.search(statement)
        if not m:
            continue
        var_name = m.group(1)
        if not _QUERY_VAR_NAME_RE.search(var_name):
            continue
        found_any = True
        for lit_m in _STRING_LITERAL_RE.finditer(statement, m.end()):
            literal = lit_m.group(1) if lit_m.group(1) is not None else lit_m.group(2)
            parts.append(literal)
    if not found_any:
        return None
    return "".join(parts)


def _extract_where_conditions(chunk_text: str) -> Optional[List[str]]:
    """Reconstructs the query text and returns its WHERE-clause conditions, in
    left-to-right order, splitting on top-level AND/OR (i.e. not inside parens).
    Returns None if a WHERE clause couldn't be confidently extracted, so callers
    can fall back to another method rather than guessing.
    """
    query_text = _reconstruct_query_text(chunk_text)
    if query_text is None:
        return None

    return _extract_where_conditions_from_query_text(query_text)


def _extract_where_conditions_from_query_text(query_text: str) -> Optional[List[str]]:
    """Extract top-level WHERE conditions from already reconstructed SQL text."""

    # Use the last top-level WHERE. A plain last-match lookup incorrectly picks
    # a nested subquery WHERE (for example NOT EXISTS (... WHERE ...)) and then
    # loses the outer ownership condition that precedes the subquery.
    matches = []
    depth = 0
    quote = ""
    escaped = False
    for index, character in enumerate(query_text):
        if escaped:
            escaped = False
            continue
        if quote:
            if character == "\\":
                escaped = True
            elif character == quote:
                quote = ""
            continue
        if character in {"'", '"'}:
            quote = character
            continue
        if character == "(":
            depth += 1
            continue
        if character == ")":
            depth = max(0, depth - 1)
            continue
        if depth == 0:
            match = WHERE_START_RE.match(query_text, index)
            if match:
                matches.append(match)
    if not matches:
        return None
    where_text = query_text[matches[-1].end():]

    # Cut off any trailing ORDER BY / GROUP BY / HAVING / LIMIT clause.
    trailing = _TRAILING_CLAUSE_RE.search(where_text)
    if trailing:
        where_text = where_text[: trailing.start()]

    where_text = where_text.strip()
    if not where_text:
        return None

    return _split_top_level_conditions(where_text)


def _ownership_scope_is_in_where(raw_query: List[str], chunk_text: str) -> bool:
    """Ownership-exempt tables require exact qt_user_id or user_name WHERE columns."""
    query_texts = [str(query) for query in raw_query if str(query).strip()]
    reconstructed = _reconstruct_query_text(chunk_text)
    if reconstructed and reconstructed not in query_texts:
        query_texts.append(reconstructed)

    return any(
        any(OWNERSHIP_WHERE_COLUMN_RE.search(condition) for condition in conditions)
        for query_text in query_texts
        for conditions in [_extract_where_conditions_from_query_text(query_text)]
        if conditions
    )


def _qt_user_id_is_in_where(raw_query: List[str], chunk_text: str) -> bool:
    """Find compared qt_user_id columns after outer WHERE or INNER JOIN."""
    query_texts = [str(query) for query in raw_query if str(query).strip()]
    if len(query_texts) > 1 and any(
        re.match(r"^\s*<dynamic(?:_fields|_values)?>", query)
        for query in query_texts[1:]
    ):
        joined_query = " ".join(
            re.sub(r"^\s*<dynamic(?:_fields|_values)?>\s*", "", query)
            for query in query_texts
        )
        if joined_query not in query_texts:
            query_texts.append(joined_query)
    reconstructed = _reconstruct_query_text(chunk_text)
    if reconstructed and reconstructed not in query_texts:
        query_texts.append(reconstructed)

    for query_text in query_texts:
        where = WHERE_START_RE.search(query_text)
        if where and QT_USER_ID_WHERE_COLUMN_RE.search(query_text[where.end():]):
            return True
        inner_join = re.search(r"\bINNER\s+JOIN\b", query_text, re.IGNORECASE)
        if inner_join and QT_USER_ID_WHERE_COLUMN_RE.search(query_text[inner_join.end():]):
            return True
    return False


def _master_auth_id_is_in_where(raw_query: List[str], chunk_text: str) -> bool:
    """Allow master_auth queries scoped by mast_auth_id in WHERE."""
    query_texts = [str(query) for query in raw_query if str(query).strip()]
    reconstructed = _reconstruct_query_text(chunk_text)
    if reconstructed and reconstructed not in query_texts:
        query_texts.append(reconstructed)

    for query_text in query_texts:
        where = WHERE_START_RE.search(query_text)
        if where and MASTER_AUTH_ID_WHERE_COLUMN_RE.search(query_text[where.end():]):
            return True
    return False


def _accepted_column_is_in_where(
    raw_query: List[str], chunk_text: str, column_re: re.Pattern
) -> bool:
    query_texts = [str(query) for query in raw_query if str(query).strip()]
    reconstructed = _reconstruct_query_text(chunk_text)
    if reconstructed and reconstructed not in query_texts:
        query_texts.append(reconstructed)

    for query_text in query_texts:
        where = WHERE_START_RE.search(query_text)
        if where and column_re.search(query_text[where.end():]):
            return True
    return False


def _oltpro_master_id_is_in_where(raw_query: List[str], chunk_text: str) -> bool:
    return _accepted_column_is_in_where(
        raw_query, chunk_text, OLTPRO_MASTER_ID_WHERE_COLUMN_RE
    )


def _oltpro_alternative_scope_is_in_where(
    tables: List[str], raw_query: List[str], chunk_text: str
) -> bool:
    """Accept the ownership key associated with specific OLTPRO table families."""
    normalized_tables = {str(table).strip().lower() for table in tables}
    accepted_columns = []
    if "oltpro_firm_info" in normalized_tables:
        accepted_columns.append(OLTPRO_FIRM_EFIN_WHERE_COLUMN_RE)
    if any(table.startswith("mo_") for table in normalized_tables):
        accepted_columns.append(MO_MASTER_ID_WHERE_COLUMN_RE)
    if any(table.startswith("dt_") for table in normalized_tables):
        accepted_columns.append(OLT_DT_USER_ID_WHERE_COLUMN_RE)

    return any(
        _accepted_column_is_in_where(raw_query, chunk_text, column_re)
        for column_re in accepted_columns
    )


def _oltpro_has_group_by(raw_query: List[str], chunk_text: str) -> bool:
    """Return whether an OLTPRO query has an explicit GROUP BY clause."""
    query_texts = [str(query) for query in raw_query if str(query).strip()]
    reconstructed = _reconstruct_query_text(chunk_text)
    if reconstructed and reconstructed not in query_texts:
        query_texts.append(reconstructed)
    return any(OLTPRO_GROUP_BY_RE.search(query) for query in query_texts)


def _amended_user_id_is_in_where(raw_query: List[str], chunk_text: str) -> bool:
    return _accepted_column_is_in_where(
        raw_query, chunk_text, AMENDED_USER_ID_WHERE_COLUMN_RE
    )


def _auth_access_indexval1_is_in_where(raw_query: List[str], chunk_text: str) -> bool:
    """Return whether one SQL statement scopes auth_access by Indexval1."""
    query_texts = [str(query) for query in raw_query if str(query).strip()]
    reconstructed = _reconstruct_query_text(chunk_text)
    if reconstructed and reconstructed not in query_texts:
        query_texts.append(reconstructed)

    for query_text in query_texts:
        conditions = _extract_where_conditions_from_query_text(query_text)
        if not conditions:
            continue
        if any(AUTH_ACCESS_INDEXVAL1_RE.search(condition) for condition in conditions):
            return True
    return False


def _split_top_level_conditions(where_text: str) -> List[str]:
    """Splits a WHERE-clause string into its individual conditions on top-level
    AND/OR (i.e. not inside parentheses), preserving left-to-right order.
    """
    tokens = re.split(r"(\(|\)|\bAND\b|\bOR\b)", where_text, flags=re.IGNORECASE)
    conditions: List[str] = []
    depth = 0
    buf = ""
    for tok in tokens:
        if tok is None or tok == "":
            continue
        if tok == "(":
            depth += 1
            buf += tok
            continue
        if tok == ")":
            depth -= 1
            buf += tok
            continue
        if depth == 0 and re.fullmatch(r"and|or", tok, re.IGNORECASE):
            stripped = buf.strip()
            if stripped:
                conditions.append(stripped)
            buf = ""
            continue
        buf += tok
    stripped = buf.strip()
    if stripped:
        conditions.append(stripped)
    return conditions


def _mixed_reference_query_has_scoped_non_reference_subquery(
    raw_query: List[str], tables: Set[str], relevant_tables: Optional[Set[str]] = None
) -> bool:
    """Ignore outer predicates from disregarded tables when the remaining tables
    are independently scoped at the start of their nested WHERE clauses.

    Example: an outer ``state_zip`` lookup can contain a subquery against a
    user-owned table.  Conditions belonging to exempt ``state_zip`` must not
    make the nested table's first ``qt_user_id`` predicate look rearranged. The
    caller may also disregard tables whose schema has no ``qt_user_id`` column.
    """
    if relevant_tables is None:
        relevant_tables = {
            table for table in tables
            if _qt_user_id_table_exemption(table) != "reference"
        }
    if not relevant_tables or len(relevant_tables) == len(tables):
        return False

    scoped_tables: Set[str] = set()
    for query in raw_query:
        text = str(query)
        for table in relevant_tables:
            table_re = re.compile(
                rf"\bFROM\s+(?:[A-Za-z_][A-Za-z0-9_]*\.)*{re.escape(table)}\b",
                re.IGNORECASE,
            )
            for table_match in table_re.finditer(text):
                # This exception is specifically for a nested SELECT. An outer
                # table must continue through the normal whole-WHERE ordering.
                nesting_depth = (
                    text.count("(", 0, table_match.start())
                    - text.count(")", 0, table_match.start())
                )
                if nesting_depth <= 0:
                    continue
                where_match = WHERE_START_RE.search(text, table_match.end())
                if not where_match:
                    continue
                depth = nesting_depth
                close = len(text)
                for index in range(where_match.end(), len(text)):
                    if text[index] == "(":
                        depth += 1
                    elif text[index] == ")":
                        depth -= 1
                        if depth < nesting_depth:
                            close = index
                            break
                nested_where = text[where_match.end():close]
                conditions = _split_top_level_conditions(nested_where)
                if not conditions:
                    continue
                exemption = _qt_user_id_table_exemption(table)
                scope_idx, _scope_var, _owner_mode = _first_scope_condition_index(
                    conditions, exemption
                )
                if scope_idx == 0:
                    scoped_tables.add(table)
                    break

    return scoped_tables == relevant_tables


def _condition_without_nested_expressions(condition: str) -> str:
    """Return only the top-level text of a WHERE condition.

    This lets rearranged analysis distinguish an outer ownership predicate from
    one that belongs to a nested SELECT, without consulting table schemas.
    """
    result: List[str] = []
    depth = 0
    quote = ""
    escaped = False
    for character in condition:
        if escaped:
            escaped = False
            if depth == 0:
                result.append(character)
            continue
        if quote:
            if character == "\\":
                escaped = True
            elif character == quote:
                quote = ""
            if depth == 0:
                result.append(character)
            continue
        if character in {"'", '"'}:
            quote = character
            if depth == 0:
                result.append(character)
        elif character == "(":
            depth += 1
        elif character == ")":
            depth = max(0, depth - 1)
        elif depth == 0:
            result.append(character)
    return "".join(result)


def _query_has_nested_scope_first(raw_query: List[str]) -> bool:
    """Return True when ownership exists only in nested WHERE clauses and is
    the first condition in every such clause.

    Outer lookup predicates must not make a correctly scoped nested query look
    rearranged. This is derived from SQL structure and therefore needs no schema
    file reads.
    """
    found_scope = False
    for query in raw_query:
        text = str(query)
        for where_match in WHERE_START_RE.finditer(text):
            nesting_depth = (
                text.count("(", 0, where_match.start())
                - text.count(")", 0, where_match.start())
            )
            if nesting_depth <= 0:
                continue
            depth = nesting_depth
            close = len(text)
            for index in range(where_match.end(), len(text)):
                if text[index] == "(":
                    depth += 1
                elif text[index] == ")":
                    depth -= 1
                    if depth < nesting_depth:
                        close = index
                        break
            conditions = _split_top_level_conditions(text[where_match.end():close])
            scope_idx, _scope_var, _owner_mode = _first_scope_condition_index(
                conditions, None
            )
            if scope_idx is None:
                continue
            found_scope = True
            if scope_idx != 0:
                return False
    return found_scope


def _qt_user_id_rearranged_chunks(
    records: List[Dict], taxyear: str = ""
) -> List[Dict]:
    issues: List[Dict] = []
    for rec in records:
        if _chunk_is_insert(rec):
            continue

        raw_query = rec.get("raw_query") or []
        tables = _query_tables(raw_query)
        chunk_text = rec.get("chunk_text") or ""

        if _chunk_has_dynamic_table(raw_query, chunk_text):
            continue  # dynamic table names are deferred until they can be resolved

        if _qt_user_id_content_is_exempt(chunk_text):
            continue  # chunk text matches an exempt keyword (datediff, country_name, ...) -- not user data
        exemption = _qt_user_id_tables_exemption(tables)

        conditions = _extract_where_conditions(chunk_text)
        if conditions is None:
            conditions = next(
                (
                    extracted
                    for query in raw_query
                    for extracted in [
                        _extract_where_conditions_from_query_text(str(query))
                    ]
                    if extracted is not None
                ),
                None,
            )

        where_has_user_id = bool(
            conditions
            and any(
                QT_USER_ID_WHERE_COLUMN_RE.search(condition)
                or OLTPRO_MASTER_ID_WHERE_COLUMN_RE.search(condition)
                for condition in conditions
            )
        )
        relevant_tables = {
            table
            for table in tables
            if _qt_user_id_table_exemption(table) != "reference"
            and (
                where_has_user_id
                or not taxyear
                or _schema_has_qt_user_id(taxyear, table)
            )
        }
        if not where_has_user_id and taxyear and not relevant_tables:
            continue  # only queries without a user ID need schema discovery

        if _mixed_reference_query_has_scoped_non_reference_subquery(
            raw_query, tables, relevant_tables
        ):
            continue

        if conditions is not None:
            order_source = "where_text"
            direct_conditions = [
                _condition_without_nested_expressions(condition)
                for condition in conditions
            ]
            if (
                direct_conditions
                and any(table.lower().startswith("mo_") for table in tables)
                and MO_MASTER_ID_WHERE_COLUMN_RE.search(direct_conditions[0])
            ):
                continue  # MO tables may use MO_masterID as their first ownership key
            direct_scope_idx, _direct_scope_var, _direct_owner_mode = (
                _first_scope_condition_index(direct_conditions, exemption)
            )
            if direct_scope_idx is None and _query_has_nested_scope_first(raw_query):
                continue
            has_oltpro_master_id = any(
                OLTPRO_MASTER_ID_WHERE_COLUMN_RE.search(condition)
                for condition in conditions
            )
            if (
                conditions
                and not has_oltpro_master_id
                and ACC_USER_ID_WHERE_COLUMN_RE.search(conditions[0])
            ):
                continue  # acc_user_id is an accepted first ownership condition
            scope_idx, scope_var, owner_mode = _first_scope_condition_index(conditions, exemption)
        else:
            # Couldn't confidently reconstruct the WHERE clause text (e.g. no
            # recognizable query-building fragments in this chunk) -- fall back
            # to inferring order from param bind order, as before.
            order_source = "params_fallback"
            scope_idx, scope_var, owner_mode = _first_scope_param_index(rec.get("params") or [], exemption)

        if scope_idx is None:
            continue  # no qt_user_id (or, for ownership-exempt tables, no stand-in) found to judge order on
        if scope_idx == 0:
            continue  # bound/checked first, as expected

        # Same table-exemption logic as the "missing" check -- if this query's tables are
        # exempt AND already carry a valid ownership-column stand-in (or are pure reference
        # tables), a late/secondary qt_user_id doesn't matter, since scoping is already
        # handled another way -- UNLESS the thing we actually matched on was itself the
        # ownership stand-in (owner_mode), in which case its own position is what we're
        # judging, and it already came back non-zero above.
        if not owner_mode and (exemption == "reference" or (exemption == "ownership" and OWNERSHIP_COLUMN_RE.search(chunk_text))):
            continue

        if conditions is not None:
            bound_before = conditions[:scope_idx]
        else:
            bound_before = [p.get("var") for p in (rec.get("params") or [])[:scope_idx]]

        issues.append({
            "file": rec.get("file"),
            "file_path": rec.get("file_path"),
            "start_line": rec.get("start_line"),
            "end_line": rec.get("end_line"),
            "query_type": rec.get("query_type") or [],
            "tables": sorted(tables),
            "raw_query": rec.get("raw_query") or [],
            "chunk_text": chunk_text,
            "scope_var": scope_var,
            "bound_before_qt_user_id": bound_before,
            "order_source": order_source,
        })
    return issues


def _first_scope_condition_index(
    conditions: List[str], exemption: Optional[str]
) -> Tuple[Optional[int], Optional[str], bool]:
    """Find the condition that must be first.

    OLTPRO_masterID has priority whenever present. Otherwise qt_user_id is checked,
    followed by an ownership-column stand-in for ownership-exempt tables. The boolean
    result is true for an alternative priority scope so table exemptions do not hide
    its position. index is None when there is no applicable scope to judge.
    """
    oltpro_master_idx = next(
        (
            i
            for i, condition in enumerate(conditions)
            if OLTPRO_MASTER_ID_WHERE_COLUMN_RE.search(condition)
        ),
        None,
    )
    if oltpro_master_idx is not None:
        return oltpro_master_idx, conditions[oltpro_master_idx], True

    qt_idx = next((i for i, c in enumerate(conditions) if re.search(r"\bqt_user_id\b", c, re.IGNORECASE)), None)
    if qt_idx is not None:
        return qt_idx, conditions[qt_idx], False

    if exemption == "ownership":
        owner_idx = next((i for i, c in enumerate(conditions) if OWNERSHIP_VAR_RE.search(c)), None)
        if owner_idx is not None:
            return owner_idx, conditions[owner_idx], True

    return None, None, False


def _first_scope_param_index(
    params: List[Dict], exemption: Optional[str]
) -> Tuple[Optional[int], Optional[str], bool]:
    """Fallback used only when WHERE-clause text couldn't be reconstructed: infers
    order from param bind order, same semantics as _first_scope_condition_index.
    """
    if not params:
        return None, None, False

    oltpro_master_positions = [
        i
        for i, param in enumerate(params)
        if "oltpro_masterid" in (param.get("var") or "").lower()
    ]
    if oltpro_master_positions:
        idx = oltpro_master_positions[0]
        return idx, params[idx].get("var"), True

    qt_positions = [i for i, p in enumerate(params) if "qt_user_id" in (p.get("var") or "").lower()]
    if qt_positions:
        idx = qt_positions[0]
        return idx, params[idx].get("var"), False

    if exemption == "ownership":
        owner_positions = [i for i, p in enumerate(params) if OWNERSHIP_VAR_RE.search(p.get("var") or "")]
        if owner_positions:
            idx = owner_positions[0]
            return idx, params[idx].get("var"), True

    return None, None, False


# efile-only gate 
EFILE_METHOD_GATE_FOLDER = "efile"
EFILE_METHOD_GATE_VALUE = "COMMON"


def _load_efile_common_files(taxyear: str) -> frozenset:
    """File keys (relative file_name and base_name, lowercased) whose method
    in the efile folder's Qdrant store is "Common". Returns an empty
    frozenset (nothing passes the gate) if the store can't be loaded.
    """
    try:
        from php_flow_scanner import load_qdrant_store
        records = load_qdrant_store(str(taxyear), EFILE_METHOD_GATE_FOLDER).get("records", [])
    except Exception:
        return frozenset()

    keys: Set[str] = set()
    for record in records:
        method = str(record.get("method", "")).strip().upper()
        if method != EFILE_METHOD_GATE_VALUE:
            continue
        file_name = str(record.get("file_name") or "").replace("\\", "/").strip().lower()
        base_name = str(record.get("base_name") or "").replace("\\", "/").strip().lower()
        if file_name:
            keys.add(file_name)
            keys.add(file_name.rsplit("/", 1)[-1])
        if base_name:
            keys.add(base_name)
            keys.add(base_name.rsplit("/", 1)[-1])
    return frozenset(keys)


def _chunk_file_keys(chunk: Dict) -> Set[str]:
    keys: Set[str] = set()
    for value in (chunk.get("file"), chunk.get("file_path")):
        if not value:
            continue
        normalized = str(value).replace("\\", "/").strip().lower()
        keys.add(normalized)
        keys.add(normalized.rsplit("/", 1)[-1])
    return keys


def _filter_to_efile_common(chunks: List[Dict], taxyear: str) -> List[Dict]:
    common_files = _load_efile_common_files(taxyear)
    if not common_files:
        return []
    return [chunk for chunk in chunks if _chunk_file_keys(chunk) & common_files]


# base - dedicated logic (acc_) and existing logic

BASE_TAX_YEAR = "base"

BASE_ACC_OWNER_RE = re.compile(
    r"(?<![$\w])(?:[A-Za-z_][A-Za-z0-9_]*\.)?(?:acc_user_id|acc_user_name)\b"
    r"\s*(?:=|<>|!=|<=|>=|<|>|\bIN\b|\bIS\b|\bLIKE\b)",
    re.IGNORECASE,
)
BASE_ACC_TABLE_RE = re.compile(
    r"\b(?:FROM|JOIN|UPDATE|INTO)\s+(?:\{\s*)?(?:[A-Za-z_][A-Za-z0-9_]*\.)*"
    r"(acc_[A-Za-z0-9_]*)",
    re.IGNORECASE,
)
BASE_STATEMENT_SPLIT_RE = re.compile(
    r"(?<=\))\s*(?=(?:SELECT|UPDATE|DELETE|INSERT)\b)", re.IGNORECASE
)


def _is_base_taxyear(taxyear: str) -> bool:
    return str(taxyear).strip().lower() == BASE_TAX_YEAR


def _base_statements(rec: Dict) -> List[str]:
    pieces: List[str] = []
    for q in rec.get("raw_query") or []:
        q = str(q)
        if not q.strip():
            continue
        if re.match(r"^\s*<dynamic(?:_fields|_values)?>", q) and pieces:
            pieces[-1] += " " + re.sub(r"^\s*<dynamic(?:_fields|_values)?>\s*", "", q)
        else:
            pieces.append(q)
    if not pieces:
        rebuilt = _reconstruct_query_text(rec.get("chunk_text") or "")
        if rebuilt:
            pieces.append(rebuilt)
    statements: List[str] = []
    for piece in pieces:
        statements.extend(s for s in BASE_STATEMENT_SPLIT_RE.split(piece) if s.strip())
    return statements


BASE_SCOPE_STOP_RE = re.compile(
    r"(?:UNION|SELECT|ORDER\s+BY|GROUP\s+BY|HAVING|LIMIT)\b", re.IGNORECASE
)


def _base_at_word_start(text: str, i: int) -> bool:
    return i == 0 or not (text[i - 1].isalnum() or text[i - 1] in "_$")


def _base_table_states(statement: str) -> List[Tuple[str, Optional[str]]]:
    results: List[Tuple[str, Optional[str]]] = []
    for m in BASE_ACC_TABLE_RE.finditer(statement):
        table = m.group(1).lower()

        # WHERE belonging to this table: same depth, before the level closes
        where = None
        depth = 0
        for i in range(m.end(), len(statement)):
            ch = statement[i]
            if ch == "(":
                depth += 1
            elif ch == ")":
                depth -= 1
                if depth < 0:
                    break
            elif depth == 0 and _base_at_word_start(statement, i):
                w = WHERE_START_RE.match(statement, i)
                if w:
                    where = w
                    break
                if BASE_SCOPE_STOP_RE.match(statement, i):
                    break
        if where is None:
            results.append((table, "missing"))
            continue

        # end of that WHERE clause
        scope_end = len(statement)
        depth = 0
        for j in range(where.end(), len(statement)):
            ch = statement[j]
            if ch == "(":
                depth += 1
            elif ch == ")":
                depth -= 1
                if depth < 0:
                    scope_end = j
                    break
            elif depth == 0 and _base_at_word_start(statement, j) and BASE_SCOPE_STOP_RE.match(statement, j):
                scope_end = j
                break

        conditions = _split_top_level_conditions(statement[where.end():scope_end].strip())
        if not conditions or not any(BASE_ACC_OWNER_RE.search(c) for c in conditions):
            results.append((table, "missing"))
        elif BASE_ACC_OWNER_RE.search(conditions[0]):
            results.append((table, None))
        else:
            results.append((table, "rearranged"))
    return results


def _base_acc_user_id_chunks(
    records: List[Dict], taxyear: str = "", folder: str = "", mode: str = "missing"
) -> List[Dict]:
    def existing_logic(recs: List[Dict]) -> List[Dict]:
        return (
            _qt_user_id_rearranged_chunks(recs, taxyear)
            if mode == "rearranged"
            else _qt_user_id_missing_chunks(recs, taxyear, folder)
        )

    issues: List[Dict] = []
    for rec in records:
        if _chunk_is_insert(rec):
            continue
        statements = _base_statements(rec)
        acc_statements = [s for s in statements if BASE_ACC_TABLE_RE.search(s)]

        if not acc_statements:
            issues.extend(existing_logic([rec]))  # no acc_ table: existing logic, untouched
            continue

        # acc_ statements -> dedicated logic
        hit_tables: Set[str] = set()
        for statement in acc_statements:
            for table, state in _base_table_states(statement):
                if state == mode:
                    hit_tables.add(table)

        # remaining (non-acc_) statements -> existing logic, evaluated on their own
        others = [
            dict(rec, raw_query=[s], chunk_text=s, params=[])
            for s in statements
            if not BASE_ACC_TABLE_RE.search(s)
        ]
        extra = existing_logic(others) if others else []
        for issue in extra:
            hit_tables.update(issue.get("tables") or [])

        if not hit_tables:
            continue
        issue = dict(extra[0]) if extra else {
            "file": rec.get("file"),
            "file_path": rec.get("file_path"),
            "start_line": rec.get("start_line"),
            "end_line": rec.get("end_line"),
            "query_type": rec.get("query_type") or [],
        }
        issue.update(
            tables=sorted(hit_tables),
            raw_query=rec.get("raw_query") or [],
            chunk_text=rec.get("chunk_text") or "",
        )
        issues.append(issue)
    return issues


def build_qt_user_id_analysis(taxyear: str, folder: Optional[str] = None, mode: str = "missing") -> List[Dict]:
    """One row per folder (reading the latest build's persisted metadata.json -- no rescan): total chunks checked and the list of chunks flagged by the selected qt_user_id check ("missing" or "rearranged")."""
    report: List[Dict] = []
    folders = [folder] if folder else sorted(_all_known_folders(taxyear))

    for folder_name in folders:
        doc = _read_folder_metadata(taxyear, folder_name)
        if not doc:
            continue

        records = doc.get("records", [])
        if _is_base_taxyear(taxyear):
            issues = _base_acc_user_id_chunks(records, taxyear, folder_name, mode)
        else:
            issues = (
                _qt_user_id_rearranged_chunks(records, taxyear)
                if mode == "rearranged"
                else _qt_user_id_missing_chunks(records, taxyear, folder_name)
            )

        if folder_name.lower() == EFILE_METHOD_GATE_FOLDER:
            issues = _filter_to_efile_common(issues, taxyear)

        report.append({
            "folder": folder_name,
            "total_chunks": len(records),
            "issue_count": len(issues),
            "issue_chunks": issues,
        })

    return report


def _shorten_site_asp_path(path: Optional[str]) -> str:
    if not path:
        return ""
    normalized = str(path).replace("/", "\\")
    marker = "\\site-asp\\"
    idx = normalized.lower().find(marker)
    return normalized[idx + len(marker):] if idx >= 0 else normalized


def _format_file_display(file: Optional[str], file_path: Optional[str]) -> str:
    if file_path:
        return "\\" + _shorten_site_asp_path(file_path)
    return file or "unknown"


def _format_line_range(start: Optional[int], end: Optional[int]) -> str:
    if start is None:
        return "\u2014"
    if end is not None and end != start:
        return f"{start}-{end}"
    return str(start)


def build_qt_user_id_export_rows(taxyear: str, folder: Optional[str] = None, mode: str = "missing") -> Tuple[List[str], List[List]]:
    columns = ["Folder", "File", "Line(s)", "Table(s)", "Reconstructed SQL"]
    rows: List[List] = []
    for entry in build_qt_user_id_analysis(taxyear, folder, mode):
        chunks = entry.get("issue_chunks") or []
        if not chunks:
            rows.append([entry["folder"],   "", "", "", ""])
            continue
        for chunk in chunks:
            rows.append([
                entry["folder"],
                _format_file_display(chunk.get("file"), chunk.get("file_path")),
                _format_line_range(chunk.get("start_line"), chunk.get("end_line")),
                ", ".join(chunk.get("tables") or []),
                " | ".join(str(q) for q in (chunk.get("raw_query") or [])),
            ])
    return columns, rows
