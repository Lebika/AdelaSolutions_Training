from pathlib import Path

folder = Path(r"/home/ads0905001/phpdata/site-asp/2025/oltproc/")  # Change this to your folder

file_count = sum(1 for f in folder.iterdir() if f.is_file())

print(f"Number of files: {file_count}")