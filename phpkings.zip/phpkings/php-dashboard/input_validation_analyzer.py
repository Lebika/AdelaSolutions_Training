"""Tree-sitter pilot for tracing values written through $_SQL_DataArray."""

from __future__ import annotations

import json
import re
from collections import defaultdict
from functools import lru_cache
from pathlib import Path
from typing import Callable, Dict, Iterable, List, Optional, Sequence, Tuple

from tree_sitter import Language, Node, Parser, Query, QueryCursor
import tree_sitter_php

from input_validation_overrides import HTML_FILE_OVERRIDES, TRUSTED_VALUE_FUNCTIONS
from php_flow_scanner import source_folder_path


SITE_ASP_ROOT = Path(r"E:\online-taxes\site-asp")
SQL_ROOT = Path(__file__).resolve().parents[2] / "phpdata" / "SQL"
PHP_LANGUAGE = Language(tree_sitter_php.language_php())
SQL_DATA_ARRAY_QUERY = Query(
    PHP_LANGUAGE,
    "(assignment_expression left: (subscript_expression) @left "
    "right: (array_creation_expression) @array) @assignment",
)
ASSIGNMENT_QUERY = Query(PHP_LANGUAGE, "(assignment_expression) @assignment")
FUNCTION_CALL_QUERY = Query(PHP_LANGUAGE, "(function_call_expression) @call")

UPDATE_TYPES = {"INSERT", "UPDATE"}
INTEGER_TYPES = ("BIGINT", "SMALLINT", "TINYINT", "INTEGER", "INT")
FLOAT_TYPES = ("MONEY", "FLOAT", "REAL")
SELECTION_INPUT_TYPES = {"checkbox", "checkboxwithlabel", "selectcombo", "combo", "radio"}
PHONE_VALIDATORS = {"isvalidphonenumber", "fmtnum"}
PHONE_FIELD_RE = re.compile(r"phone|area_?code|areacode", re.I)
ZERO_BYTE_HTML_REASON = "Need to 0kb the file, because input is 0kb"
GRAPH_VALIDATION_FUNCTIONS = (
    "udf_trim", "isnumeric", "isvalidvalue", "isvalidssn", "isvalidein",
    "udf_strlen", "fmtnamesp", "fmtnum", "formatname", "formatnameline1",
    "formataddress", "isvalidmonth", "isvalidday", "isvalidyearvalue",
    "isvaliddate", "fixnum", "isalphanumeric",
)
PHP_INCLUDE_RE = re.compile(
    r"\b(?:include|include_once|require|require_once)\s*"
    r"(?:\(\s*)?[\"']([^\"']+\.php)[\"']\s*\)?\s*;",
    re.I,
)
STRING_NODE_TYPES = {"string", "encapsed_string", "nowdoc", "heredoc"}
LITERAL_NODE_TYPES = STRING_NODE_TYPES | {
    "integer", "float", "boolean", "null", "true", "false",
}


def _parser() -> Parser:
    return Parser(PHP_LANGUAGE)


def _walk(node: Node) -> Iterable[Node]:
    yield node
    for child in node.named_children:
        yield from _walk(child)


def _node_text(source: bytes, node: Optional[Node]) -> str:
    if node is None:
        return ""
    return source[node.start_byte:node.end_byte].decode("utf-8", errors="ignore")


def _clean_string(value: str) -> str:
    value = value.strip()
    if len(value) >= 2 and value[0] == value[-1] and value[0] in "\"'":
        return value[1:-1]
    return value


def _function_name(source: bytes, node: Node) -> str:
    function = node.child_by_field_name("function")
    return _node_text(source, function).strip().lstrip("\\")


def _variable_names(source: bytes, node: Node) -> List[str]:
    return sorted({
        _node_text(source, child).strip()
        for child in _walk(node)
        if child.type == "variable_name"
    })


def _array_values(source: bytes, array_node: Node) -> Dict[str, Tuple[str, Node]]:
    values: Dict[str, Tuple[str, Node]] = {}
    for element in array_node.named_children:
        if element.type != "array_element_initializer":
            continue
        children = element.named_children
        if len(children) < 2:
            continue
        key = _clean_string(_node_text(source, children[0])).lower()
        value_node = children[-1]
        values[key] = (_clean_string(_node_text(source, value_node)), value_node)
    return values


def _split_top_level_csv(text: str) -> List[str]:
    parts: List[str] = []
    start = 0
    depth = 0
    quote = ""
    escaped = False
    for index, character in enumerate(text):
        if quote:
            if escaped:
                escaped = False
            elif character == "\\":
                escaped = True
            elif character == quote:
                quote = ""
            continue
        if character in "\"'":
            quote = character
        elif character in "([{":
            depth += 1
        elif character in ")]}" and depth:
            depth -= 1
        elif character == "," and depth == 0:
            parts.append(text[start:index])
            start = index + 1
    parts.append(text[start:])
    return parts


def _array_text_values(array_text: str) -> Dict[str, str]:
    body = array_text.strip()
    if body.lower().startswith("array"):
        body = body[5:].strip()
    if len(body) >= 2 and body[0] in "([" and body[-1] in ")]":
        body = body[1:-1]
    values: Dict[str, str] = {}
    for item in _split_top_level_csv(body):
        if "=>" not in item:
            continue
        key, value = item.split("=>", 1)
        values[_clean_string(key).lower()] = value.strip()
    return values


def _line_in_ranges(line: int, ranges: Sequence[Tuple[int, int]]) -> bool:
    return any(start <= line <= end for start, end in ranges)


def _ast_index(tree) -> Dict[str, List[Node]]:
    return {
        "assignments": sorted(
            QueryCursor(ASSIGNMENT_QUERY).captures(tree.root_node).get("assignment", []),
            key=lambda item: item.start_byte,
        ),
        "calls": sorted(
            QueryCursor(FUNCTION_CALL_QUERY).captures(tree.root_node).get("call", []),
            key=lambda item: item.start_byte,
        ),
    }


def _sql_data_sinks(
    source: bytes,
    tree,
    ranges: Sequence[Tuple[int, int]],
) -> List[Dict]:
    sinks: List[Dict] = []
    assignments = QueryCursor(SQL_DATA_ARRAY_QUERY).captures(tree.root_node).get("assignment", [])
    for node in sorted(assignments, key=lambda item: item.start_byte):
        node_start_byte = node.start_byte
        line = node.start_point.row + 1
        node_text = _node_text(source, node)
        left = node.child_by_field_name("left")
        right = node.child_by_field_name("right")
        if (
            left is None
            or right is None
            or not re.fullmatch(r"\$_SQL_DataArray\s*\[\s*\]", _node_text(source, left), re.I)
        ):
            continue
        if ranges and not _line_in_ranges(line, ranges):
            continue
        values = _array_text_values(_node_text(source, right))
        if not all(name in values for name in ("key", "val", "table")):
            continue
        val_text = values["val"]
        variables = sorted(set(re.findall(r'\$[A-Za-z_]\w*', val_text)))
        direct_cast_match = re.match(r"\s*\(\s*(int|integer|float|double|real)\s*\)", val_text, re.I)
        sinks.append({
            "line": line,
            "table": _clean_string(values["table"]),
            "column": _clean_string(values["key"]),
            "value": val_text,
            "variable": variables[0] if len(variables) == 1 else "",
            "val_start_byte": node_start_byte,
            "direct_cast": direct_cast_match.group(1).lower() if direct_cast_match else "",
            "snippet": " ".join(node_text.split())[:300],
        })
    return sinks


def _schema_directory(taxyear: str) -> Path:
    year = str(taxyear).strip()
    short_year = year[-2:] if year.isdigit() and len(year) == 4 else year
    return SITE_ASP_ROOT / "Schema" / f"{short_year}CLIENT"


@lru_cache(maxsize=8192)
def resolve_schema_type(taxyear: str, table: str, column: str) -> Dict[str, str]:
    table = table.strip()
    column = column.strip()
    if not table or not column:
        return {"sql_type": "", "category": "unknown", "schema_file": ""}
    schema_directory = (
        SITE_ASP_ROOT / "Schema" / "ACCMASTER"
        if table.lower().startswith("acc_")
        else _schema_directory(taxyear)
    )
    schema_file = schema_directory / table[0].upper() / f"{table}.php"
    if not schema_file.is_file():
        parent = schema_file.parent
        if parent.is_dir():
            match = next((item for item in parent.iterdir() if item.name.lower() == f"{table}.php".lower()), None)
            if match:
                schema_file = match
    if not schema_file.is_file():
        return {"sql_type": "", "category": "unknown", "schema_file": str(schema_file)}
    text = schema_file.read_text(encoding="utf-8", errors="ignore")
    global_name = f"SQLTYPE_{table}_{column}"
    match = re.search(
        rf'["\']{re.escape(global_name)}["\']\s*\]\s*=\s*["\']([^"\']+)["\']',
        text,
        re.I | re.S,
    )
    sql_type = match.group(1).strip() if match else ""
    upper_type = sql_type.upper()
    numeric_match = re.search(r"\b(?:DECIMAL|NUMERIC)\s*\(\s*\d+\s*,\s*(\d+)\s*\)", upper_type)
    if numeric_match and numeric_match.group(1) == "0":
        category = "integer"
    elif numeric_match or any(token in upper_type for token in FLOAT_TYPES):
        category = "float"
    elif any(re.search(rf"\b{token}\b", upper_type) for token in INTEGER_TYPES):
        category = "integer"
    elif any(token in upper_type for token in ("CHAR", "TEXT", "XML")):
        category = "string"
    elif any(token in upper_type for token in ("DATE", "TIME")):
        category = "date"
    elif sql_type:
        category = "other"
    else:
        category = "unknown"
    return {"sql_type": sql_type, "category": category, "schema_file": str(schema_file)}


def _candidate_html_files(taxyear: str, folder: str, source_path: Path, source_text: str) -> List[Path]:
    """Return matching HTML files in override, de-prefixed, exact-name order."""
    html_root = source_folder_path(taxyear, "html", site_root=SITE_ASP_ROOT)
    relative_key = f"{folder}/{source_path.name}".replace("\\", "/").lower()
    candidates: List[Path] = []
    override = HTML_FILE_OVERRIDES.get(relative_key)
    if override:
        override_parts = Path(override.replace("\\", "/")).parts
        candidates.append(
            source_folder_path(taxyear, override_parts[0], site_root=SITE_ASP_ROOT)
            .joinpath(*override_parts[1:])
        )
    exact_stem = source_path.stem
    matching_stem = exact_stem[4:] if exact_stem.lower().startswith("olt_") else exact_stem
    candidates.append(html_root / f"{matching_stem}.html")
    candidates.append(html_root / f"{exact_stem}.html")
    unique: List[Path] = []
    seen = set()
    for candidate in candidates:
        key = str(candidate).lower()
        if key not in seen and candidate.is_file():
            seen.add(key)
            unique.append(candidate)
    return unique


def resolve_html_input(
    taxyear: str,
    folder: str,
    source_path: Path,
    source_text: str,
    variable: str,
) -> Dict[str, str]:
    name = variable.lstrip("$")
    if not name:
        return {"input_type": "", "html_file": ""}
    escaped = re.escape(name)
    for html_path in _candidate_html_files(taxyear, folder, source_path, source_text):
        text = html_path.read_text(encoding="utf-8", errors="ignore")
        radio = re.search(rf'\$radioBtnName\s*=\s*["\']{escaped}["\']', text, re.I)
        if radio:
            return {"input_type": "radio", "html_file": str(html_path)}
        name_match = re.search(
            rf'\$InputArray\s*\[\s*["\']name["\']\s*\]\s*=\s*["\']{escaped}["\']\s*;',
            text,
            re.I,
        )
        if not name_match:
            continue
        nearby_start = max(0, name_match.start() - 1200)
        nearby_end = min(len(text), name_match.end() + 1800)
        nearby = text[nearby_start:nearby_end]
        type_matches = list(re.finditer(
            r'\$InputArray\s*\[\s*["\']inputType["\']\s*\]\s*=\s*["\']([^"\']+)["\']',
            nearby,
            re.I,
        ))
        name_position = name_match.start() - nearby_start
        type_match = min(type_matches, key=lambda item: abs(item.start() - name_position)) if type_matches else None
        return {
            "input_type": type_match.group(1) if type_match else "unknown",
            "html_file": str(html_path),
        }
    return {"input_type": "", "html_file": ""}


def _zero_byte_html_file(
    taxyear: str,
    folder: str,
    source_path: Path,
    source_text: str,
) -> Optional[Path]:
    """Return the highest-priority matching HTML when it exists but is empty."""
    candidates = _candidate_html_files(taxyear, folder, source_path, source_text)
    if not candidates:
        return None
    matched = candidates[0]
    try:
        return matched if matched.stat().st_size == 0 else None
    except OSError:
        return None


def _resolve_table_candidates(
    table_expression: str,
    source: bytes,
    ast_index: Dict[str, List[Node]],
    sink_byte: int,
) -> List[str]:
    """Resolve literal, variable, and array-fed table expressions before a sink."""
    assignments = [node for node in ast_index["assignments"] if node.start_byte < sink_byte]

    def resolve(expression: str, visited: set) -> List[str]:
        expression = expression.strip()
        literal = re.fullmatch(r'(["\'])([A-Za-z_][A-Za-z0-9_]*)\1', expression)
        if literal:
            return [literal.group(2)]
        subscript = re.fullmatch(r'(\$[A-Za-z_]\w*)\s*\[[^\]]+\]', expression)
        if subscript:
            array_name = subscript.group(1)
            if array_name.lower() in visited:
                return []
            values: List[str] = []
            latest_by_element: Dict[str, Node] = {}
            for assignment in assignments:
                left = _node_text(source, assignment.child_by_field_name("left")).strip()
                if not re.fullmatch(rf'{re.escape(array_name)}\s*\[[^\]]+\]', left, re.I):
                    continue
                latest_by_element[re.sub(r"\s+", "", left).lower()] = assignment
            for assignment in latest_by_element.values():
                right = _node_text(source, assignment.child_by_field_name("right"))
                values.extend(resolve(right, visited | {array_name.lower()}))
            return values
        if re.fullmatch(r'\$[A-Za-z_]\w*', expression):
            variable = expression
            if variable.lower() in visited:
                return []
            matches = []
            for assignment in assignments:
                left = _node_text(source, assignment.child_by_field_name("left")).strip()
                if left.lower() == variable.lower():
                    matches.append(assignment)
            if not matches:
                return []
            latest = matches[-1]
            right = _node_text(source, latest.child_by_field_name("right"))
            return resolve(right, visited | {variable.lower()})
        return []

    return list(dict.fromkeys(resolve(table_expression, set())))


def _qt_user_id_policy(source: bytes) -> Dict:
    file_text = source.decode("utf-8", errors="ignore")
    checks = [
        (
            "include_once header.php",
            re.compile(r'\binclude_once\s*\(\s*["\']header\.php["\']\s*\)\s*;', re.I),
        ),
        (
            "include_once qt_func.php",
            re.compile(r'\binclude_once\s*\(\s*["\']qt_func\.php["\']\s*\)\s*;', re.I),
        ),
        (
            "GetUniqueUserInfo($o9Ljw, $qt_user_id, $siteid, $pageid, $lasttime)",
            re.compile(
                r'\bGetUniqueUserInfo\s*\(\s*\$o9Ljw\s*,\s*\$qt_user_id\s*,\s*'
                r'\$siteid\s*,\s*\$pageid\s*,\s*\$lasttime\s*\)',
                re.I,
            ),
        ),
    ]
    found = [label for label, pattern in checks if pattern.search(file_text)]
    missing = [label for label, pattern in checks if not pattern.search(file_text)]
    return {"found": found, "missing": missing}


def _load_qdrant_file_methods(taxyear: str, folder: str) -> Dict[str, str]:
    """Load each file's classification from the folder's existing Qdrant store."""
    try:
        from php_flow_scanner import load_qdrant_store

        records = load_qdrant_store(str(taxyear), folder).get("records", [])
    except Exception:
        return {}

    methods: Dict[str, str] = {}
    prefix = f"/{taxyear}/{folder}/".lower()
    for record in records:
        method = str(record.get("method", "")).strip().upper()
        file_name = str(record.get("file_name") or record.get("base_name") or "")
        normalized = file_name.replace("\\", "/").strip().lower()
        relative = normalized[len(prefix):] if normalized.startswith(prefix) else normalized.lstrip("/")
        if relative:
            methods[relative] = method
        base_name = str(record.get("base_name") or Path(normalized).name).strip().lower()
        if base_name:
            methods.setdefault(base_name, method)
    return methods


def _qdrant_method_for_file(file_name: str, methods: Dict[str, str]) -> str:
    normalized = file_name.replace("\\", "/").strip().lower()
    return methods.get(normalized, methods.get(Path(normalized).name, "")).strip().upper()


def _prior_variable_evidence(
    source: bytes,
    ast_index: Dict[str, List[Node]],
    variable: str,
    sink: Dict,
    sink_byte: Optional[int] = None,
    visited: Optional[set] = None,
) -> Dict:
    sink_byte = sink["val_start_byte"] if sink_byte is None else sink_byte
    visited = set() if visited is None else visited
    variable_key = variable.lower()
    if variable_key in visited:
        return {
            "calls": [], "assignments": [], "trusted": False,
            "cast_types": [], "upstream_variables": [], "root_variable": variable,
        }
    visited = visited | {variable_key}
    calls: List[Dict] = []
    assignments: List[Dict] = []
    trusted = False
    cast_types: List[str] = []
    if sink["direct_cast"]:
        cast_types.append(sink["direct_cast"])

    for node in ast_index["calls"]:
        if node.start_byte >= sink_byte:
            continue
        if variable in _variable_names(source, node):
            calls.append({
                "name": _function_name(source, node),
                "line": node.start_point.row + 1,
                "start_byte": node.start_byte,
                "snippet": " ".join(_node_text(source, node).split())[:180],
            })
    for node in ast_index["assignments"]:
        if node.start_byte >= sink_byte:
            continue
        left = node.child_by_field_name("left")
        right = node.child_by_field_name("right")
        if _node_text(source, left).strip() != variable or right is None:
            continue
        functions = [
            _function_name(source, item)
            for item in _walk(right)
            if item.type == "function_call_expression"
        ]
        right_text = _node_text(source, right)
        casts = [
            _node_text(source, item.child_by_field_name("type")).strip().lower()
            for item in _walk(right)
            if item.type == "cast_expression"
        ]
        cast_types.extend(casts)
        literal = right.type in LITERAL_NODE_TYPES
        trusted_function = any(name.lower() in TRUSTED_VALUE_FUNCTIONS for name in functions)
        assignments.append({
            "line": node.start_point.row + 1,
            "start_byte": node.start_byte,
            "snippet": " ".join(_node_text(source, node).split())[:180],
            "functions": functions,
            "casts": casts,
            "trusted": literal or trusted_function,
            "self_referential": variable in _variable_names(source, right),
            "dependencies": sorted(
                name for name in _variable_names(source, right)
                if name.lower() != variable_key
            ),
            "database_result": bool(
                re.search(r'\$res_?data\s*\[', right_text, re.I)
                or any(name.lower() in {"resdata", "res_data"} for name in functions)
            ),
        })
    active_assignments = assignments
    reset_indexes = [index for index, item in enumerate(assignments) if not item["self_referential"]]
    if reset_indexes:
        active_assignments = assignments[reset_indexes[-1]:]
    if active_assignments:
        calls = [item for item in calls if item["start_byte"] >= active_assignments[0]["start_byte"]]
        cast_types = [sink["direct_cast"]] if sink["direct_cast"] else []
        cast_types.extend(cast for item in active_assignments for cast in item["casts"])
        trusted = active_assignments[0]["trusted"]
    upstream_variables: List[Dict] = []
    root_variable = variable
    combined_assignments = list(active_assignments)
    for assignment in list(active_assignments):
        for dependency in assignment["dependencies"]:
            upstream_variables.append({
                "name": dependency,
                "line": assignment["line"],
                "derived_variable": variable,
            })
            upstream = _prior_variable_evidence(
                source, ast_index, dependency, sink,
                sink_byte=assignment["start_byte"], visited=visited,
            )
            calls.extend(upstream["calls"])
            combined_assignments.extend(upstream["assignments"])
            cast_types.extend(upstream["cast_types"])
            upstream_variables.extend(upstream["upstream_variables"])
            root_variable = upstream.get("root_variable") or dependency
            trusted = trusted or upstream["trusted"]

    calls = list({item["start_byte"]: item for item in calls}.values())
    combined_assignments = list({item["start_byte"]: item for item in combined_assignments}.values())
    return {
        "calls": sorted(calls, key=lambda item: item["start_byte"]),
        "assignments": sorted(combined_assignments, key=lambda item: item["start_byte"]),
        "trusted": trusted,
        "cast_types": sorted(set(cast_types)),
        "upstream_variables": upstream_variables,
        "root_variable": root_variable,
    }


def _derived_variable_validation_evidence(
    source: bytes,
    ast_index: Dict[str, List[Node]],
    variable: str,
    sink_byte: int,
    validator_names: set,
) -> Dict:
    """Find validators applied to temporary variables derived from a sink value."""
    tracked = {variable.lower()}
    assignments: List[Dict] = []
    for node in ast_index["assignments"]:
        if node.start_byte >= sink_byte:
            continue
        left = node.child_by_field_name("left")
        right = node.child_by_field_name("right")
        left_text = _node_text(source, left).strip()
        if right is None or not re.fullmatch(r'\$[A-Za-z_]\w*', left_text):
            continue
        right_variables = {name.lower() for name in _variable_names(source, right)}
        if not right_variables.intersection(tracked) or left_text.lower() in tracked:
            continue
        tracked.add(left_text.lower())
        functions = [
            _function_name(source, item)
            for item in _walk(right)
            if item.type == "function_call_expression"
        ]
        assignments.append({
            "line": node.start_point.row + 1,
            "start_byte": node.start_byte,
            "snippet": " ".join(_node_text(source, node).split())[:180],
            "functions": functions,
            "casts": [],
            "trusted": False,
            "self_referential": False,
            "dependencies": [],
            "database_result": False,
        })

    calls: List[Dict] = []
    for node in ast_index["calls"]:
        if node.start_byte >= sink_byte:
            continue
        name = _function_name(source, node)
        if name.lower() not in validator_names:
            continue
        call_variables = {item.lower() for item in _variable_names(source, node)}
        if call_variables.intersection(tracked):
            calls.append({
                "name": name,
                "line": node.start_point.row + 1,
                "start_byte": node.start_byte,
                "snippet": " ".join(_node_text(source, node).split())[:180],
            })
    return {
        "calls": calls,
        "assignments": assignments,
        "variables": sorted(tracked),
    }


def _included_php_contexts(source_path: Path, source: bytes) -> List[Dict]:
    """Parse literal PHP includes once, preserving their execution position."""
    source_text = source.decode("utf-8", errors="ignore")
    contexts: List[Dict] = []
    allowed_root = (SITE_ASP_ROOT / source_path.parts[-3]).resolve() if len(source_path.parts) >= 3 else None
    for match in PHP_INCLUDE_RE.finditer(source_text):
        include_name = match.group(1).replace("\\", "/")
        include_path = (source_path.parent / include_name).resolve()
        if allowed_root is not None:
            try:
                include_path.relative_to(allowed_root)
            except ValueError:
                continue
        if not include_path.is_file():
            continue
        included_source = include_path.read_bytes()
        included_tree = _parser().parse(included_source)
        contexts.append({
            "path": include_path,
            "source": included_source,
            "ast_index": _ast_index(included_tree),
            "include_byte": len(source_text[:match.start()].encode("utf-8")),
            "include_line": source_text.count("\n", 0, match.start()) + 1,
        })
    return contexts


def _included_variable_evidence(
    contexts: Sequence[Dict],
    variable: str,
    sink: Dict,
) -> Dict:
    """Collect validation/conversion evidence from includes executed before a sink."""
    merged = {
        "calls": [], "assignments": [], "cast_types": [],
        "trusted": False, "upstream_variables": [], "sources": [],
    }
    for context_index, context in enumerate(contexts):
        if context["include_byte"] >= sink["val_start_byte"]:
            continue
        included_source = context["source"]
        included_sink = {
            "val_start_byte": len(included_source) + 1,
            "direct_cast": "",
        }
        evidence = _prior_variable_evidence(
            included_source,
            context["ast_index"],
            variable,
            included_sink,
        )
        if not evidence["calls"] and not evidence["assignments"]:
            continue

        source_file = context["path"].name
        byte_scale = max(len(included_source) + 1, 1)
        for category in ("calls", "assignments"):
            for item in evidence[category]:
                local_line = item["line"]
                # Position included evidence at the include statement while
                # keeping every event's identity stable for graph de-duplication.
                item = {
                    **item,
                    "start_byte": context["include_byte"]
                    + ((context_index + 1) / 1000)
                    + (item["start_byte"] / byte_scale / 1000),
                    "line": context["include_line"],
                    "source_file": source_file,
                    "source_line": local_line,
                }
                merged[category].append(item)
        merged["cast_types"].extend(evidence["cast_types"])
        merged["upstream_variables"].extend(evidence["upstream_variables"])
        merged["trusted"] = merged["trusted"] or evidence["trusted"]
        merged["sources"].append(included_source)
    merged["cast_types"] = sorted(set(merged["cast_types"]))
    return merged


def _field_names(sink: Dict, variable: str) -> List[str]:
    return [
        re.sub(r"[^a-z0-9]", "", str(value).lower().lstrip("$"))
        for value in (sink.get("column", ""), variable)
        if value
    ]


def _field_matches(names: Sequence[str], *suffixes: str) -> bool:
    return any(name.endswith(suffixes) for name in names)


def _has_required_length_check(source: bytes, variable: str, sink_byte: int, length: int) -> bool:
    if not variable:
        return False
    prefix = source[:sink_byte].decode("utf-8", errors="ignore")
    escaped = re.escape(variable)
    return bool(re.search(
        rf"\bUDF_strlen\s*\(\s*{escaped}\s*\)\s*(?:!==|!=|<>)\s*{length}\b",
        prefix,
        re.I,
    ))


def _date_component(names: Sequence[str]) -> Tuple[str, str]:
    for name in names:
        for component in ("month", "day", "year"):
            if name.endswith(component) and len(name) > len(component):
                return component, name[:-len(component)]
    return "", ""


def _source_has_date_triplet(source: bytes, prefix: str, sink_byte: int) -> bool:
    if not prefix:
        return False
    variables = re.findall(
        r"\$[A-Za-z_]\w*",
        source[:sink_byte].decode("utf-8", errors="ignore"),
    )
    compact = {
        re.sub(r"[^a-z0-9]", "", variable.lower().lstrip("$"))
        for variable in variables
    }
    return all(f"{prefix}{component}" in compact for component in ("month", "day", "year"))


def _build_graph(
    variable: str,
    sink: Dict,
    evidence: Dict,
    issues: List[str],
    qt_policy: Optional[Dict] = None,
) -> Dict:
    nodes = [{
        "id": "source",
        "label": evidence.get("root_variable") or variable or sink["value"],
        "kind": "variable",
    }]
    edges: List[Dict[str, str]] = []
    previous = "source"
    events: List[Tuple[int, str, str]] = []
    for assignment in evidence["assignments"]:
        label = assignment["snippet"]
        if assignment.get("source_file"):
            label = f"{assignment['source_file']}:Line {assignment['source_line']} — {label}"
        kind = "trusted" if assignment["trusted"] else "assignment"
        events.append((assignment["line"], label, kind))
    for call in evidence["calls"]:
        label = f"{call['name']}()"
        if call.get("source_file"):
            label += f" [{call['source_file']}:Line {call['source_line']}]"
        events.append((call["line"], label, "function"))
    ordered_events = sorted(set(events))
    if len(ordered_events) > 12:
        validators = [
            event
            for event in ordered_events
            if any(name in event[1].lower() for name in GRAPH_VALIDATION_FUNCTIONS)
        ]
        ordered_events = sorted(set(validators + ordered_events[-12:]))
    for index, (line, label, kind) in enumerate(ordered_events, start=1):
        node_id = f"step-{index}"
        nodes.append({"id": node_id, "label": f"L{line}: {label}", "kind": kind})
        edges.append({"from": previous, "to": node_id})
        previous = node_id
    if qt_policy is not None:
        found = set(qt_policy["found"])
        policy_labels = qt_policy["found"] + qt_policy["missing"]
        if not qt_policy.get("required", True):
            policy_labels = [f"Qdrant method {qt_policy['method']}: startup check not required"]
            found = set(policy_labels)
        for index, label in enumerate(policy_labels, start=1):
            node_id = f"qt-policy-{index}"
            nodes.append({
                "id": node_id,
                "label": f"{label}: {'found' if label in found else 'missing'}",
                "kind": "trusted" if label in found else "issue",
            })
            edges.append({"from": previous, "to": node_id})
            previous = node_id
    sink_id = "sink"
    nodes.append({
        "id": sink_id,
        "label": f"L{sink['line']}: {sink['table']}.{sink['column']}",
        "kind": "issue" if issues else "sink",
    })
    edges.append({"from": previous, "to": sink_id})
    return {"nodes": nodes, "edges": edges}


def _evaluate_sink(
    taxyear: str,
    folder: str,
    source_path: Path,
    source_text: str,
    source: bytes,
    tree,
    ast_index: Dict[str, List[Node]],
    sink: Dict,
    qdrant_method: str,
    included_contexts: Sequence[Dict] = (),
) -> Dict:
    variable = sink["variable"]
    zero_byte_html_path = _zero_byte_html_file(
        taxyear, folder, source_path, source_text
    )
    zero_byte_html = zero_byte_html_path is not None
    table_candidates = _resolve_table_candidates(
        sink["table"], source, ast_index, sink["val_start_byte"]
    ) or [sink["table"]]
    candidate_schemas = [
        (table, resolve_schema_type(taxyear, table, sink["column"]))
        for table in table_candidates
    ]
    resolved_schemas = [(table, schema) for table, schema in candidate_schemas if schema["sql_type"]]
    effective_schemas = resolved_schemas or candidate_schemas
    effective_tables = [table for table, _schema in effective_schemas]
    sql_types = list(dict.fromkeys(schema["sql_type"] for _table, schema in effective_schemas if schema["sql_type"]))
    categories = {schema["category"] for _table, schema in effective_schemas}
    schema_files = list(dict.fromkeys(schema["schema_file"] for _table, schema in effective_schemas if schema["schema_file"]))
    schema = {
        "sql_type": " | ".join(sql_types),
        "category": next(iter(categories)) if len(categories) == 1 else ("mixed" if categories else "unknown"),
        "schema_file": " | ".join(schema_files),
    }
    resolved_table = " | ".join(effective_tables)
    evidence = _prior_variable_evidence(source, ast_index, variable, sink) if variable else {
        "calls": [], "assignments": [], "trusted": True, "cast_types": [],
        "upstream_variables": [], "root_variable": "",
    }
    included_evidence = _included_variable_evidence(
        included_contexts, variable, sink
    ) if variable else {
        "calls": [], "assignments": [], "cast_types": [], "trusted": False,
        "upstream_variables": [], "sources": [],
    }
    evidence["calls"].extend(included_evidence["calls"])
    evidence["assignments"].extend(included_evidence["assignments"])
    evidence["cast_types"] = sorted(set(evidence["cast_types"] + included_evidence["cast_types"]))
    evidence["upstream_variables"].extend(included_evidence["upstream_variables"])
    evidence["trusted"] = evidence["trusted"] or included_evidence["trusted"]
    is_foreign_phone = bool(re.search(
        r"(?:frg|frgn|foreign).*phone|phone.*(?:frg|frgn|foreign)",
        f"{sink['column']} {variable}",
        re.I,
    ))
    is_phone_field = bool(PHONE_FIELD_RE.search(f"{sink['column']} {variable}"))
    if variable and is_phone_field:
        derived_validation = _derived_variable_validation_evidence(
            source, ast_index, variable, sink["val_start_byte"], PHONE_VALIDATORS
        )
        evidence["calls"] = list({
            item["start_byte"]: item
            for item in evidence["calls"] + derived_validation["calls"]
        }.values())
        evidence["assignments"] = list({
            item["start_byte"]: item
            for item in evidence["assignments"] + derived_validation["assignments"]
        }.values())
    function_names = {item["name"].lower() for item in evidence["calls"]}
    for assignment in evidence["assignments"]:
        function_names.update(name.lower() for name in assignment["functions"])
    phone_validation_found = bool(PHONE_VALIDATORS & function_names)
    is_qt_user_id = sink["column"].lower() == "qt_user_id"
    database_result_value = any(
        assignment.get("database_result") for assignment in evidence["assignments"]
    )
    upstream_phone_validated = (
        phone_validation_found
        and any("phone" in item["name"].lower() for item in evidence["upstream_variables"])
    )
    html_validation_checked = (
        qdrant_method == "POST"
        and not is_qt_user_id
        and not database_result_value
        and not upstream_phone_validated
        and not zero_byte_html
    )
    if zero_byte_html:
        html = {"input_type": "0 KB", "html_file": str(zero_byte_html_path)}
    elif html_validation_checked:
        html = resolve_html_input(taxyear, folder, source_path, source_text, variable)
    else:
        html = {"input_type": "N/A" if is_qt_user_id else "Not checked", "html_file": ""}
    input_type = html["input_type"].lower()
    field_names = _field_names(sink, variable)
    is_textbox = "textbox" in input_type
    is_money_field = "MONEY" in schema["sql_type"].upper()
    is_ssn_field = _field_matches(field_names, "ssn")
    is_ein_field = _field_matches(field_names, "ein")
    is_payerin_field = _field_matches(field_names, "payerin")
    is_first_or_last_name = _field_matches(field_names, "firstname", "lastname")
    is_person_name = _field_matches(
        field_names,
        "firstname", "lastname", "middlename", "middleinitial",
    )
    is_address_field = _field_matches(
        field_names,
        "address", "address1", "address2", "street", "street1", "street2", "careof",
    )
    is_account_number = _field_matches(
        field_names,
        "accountnbr", "accountnumber", "acctnbr", "acctnumber",
    )
    date_component, date_prefix = _date_component(field_names)
    has_date_triplet = _source_has_date_triplet(
        source, date_prefix, sink["val_start_byte"]
    ) if date_component else False
    issues: List[str] = []
    review_notes: List[str] = []
    qt_policy = None

    if zero_byte_html:
        issues.append(ZERO_BYTE_HTML_REASON)
    elif is_qt_user_id:
        if qdrant_method in {"GET", "POST"}:
            qt_policy = {**_qt_user_id_policy(source), "required": True, "method": qdrant_method}
            issues.extend(f"Required {item} is missing" for item in qt_policy["missing"])
        else:
            qt_policy = {
                "found": [],
                "missing": [],
                "required": False,
                "method": qdrant_method or "UNKNOWN",
            }

    if not zero_byte_html and variable and not evidence["trusted"] and qt_policy is None:
        # UDF_trim is intentionally not enforced as an input-validation issue.
        # if html_validation_checked and "udf_trim" not in function_names:
        #     issues.append(f"UDF_trim conversion for {variable} is missing")
        if schema["category"] == "integer" and "int" not in evidence["cast_types"] and "integer" not in evidence["cast_types"]:
            issues.append(f"Integer conversion for {variable} is missing")
        if schema["category"] == "float" and not ({"float", "double", "real"} & set(evidence["cast_types"])):
            issues.append(f"Float conversion for {variable} is missing")
        if html_validation_checked and is_money_field and "isnumeric" not in function_names:
            issues.append(f"isNumeric validation for money field {variable} is missing")
        if html_validation_checked and input_type in SELECTION_INPUT_TYPES and "isvalidvalue" not in function_names:
            issues.append(f"IsValidValue for {variable} is missing")
        if html_validation_checked and "textarea" in input_type:
            if "fmtvalue" not in function_names:
                issues.append(f"fmtvalue for {variable} is missing")
            if not ({"fixtext", "formatdescription"} & function_names):
                issues.append(f"fixtext or Formatdescription for {variable} is missing")
        if re.search(r"(^|_)email$", sink["column"].lower()):
            if "isvalidemail" not in function_names:
                issues.append(f"IsValidEmail for {variable} is missing")
        if (
            html_validation_checked
            and is_phone_field
            and input_type not in SELECTION_INPUT_TYPES
        ):
            if not phone_validation_found:
                issues.append(f"IsValidPhoneNumber or fmtNum for {variable} is missing")
        if html_validation_checked and is_textbox and is_ssn_field:
            if "isvalidssn" not in function_names:
                issues.append(f"IsValidSSN for {variable} is missing")
        if html_validation_checked and is_textbox and is_ein_field:
            if "isvalidein" not in function_names:
                issues.append(f"IsValidEIN for {variable} is missing")
        if html_validation_checked and (is_ssn_field or is_payerin_field):
            has_length_check = _has_required_length_check(
                source, variable, sink["val_start_byte"], 9
            ) or any(
                _has_required_length_check(item, variable, len(item), 9)
                for item in included_evidence["sources"]
            )
            if not has_length_check:
                issues.append(f"UDF_strlen({variable}) != 9 validation is missing")
        if html_validation_checked and (is_ssn_field or is_ein_field):
            if "fmtnum" not in function_names:
                issues.append(f"fmtNum validation for 9-digit field {variable} is missing")
            if "isnumeric" in function_names:
                identity_type = "SSN" if is_ssn_field else "EIN"
                issues.append(
                    f"isNumeric validation for {identity_type} field {variable} is not needed"
                )
        if html_validation_checked and is_textbox and is_first_or_last_name:
            if "fmtnamesp" not in function_names:
                issues.append(f"fmtNamesp validation for {variable} is missing")
        if html_validation_checked and is_person_name:
            if not ({"formatname", "formatnameline1"} & function_names):
                issues.append(f"formatName or FormatNameLine1 conversion for {variable} is missing")
        if html_validation_checked and is_address_field:
            if "formataddress" not in function_names:
                issues.append(f"FormatAddress conversion for {variable} is missing")
        if html_validation_checked and date_component:
            required_date_validator = {
                "month": "isvalidmonth",
                "day": "isvalidday",
                "year": "isvalidyearvalue",
            }[date_component]
            display_name = {
                "month": "IsValidMonth",
                "day": "IsValidDay",
                "year": "IsValidYearValue",
            }[date_component]
            if required_date_validator not in function_names:
                issues.append(f"{display_name} for {variable} is missing")
            if "fixnum" not in function_names:
                issues.append(f"fixnum conversion for {variable} is missing")
            if has_date_triplet and "isvaliddate" not in function_names:
                issues.append(f"IsValidDate for {date_prefix} month/day/year is missing")
        if html_validation_checked and is_account_number:
            if "isalphanumeric" not in function_names:
                issues.append(f"isAlphaNumeric validation for {variable} is missing")

    if not zero_byte_html and variable and schema["category"] == "unknown" and qt_policy is None:
        review_notes.append(f"Schema datatype for {resolved_table}.{sink['column']} was not resolved")
    if not zero_byte_html and html_validation_checked and variable and html["input_type"].lower() in {"", "unknown"} and not evidence["trusted"] and qt_policy is None:
        review_notes.append(f"HTML input type for {variable} was not resolved")
    status = "ISSUE" if issues else ("REVIEW" if review_notes else "PASS")
    graph_sink = {**sink, "table": resolved_table}
    graph = _build_graph(variable, graph_sink, evidence, issues, qt_policy)
    return {
        "file": source_path.name,
        "file_path": str(source_path),
        "line": sink["line"],
        "table": resolved_table,
        "table_expression": sink["table"],
        "table_candidates": table_candidates,
        "column": sink["column"],
        "variable": variable or sink["value"],
        "value": sink["value"],
        "sql_type": schema["sql_type"],
        "schema_category": schema["category"],
        "schema_file": schema["schema_file"],
        "input_type": html["input_type"],
        "html_file": html["html_file"],
        "html_validation_checked": html_validation_checked,
        "zero_byte_html": zero_byte_html,
        "database_result_value": database_result_value,
        "upstream_phone_validated": upstream_phone_validated,
        "phone_validation_found": phone_validation_found,
        "included_validation_files": sorted({
            item.get("source_file", "")
            for item in evidence["calls"] + evidence["assignments"]
            if item.get("source_file")
        }),
        "upstream_variables": evidence["upstream_variables"],
        "is_foreign_phone": is_foreign_phone,
        "qdrant_method": qdrant_method or "UNKNOWN",
        "status": status,
        "issues": issues,
        "review_notes": review_notes,
        "reason": (
            f"qt_user_id startup check is not required for Qdrant method {qt_policy['method']}"
            if qt_policy is not None and not qt_policy["required"]
            else "; ".join(issues or review_notes) or "Required validation evidence found"
        ),
        "snippet": sink["snippet"],
        "tree_has_errors": tree.root_node.has_error,
        "qt_user_id_policy": qt_policy,
        "graph": graph,
    }


def _read_chunk_candidates(taxyear: str, folder: str) -> Dict[str, List[Tuple[int, int]]]:
    chunk_file = SQL_ROOT / str(taxyear) / folder / "chunks.json"
    if not chunk_file.is_file():
        raise FileNotFoundError(f"Query chunk build not found: {chunk_file}")
    with chunk_file.open("r", encoding="utf-8") as handle:
        chunks = json.load(handle)
    candidates: Dict[str, List[Tuple[int, int]]] = defaultdict(list)
    for chunk in chunks if isinstance(chunks, list) else []:
        query_types = {str(item).upper() for item in chunk.get("query_type", [])}
        if not query_types.intersection(UPDATE_TYPES):
            continue
        file_name = str(chunk.get("file", "")).replace("\\", "/")
        if file_name:
            candidates[file_name].append((int(chunk.get("start_line", 1)), int(chunk.get("end_line", 1))))
    return candidates


def analyse_input_validation(
    taxyear: str,
    folder: str,
    sample_files: int = 5,
    progress: Optional[Callable[[str, int, int], None]] = None,
    post_only: bool = True,
) -> Dict:
    taxyear = str(taxyear).strip()
    folder = str(folder).strip()
    # Schema files and routing rules can change while the dashboard process is
    # running. Refresh once per analysis so an earlier Unknown result does not
    # remain in the process-wide resolver cache.
    resolve_schema_type.cache_clear()
    requested_sample_files = int(sample_files)
    analyse_all = requested_sample_files <= 0
    sample_files = 0 if analyse_all else min(max(requested_sample_files, 1), 25)
    candidates = _read_chunk_candidates(taxyear, folder)
    qdrant_methods = _load_qdrant_file_methods(taxyear, folder)
    eligible_candidates = {
        name: ranges
        for name, ranges in candidates.items()
        if not post_only or _qdrant_method_for_file(name, qdrant_methods) == "POST"
    }
    preferred = (
        ["olt_contactInfo.php", "az_general_infox.php"]
        if folder.lower() == "oltproc"
        else []
    )
    ordered_names = [name for name in preferred if name in eligible_candidates]
    ordered_names.extend(
        name for name in sorted(eligible_candidates, key=str.lower)
        if name not in ordered_names
    )
    folder_root = source_folder_path(taxyear, folder, site_root=SITE_ASP_ROOT)
    findings: List[Dict] = []
    analysed_files: List[str] = []
    checked = 0
    max_candidates = (
        len(ordered_names)
        if analyse_all
        else min(len(ordered_names), max(sample_files * 20, 50))
    )

    for file_name in ordered_names[:max_candidates]:
        checked += 1
        if progress:
            progress(file_name, checked, max_candidates)
        source_path = folder_root / Path(file_name)
        if not source_path.is_file():
            continue
        source = source_path.read_bytes()
        source_text = source.decode("utf-8", errors="ignore")
        parser = _parser()
        tree = parser.parse(source)
        ast_index = _ast_index(tree)
        included_contexts = _included_php_contexts(source_path, source)
        sinks = _sql_data_sinks(source, tree, eligible_candidates[file_name])
        if not sinks:
            continue
        analysed_files.append(file_name)
        qdrant_method = _qdrant_method_for_file(file_name, qdrant_methods)
        # A zero-byte matched HTML is a file-level problem, not one validation
        # failure per SQL field. Emit one representative issue for the file.
        sinks_to_evaluate = (
            sinks[:1]
            if _zero_byte_html_file(taxyear, folder, source_path, source_text)
            else sinks[:100]
        )
        for sink in sinks_to_evaluate:
            findings.append(
                _evaluate_sink(
                    taxyear, folder, source_path, source_text, source, tree, ast_index, sink,
                    qdrant_method, included_contexts,
                )
            )
        if not analyse_all and len(analysed_files) >= sample_files:
            break

    status_order = {"ISSUE": 0, "REVIEW": 1, "PASS": 2}
    findings.sort(key=lambda item: (status_order[item["status"]], item["file"].lower(), item["line"]))
    counts = {status: sum(item["status"] == status for item in findings) for status in ("ISSUE", "REVIEW", "PASS")}
    return {
        "taxyear": taxyear,
        "folder": folder,
        "sample_files_requested": sample_files,
        "analyse_all": analyse_all,
        "post_only": post_only,
        "eligible_post_files": len(eligible_candidates) if post_only else None,
        "files_analysed": analysed_files,
        "candidate_files_checked": checked,
        "findings": findings,
        "summary": {
            "files": len(analysed_files),
            "values": len(findings),
            "issues": counts["ISSUE"],
            "review": counts["REVIEW"],
            "passed": counts["PASS"],
        },
    }
