"""Project-specific mappings and policies for input-validation analysis."""

# Keys and values are relative to <site-asp>/<taxyear>.
HTML_FILE_OVERRIDES = {
    "oltproc/olt_contactinfo.php": "html/contact_info.html",
}

# Functions whose return values originate inside the application rather than
# directly from request input. Names are matched case-insensitively.
TRUSTED_VALUE_FUNCTIONS = {
    "time",
}

