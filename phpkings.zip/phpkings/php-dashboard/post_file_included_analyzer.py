from __future__ import annotations

import re
from typing import Dict, Iterable, List


INCLUDE_REQUIRE_RE = re.compile(
    r"\b(?P<pattern>include_once|require_once|include|require)\b"
    r"\s*(?:\(\s*)?[\"'](?P<target>[^\"']+)[\"']",
    re.IGNORECASE,
)


def _reference_basename(value: str) -> str:
    normalized = str(value).replace("\\", "/").split("?", 1)[0].split("#", 1)[0]
    return normalized.rstrip("/").rsplit("/", 1)[-1].strip().lower()


def _strip_snippet_comments(snippet: str) -> str:
    """Remove comments from persisted one-line evidence, preserving strings."""
    output = []
    quote = ""
    escaped = False
    index = 0
    while index < len(snippet):
        char = snippet[index]
        next_char = snippet[index + 1] if index + 1 < len(snippet) else ""
        if quote:
            output.append(char)
            if escaped:
                escaped = False
            elif char == "\\":
                escaped = True
            elif char == quote:
                quote = ""
            index += 1
            continue
        if char in {'"', "'"}:
            quote = char
            output.append(char)
            index += 1
            continue
        if char == "/" and next_char == "/":
            break
        if char == "#" and not "".join(output).strip():
            break
        if char == "/" and next_char == "*":
            closing = snippet.find("*/", index + 2)
            if closing < 0:
                break
            index = closing + 2
            continue
        output.append(char)
        index += 1
    return "".join(output)


def analyse_method_file_includes(
    records: Iterable[Dict], method: str, folder: str = ""
) -> Dict:
    """Return include/require evidence for files with one Qdrant primary method."""
    method = str(method).strip().upper()
    method_records = [
        record
        for record in records
        if str(record.get("method", "")).strip().upper() == method
    ]
    matches: List[Dict] = []
    included_files = set()
    seen = set()

    for record in method_records:
        target_file = str(record.get("file_name") or record.get("base_name") or "").strip()
        if not target_file:
            continue
        for evidence in record.get("evidence") or []:
            if not isinstance(evidence, dict):
                continue
            snippet = str(evidence.get("snippet") or "").strip()
            parsed_snippet = _strip_snippet_comments(snippet)
            source_file = str(evidence.get("source_file") or "").strip()
            source_line = evidence.get("source_line")
            target_basename = _reference_basename(
                str(record.get("base_name") or target_file)
            )
            for pattern_match in INCLUDE_REQUIRE_RE.finditer(parsed_snippet):
                included_target = pattern_match.group("target")
                if _reference_basename(included_target) != target_basename:
                    continue
                pattern = pattern_match.group("pattern").lower()
                key = (
                    target_file.lower(), source_file.lower(), source_line,
                    pattern, included_target.lower(), snippet,
                )
                if key in seen:
                    continue
                seen.add(key)
                included_files.add(target_file.lower())
                include_snippet = pattern_match.group(0)
                matches.append({
                    "folder": folder or str(record.get("folder") or ""),
                    "target_file": target_file,
                    "post_file": target_file,
                    "base_name": str(record.get("base_name") or ""),
                    "included_by": source_file,
                    "line": source_line,
                    "pattern": pattern,
                    "snippet": include_snippet,
                })

    matches.sort(key=lambda item: (
        item["target_file"].lower(),
        item["included_by"].lower(),
        item["line"] if isinstance(item["line"], int) else 0,
    ))
    return {
        "folder": folder,
        "method": method,
        "method_file_count": len(method_records),
        "post_file_count": len(method_records) if method == "POST" else 0,
        "get_file_count": len(method_records) if method == "GET" else 0,
        "included_file_count": len(included_files),
        "include_count": len(matches),
        "matches": matches,
    }


def analyse_post_file_includes(records: Iterable[Dict], folder: str = "") -> Dict:
    return analyse_method_file_includes(records, "POST", folder)


def analyse_get_file_includes(records: Iterable[Dict], folder: str = "") -> Dict:
    return analyse_method_file_includes(records, "GET", folder)


def post_file_include_export_rows(result: Dict):
    method = str(result.get("method") or "POST").upper()
    columns = ["Folder", f"{method} File", "Included By", "Line", "Pattern", "Snippet"]
    rows = [
        [
            item.get("folder", ""),
            item.get("target_file") or item.get("post_file", ""),
            item.get("included_by", ""),
            item.get("line", ""),
            item.get("pattern", ""),
            item.get("snippet", ""),
        ]
        for item in result.get("matches") or []
    ]
    return columns, rows
