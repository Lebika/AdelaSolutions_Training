import shutil
import unittest
from uuid import uuid4
from pathlib import Path
from unittest.mock import patch

from flask import Flask

from software_flow import scanner, store, register


class FlowTests(unittest.TestCase):
    def setUp(self):
        # Keep embedded Qdrant/SQLite paths below Windows' legacy path limit.
        fixture_root = scanner.existing.REPO_ROOT / ".sf_tests"
        self.root = (fixture_root / uuid4().hex[:12]).resolve()
        self.root.mkdir(parents=True)
        def cleanup():
            if not self.root.is_relative_to(fixture_root.resolve()):
                raise ValueError("Test fixture cleanup escaped its workspace folder")
            shutil.rmtree(self.root)
        self.addCleanup(cleanup)
        self.html = self.root / "protected" / "2025" / "html"
        self.post = self.root / "public" / "2025" / "oltproc"
        self.html.mkdir(parents=True)
        self.post.mkdir(parents=True)
        for name, value in {"SITE_ASP_ROOT": self.root / "public", "SITE_ASP_PROTECTED_ROOT": self.root / "protected"}.items():
            patcher = patch.object(scanner.existing, name, value)
            patcher.start()
            self.addCleanup(patcher.stop)
        patcher = patch.object(store, "DATA_ROOT", self.root / "data")
        patcher.start()
        self.addCleanup(patcher.stop)
        (self.html / "1099intdone.html").write_text('<label for="more">Add interest</label><input id="more" name="more" type="submit" value="1">')
        (self.post / "olt_1099intdone.php").write_text('''<?
if($err_flag != 1) {
 if($more == 1) {
 echo '<form action="olt_1099int.php" method="post">';
 BuildDynamicFormHiddenData("step=1099int");
 include(PROTECTED_PATHQT."html/1099int.html");
 } else { include(PROTECTED_PATHQT."html/otherdone.html"); }
}
// include(PROTECTED_PATHQT."html/1099int_commented.html");
''')
        (self.html / "1099int.html").write_text('''<div id="box8"><span id="amount-group">
<?
$InputArray['labelText']="8. Tax-exempt interest";
$InputArray['name']="tax_exempt_1099int";
$InputArray['inputType']="labelWithAmount";
if($amount_err == 1){$InputArray['errMsg']="Invalid amount";}
OLTGenerateInputGrp($InputArray);
$radioBtnName="whose_int";
$radioPnlHead="Recipient";
$radioBtnValues[]="0";$radioBtnValues[]="1";
$radioBtnText[]="Primary";$radioBtnText[]="Spouse";
include("generatRadioPnl.html");
?>
<label for="memo">Notes</label><textarea name="memo" id="memo"></textarea>
<select name="kind"><option value="A">Taxable</option></select>
</span></div>
<script>function toggle(){document.getElementById('box8').style.display='none';}</script>''')
        (self.post / "olt_1099int.php").write_text('''<?
if(!is_numeric($tax_exempt_1099int)) { $err_flag=1; }
if($err_flag == 0) {
 if($tax_exempt_1099int > 0) {
 echo '<form action="olt_1099int_stexempt.php" method="post">';
 include(PROTECTED_PATHQT."html/1099int_stexempt.html");
 } elseif($whose_int == 1) {include(PROTECTED_PATHQT."html/1099intnec.html");}
 else {include(PROTECTED_PATHQT."html/1099intdone.html");}
} else {include(PROTECTED_PATHQT."html/1099int.html");}
''')
        (self.html / "1099int_stexempt.html").write_text('<input name="state_amt" type="number">')
        (self.html / "1099intnec.html").write_text('<input name="nr" type="checkbox">')
        (self.post / "olt_1099int_stexempt.php").write_text('<? include(PROTECTED_PATHQT."html/1099intdone.html");')
        (self.post / "olt_1099intnec.php").write_text('<? include(PROTECTED_PATHQT."html/1099intdone.html");')

    def graph(self):
        return scanner.build_graph("2025", "Individual", "FED", "1099int", "1099intdone.html")

    @staticmethod
    def vectors(texts, **kwargs):
        return [[1.0] + [0.0] * 383 for _ in texts]

    def test_controls_groups_radio_validation_and_conditional_cycles(self):
        graph = self.graph()
        self.assertEqual(len(graph["pages"]), 8)
        page = next(p for p in graph["pages"] if p["id"] == "html/1099int.html")
        controls = {c["name"]: c for c in page["inputs"]}
        amount = controls["tax_exempt_1099int"]
        self.assertEqual(amount["label"], "8. Tax-exempt interest")
        self.assertEqual(amount["parent_groups"], ["box8", "amount-group"])
        self.assertTrue(amount["post_validation"])
        self.assertEqual(controls["memo"]["label"], "Notes")
        self.assertEqual(controls["kind"]["options"], [{"value": "A", "label": "Taxable"}])
        self.assertEqual(controls["whose_int"]["options"][1]["label"], "Spouse")
        self.assertEqual(page["javascript"][0]["referenced_ids"], ["box8"])
        branches = [e for e in graph["edges"] if e["source"] == "oltproc/olt_1099int.php" and e["kind"] == "render"]
        tax_branch = next(e for e in branches if e["target"].endswith("stexempt.html"))
        self.assertIn("($tax_exempt_1099int > 0)", tax_branch["conditions"])
        self.assertEqual(tax_branch["action"], "olt_1099int_stexempt.php")
        fallback = next(e for e in branches if e["target"].endswith("done.html"))
        self.assertIn("!(($tax_exempt_1099int > 0))", fallback["conditions"])
        self.assertIn("!(($whose_int == 1))", fallback["conditions"])
        self.assertFalse(any("commented" in e["target"] for e in graph["edges"]))
        self.assertTrue(any(e["target_status"] == "external" for e in graph["edges"]))

    def test_scope_discovery_protected_root_and_path_boundaries(self):
        self.assertEqual(scanner.options("2025", "Individual", "FED")["forms"][0]["name"], "1099int")
        self.assertEqual(scanner.options("2025", "Individual", "CA")["forms"], [])
        for filename in ("../secret.html", "C:/secret.html", "/secret.html"):
            with self.subTest(filename=filename), self.assertRaises(ValueError):
                scanner.safe_file(self.html, filename)
        with self.assertRaises(ValueError):
            scanner.build_graph("2025", "Individual", "CA", "1099int", "1099intdone.html")
        with self.assertRaisesRegex(ValueError, "belongs to form '1099int'.*'1040x'"):
            scanner.build_graph("2025", "Individual", "FED", "1040x", "1099intdone.html")
        scanner.validate_starting_form('1099int', '1099intdone.html')
        scanner.validate_starting_form('1099int', '1099intsummary.html')
        scanner.validate_starting_form('1099int', '1099int.html')

    def test_php_html_and_javascript_comments_do_not_contribute_records(self):
        path = self.html / "comments.html"
        path.write_text('''<!--
<input name="html_commented">
<? include(PROTECTED_PATHQT.'html/1099int_html_comment.html');
$multipleInputArray['Delete']='olt_1099int_commented.php?id='.$id;
?>
<script>document.getElementById('html_commented');</script>
-->
<?
// include(PROTECTED_PATHQT.'html/1099int_slash_comment.html');
# include(PROTECTED_PATHQT.'html/1099int_hash_comment.html');
/* include(PROTECTED_PATHQT.'html/1099int_block_comment.html');
$InputArray['name']='php_commented';OLTGenerateInputGrp($InputArray);
*/
$InputArray['name']='active';
$InputArray['labelText']='https://example.test/*literal*/';
$InputArray['inputType']='labelWithTextBox';
OLTGenerateInputGrp($InputArray);
include(PROTECTED_PATHQT.'html/1099int.html');
?>
<input name="visible">
<script>
// document.getElementById('js_line_commented');
/* document.getElementById('js_block_commented'); */
const url = "https://example.test/path/*literal*/";
const pattern = /https?:\\/\\/example/;
document.getElementById('visible').disabled=false;
</script>''')
        parsed = scanner.parse_file(path)
        self.assertEqual({i["name"] for i in parsed["inputs"]}, {"active", "visible"})
        self.assertEqual([i["target"] for i in parsed["includes"]], ['html/1099int.html'])
        self.assertEqual(parsed["navigation"], [])
        self.assertEqual(len(parsed["javascript"]), 1)
        self.assertEqual(parsed["javascript"][0]["referenced_ids"], ["visible"])
        self.assertIn('https://example.test/path/*literal*/', parsed["javascript"][0]["code"])
        self.assertEqual(next(i for i in parsed["inputs"] if i["name"] == "active")["label"], 'https://example.test/*literal*/')
        expected_line = path.read_text().splitlines().index('<input name="visible">') + 1
        self.assertEqual(next(i for i in parsed["inputs"] if i["name"] == "visible")["source_line"], expected_line)

    def test_legacy_php_comments_and_commented_echoes_do_not_add_edges(self):
        path = self.post / "legacy.php"
        path.write_text('''<?
/* ?> <input name="old_control"> <?
include(PROTECTED_PATHQT.'html/old.html');
*/
// echo '<form action="old.php"><input name="old_echo">';
include(PROTECTED_PATHQT.'html/active.html');
echo '<!-- <form action="comment.php"><input name="old_markup"> -->';
?>''')
        parsed = scanner.parse_file(path)
        self.assertEqual([i['target'] for i in parsed['includes']], ['html/active.html'])
        self.assertEqual(parsed['inputs'], [])
        self.assertEqual(parsed['forms'], [])

    def test_javascript_comment_mask_preserves_templates_regex_and_division(self):
        code = '''const url="https://example.test"; const regex=/[/*]foo\\/\\//g;
const value=amount / 2; // removed navigation
const template=`literal // text ${ /* removed block */ amount + 1 }`;
/* $('#YesRemove').attr('href', $(this).data('id')); */
document.getElementById('active');'''
        active = scanner.javascript_without_comments(code)
        self.assertEqual(len(active), len(code))
        self.assertEqual(active.count('\n'), code.count('\n'))
        self.assertIn('"https://example.test"', active)
        self.assertIn('/[/*]foo\\/\\//g', active)
        self.assertIn('amount / 2', active)
        self.assertIn('literal // text', active)
        self.assertNotIn('removed block', active)
        self.assertNotIn('YesRemove', active)

    def test_dynamic_combo_options_repetition_and_echoed_controls(self):
        path = self.html / "dynamic.html"
        path.write_text('''<div id="states"><?
for($i=1;$i<3;$i++) {
$InputArray['name']='state'.$i;
$InputArray['inputType']='SELECTCOMBO';
$InputArray['opt']['option1']['value']='CA';
$InputArray['opt']['option1']['text']='California';
OLTGenerateInputGrp($InputArray);
}
echo '<input type="hidden" name="step" value="save">';
?></div>''')
        parsed = scanner.parse_file(path)
        combo = next(c for c in parsed["inputs"] if c["input_type"] == "SELECTCOMBO")
        self.assertEqual(combo["options"], [{"value": "CA", "label": "California"}])
        self.assertTrue(combo["repetition"])
        hidden = next(c for c in parsed["inputs"] if c["name"] == "step")
        self.assertEqual(hidden["parent_groups"], ["states"])
        self.assertIn("step", parsed["groups"][0]["input_names"])

    def test_edit_and_confirmed_delete_keep_record_id_and_cancel_without_request(self):
        with (self.html / "1099intdone.html").open("a") as file:
            file.write('''<? if($rows > 0) { while($row = db_fetchrow($result)) {
$multipleInputArray['Edit']='../oltproc/olt_1099intdone.php?id='.$id.'&step=editint';
$multipleInputArray['Delete']='../oltproc/olt_1099int_delete.php?id='.$id.'&step=yes';
include('multipleEntrySnippetBody.html');
}} ?>''')
        with (self.post / "olt_1099intdone.php").open("a") as file:
            file.write('''if($step == 'editint') {include(PROTECTED_PATHQT.'html/1099int.html');}
include('olt_pageftr.php');''')
        (self.html / "multipleEntrySnippetBody.html").write_text('''<a title="EDIT" href="<? echo $EditUrl; ?>">Edit</a>
<a title="DELETE" data-toggle="modal" href="#RemoveEntry" data-id="<? echo $DeleteUrl; ?>">Delete</a>''')
        (self.post / "olt_pageftr.php").write_text("<? include('../inc/confirmation.php');")
        inc = self.post.parent / "inc"
        inc.mkdir()
        (inc / "confirmation.php").write_text('''<div id="RemoveEntry"><a href="" id="YesRemove">Yes</a>
<button data-dismiss="modal">No</button></div>
<script>$(document).on('click', '.remove', function(){var url=$(this).data('id');$('#YesRemove').attr('href',url);});</script>''')
        (self.post / "olt_1099int_delete.php").write_text('''<?
if($step == 'yes') {$query="delete from int1099 where int1099_ID=(?)"; db_sql_BuildParamArray($id,'int1099::int1099_ID');}
echo '<form action="olt_1099intdone.php" method="post">';
include(PROTECTED_PATHQT.'html/1099intdone.html');''')
        graph = self.graph()
        edit = next(e for e in graph["edges"] if e["kind"] == "edit")
        self.assertEqual(edit["query_parameters"], {"id": "{$id}", "step": "editint"})
        self.assertEqual(edit["selected_record_id"], "{$id}")
        self.assertEqual(edit["request_method"], "GET")
        opened = next(e for e in graph["edges"] if e["kind"] == "delete")
        self.assertEqual(opened["target"], "html/1099intdone.html#RemoveEntry")
        self.assertFalse(opened["server_request"])
        yes = next(e for e in graph["edges"] if e["kind"] == "confirm_delete")
        self.assertEqual(yes["query_parameters"], {"id": "{$id}", "step": "yes"})
        self.assertTrue(yes["server_request"])
        cancel = next(e for e in graph["edges"] if e["kind"] == "cancel_delete")
        self.assertFalse(cancel["server_request"])
        self.assertEqual(cancel["target"], "html/1099intdone.html")
        handler = next(p for p in graph["pages"] if p["id"] == yes["target"])
        self.assertEqual(handler["method"], "GET")
        self.assertTrue(any("delete from int1099" in s["source"] for s in handler["sql"]))
        self.assertTrue(any(e["source"] == yes["target"] and e["target"] == "html/1099intdone.html" for e in graph["edges"]))
        store.save(graph, embedder=self.vectors)
        loaded = store.load("2025", "Individual", "FED", "1099int")
        self.assertEqual(loaded["manifest"]["confirmations"], 1)
        self.assertTrue(any(e["kind"] == "cancel_delete" for e in loaded["edges"]))
        records = list(store.records_for(graph))
        self.assertEqual(len([r for r in records if r["kind"] == "action"]), 2)

    def test_unresolved_confirmation_is_reported_without_inventing_a_modal(self):
        with (self.html / "1099intdone.html").open("a") as file:
            file.write("<? $multipleInputArray['Delete']='olt_1099int.php?id='.$id.'&step=yes'; include('entryRow.html'); ?>")
        (self.html / "entryRow.html").write_text('<a title="DELETE" data-toggle="modal" href="#MissingModal">Delete</a>')
        graph = self.graph()
        self.assertFalse(any(p["method"] == "CONFIRMATION" for p in graph["pages"]))
        self.assertTrue(any("Yes/No binding" in warning for warning in graph["warnings"]))

    def test_qdrant_roundtrip_search_and_failed_update_keeps_previous_generation(self):
        graph = self.graph()
        first = store.save(graph, embedder=self.vectors)
        loaded = store.load("2025", "Individual", "FED", "1099int")
        self.assertEqual(len(loaded["pages"]), 8)
        self.assertEqual(loaded["embedding_model"], "BAAI/bge-small-en-v1.5")
        result = store.search("2025", "Individual", "FED", "1099int", "interest", embedder=self.vectors)
        self.assertTrue(result)
        self.assertIn("data", result[0]["metadata"])
        with self.assertRaises(ValueError):
            store.save(graph, embedder=self.vectors)
        with self.assertRaises(RuntimeError):
            store.save(graph, update=True, embedder=lambda texts: (_ for _ in ()).throw(RuntimeError("Model unavailable")))
        self.assertEqual(store.load("2025", "Individual", "FED", "1099int")["generation"], first["generation"])
        graph["pages"][0]["inputs"] = []
        second = store.save(graph, update=True, embedder=self.vectors)
        self.assertNotEqual(first["generation"], second["generation"])
        self.assertEqual(store.load("2025", "Individual", "FED", "1099int")["pages"][0]["inputs"], [])

    def test_routes_validate_requests_and_render_page(self):
        app = Flask(__name__, template_folder=str(Path(scanner.existing.__file__).parent / "templates"))
        app.add_url_rule("/", endpoint="dashboard", view_func=lambda: "")
        # Base layout links refer to existing dashboard endpoints.
        for endpoint in ("vectordb", "query_chunk_page", "file_grabber", "analyse_user_id", "analyse_input_validation", "analyse_post_file_included_page", "analyse_get_file_included_page", "analyse_mo_issues", "email_vectordb", "email_sql", "email_post_file_included"):
            app.add_url_rule("/" + endpoint, endpoint=endpoint, view_func=lambda: "")
        register(app)
        client = app.test_client()
        base = "/phphelper/software-flow"
        self.assertEqual(client.get(base + "/").status_code, 200)
        self.assertEqual(client.get(base + "/api/options?taxyear=2025").status_code, 200)
        self.assertEqual(client.get(base + "/api/options?taxyear=../").status_code, 400)
        self.assertEqual(client.get(base + "/api/view?form=missing").status_code, 404)
        self.assertEqual(client.post(base + "/api/build", json={"form": "1099int", "starting_page": "../secret.html"}).status_code, 400)
        mismatch=client.post(base + "/api/build", json={"form": "1040x", "starting_page": "1099intdone.html"})
        self.assertEqual(mismatch.status_code,400)
        self.assertIn("belongs to form '1099int'",mismatch.json['error'])
        from software_flow import routes
        with patch.object(routes, "Thread") as thread:
            response = client.post(base + "/api/build", json={"form": "1099int", "starting_page": "1099intdone.html"})
            self.assertEqual(response.status_code, 202)
            thread.return_value.start.assert_called_once()
            job_id = response.json["job_id"]
            self.assertEqual(client.get(base + "/api/status/" + job_id).json["status"], "running")
            self.assertEqual(client.post(base + "/api/build", json={"form": "1099int", "starting_page": "1099intdone.html"}).status_code, 409)
            with routes.JOB_LOCK:
                routes.JOBS.pop(job_id)


if __name__ == "__main__":
    unittest.main()
