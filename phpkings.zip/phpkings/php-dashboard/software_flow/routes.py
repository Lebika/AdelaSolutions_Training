"""Separate dashboard routes and background build lifecycle."""
from threading import Lock, Thread
import logging
from uuid import uuid4

from flask import Blueprint, jsonify, render_template, request

from . import scanner, store
from .visibility import explain_graph

blueprint = Blueprint("software_flow", __name__, template_folder="templates", static_folder="static",
                      url_prefix="/phphelper/software-flow")
JOBS = {}
JOB_LOCK = Lock()


def selection(data):
    return scanner.scope(data.get("taxyear", "2025"), data.get("product", "Individual"), data.get("fed_or_state", "FED"))


@blueprint.route("/")
def page():
    years = set()
    for root in (scanner.existing.SITE_ASP_ROOT, scanner.existing.SITE_ASP_PROTECTED_ROOT):
        if root.is_dir():
            years.update(p.name for p in root.iterdir() if p.is_dir() and p.name.isdigit() and len(p.name) == 4)
    return render_template("software_flow.html", years=sorted(years or {"2025"}, reverse=True),
                           products=scanner.PRODUCTS, states=sorted(scanner.existing.STATES))


@blueprint.route("/api/options")
def options():
    try:
        selected = selection(request.args)
        return jsonify(ok=True, **scanner.options(*selected), builds=store.list_builds(*selected))
    except ValueError as exc:
        return jsonify(ok=False, error=str(exc)), 400


def set_job(job_id, **updates):
    with JOB_LOCK:
        JOBS[job_id].update(updates)


def run_build(job_id, selected, form, starting_page, update):
    def progress(message):
        set_job(job_id, message=message)
    try:
        graph = scanner.build_graph(*selected, form, starting_page, progress=progress)
        manifest = store.save(graph, update=update, progress=progress)
        set_job(job_id, status="complete", message="Recording saved", result=manifest)
    except Exception as exc:
        logging.getLogger(__name__).exception("Software flow build failed")
        set_job(job_id, status="failed", message=str(exc))


@blueprint.route("/api/build", methods=["POST"])
def build():
    try:
        data = request.get_json(silent=True) or {}
        selected = selection(data)
        form, start = str(data.get("form", "")).strip(), str(data.get("starting_page", "")).strip()
        if data.get("mode", "create") not in {"create", "update"}:
            raise ValueError("Choose Create or Update")
        update = data.get("mode") == "update"
        if not form:
            raise ValueError("Choose a form")
        if not start and update:
            start = store.load(*selected, form)["starting_page"].removeprefix("html/")
        if not start:
            raise ValueError("Choose or enter a starting HTML filename")
        scanner.validate_starting_form(form, start)
        path = scanner.safe_file(scanner.roots(*selected[:2])[0], start)
        if not path.is_file():
            raise ValueError("Starting page does not exist")
        store.directory(*selected, form)
        key = (*selected, form)
        with JOB_LOCK:
            if any(job["key"] == key and job["status"] == "running" for job in JOBS.values()):
                return jsonify(ok=False, error="This form already has a running job"), 409
            # Retain recent job notices without unbounded process memory growth.
            completed = [j for j, value in JOBS.items() if value["status"] != "running"]
            for old in completed[:-100]:
                JOBS.pop(old)
            job_id = uuid4().hex
            JOBS[job_id] = {"key": key, "status": "running", "message": "Reading source files"}
        Thread(target=run_build, args=(job_id, selected, form, start, update), daemon=True).start()
        return jsonify(ok=True, job_id=job_id), 202
    except (ValueError, FileNotFoundError) as exc:
        return jsonify(ok=False, error=str(exc)), 400


@blueprint.route("/api/status/<job_id>")
def status(job_id):
    with JOB_LOCK:
        job = JOBS.get(job_id)
        if job is None:
            return jsonify(ok=False, error="Job not found; the dashboard may have restarted"), 404
        return jsonify(ok=True, **job)


@blueprint.route("/api/view")
def view():
    try:
        graph=explain_graph(store.load(*selection(request.args), request.args.get("form", "")))
        return jsonify(ok=True, graph=graph)
    except FileNotFoundError as exc:
        return jsonify(ok=False, error=str(exc)), 404
    except ValueError as exc:
        return jsonify(ok=False, error=str(exc)), 400


@blueprint.route("/api/search", methods=["POST"])
def search():
    try:
        data = request.get_json(silent=True) or {}
        results=store.search(*selection(data), data.get("form", ""), data.get("query", ""))
        if any(item["metadata"].get("kind")=="input" for item in results):
            graph=explain_graph(store.load(*selection(data), data.get("form", "")))
            pages={page["id"]:page for page in graph["pages"]}
            for item in results:
                metadata=item["metadata"]
                page=pages.get(metadata.get("page_id"))
                index=metadata.get("input_index")
                if metadata.get("kind")=="input" and page and isinstance(index,int) and 0<=index<len(page["inputs"]):
                    metadata["data"]=page["inputs"][index]
        return jsonify(ok=True, results=results)
    except FileNotFoundError as exc:
        return jsonify(ok=False, error=str(exc)), 404
    except ValueError as exc:
        return jsonify(ok=False, error=str(exc)), 400
    except Exception as exc:
        return jsonify(ok=False, error=str(exc)), 500
