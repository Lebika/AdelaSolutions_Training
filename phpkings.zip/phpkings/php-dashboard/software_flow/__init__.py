"""Software page flow recording, isolated from the existing scanner stores."""


def register(app):
    from .routes import blueprint
    app.register_blueprint(blueprint)
