# Software flow implementation

Reference: `documentation/Software codewise flow/Software flow.docx`.

1. Discover tax years, products, FED/state form names and done/summary entry pages from configured source folders. Accept a custom starting HTML filename.
2. Parse PHP with tree-sitter without executing source. Record literal HTML controls and OLT-generated controls, options, labels, source lines, validation evidence, parent groups and JavaScript.
3. Traverse form handlers and conditional input-page includes. Preserve branch predicates, form actions, hidden data, error paths and SQL evidence. Include summary Edit/Delete actions, selected-record URL parameters, shared confirmation modals, Yes requests, No/close cancellation and return-to-summary paths. Mark exits to other forms rather than following the entire tax return.
4. Store page, input, script and transition records in a separate local Qdrant database under `phpdata/software flow`, using `BAAI/bge-small-en-v1.5`. Publish complete generations and retain the previous generation if an update fails.
5. Add Software Flow Create/View/Search/Update navigation, background job progress, metadata inspection and a source-linked flow chart.
6. Verify with isolated source fixtures, Qdrant persistence/search tests, dashboard route tests and the real 2025 1099-INT example. Report unresolved dynamic references rather than inventing destinations.

## Scope and operation

This is static source analysis. Branches are recorded as source expressions; PHP/SQL/JavaScript is never executed. Dynamic targets that cannot be resolved statically are reported. Followed HTML pages belong to the selected form family; external form destinations remain graph boundaries. Explicit entry pages may be chosen within the selected HTML folder. No scanner database is required beforehand.

Install dashboard requirements (including `fastembed`) into the dashboard Python environment. The first build/search downloads the BGE model unless it is cached. No placeholder or hash embeddings are used. Model/cache failures fail the job without replacing the current build.

Products currently map to the source layouts used in this repository: Individual (protected HTML for 2025/2026, public PHP handlers) and OLTPRO (year/OLTPRO folders). FED/state classification uses the existing scanner metadata rules.

Updates rescan the entire selected form so removed inputs and obsolete branches disappear together. Builds persist an immutable generation with a `current.json` pointer, source hashes, timestamps, schema/model identifiers and an inspection snapshot. View reads Qdrant payloads; the snapshot provides a portable audit/export. Unreferenced generations are retained for recovery.

## Edit / Delete scenario

`$multipleInputArray['Edit']` and `['Delete']` URL expressions are parsed without evaluating PHP. Dynamic record IDs remain symbolic (`{$id}`); static values such as `step=editint` and `step=yes` remain intact. Each navigation record retains the expression, source line, branch predicates, loop context and request parameters.

For 2025 1099-INT, the summary row renderer opens `#DeleteModal`. The recorder traces the handler's footer include to `inc/oltDelConfirmation.php`, verifies the Yes link's JavaScript URL binding and records the modal as a separate confirmation node. Yes calls `olt_1099int_delete_ind.php` by GET with the selected record ID; No/close remains on the summary without a server request. The delete handler's SQL and its render back to the summary are recorded. Edit calls `olt_1099intdone.php` by GET with `step=editint`; normal saves remain POST requests.

Source-file counts exclude modal nodes. Confirmation source files, source lines, fingerprints, controls and JavaScript remain available in node metadata. If a modal trigger exists but its implementation cannot be found, the recorder flags the unresolved confirmation instead of creating Yes/No behavior.

## Comment filtering

PHP `//`, `#`, and `/* ... */` comments and HTML `<!-- ... -->` sections are masked before flow extraction. PHP snippets inside HTML-commented sections are excluded as well. JavaScript line/block comments are masked before recording script behavior, referenced element IDs and confirmation URL bindings. Markers inside quoted strings, URLs, templates and regular-expression literals are preserved. Source byte offsets and line numbers remain stable; fingerprints still reflect the original file.

After restarting the dashboard with this change, use Update for previously recorded forms so their stored graph and vectors are regenerated. The prepared 2025 Individual/FED 1099-INT recording has been regenerated. Ten focused tests pass, including comment-filtering regression cases.

## Validation

- Focused tests cover guarded/cyclic page flows, controls and groups, dynamic dropdowns and repeated inputs, Edit/Delete query parameters, modal Yes/No behavior, missing modal definitions, Qdrant roundtrips, semantic-search plumbing, failed-update preservation and route validation.
- Real 2025 Individual/FED 1099-INT recording uses BGE embeddings and is stored separately under `phpdata/software flow/2025/Individual/FED/1099int`.
- The legacy source still references a missing `1099int_delete_ind.html`; this is reported separately from the verified shared Delete modal. The delete handler also contains an unresolved dynamic OLTPRO include, retained as a source warning.
- Existing dashboard regression results: 37/38 passed. The unchanged Input Validation template says `variable-flow graph`, while its existing test expects `Tree-sitter variable-flow graph`.
- Flask page, options, static assets and saved-data endpoints were checked, and the JavaScript passed syntax validation. Interactive visual QA could not run because no browser connection is available in this session.

## Use

**Visibility and input behavior** appears inside each input's details. It explains checkbox checked/unchecked states, radio/dropdown selections, enable/disable and read-only changes, and group show/hide behavior in user sentences. The page's **JavaScript visibility behavior** section lists all derived explanations. Each explanation identifies affected fields and offers source evidence. These are derived by a bounded JavaScript AST interpreter; application JavaScript is never executed. Missing functions, unresolved values and unsupported control-flow paths are reported rather than filled in. Existing saved recordings receive these explanations when loaded, so no vector rebuild is needed. New builds also retain the derived metadata. The JavaScript grammar dependency is included in dashboard requirements.

Validation for this addition: 23 Python tests and 5 display-model tests pass, including checked/unchecked enablement, Yes/No visibility, radio IDs, callbacks, nested helpers, comments, early returns, jQuery controls, native attributes and unresolved server values. The existing 1099-INT view endpoint was verified to return the state-exempt Yes/No explanations for both the question and the affected state fields.

Select the matching form before loading or building a recording. A done/summary filename must match that selected form; for example, `1099intdone.html` requires `1099int`, not `1040x`. Builds now reject mismatches before launching the background job. Existing mismatched recordings display a notice and offer to load the matching saved form when available.

After loading, the page selector lists input pages, confirmation dialogs and PHP handlers. Select an input page and use **Inputs** for its controls or **Next pages and conditions** for conditional outcomes. Save transitions follow the PHP handler to the rendered destination, retaining source predicates and location. Input and option labels are shown alongside the branch logic; each recorded destination has an **Open page and inputs** button. Chart arrows and the complete transition list also show readable transition details, with raw data collapsed under Advanced.

The 2025 Individual/FED `1099int` recording has four input pages: `1099intdone.html`, `1099int.html`, `1099int_stexempt.html` and `1099intnec.html`. Ten backend tests and five metadata/navigation display-model tests pass.

The input list opens a readable details card with Label, Name, Type, HTML ID, Page, Source line and Parent groups. Options are shown as a table of labels and submitted values. Available validation messages, visibility conditions, repeated-input context and events have separate sections. Raw JSON is collapsed under `Advanced: raw input data`. Missing explicit labels are distinguished from nearby page text. The same readable cards are used for input search results. This display works with existing recordings without regenerating embeddings.

Restart the dashboard using its existing launch procedure, then open **Software Flow** from the sidebar (`/phphelper/software-flow/`). Select tax year, product, FED/state and form. Create records a new form; Update rescans an existing one; View shows its chart, inputs, actions, warnings and complete metadata; Search queries the separate BGE vector store. The prepared example is tax year **2025**, product **Individual**, jurisdiction **FED**, form **1099int**.
