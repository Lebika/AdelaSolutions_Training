"""Explain recorded JavaScript using a bounded AST interpreter, never a JS runtime."""
from __future__ import annotations

from dataclasses import dataclass, field
import re

from tree_sitter import Language, Parser
import tree_sitter_javascript

LANGUAGE = Language(tree_sitter_javascript.language())
HIDDEN_CLASSES = {"is-hidden", "hidden", "d-none"}


def primitive_equal(left, right, strict=False):
    def number(value):
        if value is None: return 0
        if isinstance(value, bool): return int(value)
        if isinstance(value, str): return float(value.strip() or '0')
        return value
    numeric=lambda value:isinstance(value,(int,float)) and not isinstance(value,bool)
    if strict:
        return left==right and (type(left)==type(right) or (numeric(left) and numeric(right)))
    if left is None or right is None:
        return left is right
    if isinstance(left,bool) or isinstance(right,bool) or (numeric(left) and isinstance(right,str)) or (numeric(right) and isinstance(left,str)):
        try: return number(left)==number(right)
        except (ValueError,TypeError): return False
    return left==right


def value_text(value):
    if isinstance(value, list):
        return value_text(value[-1]) if value else ""
    if isinstance(value, dict):
        return value_text(value.get("value", value.get("expression", "")))
    return "" if value is None else str(value)


def label(control):
    value = control.get("label") or control.get("nearby_text") or control.get("name") or control.get("id") or "unnamed input"
    value = re.sub(r"<[^>]*>", " ", value)
    value = re.sub(r'\$?"\s*\.\s*\$\w+\s*\.\s*"', '[value]', value)
    match = re.match(r'^"([^"\n]+)"\s*\.', value)
    if match:
        value = match[1] + " (repeated field)"
    if not re.search(r"[A-Za-z0-9]", value):
        value = control.get("name") or control.get("id") or "unnamed input"
    if value == control.get('name') and not control.get('label'):
        dynamic=bool(re.search(r'\$\w+',value))
        value=re.sub(r'\$\w+','',value).replace('_',' ').strip('" .')
        if dynamic: value+=' (generated name)'
    return re.sub(r"\s+", " ", value).strip()


@dataclass(frozen=True)
class Unknown:
    description: str


@dataclass(frozen=True)
class Element:
    key: str
    kind: str = "id"
    path: tuple = ()
    descendants: bool = False


@dataclass(frozen=True)
class Event:
    target: Element


@dataclass
class State:
    env: dict = field(default_factory=dict)
    guards: list = field(default_factory=list)
    stopped: bool = False

    def fork(self):
        return State(dict(self.env), list(self.guards),self.stopped)


class Explainer:
    def __init__(self, page):
        self.page, self.inputs = page, page.get("inputs", [])
        self.functions, self.globals, self.bindings = {}, [], []
        self.rules, self.notes = [], []
        self.steps, self.depth = 0, 0
        self.initializing = False
        self.context = {}
        self.identities = {}
        for control in self.inputs:
            if control.get("id"):
                self.identities[control["id"]] = (control, None)
            attrs = control.get("attributes", {})
            ids = next((values for key, values in attrs.items() if key.lower().replace("$", "") == "radiobtnid[]"), [])
            for index, option in enumerate(control.get("options", [])):
                option_id = option.get("id") or (value_text(ids[index]) if index < len(ids) else "")
                if option_id:
                    self.identities[option_id] = (control, str(option.get("value", "")))
        parser = Parser(LANGUAGE)
        for script in page.get("javascript", []):
            source = script.get("code", "").encode("utf-8")
            root = parser.parse(source).root_node
            line = script.get("line", 1)
            for node in root.named_children:
                if node.type == "function_declaration":
                    self.functions[self.text(source, node.child_by_field_name("name"))] = (source, node, line)
                elif node.type in {"lexical_declaration", "variable_declaration"}:
                    self.globals.append((source, node, line))
            self.find_bindings(source,root,line)

    def find_bindings(self,source,root,line):
        pending=[root]
        while pending:
            node=pending.pop()
            pending.extend(node.named_children)
            if node.type!='call_expression': continue
            function=node.child_by_field_name('function')
            if function is None or function.type!='member_expression': continue
            method=self.text(source,function.child_by_field_name('property'))
            if method not in {'on','addEventListener','click','change','input'}: continue
            args=node.child_by_field_name('arguments').named_children
            event='on'+method if method in {'click','change','input'} else 'on'+self.text(source,args[0]).strip("\"'") if args else ''
            if event not in {'onclick','onchange','oninput','onkeyup','onblur'}: continue
            callback=args[-1] if args else None
            if callback is None: continue
            owner=self.text(source,function.child_by_field_name('object'))
            key=re.search(r"(?:getElementById|querySelector|\$|jQuery)\(\s*['\"](#?[\w:-]+)['\"]",owner)
            if method=='on' and len(args)>=3:
                selector=self.text(source,args[1]).strip("\"'")
                if selector.startswith('#'): key=re.fullmatch(r'#([\w:-]+)',selector)
            if not key: continue
            identity=key[1].lstrip('#')
            control,option_value=self.identities.get(identity,(None,None))
            if control is None: continue
            if callback.type=='identifier':
                original=self.text(source,callback)
                if original not in self.functions: continue
                name='__recorded_binding_'+str(len(self.bindings))
                self.functions[name]=self.functions[original]
                handler=name+'(__recorded_event)'
            elif callback.type in {'function_expression','arrow_function'}:
                name='__recorded_binding_'+str(len(self.bindings))
                self.functions[name]=(source,callback,line)
                handler=name+'(__recorded_event)'
            else: continue
            self.bindings.append((control,event,handler,option_value))

    @staticmethod
    def text(source, node):
        return source[node.start_byte:node.end_byte].decode("utf-8", errors="replace") if node else ""

    def control(self, element):
        if element.kind == "id":
            return self.identities.get(element.key, (None, None))
        return next(((i, None) for i in self.inputs if i.get("name") == element.key), (None, None))

    def affected(self, element):
        control, _ = self.control(element)
        if control and not element.descendants:
            return [control]
        return [i for i in self.inputs if element.key in i.get("parent_groups", [])]

    def target_label(self, element):
        control, _ = self.control(element)
        if control and not element.descendants:
            return f'“{label(control)}”'
        affected = [item for item in self.affected(element) if item.get("input_type", "").lower() not in {"hidden", "button", "submit"}]
        if affected:
            names = ', '.join(f'“{label(item)}”' for item in affected[:2])
            more = f' and {len(affected)-2} other inputs' if len(affected)>2 else ''
            return f'the section containing {names}{more}'
        return f'the “{element.key}” section'

    def read_property(self, element, prop):
        control, option = self.control(element)
        active = self.context["control"]
        if control is active:
            if prop == "checked":
                return self.context.get("checked", option == self.context.get("value")) if option is None else option == self.context.get("value")
            if prop == "value":
                return self.context.get("value", Unknown(f'the value of {self.target_label(element)}'))
        if prop == "checked":
            if control and option is not None:
                option_label=next((item.get('label') for item in control.get('options',[]) if str(item.get('value'))==option),option)
                return Unknown(f'“{label({"label":option_label})}” is selected for “{label(control)}”')
            return Unknown(f'{self.target_label(element)} is checked')
        if prop == "value":
            return Unknown(f'the value of {self.target_label(element)}')
        if prop in {'disabled','readOnly','hidden'}:
            return Unknown(f'{self.target_label(element)} is '+{'disabled':'disabled','readOnly':'read-only','hidden':'hidden'}[prop])
        return Unknown(f'{self.target_label(element)}.{".".join(element.path + (prop,))}')

    def evaluate(self, source, node, state, line):
        if node is None:
            return Unknown("an unavailable value")
        self.steps += 1
        if self.steps > 4000:
            return Unknown("the analysis limit was reached")
        kind, raw = node.type, self.text(source, node)
        if kind in {"string", "string_fragment"}:
            value = raw[1:-1] if kind == "string" else raw
            return Unknown("a server-provided or blank value") if len(value)>2 and not value.strip() else value
        if kind == "number":
            try:
                return float(raw) if "." in raw else int(raw)
            except ValueError:
                return Unknown(raw)
        if kind in {"true", "false"}:
            return kind == "true"
        if kind in {"null", "undefined"}:
            return None
        if kind in {"identifier", "shorthand_property_identifier"}:
            return state.env.get(raw, Unknown(raw))
        if kind == "this":
            return state.env.get('__this__',Unknown('the enclosing this context'))
        if kind == "parenthesized_expression":
            return self.evaluate(source, node.named_children[0], state, line)
        if kind == "member_expression":
            obj, prop = node.child_by_field_name("object"), self.text(source, node.child_by_field_name("property"))
            base = self.evaluate(source, obj, state, line)
            if isinstance(base,Event):
                return base.target if prop in {'target','currentTarget'} else Unknown(raw)
            if isinstance(base, Element):
                if prop in {"checked", "value", "disabled", "readOnly", "hidden", "display", "visibility"}:
                    return self.read_property(base, prop)
                return Element(base.key, base.kind, base.path + (prop,), base.descendants)
            if re.fullmatch(r"document\.(?:forms\[\d+\]|form\w*)", self.text(source, obj)):
                return Element(prop, "name")
            return Unknown(raw)
        if kind == "subscript_expression":
            obj = self.evaluate(source, node.child_by_field_name("object"), state, line)
            return obj if isinstance(obj, Element) else Unknown(raw)
        if kind == "unary_expression":
            operand = self.evaluate(source, node.child_by_field_name("argument"), state, line)
            if self.text(source, node.child_by_field_name("operator")) == "!":
                return Unknown("not (" + operand.description + ")") if isinstance(operand, Unknown) else not bool(operand)
            return Unknown(raw)
        if kind == "binary_expression":
            left = self.evaluate(source, node.child_by_field_name("left"), state, line)
            right = self.evaluate(source, node.child_by_field_name("right"), state, line)
            operator = self.text(source, node.child_by_field_name("operator"))
            if operator == "&&" and (left is False or right is False):
                return False
            if operator == "||" and (left is True or right is True):
                return True
            if isinstance(left, Unknown) or isinstance(right, Unknown):
                describe = lambda value: value.description if isinstance(value, Unknown) else str(value)
                phrase = f'{describe(left)} {operator} {describe(right)}'
                phrase = re.sub(r'\.style\.display\s*(?:===|==)\s*block', ' is currently shown', phrase)
                phrase = re.sub(r'\.style\.display\s*(?:===|==)\s*none', ' is currently hidden', phrase)
                return Unknown(phrase)
            if operator in {"==", "!=", "===", "!=="}:
                same = primitive_equal(left,right,strict=operator in {'===','!=='})
                return not same if operator.startswith("!") else same
            if operator == "&&":
                return bool(left) and bool(right)
            if operator == "||":
                return bool(left) or bool(right)
            try:
                if operator == ">": return float(left) > float(right)
                if operator == "<": return float(left) < float(right)
                if operator == ">=": return float(left) >= float(right)
                if operator == "<=": return float(left) <= float(right)
            except (ValueError, TypeError):
                pass
            return Unknown(raw)
        if kind == "ternary_expression":
            test = self.evaluate(source, node.child_by_field_name("condition"), state, line)
            if not isinstance(test, Unknown):
                return self.evaluate(source, node.child_by_field_name("consequence" if test else "alternative"), state, line)
            return test
        if kind == "call_expression":
            return self.call(source, node, state, line)
        if kind == "assignment_expression":
            left = node.child_by_field_name("left")
            value = self.evaluate(source, node.child_by_field_name("right"), state, line)
            if left.type == "identifier":
                state.env[self.text(source, left)] = value
            elif left.type == "member_expression":
                base = self.evaluate(source, left.child_by_field_name("object"), state, line)
                prop = self.text(source, left.child_by_field_name("property"))
                if isinstance(base, Element):
                    effect = None
                    if prop in {"disabled", "readOnly", "hidden"} and not isinstance(value, (Unknown,Element)):
                        effect = {"disabled": ("disabled", "enabled"), "readOnly": ("read-only", "editable"), "hidden": ("hidden", "shown")}[prop][0 if bool(value) else 1]
                    elif prop == "display" and "style" in base.path:
                        effect = "hidden" if value == "none" else "shown" if value in {"block", "inline", "inline-block", "flex", "grid", "table", "table-row"} else None
                    elif prop == "visibility" and "style" in base.path:
                        effect = "hidden" if value == "hidden" else "shown" if value == "visible" else None
                    if effect:
                        self.emit(base, effect, source, node, state, line)
                    elif prop in {"disabled", "readOnly", "hidden", "display", "visibility"} and isinstance(value, Unknown):
                        self.note("A visibility or enabled-state change depends on a value that cannot be resolved from the recorded scripts.")
            return value
        return Unknown(raw)

    def call(self, source, node, state, line):
        function = node.child_by_field_name("function")
        name = self.text(source, function)
        args_node = node.child_by_field_name("arguments")
        arg_nodes = args_node.named_children if args_node else []
        args = [self.evaluate(source, arg, state, line) for arg in arg_nodes]
        if name in {'$','jQuery'} and args and isinstance(args[0],Element):
            return args[0]
        if name in {"document.getElementById", "document.getElementsByName", "document.querySelector", "document.querySelectorAll", "$", "jQuery"} and args and isinstance(args[0], str):
            selector = args[0]
            if name == "document.getElementById": return Element(selector)
            if name == "document.getElementsByName": return Element(selector, "name")
            match = re.fullmatch(r"#([\w:-]+)(\s+.*)?", selector)
            if match:
                return Element(match[1], descendants=bool(match[2]))
            return Unknown(name + " selector")
        if name in self.functions and self.depth >= 8:
            self.note('The nested function-call limit was reached; further visibility changes were not evaluated.')
            return Unknown('an unresolved function result')
        if name in self.functions:
            if self.initializing:
                return Unknown(name + " initial return value")
            fn_source, declaration, fn_line = self.functions[name]
            parameter_list=declaration.child_by_field_name("parameters")
            single_parameter=declaration.child_by_field_name('parameter')
            parameters = parameter_list.named_children if parameter_list else [single_parameter] if single_parameter else []
            inner = state.fork()
            inner.env['__this__']=self.context['element'] if name.startswith('__recorded_binding_') and declaration.type!='arrow_function' else Unknown("the function's this context")
            for index, parameter in enumerate(parameters):
                inner.env[self.text(fn_source, parameter)] = args[index] if index < len(args) else Unknown("unspecified argument")
            self.depth += 1
            self.run(fn_source, declaration.child_by_field_name("body"), [inner], fn_line)
            self.depth -= 1
            return Unknown(name + " return value")
        if function and function.type == "member_expression":
            base = self.evaluate(source, function.child_by_field_name("object"), state, line)
            method = self.text(source, function.child_by_field_name("property"))
            if isinstance(base, Element):
                effect = None
                if method=='is' and args and args[0] in {':checked',':disabled'}:
                    return self.read_property(base,'checked' if args[0]==':checked' else 'disabled')
                if method=='val' and not args:
                    return self.read_property(base,'value')
                if method=='prop' and len(args)==1 and args[0] in {'checked','disabled','readOnly','hidden','value'}:
                    return self.read_property(base,args[0])
                if method=='contains' and 'classList' in base.path and args and args[0] in HIDDEN_CLASSES:
                    return Unknown(f'{self.target_label(base)} is currently hidden')
                if method in {"show", "hide"}:
                    effect = "shown" if method == "show" else "hidden"
                elif method in {"add", "remove"} and "classList" in base.path and any(arg in HIDDEN_CLASSES for arg in args if isinstance(arg, str)):
                    effect = "hidden" if method == "add" else "shown"
                elif method in {"prop", "attr"} and len(args) > 1 and args[0] in {"disabled", "readonly", "hidden"} and isinstance(args[1], bool):
                    effect = {"disabled": ("disabled", "enabled"), "readonly": ("read-only", "editable"), "hidden": ("hidden", "shown")}[args[0]][0 if args[1] else 1]
                elif method == "removeAttr" and args and args[0] in {"disabled", "readonly", "hidden"}:
                    effect = {"disabled": "enabled", "readonly": "editable", "hidden": "shown"}[args[0]]
                elif method=='setAttribute' and args and args[0] in {'disabled','readonly','hidden'}:
                    effect={'disabled':'disabled','readonly':'read-only','hidden':'hidden'}[args[0]]
                elif method=='removeAttribute' and args and args[0] in {'disabled','readonly','hidden'}:
                    effect={'disabled':'enabled','readonly':'editable','hidden':'shown'}[args[0]]
                elif method in {'toggle','toggleClass'} and args and 'classList' not in base.path:
                    flag=args[0] if method=='toggle' else args[1] if len(args)>1 and args[0] in HIDDEN_CLASSES else None
                    if isinstance(flag,bool):
                        effect=('shown' if flag else 'hidden') if method=='toggle' else ('hidden' if flag else 'shown')
                elif method=='toggle' and 'classList' in base.path and len(args)>1 and args[0] in HIDDEN_CLASSES and isinstance(args[1],bool):
                    effect='hidden' if args[1] else 'shown'
                elif method == "css" and len(args) > 1 and args[0] == "display":
                    effect = "hidden" if args[1] == "none" else "shown" if args[1] in {"block", "inline", "inline-block", "flex", "grid"} else None
                if effect:
                    self.emit(base, effect, source, node, state, line)
                    return None
                if method == "find" and args:
                    return Element(base.key, base.kind, base.path, True)
                if method == "forEach" and arg_nodes and arg_nodes[0].type in {"arrow_function", "function_expression"}:
                    callback = arg_nodes[0]
                    parameter = callback.child_by_field_name("parameter")
                    parameters = callback.child_by_field_name("parameters")
                    parameter = parameter or (parameters.named_children[0] if parameters and parameters.named_children else None)
                    if parameter:
                        inner = state.fork()
                        inner.env[self.text(source, parameter)] = base
                        self.run(source, callback.child_by_field_name("body"), [inner], line)
                    return None
        if function and function.type == "identifier" and name not in {"parseInt", "parseFloat", "Number", "String", "Boolean", "alert"}:
            self.note(f'This input calls {name}(), but that function is not present in the recorded page scripts.')
        return Unknown(name + " result")

    def run(self, source, node, states, line):
        if node is None or self.steps > 4000:
            return states
        kind = node.type
        if kind in {"program", "statement_block", "else_clause", "expression_statement"}:
            for child in node.named_children:
                stopped=[state for state in states if state.stopped]
                running=[state for state in states if not state.stopped]
                if not running: break
                states = stopped+self.run(source, child, running, line)
            return states
        if kind in {"lexical_declaration", "variable_declaration"}:
            for state in states:
                for child in node.named_children:
                    if child.type == "variable_declarator":
                        state.env[self.text(source, child.child_by_field_name("name"))] = self.evaluate(source, child.child_by_field_name("value"), state, line)
        elif kind == "if_statement":
            result = []
            for state in states:
                condition = node.child_by_field_name("condition")
                value = self.evaluate(source, condition, state, line)
                choices = (True, False) if isinstance(value, Unknown) else (bool(value),)
                for yes in choices:
                    inner = state.fork()
                    inner.guards.append({"expression": self.text(source, condition), "result": yes,
                                         "additional": isinstance(value, Unknown), "description": value.description if isinstance(value, Unknown) else ""})
                    branch = node.child_by_field_name("consequence" if yes else "alternative")
                    result.extend(self.run(source, branch, [inner], line) if branch else [inner])
            return result[:32]
        elif kind in {"assignment_expression", "call_expression"}:
            for state in states:
                self.evaluate(source, node, state, line)
        elif kind in {"for_statement", "while_statement", "do_statement", "switch_statement", "try_statement"}:
            self.note("This handler contains a loop, switch or exception path that the visibility explanation does not evaluate.")
        elif kind in {'return_statement','throw_statement'}:
            for state in states:
                for child in node.named_children:
                    self.evaluate(source,child,state,line)
                state.stopped=True
        return states

    def note(self, message):
        entry = {"input_name": self.context["control"].get("name", ""), "message": message}
        if entry not in self.notes:
            self.notes.append(entry)

    def emit(self, target, effect, source, node, state, line):
        if self.initializing:
            return
        affected = self.affected(target)
        # A disabled property on a div/span does not disable its descendant controls.
        if effect in {"disabled", "enabled", "read-only", "editable"} and not self.control(target)[0] and not target.descendants:
            self.note(f'The handler changes a control property on “{target.key}”, but that target was not identified as an input.')
            return
        origin = self.context["control"]
        prefix = self.context["trigger"]
        additional=[]
        for guard in state.guards:
            if not guard['additional']: continue
            description=guard['description']
            if re.fullmatch(r'[\w$]+',description) or re.search(r'document\.|\$\(|return value| result|this context',description):
                description='an additional condition in the recorded script is met'
                self.note('An additional condition could not be translated completely; its exact expression is available under View source evidence.')
            additional.append(description if guard['result'] else 'not ('+description+')')
        if additional:
            prefix += ", provided that " + " and ".join(additional)
        sentence = f'{prefix}, {self.target_label(target)} is {effect}.'
        rule = {"trigger_input": origin.get("name", ""), "target": target.key, "effect": effect,
                "affected_inputs": [i.get("name", "") for i in affected], "sentence": sentence,
                "affected_labels": [label(i) for i in affected],
                "trigger": self.context["trigger"], "additional_conditions": additional,
                "source_file": self.page.get("source_path", self.page.get("filename", "")),
                "source_line": line + node.start_point.row, "source_code": self.text(source, node), "guards": state.guards}
        if not any(r["sentence"] == sentence and r["affected_inputs"] == rule["affected_inputs"] for r in self.rules):
            self.rules.append(rule)

    def explain(self):
        parser = Parser(LANGUAGE)
        for control in self.inputs:
            attrs = {key.lower(): value for key, value in control.get("attributes", {}).items()}
            events = {key.lower(): value for key, value in control.get("events", {}).items()}
            events.update({key: value for key, value in attrs.items() if key.startswith("on")})
            for bound,event,handler,option_value in self.bindings:
                if bound is control and option_value is None:
                    existing=events.get(event,[])
                    events[event]=(existing if isinstance(existing,list) else [existing])+[handler]
            contexts = []
            options = control.get("options", [])
            kind = control.get("input_type", "").lower()
            if kind == "radio" or "combo" in kind or kind == "select":
                for option in options:
                    handlers = [value_text(entry) for value in events.values() for entry in (value if isinstance(value,list) else [value])]
                    handlers.extend(handler for bound,event,handler,option_value in self.bindings if bound is control and option_value is not None and option_value==str(option.get('value','')))
                    if option.get("onclick"): handlers.append(option["onclick"])
                    for handler in set(handlers):
                        contexts.append((handler, str(option.get("value", "")), None, f'When you select “{label({"label": option.get("label") or str(option.get("value", ""))})}” for “{label(control)}”'))
            elif "checkbox" in kind:
                for handler in {value_text(entry) for value in events.values() for entry in (value if isinstance(value,list) else [value])}:
                    for checked in (True, False):
                        contexts.append((handler, value_text(attrs.get("defvalue", attrs.get("value"))), checked, f'When you {"check" if checked else "uncheck"} “{label(control)}”'))
            else:
                for event, values in events.items():
                    for value in values if isinstance(values, list) else [values]:
                        verb = "click" if event == "onclick" else "change" if event == "onchange" else "interact with"
                        text = label(control)
                        if not control.get("label") and kind in {"button", "submit"}:
                            text = value_text(attrs.get("value")) or text
                        contexts.append((value_text(value), Unknown(f'the value entered for “{text}”'), None, f'When you {verb} “{text}”'))
            for handler, value, checked, trigger in contexts:
                if not handler.strip(): continue
                self.context = {"control": control, "value": value, "trigger": trigger}
                element=Element(control.get('id') or control.get('name',''),'id' if control.get('id') else 'name')
                self.context['element']=element
                if checked is not None: self.context["checked"] = checked
                self.steps, self.depth = 0, 0
                state = State({'__this__':element,'__recorded_event':Event(element)})
                self.initializing = True
                for source, declaration, line in self.globals:
                    self.run(source, declaration, [state], line)
                self.initializing = False
                source = handler.encode("utf-8")
                self.run(source, parser.parse(source).root_node, [state], control.get("source_line", control.get("line", 1)))
                if self.steps > 4000:
                    self.note("This handler exceeded the bounded visibility analysis limit.")
        return {"version": 1, "rules": self.rules, "notes": self.notes}


def explain_page(page):
    analysis = Explainer(page).explain()
    page["visibility_analysis"] = analysis
    for control in page.get("inputs", []):
        name = control.get("name", "")
        control["visibility_behaviors"] = [rule for rule in analysis["rules"] if rule["trigger_input"] == name or name in rule["affected_inputs"]]
        control["visibility_notes"] = [note["message"] for note in analysis["notes"] if note["input_name"] == name]
    return page


def explain_graph(graph):
    for page in graph.get("pages", []):
        explain_page(page)
    return graph
