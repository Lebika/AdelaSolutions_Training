"""Source-backed page/control graph extraction. Never executes application code."""
from __future__ import annotations

import hashlib
import html
import re
from collections import deque
from html.parser import HTMLParser
from pathlib import Path
from urllib.parse import parse_qsl, urlsplit

from tree_sitter import Language, Parser
import tree_sitter_php

import php_flow_scanner as existing

PRODUCTS = ("Individual", "OLTPRO")


def starting_form(filename):
    stem = Path(str(filename).replace("\\", "/")).stem
    match = re.fullmatch(r"(.+?)(?:_?done|_?summary)", stem, re.I)
    return match[1] if match else None


def validate_starting_form(form, filename):
    expected = starting_form(filename)
    if expected and expected.casefold() != str(form).casefold():
        raise ValueError(f"Starting page '{filename}' belongs to form '{expected}', but '{form}' is selected. Select '{expected}' or choose a starting page for '{form}'.")


def scope(taxyear, product, jurisdiction):
    year, product, jurisdiction = str(taxyear), str(product), str(jurisdiction).upper()
    if not re.fullmatch(r"20\d{2}", year):
        raise ValueError("Choose a four-digit tax year")
    if product not in PRODUCTS or jurisdiction not in {"FED", *existing.STATES}:
        raise ValueError("Unsupported product or FED/state")
    return year, product, jurisdiction


def roots(year, product):
    if product == "Individual":
        return existing.source_folder_path(year, "html"), existing.source_folder_path(year, "oltproc")
    base = existing.SITE_ASP_ROOT / year / "OLTPRO"
    return base / "html", base / "oltproc"


def safe_file(root, filename):
    filename = str(filename).replace("\\", "/")
    if not filename or filename.startswith("/") or ":" in filename:
        raise ValueError("Use a relative filename within the selected source folder")
    path = (Path(root) / filename).resolve()
    if not path.is_relative_to(Path(root).resolve()):
        raise ValueError("Filename is outside the selected source folder")
    return path


def options(year, product, jurisdiction):
    year, product, jurisdiction = scope(year, product, jurisdiction)
    html_root, post_root = roots(year, product)
    forms = {}
    if html_root.is_dir():
        for path in sorted(html_root.rglob("*")):
            if path.suffix.lower() not in {".html", ".htm"}:
                continue
            if existing.metadata_state("html", path.relative_to(html_root).as_posix(), path.name) != jurisdiction:
                continue
            match = re.match(r"(.+?)(?:_?done|_?summary)$", path.stem, re.I)
            if match:
                forms.setdefault(match[1], []).append(path.relative_to(html_root).as_posix())
    return {"forms": [{"name": name, "starting_pages": pages} for name, pages in forms.items()],
            "html_root": str(html_root), "post_root": str(post_root),
            "available": html_root.is_dir() and post_root.is_dir()}


def walk(node):
    if node.type == "comment":
        return
    yield node
    for child in node.named_children:
        yield from walk(child)


def blank_range(source, start, end):
    """Remove comment content without shifting byte offsets or source line numbers."""
    source[start:end] = bytes(c if c in (10, 13) else 32 for c in source[start:end])


def javascript_without_comments(code):
    """Mask JS comments while preserving quoted text, templates and regex literals."""
    result = list(code)
    size = len(code)

    def blank(start, end):
        for index in range(start, end):
            if code[index] not in "\r\n":
                result[index] = " "

    def quoted(index, quote):
        index += 1
        while index < size:
            if code[index] == "\\":
                index += 2
            elif code[index] == quote:
                return index + 1
            else:
                index += 1
        return index

    def template(index):
        index += 1
        while index < size:
            if code[index] == "\\":
                index += 2
            elif code[index] == "`":
                return index + 1
            elif code.startswith("${", index):
                index = scan(index + 2, interpolation=True)
            else:
                index += 1
        return index

    def scan(index, interpolation=False):
        expression, braces = True, 0
        while index < size:
            char = code[index]
            if code.startswith("//", index) or code.startswith("<!--", index):
                end = code.find("\n", index)
                end = size if end < 0 else end
                blank(index, end)
                index = end
            elif code.startswith("/*", index):
                end = code.find("*/", index + 2)
                end = size if end < 0 else end + 2
                blank(index, end)
                index = end
            elif char in "\"'":
                index, expression = quoted(index, char), False
            elif char == "`":
                index, expression = template(index), False
            elif char == "/" and expression:
                # A regex body may contain escaped slashes and slash characters in [].
                index += 1
                char_class = False
                while index < size:
                    current = code[index]
                    if current == "\\":
                        index += 2
                        continue
                    if current == "[":
                        char_class = True
                    elif current == "]":
                        char_class = False
                    elif current == "/" and not char_class:
                        index += 1
                        while index < size and code[index].isalpha():
                            index += 1
                        break
                    index += 1
                expression = False
            elif char.isalpha() or char in "_$":
                end = index + 1
                while end < size and (code[end].isalnum() or code[end] in "_$"):
                    end += 1
                expression = code[index:end] in {"return", "throw", "case", "delete", "void", "typeof", "yield", "await", "in", "of", "new"}
                index = end
            else:
                if char == "}" and interpolation and braces == 0:
                    return index + 1
                if char == "{":
                    braces += 1
                elif char == "}":
                    braces -= 1
                if not char.isspace():
                    expression = char in "=(:,;!?&|+-*%~^<>[{/"
                index += 1
        return index

    scan(0)
    return "".join(result)


def text(source, node):
    return source[node.start_byte:node.end_byte].decode("utf-8", errors="replace") if node else ""


def literal(value):
    value = value.strip()
    if len(value) > 1 and value[0] in "\"'" and value[-1] == value[0]:
        # Only unescape PHP quote delimiters/backslashes, never evaluate interpolation.
        return value[1:-1].replace("\\\"", '"').replace("\\'", "'").replace("\\\\", "\\")
    return value


def clean(value):
    return html.unescape(re.sub(r"<[^>]+>", " ", str(value))).strip()


def url_template(source, node):
    """Resolve literal concatenation only; leave variables as symbolic placeholders."""
    if node is None:
        return ""
    if node.type == "binary_expression" and text(source, node.child_by_field_name("operator")) == ".":
        return url_template(source, node.child_by_field_name("left")) + url_template(source, node.child_by_field_name("right"))
    if node.type in {"string", "encapsed_string"}:
        value = literal(text(source, node))
        return re.sub(r"\$[A-Za-z_]\w*", lambda m: "{" + m[0] + "}", value)
    return "{" + text(source, node) + "}"


def request_details(template):
    parts = urlsplit(html.unescape(template))
    return {"url_template": template, "target_file": parts.path,
            "query_parameters": dict(parse_qsl(parts.query, keep_blank_values=True)), "request_method": "GET"}


def repetition(source, node):
    loops = []
    parent = node.parent
    while parent:
        if parent.type in {"for_statement", "foreach_statement", "while_statement", "do_statement"}:
            body = parent.child_by_field_name("body")
            end = body.start_byte if body else parent.end_byte
            loops.append(source[parent.start_byte:end].decode("utf-8", errors="replace"))
        parent = parent.parent
    return list(reversed(loops))


def predicates(source, node):
    """Retain outer guards and negative preceding branches of elseif/else chains."""
    result = []
    child, parent = node, node.parent
    while parent:
        if parent.type in {"if_statement", "else_if_clause", "else_clause"}:
            cond = parent.child_by_field_name("condition")
            # An alternative clause is not controlled by its parent's positive condition.
            alternative = child.type in {"else_clause", "else_if_clause"}
            if not alternative and cond and not (cond.start_byte <= node.start_byte <= cond.end_byte):
                result.append(text(source, cond))
            if parent.type in {"else_clause", "else_if_clause"}:
                prev = parent.prev_named_sibling
                while prev:
                    prior_cond = prev.child_by_field_name("condition")
                    if prior_cond:
                        result.append("!(" + text(source, prior_cond) + ")")
                    prev = prev.prev_named_sibling
                owner = parent.parent
                if owner and owner.type == "if_statement":
                    owner_cond = owner.child_by_field_name("condition")
                    if owner_cond:
                        result.append("!(" + text(source, owner_cond) + ")")
        child, parent = parent, parent.parent
    return list(dict.fromkeys(reversed(result)))


class Markup(HTMLParser):
    """Read literal markup while PHP is whitespace-masked, retaining source offsets."""
    def __init__(self, source, masked):
        super().__init__(convert_charrefs=True)
        self.source = masked
        self.starts = [0]
        for match in re.finditer("\n", masked):
            self.starts.append(match.end())
        self.stack, self.groups, self.controls, self.forms, self.scripts, self.links = [], [], [], [], [], []
        self.link = None
        self.labels, self.label, self.active, self.option, self.script = {}, None, None, None, None
        self.recent = ""
        self.comment_ranges = []
        self.feed(masked)
        self.close()
        if self.rawdata.startswith("<!--"):
            self.comment_ranges.append((self.source_offset(), len(masked.encode("utf-8"))))

    def handle_comment(self, data):
        line, col = self.getpos()
        start = self.starts[line - 1] + col
        end = self.source.find("-->", start + 4)
        end = len(self.source) if end < 0 else end + 3
        self.comment_ranges.append((len(self.source[:start].encode("utf-8")), len(self.source[:end].encode("utf-8"))))

    def source_offset(self):
        line, col = self.getpos()
        return len(self.source[:self.starts[line - 1] + col].encode("utf-8"))

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        pos = self.source_offset()
        if tag in {"div", "span"}:
            group = {"tag": tag, "id": attrs.get("id", ""), "class": attrs.get("class", ""),
                     "style": attrs.get("style", ""), "line": self.getpos()[0], "start": pos, "end": len(self.source.encode("utf-8"))}
            self.groups.append(group)
            self.stack.append(group)
        if tag == "label":
            self.label = {"for": attrs.get("for"), "text": "", "controls": []}
        if tag == "form":
            self.forms.append({"action": attrs.get("action", ""), "method": attrs.get("method", "get"),
                               "line": self.getpos()[0], "offset": pos})
        if tag == "a":
            self.link = {"attributes": attrs, "label": attrs.get("title", ""), "line": self.getpos()[0],
                         "offset": pos, "parent_groups": [g["id"] for g in self.stack if g["id"]]}
            self.links.append(self.link)
        if tag in {"input", "select", "textarea", "button"}:
            control = {"name": attrs.get("name", attrs.get("id", "")), "id": attrs.get("id", ""),
                       "input_type": attrs.get("type", "text") if tag == "input" else tag,
                       "label": attrs.get("aria-label", attrs.get("title", attrs.get("placeholder", ""))),
                       "attributes": attrs, "options": [], "line": self.getpos()[0], "offset": pos,
                       "parent_groups": [g["id"] for g in self.stack if g["id"]],
                       "nearby_text": clean(self.recent[-200:])}
            self.controls.append(control)
            if tag in {"select", "textarea", "button"}:
                self.active = control
            if self.label:
                control["label"] = self.label["text"].strip()
                self.label["controls"].append(control)
        if tag == "option" and self.active:
            self.option = {"value": attrs.get("value", ""), "label": ""}
            self.active["options"].append(self.option)
        if tag == "script":
            self.script = {"line": self.getpos()[0], "src": attrs.get("src", ""), "code": ""}
            self.scripts.append(self.script)

    def handle_endtag(self, tag):
        if tag in {"div", "span"}:
            for index in range(len(self.stack) - 1, -1, -1):
                if self.stack[index]["tag"] == tag:
                    for group in self.stack[index:]:
                        group["end"] = self.source_offset()
                    del self.stack[index:]
                    break
        if tag == "label" and self.label:
            if self.label["for"]:
                self.labels[self.label["for"]] = clean(self.label["text"])
            for control in self.label["controls"]:
                control["label"] = clean(self.label["text"])
            self.label = None
        if tag == "option":
            self.option = None
        if tag in {"select", "textarea", "button"}:
            self.active = None
        if tag == "script":
            self.script = None
        if tag == "a":
            self.link = None

    def handle_data(self, value):
        if self.script is not None:
            self.script["code"] += value
            return
        self.recent = (self.recent + " " + value)[-500:]
        if self.link is not None:
            self.link["label"] += value
        if self.label:
            self.label["text"] += value
        if self.option is not None:
            self.option["label"] += value
        elif self.active:
            self.active["label"] += value


def parse_file(path):
    raw = path.read_bytes()
    # All offsets below refer to the same UTF-8 representation.
    decoded = raw.decode("utf-8", errors="replace")
    source = decoded.encode("utf-8")
    parser = Parser(Language(tree_sitter_php.language_php()))
    tree = parser.parse(source)
    # Find HTML comments in the PHP-masked markup first. PHP snippets inside an
    # HTML-commented section must not contribute hidden inputs or flow edges.
    preliminary = bytearray(10 if c == 10 else 13 if c == 13 else 32 for c in source)
    for node in walk(tree.root_node):
        if node.type == "text":
            preliminary[node.start_byte:node.end_byte] = source[node.start_byte:node.end_byte]
    comments = Markup(decoded, preliminary.decode("utf-8", errors="replace")).comment_ranges
    active_source = bytearray(source)
    for start, end in comments:
        blank_range(active_source, start, end)
    tree = parser.parse(bytes(active_source))
    # Use AST comment spans, so comment markers inside PHP strings stay intact.
    pending = [tree.root_node]
    while pending:
        node = pending.pop()
        if node.type == "comment":
            blank_range(active_source, node.start_byte, node.end_byte)
        else:
            pending.extend(node.named_children)
    source = bytes(active_source)
    decoded = source.decode("utf-8", errors="replace")
    tree = parser.parse(source)
    nodes = list(walk(tree.root_node))
    # Tree-sitter supports the short PHP tags used in the protected templates.
    masked = bytearray(10 if c == 10 else 13 if c == 13 else 32 for c in source)
    for node in nodes:
        if node.type == "text":
            masked[node.start_byte:node.end_byte] = source[node.start_byte:node.end_byte]
    markup = Markup(decoded, masked.decode("utf-8", errors="replace"))
    inputs = markup.controls
    for item in inputs:
        item["label"] = markup.labels.get(item["id"], item["label"])
    input_attrs, radio = {}, {}
    includes, calls, validation, sql, warnings, navigation = [], [], [], [], [], []
    if tree.root_node.has_error:
        warnings.append("PHP parser reported syntax errors; inspect source evidence for incomplete extraction")
    for node in sorted(nodes, key=lambda n: (n.start_byte, n.end_byte)):
        if node.type in {"assignment_expression", "augmented_assignment_expression"}:
            left = text(source, node.child_by_field_name("left"))
            right = text(source, node.child_by_field_name("right"))
            evidence = {"expression": right, "value": literal(right), "line": node.start_point.row + 1,
                        "conditions": predicates(source, node)}
            prop = re.fullmatch(r"\$InputArray\s*(\[.+\])", left, re.I)
            if prop:
                keys = re.findall(r"\[([^\]]+)\]", prop[1])
                prop_key = ".".join(literal(k).lower() for k in keys)
                input_attrs.setdefault(prop_key, []).append(evidence)
            action_match = re.fullmatch(r"\$multipleInputArray\s*\[\s*['\"](Edit|Delete)['\"]\s*\]", left, re.I)
            if action_match:
                navigation.append({"operation": action_match[1].lower(), "label": action_match[1].title(),
                                   **request_details(url_template(source, node.child_by_field_name("right"))),
                                   "expression": text(source, node), "line": node.start_point.row + 1,
                                   "conditions": predicates(source, node), "repetition": repetition(source, node),
                                   "source_kind": "multipleInputArray"})
            elif re.match(r"\$(?:radio|combo|select|eleErr_flag|errMsg)", left, re.I):
                radio.setdefault(left.replace(" ", ""), []).append(evidence)
            if re.search(r"(?:err_flag|_err(?:or)?(?:_flag)?)\b", left, re.I):
                validation.append({"line": node.start_point.row + 1, "source": text(source, node),
                                   "conditions": predicates(source, node)})
            if "_SQL_DataArray" in left or re.search(r"\b(?:select|insert\s+into|update|delete\s+from)\b", right, re.I) or re.search(r"\$(?:\w*query\w*|query_clause)$", left, re.I):
                sql.append({"line": node.start_point.row + 1, "source": text(source, node),
                            "conditions": predicates(source, node)})
        if node.type in {"include_expression", "include_once_expression", "require_expression", "require_once_expression"}:
            expression = text(source, node)
            strings = [literal(text(source, child)) for child in walk(node)
                       if child.type in {"string", "encapsed_string"}]
            targets = [value for value in strings if re.search(r"\.(?:html?|php|js)$", value, re.I)]
            includes.append({"target": targets[-1] if targets else "", "expression": expression,
                             "line": node.start_point.row + 1, "offset": node.start_byte,
                             "conditions": predicates(source, node)})
            if targets and re.search(r"generat.*(?:radio|combo|select)", targets[-1], re.I):
                def rv(key):
                    return radio.get(key, [])
                names = rv("$radioBtnName")
                if names:
                    labels, values, events = rv("$radioBtnText[]"), rv("$radioBtnValues[]"), rv("$radioBtnonClick[]")
                    inputs.append({"name": names[-1]["value"], "input_type": "radio", "id": "",
                                   "label": (rv("$radioPnlHead") or [{"value": ""}])[-1]["value"],
                                   "line": node.start_point.row + 1, "offset": node.start_byte,
                                   "options": [{"value": item["value"], "label": labels[i]["value"] if i < len(labels) else "",
                                                "onclick": events[i]["value"] if i < len(events) else ""}
                                               for i, item in enumerate(values)], "attributes": radio,
                                   "conditions": predicates(source, node)})
                radio = {}
        if node.type == "function_call_expression":
            name = text(source, node.child_by_field_name("function"))
            snippet = text(source, node)
            calls.append({"name": name, "source": snippet, "line": node.start_point.row + 1,
                          "offset": node.start_byte, "conditions": predicates(source, node)})
            if name.lower() == "oltgenerateinputgrp":
                def attr(key):
                    return (input_attrs.get(key) or [{"value": ""}])[-1]["value"]
                if attr("name"):
                    option_values = {}
                    for key, entries in input_attrs.items():
                        if key.startswith("opt."):
                            key_path, _, field = key.rpartition(".")
                            option_values.setdefault(key_path, {})["label" if field == "text" else field] = entries[-1]["value"]
                    inputs.append({"name": attr("name"), "id": attr("id"), "label": clean(attr("labeltext") or attr("text") or attr("placeholder")),
                                   "input_type": attr("inputtype"), "attributes": input_attrs, "options": list(option_values.values()),
                                   "line": node.start_point.row + 1, "offset": node.start_byte,
                                   "conditions": predicates(source, node), "repetition": repetition(source, node)})
                input_attrs = {}
            if name.lower().startswith("db_sql"):
                sql.append({"line": node.start_point.row + 1, "source": snippet,
                            "conditions": predicates(source, node)})
        if node.type == "echo_statement":
            # Form wrappers are commonly emitted by PHP before a protected include.
            echo = literal(text(source, node)[4:].strip().rstrip(";").strip())
            if "<" in echo:
                parser = Markup(echo, echo)
                for form in parser.forms:
                    form.update(line=node.start_point.row + 1, offset=node.start_byte,
                                conditions=predicates(source, node))
                    markup.forms.append(form)
                for control in parser.controls:
                    control.update(line=node.start_point.row + control["line"], offset=node.start_byte,
                                   conditions=predicates(source, node), repetition=repetition(source, node),
                                   generated_markup=text(source, node))
                    control["parent_groups"] = [g["id"] for g in markup.groups if g["id"] and g["start"] <= node.start_byte < g["end"]] + control["parent_groups"]
                    inputs.append(control)
                for script in parser.scripts:
                    script["line"] += node.start_point.row
                    markup.scripts.append(script)
                for link in parser.links:
                    link.update(line=node.start_point.row + link["line"], offset=node.start_byte,
                                conditions=predicates(source, node))
                    markup.links.append(link)
    for link in markup.links:
        href = link["attributes"].get("href", "") or ""
        if ".php" in href and not re.search(r"://|[$<>]", href):
            label = clean(link["label"])
            operation = "edit" if re.search(r"\bedit\b", label, re.I) else "delete" if re.search(r"\bdelete\b", label, re.I) else "navigate"
            navigation.append({"operation": operation, "label": label, **request_details(href),
                               "line": link["line"], "conditions": link.get("conditions", []),
                               "source_kind": "anchor", "attributes": link["attributes"]})
    for item in inputs:
        offset = item.pop("offset", 0)
        item.setdefault("parent_groups", [g["id"] for g in markup.groups if g["id"] and g["start"] <= offset < g["end"]])
        if "conditions" not in item:
            container = tree.root_node.descendant_for_byte_range(offset, offset)
            item["conditions"] = predicates(source, container)
        item["source_line"] = item["line"]
        item["source_excerpt"] = decoded.splitlines()[item["line"] - 1] if item["line"] <= len(decoded.splitlines()) else ""
        if item["input_type"].lower() in {"radio", "checkbox", "checkboxwithlabel"} and not item["options"]:
            attrs = item["attributes"]
            value = attrs.get("value", attrs.get("defvalue", ""))
            if isinstance(value, list):
                value = value[-1]["value"]
            item["options"] = [{"value": value, "label": item["label"]}]
        name = item.get("name", "").split("[")[0].lstrip("$")
        pattern = re.compile(r"\$" + re.escape(name) + r"\b") if name else None
        item["validation"] = [v for v in validation if pattern and pattern.search(" ".join(v["conditions"]) + " " + v["source"])]
        item["events"] = {k: v for k, v in item.get("attributes", {}).items() if k.lower().startswith("on")}
    for script in markup.scripts:
        script["code"] = javascript_without_comments(script["code"])
        script["referenced_ids"] = sorted(set(re.findall(r"getElementById\(\s*['\"]([^'\"]+)", script["code"])))
    for group in markup.groups:
        group["input_names"] = [item["name"] for item in inputs if group["id"] and group["id"] in item["parent_groups"]]
        group["content_preview"] = clean(bytes(masked[group["start"]:group["end"]]).decode("utf-8", errors="replace"))[:800]
    return {"inputs": inputs, "groups": markup.groups, "javascript": markup.scripts, "forms": markup.forms,
            "navigation": navigation, "links": markup.links,
            "includes": includes, "calls": calls, "validation": validation, "sql": sql,
            "sha256": hashlib.sha256(raw).hexdigest(), "warnings": warnings}


def resolve_include(owner, target, html_root, post_root):
    """Resolve the same public/protected split used for PHP and HTML sources."""
    target = target.replace("\\", "/")
    if not target or re.search(r"[$<>]|://", target):
        return None
    candidates = [owner.parent / target]
    if re.search(r"(?:^|/)html/", target, re.I):
        candidates.append(html_root / re.split("html/", target, flags=re.I)[-1])
    candidates.extend([html_root / target, post_root / target])
    for candidate in candidates:
        candidate = candidate.resolve()
        if any(candidate.is_relative_to(root.parent.resolve()) for root in (html_root, post_root)) and candidate.is_file():
            return candidate
    return None


def delete_confirmation(owner, parsed, html_root, post_root, cache):
    """Trace the shared row renderer to its modal, footer include and Yes/No controls."""
    def read(path):
        if path not in cache:
            cache[path] = parse_file(path)
        return cache[path]

    trigger = None
    for include in parsed["includes"]:
        helper = resolve_include(owner, include["target"], html_root, post_root)
        if helper is None or helper.suffix.lower() not in {".html", ".htm", ".php"}:
            continue
        # Discover the modal trigger from markup, without depending on helper filenames.
        helper_text = helper.read_text(encoding="utf-8", errors="replace")
        if not re.search(r"data-toggle\s*=\s*['\"]modal['\"]", helper_text, re.I):
            continue
        helper_data = read(helper)
        for link in helper_data["links"]:
            attrs = link["attributes"]
            if re.search(r"delete", attrs.get("title", ""), re.I) and attrs.get("data-toggle") == "modal" and attrs.get("href", "").startswith("#"):
                trigger = {"modal_id": attrs["href"][1:], "source_path": str(helper), "source_line": link["line"], "attributes": attrs}
                break
        if trigger:
            break
    if trigger is None:
        return None
    # Prefer modal/footer includes over large unrelated header and navigation trees.
    import heapq
    pending, visited, counter = [], set(), 0
    def enqueue(path, depth):
        nonlocal counter
        name = path.stem.lower()
        rank = 0 if re.search(r"modal|confirm", name) else 1 if re.search(r"ftr|footer", name) else 2
        counter += 1
        heapq.heappush(pending, (rank, depth, counter, path))
    enqueue(owner, 0)
    conventional = next((post_root / p for p in ("olt_" + owner.stem + ".php", owner.stem + ".php", "qt_" + owner.stem + ".php") if (post_root / p).is_file()), None)
    if conventional:
        enqueue(conventional, 0)
    while pending and len(visited) < 60:
        _, depth, _, path = heapq.heappop(pending)
        if path in visited:
            continue
        visited.add(path)
        data = read(path)
        group = next((g for g in data["groups"] if g["id"] == trigger["modal_id"]), None)
        if group:
            yes = next((link for link in data["links"] if trigger["modal_id"] in link["parent_groups"] and clean(link["label"]).lower() == "yes"), None)
            no = [control for control in data["inputs"] if trigger["modal_id"] in control["parent_groups"] and control["attributes"].get("data-dismiss") == "modal"]
            # Require a source-backed binding from the clicked row URL to the Yes link.
            binding = next((script for script in data["javascript"] if yes and yes["attributes"].get("id") in script["code"] and "href" in script["code"] and "data(" in script["code"]), None)
            if yes and no and binding:
                return {"trigger": trigger, "source_path": str(path), "source_line": group["line"],
                        "modal_id": trigger["modal_id"], "yes": yes, "cancel_controls": no,
                        "javascript": binding, "sha256": data["sha256"], "groups": [group]}
        if depth < 3:
            for include in data["includes"]:
                child = resolve_include(path, include["target"], html_root, post_root)
                if child and child.suffix.lower() in {".php", ".html", ".htm"} and child not in visited:
                    enqueue(child, depth + 1)
    return {"trigger": trigger, "unresolved": True}


def _family(stem, form):
    stem, form = stem.lower(), form.lower()
    return stem == form or (stem.startswith(form) and not stem[len(form):len(form) + 1].isdigit())


def build_graph(year, product, jurisdiction, form, start, progress=None):
    year, product, jurisdiction = scope(year, product, jurisdiction)
    if not re.fullmatch(r"[\w.-]+", str(form)) or form in {".", ".."}:
        raise ValueError("Choose a form name containing letters, numbers, underscores, periods or hyphens")
    validate_starting_form(form, start)
    html_root, post_root = roots(year, product)
    start_path = safe_file(html_root, start)
    if start_path.suffix.lower() not in {".html", ".htm"} or not start_path.is_file():
        raise ValueError("Starting HTML page does not exist in the selected product folder")
    if existing.metadata_state("html", str(start), start_path.name) != jurisdiction:
        raise ValueError("Starting page does not match the selected FED/state")
    pages, edges, warnings, queued, parse_cache = {}, [], [], set(), {}
    pending = deque()

    def page_id(kind, relative):
        return f"{kind}/{relative}"

    def queue(kind, relative, allow=False):
        root = html_root if kind == "html" else post_root
        path = safe_file(root, relative)
        key = page_id(kind, path.relative_to(root.resolve()).as_posix())
        family_stem = re.sub(r"^(?:olt_|qt_)", "", path.stem, flags=re.I)
        if not allow and not _family(family_stem, form):
            return key, "external"
        if not path.is_file():
            warnings.append(f"Missing source: {path}")
            return key, "missing"
        if key not in queued:
            queued.add(key)
            pending.append((key, path, kind))
        return key, "internal"

    def edge(source, target, kind, evidence, status="internal", **extra):
        item = {"source": source, "target": target, "kind": kind, "target_status": status,
                "conditions": evidence.get("conditions", []), "source_line": evidence.get("line"),
                "source_file": evidence.get("source_path", pages.get(source, {}).get("source_path", "")), **extra}
        if item not in edges:
            edges.append(item)

    start_id, _ = queue("html", start_path.relative_to(html_root.resolve()).as_posix(), True)
    while pending:
        if len(pages) >= 250:
            raise ValueError("Flow exceeds 250 source files; select a narrower form/starting page")
        key, path, kind = pending.popleft()
        if progress:
            progress(f"Reading {key} ({len(pages) + 1} files)")
        if path not in parse_cache:
            parse_cache[path] = parse_file(path)
        parsed = parse_cache[path]
        warnings.extend(f"{key}: {value}" for value in parsed["warnings"])
        page = {"id": key, "filename": path.name, "source_path": str(path), "method": "INPUT" if kind == "html" else "POST",
                "form_type": form, "taxyear": year, "product": product, "fed_or_state": jurisdiction, **parsed}
        pages[key] = page
        for action in parsed["navigation"]:
            details = {k: action[k] for k in ("url_template", "query_parameters", "request_method", "operation", "label")}
            details["selected_record_id"] = action["query_parameters"].get("id", "")
            details["expression"] = action.get("expression", "")
            target_value = action["target_file"]
            if not re.search(r"\.php$", target_value, re.I) or re.search(r"[$<>{}]|://", target_value):
                warnings.append(f"{key}:{action['line']}: unresolved navigation {action['url_template']}")
                continue
            target, status = queue("oltproc", Path(target_value).name)
            confirmation = None
            if action["operation"] == "delete" and action["source_kind"] == "multipleInputArray":
                confirmation = delete_confirmation(path, parsed, html_root, post_root, parse_cache)
            if confirmation and not confirmation.get("unresolved"):
                modal_id = key + "#" + confirmation["modal_id"]
                source_path = Path(confirmation["source_path"])
                modal_inputs = list(confirmation["cancel_controls"])
                yes = confirmation["yes"]
                modal_inputs.append({"name": yes["attributes"].get("id", "Yes"), "id": yes["attributes"].get("id", ""),
                                     "label": clean(yes["label"]), "input_type": "link", "options": [],
                                     "attributes": yes["attributes"], "line": yes["line"], "source_line": yes["line"],
                                     "parent_groups": yes["parent_groups"], "conditions": []})
                pages[modal_id] = {"id": modal_id, "filename": source_path.name, "source_path": str(source_path),
                                   "method": "CONFIRMATION", "host_page": key, "form_type": form,
                                   "taxyear": year, "product": product, "fed_or_state": jurisdiction,
                                   "inputs": modal_inputs, "groups": confirmation["groups"],
                                   "javascript": [confirmation["javascript"]], "sha256": confirmation["sha256"],
                                   "navigation": [], "validation": [], "sql": [], "includes": [], "calls": [], "forms": [],
                                   "confirmation": confirmation}
                edge(key, modal_id, "delete", action, operation="delete", label="Delete: open confirmation",
                     selected_record_id=details["selected_record_id"], pending_request=details, server_request=False,
                     trigger=confirmation["trigger"])
                evidence = {"source_path": str(source_path), "line": yes["line"]}
                edge(modal_id, target, "confirm_delete", evidence, status, **details, choice="Yes", server_request=True)
                no = next(c for c in confirmation["cancel_controls"] if clean(c["label"]).lower() == "no") if any(clean(c["label"]).lower() == "no" for c in confirmation["cancel_controls"]) else confirmation["cancel_controls"][0]
                edge(modal_id, key, "cancel_delete", {"source_path": str(source_path), "line": no["line"]},
                     operation="delete", label="No / close: retain record and stay on summary", choice="No / close", server_request=False)
                action["confirmation"] = {"page_id": modal_id, "source_path": str(source_path), "source_line": confirmation["source_line"]}
            else:
                if confirmation:
                    warnings.append(f"{key}:{action['line']}: Delete modal trigger found, but its Yes/No binding could not be resolved")
                edge(key, target, action["operation"], action, status, **details, server_request=True,
                     confirmation_status="unresolved" if action["operation"] == "delete" else "not_required")
        if kind == "html":
            actions = [f for f in parsed["forms"] if f.get("action")]
            if not actions:
                # Protected templates usually inherit <form> from their PHP handler.
                candidates = ["olt_" + path.stem + ".php", path.stem + ".php", "qt_" + path.stem + ".php"]
                chosen = next((c for c in candidates if (post_root / c).is_file()), None)
                if chosen:
                    actions = [{"action": chosen, "inferred": True}]
                else:
                    warnings.append(f"{key}: no literal action or matching PHP handler")
            for action in actions:
                value = action["action"].split("?")[0].strip()
                if re.search(r"[$<>]|://", value):
                    warnings.append(f"{key}: unresolved form action {value}")
                    continue
                target, status = queue("oltproc", Path(value).name)
                edge(key, target, "submit", action, status, action=action["action"], inferred=action.get("inferred", False))
        else:
            forms = sorted(parsed["forms"], key=lambda x: x["offset"])
            for include in parsed["includes"]:
                target_value = include["target"].replace("\\", "/")
                if not target_value:
                    warnings.append(f"{key}:{include['line']}: unresolved include {include['expression']}")
                    continue
                if not re.search(r"\.html?$", target_value, re.I):
                    continue
                if "html/" not in target_value.lower() and "PROTECTED_PATH" not in include["expression"]:
                    continue
                relative = re.split(r"html/", target_value, flags=re.I)[-1]
                target, status = queue("html", relative)
                # Match the closest preceding wrapper in this branch, excluding unrelated sibling branches.
                compatible = [f for f in forms if f["offset"] < include["offset"] and
                              all(c in include["conditions"] for c in f.get("conditions", []))]
                wrapper = compatible[-1] if compatible else {}
                hidden = [c["source"] for c in parsed["calls"] if c["name"].lower() == "builddynamicformhiddendata"
                          and wrapper.get("offset", include["offset"]) <= c["offset"] < include["offset"]]
                edge(key, target, "render", include, status, expression=include["expression"],
                     action=wrapper.get("action", ""), hidden_data=hidden)
                if status == "internal" and wrapper.get("action"):
                    action = wrapper["action"].split("?")[0].strip()
                    if not re.search(r"[$<>]|://", action):
                        handler, handler_status = queue("oltproc", Path(action).name)
                        edge(target, handler, "submit", include, handler_status, action=action, inferred=False)
    # Link PHP validation/storage evidence to every input submitted to that handler.
    for transition in edges:
        if transition["kind"] != "submit" or transition["target"] not in pages or transition["source"] not in pages:
            continue
        handler, page = pages[transition["target"]], pages[transition["source"]]
        for control in page["inputs"]:
            name = control["name"].split("[")[0].lstrip("$")
            if not name:
                continue
            token = re.compile(r"\$" + re.escape(name) + r"\b")
            control.setdefault("post_validation", []).extend({"handler": handler["id"], **v} for v in handler["validation"]
                if token.search(" ".join(v["conditions"]) + " " + v["source"]))
            control.setdefault("storage", []).extend({"handler": handler["id"], **v} for v in handler["sql"] if token.search(v["source"]))
    all_inputs = [control for page in pages.values() for control in page["inputs"]]
    for transition in edges:
        conditions = " ".join(transition["conditions"])
        transition["condition_inputs"] = [{"name": control["name"], "label": control["label"]} for control in all_inputs
                                          if re.fullmatch(r"\w+", control["name"]) and re.search(r"\$" + re.escape(control["name"]) + r"\b", conditions)]
    for page in pages.values():
        incoming = [e for e in edges if e["target"] == page["id"]]
        page["entry_contexts"] = [{"source": e["source"], "operation": e.get("operation", e["kind"]),
                                   "query_parameters": e.get("query_parameters", {}), "choice": e.get("choice", ""),
                                   "selected_record_id": e.get("selected_record_id", "")} for e in incoming if e.get("operation")]
        if page["id"].startswith("oltproc/"):
            methods = sorted({e.get("request_method", "POST" if e["kind"] == "submit" else "GET") for e in incoming if e.get("server_request", True)})
            page["request_methods"] = methods
            page["method"] = "/".join(methods) or "POST"
    from .visibility import explain_graph
    return explain_graph({"schema_version": 2, "taxyear": year, "product": product, "fed_or_state": jurisdiction,
            "form_type": form, "starting_page": start_id, "pages": list(pages.values()), "edges": edges,
            "warnings": sorted(set(warnings)), "analysis": "static; predicates are source expressions, not evaluated outcomes"})
