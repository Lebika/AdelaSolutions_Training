/* Normalize stored input metadata for the readable details view, including older builds. */
(function(root, factory) {
 const api=factory();
 if(typeof module==='object' && module.exports)module.exports=api;
 else root.SoftwareFlowInputMetadata=api;
})(typeof globalThis!=='undefined'?globalThis:this,function() {
 'use strict';
 const types={text:'Text box',textboxinputctrl:'Text box',labelwithtextbox:'Text box',labelwithamount:'Amount',number:'Number',textarea:'Text area',radio:'Radio buttons',checkbox:'Checkbox',checkboxwithlabel:'Checkbox',select:'Dropdown',selectcombo:'Dropdown',combo:'Dropdown',hidden:'Hidden field',button:'Button',submit:'Submit button',link:'Link',labelwithlabelinput:'Read-only text'};
 const scalar=value=>{
  if(value===null || value===undefined)return '';
  if(Array.isArray(value))return value.length?scalar(value[value.length-1]):'';
  if(typeof value==='object')return scalar(value.value??value.expression??'');
  return String(value);
 };
 const plain=value=>scalar(value).replace(/<[^>]*>/g,' ').replace(/&(?:amp|lt|gt|quot|apos|nbsp);/g,m=>({'&amp;':'&','&lt;':'<','&gt;':'>','&quot;':'"','&apos;':"'",'&nbsp;':' '})[m]).replace(/\s+/g,' ').trim();
 function describe(input) {
  const attributes=Object.fromEntries(Object.entries(input.attributes||{}).map(([key,value])=>[key.replace(/^\$/,'').toLowerCase(),value]));
  const attr=key=>scalar(attributes[key]);
  const label=plain(input.label),nearby=plain(input.nearby_text),name=scalar(input.name),typeCode=scalar(input.input_type);
  let options=(input.options||[]).map(option=>({label:plain(option.label??option.text),value:scalar(option.value),event:scalar(option.onclick)}));
  if(!options.length){
   const grouped={};
   for(const [key,value] of Object.entries(attributes))if(key.startsWith('opt.')){
    const separator=key.lastIndexOf('.'),group=key.slice(0,separator),property=key.slice(separator+1);
    grouped[group]??={};grouped[group][property==='text'?'label':property]=scalar(value);
   }
   options=Object.values(grouped).map(option=>({label:plain(option.label),value:scalar(option.value),event:''}));
  }
  const messages=[];
  for(const value of [attributes.errmsg,attributes.errormessage]){
   if(value===undefined)continue;
   for(const entry of Array.isArray(value)?value:[value]){
    const message=scalar(entry);
    if(message && !messages.some(m=>m.message===message))messages.push({message:plain(message),conditions:entry?.conditions||[]});
   }
  }
  const properties=[];
  for(const [key,label] of [['placeholder','Placeholder'],['maxlength','Maximum length'],['minlength','Minimum length'],['min','Minimum value'],['max','Maximum value'],['step','Increment'],['inputformat','Input format'],['radiobtndef','Default option'],['defvalue','Option value'],['value','Value from source']]){
   const value=attr(key);if(value!=='')properties.push({label,value});
  }
  for(const [key,label] of [['required','Required'],['disabled','Disabled'],['readonly','Read only']])if(key in attributes){
   const value=attr(key);properties.push({label,value:value===''?'Yes (attribute present)':value});
  }
  const events=Object.entries(input.events||{}).map(([name,value])=>({name,handler:scalar(value)}));
  return {label,labelOrigin:label?'Explicit label':nearby?'Nearby page text':'Not recorded',displayLabel:label||nearby||name||'Unnamed input',nearby,name,id:scalar(input.id),type:types[typeCode.toLowerCase()]||typeCode||'Not recorded',typeCode,options,messages,properties,events,groups:input.parent_groups||[],conditions:input.conditions||[],repetition:input.repetition||[],rules:input.post_validation||input.validation||[],line:input.source_line??input.line??'',noOptions:/text|amount|number/i.test(typeCode)?'Free entry; no fixed options':'No fixed options recorded'};
 }
 function conditionText(condition,inputs) {
  const byName=new Map();
  const score=input=>(input.label?1:0)+(input.options?.length||0);
  for(const input of inputs)if(input.name&&(!byName.has(input.name)||score(input)>score(byName.get(input.name))))byName.set(input.name,input);
  let result=String(condition).replace(/\$(\w+)\s*(===|==|!==|!=)\s*(?:['"]([^'"]*)['"]|(-?\d+(?:\.\d+)?))/g,(full,name,operator,quoted,numeric)=>{
   const input=byName.get(name);if(!input)return full;
   const value=quoted??numeric,option=(input.options||[]).find(option=>String(option.value)===value);
   const subject=plain(input.label)||name,answer=option?.label?`"${plain(option.label)}"`:value;
   return `${subject} ${operator.includes('!')?'is not':'is'} ${answer}`;
  });
  result=result.replace(/\$(\w+)/g,(full,name)=>{const input=byName.get(name);return input?(plain(input.label)||name):full;});
  return result.replace(/&&/g,' AND ').replace(/\|\|/g,' OR ').trim();
 }
 function nextPages(graph,pageId,includeExternal=false) {
  const pages=new Map(graph.pages.map(page=>[page.id,page])),outcomes=[];
  for(const edge of graph.edges.filter(edge=>edge.source===pageId)){
   const steps=edge.kind==='submit'?graph.edges.filter(next=>next.source===edge.target && next.kind==='render'):[];
   for(const next of steps.length?steps:[edge]){
    if(next.target_status==='external'&&!includeExternal)continue;
    const target=pages.get(next.target);
    const outcome={edge:next,via:steps.length?edge.target:'',label:steps.length?'After save / continue':edge.label||edge.kind,target:next.target,page:target,conditions:next.conditions||[],choice:next.choice||''};
    if(!outcomes.some(item=>item.target===outcome.target&&item.label===outcome.label&&item.choice===outcome.choice&&JSON.stringify(item.conditions)===JSON.stringify(outcome.conditions)))outcomes.push(outcome);
   }
  }
  return outcomes;
 }
 return {describe,conditionText,nextPages};
});
