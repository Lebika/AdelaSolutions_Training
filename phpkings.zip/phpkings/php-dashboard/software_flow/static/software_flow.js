(() => {
 'use strict';
 const $ = id => document.getElementById(`sf-${id}`);
 const base = '/phphelper/software-flow/api';
 let available = [], builds = [], graph = null, tab = 'create', busy = false, optionRequest = 0, activePageId = '';
 const selection = () => ({taxyear:$('year').value, product:$('product').value, fed_or_state:$('state').value, form:$('form').value.trim()});
 const message = (value, error=false) => {$('status').textContent=value;$('status').classList.toggle('error',error);};
 async function api(path, data) {
  const response = await fetch(base + path, data ? {method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(data)} : {});
  const result = await response.json();
  if (!response.ok || !result.ok) throw Error(result.error || `Request failed (${response.status})`);
  return result;
 }
 function el(tag, text, parent, cls) {const node=document.createElement(tag);if(text!==undefined)node.textContent=text;if(cls)node.className=cls;if(parent)parent.append(node);return node;}
 function details(parent, title, value) {const d=el('details',undefined,parent);el('summary',title,d);el('pre',JSON.stringify(value,null,2),d);return d;}
 function field(parent,label,value) {el('dt',label,parent);el('dd',value===undefined||value===''?'Not recorded':String(value),parent);}
 function readableTable(parent,headings,rows) {
  const table=el('table',undefined,el('div',undefined,parent,'scroll'));
  const head=el('tr',undefined,el('thead',undefined,table));headings.forEach(h=>el('th',h,head));
  const body=el('tbody',undefined,table);rows.forEach(values=>{const row=el('tr',undefined,body);values.forEach(value=>el('td',String(value??''),row));});return table;
 }
 function visibilityDetails(parent,rules,notes=[]) {
  if(!rules.length)el('p','No show/hide or enable/disable rule was identified in the recorded scripts.',parent,'muted');
  for(const rule of rules){
   const card=el('article',undefined,parent,'outcome');el('p',rule.sentence,card);
   if(rule.affected_labels?.length)el('p',`Affected inputs: ${rule.affected_labels.join('; ')}`,card,'muted');
   const source=el('details',undefined,card);el('summary','View source evidence',source);
   el('p',`${rule.source_file}:${rule.source_line}`,source,'muted');el('div',rule.source_code,source,'source-expression');
  }
  for(const note of new Set(notes.map(note=>typeof note==='string'?note:note.message)))el('p',note,parent,'muted');
 }
 function inputDetails(parent,input,page) {
  const model=SoftwareFlowInputMetadata.describe(input);
  parent.replaceChildren();
  el('h3',model.displayLabel,parent);
  if(model.labelOrigin==='Nearby page text')el('p','No explicit label was recorded. The heading above comes from nearby page text.',parent,'muted');
  const definition=el('dl',undefined,parent,'input-fields');
  field(definition,'Label',model.label||'No explicit label recorded');
  if(!model.label && model.nearby)field(definition,'Nearby page text',model.nearby);
  field(definition,'Name',model.name);field(definition,'Type',model.type);field(definition,'HTML ID',model.id);
  field(definition,'Page',page.id||page.filename);field(definition,'Source line',model.line);
  field(definition,'Parent groups',model.groups.join(' / ')||'No group recorded');
  if(model.typeCode!==model.type)field(definition,'Source input type',model.typeCode);
  for(const property of model.properties)field(definition,property.label,property.value);
  el('h4','Input options',parent);
  if(model.options.length)readableTable(parent,['Option label','Submitted value','On selection'],model.options.map(o=>[o.label||'(No label recorded)',o.value===''?'(Empty value)':o.value,o.event||'—']));
  else el('p',model.noOptions,parent,'muted');
  el('h4','Visibility and input behavior',parent);
  visibilityDetails(parent,input.visibility_behaviors||[],input.visibility_notes||[]);
  if(model.messages.length){el('h4','Validation messages',parent);readableTable(parent,['Message / source expression','Shown when'],model.messages.map(m=>[m.message,m.conditions.join(' AND ')||'No condition recorded']));}
  if(model.conditions.length){el('h4','Displayed when',parent);const list=el('ul',undefined,parent);model.conditions.forEach(condition=>el('li',condition,list,'source-expression'));}
  if(model.repetition.length){el('h4','Repeated input',parent);el('p','This input is created inside a loop. Its name or options may depend on the row.',parent,'muted');model.repetition.forEach(rule=>el('div',rule,parent,'source-expression'));}
  if(model.events.length){el('h4','Input events',parent);readableTable(parent,['Event','Action from source'],model.events.map(e=>[e.name,e.handler]));}
  if(model.rules.length){const section=el('details',undefined,parent);el('summary',`Validation rules (${model.rules.length})`,section);readableTable(section,['When','Rule from source','Location'],model.rules.map(r=>[(r.conditions||[]).join(' AND ')||'No condition recorded',r.source,`${r.handler||page.filename||page.id}:${r.line||''}`]));}
  details(parent,'Advanced: raw input data',input);
 }
 function starts() {
  const pages=available.find(f=>f.name===$('form').value)?.starting_pages || [];
  $('starts').replaceChildren(...pages.map(p=>{const o=document.createElement('option');o.value=p;return o;}));
  $('start').value=pages[0] || '';
 }
 function clearView() {graph=null;activePageId='';$('page').replaceChildren();$('page').disabled=true;$('page-count').textContent='';$('recording-notice').hidden=true;$('chart').replaceChildren();$('stats').replaceChildren();$('transitions').replaceChildren();$('warnings').textContent='';$('detail').textContent='Load a recorded flow to inspect its metadata.';$('export').disabled=true;$('results').replaceChildren();}
 async function options() {
  const requestId=++optionRequest;
  const result=await api('/options?'+new URLSearchParams(selection()));
  if(requestId!==optionRequest)return;
  available=result.forms;builds=result.builds;
  const names=[...new Set([...available.map(f=>f.name),...builds.map(b=>b.form_type)])].sort();
  $('forms').replaceChildren(...names.map(name=>{const o=document.createElement('option');o.value=name;o.label=builds.some(b=>b.form_type===name)?`${name} (recorded)`:name;return o;}));
  $('paths').textContent=`HTML: ${result.html_root} | Handlers: ${result.post_root}`;
  if(!$('form').value && names.length)$('form').value=names[0];
  starts();
  message(result.available?`${available.length} forms discovered; ${builds.length} recordings saved.`:'The selected source folders are unavailable. Saved recordings can still be viewed.');
 }
 function switchTab(value) {
  tab=value;
  document.querySelectorAll('[data-tab]').forEach(b=>b.setAttribute('aria-selected',String(b.dataset.tab===value)));
  $('build-panel').hidden=!['create','update'].includes(value);$('view-panel').hidden=value!=='view';$('search-panel').hidden=value!=='search';
  $('build-title').textContent=value==='update'?'Update a flow recording':'Create a flow recording';
  $('build').textContent=value==='update'?'Update recording':'Create recording';
 }
 function conditionList(parent,conditions) {
  const inputs=graph.pages.flatMap(page=>page.inputs||[]);
  if(!conditions.length){el('p','No additional condition recorded.',parent,'muted');return;}
  const list=el('ul',undefined,parent);conditions.forEach(condition=>el('li',SoftwareFlowInputMetadata.conditionText(condition,inputs),list));
 }
 function transitionDetails(parent,edge) {
  const fields=el('dl',undefined,parent,'input-fields');
  field(fields,'From',edge.source);field(fields,'To',edge.target);field(fields,'Action',edge.label||edge.kind);
  if(edge.choice)field(fields,'Choice',edge.choice);
  if(edge.request_method)field(fields,'Request method',edge.request_method);
  if(edge.selected_record_id)field(fields,'Selected record ID',edge.selected_record_id);
  if(edge.server_request===false)field(fields,'Server request','None; the action stays in the page');
  el('h4','Conditions',parent);conditionList(parent,edge.conditions||[]);
  if(Object.keys(edge.query_parameters||{}).length)readableTable(parent,['Parameter','Value from source'],Object.entries(edge.query_parameters));
  const destination=graph.pages.find(page=>page.id===edge.target);
  if(destination){const button=el('button','Open destination page',parent,'input-detail-button');button.addEventListener('click',()=>inspect(destination));}
  details(parent,'Advanced: transition source data',edge);
 }
 function nextPageDetails(parent,page) {
  const outcomes=SoftwareFlowInputMetadata.nextPages(graph,page.id,$('external').checked);
  el('h3','Next pages and conditions',parent);
  el('p','These are source-code branches. Each condition determines which page is displayed after an action or save.',parent,'muted');
  if(!outcomes.length)el('p','No next-page transitions were recorded for this page.',parent,'muted');
  for(const outcome of outcomes){
   const card=el('article',undefined,parent,'outcome');
   el('h4',`${outcome.label}${outcome.choice?' ('+outcome.choice+')':''}`,card);
   el('strong',outcome.target,card);
   if(outcome.via)el('p',`Handled by ${outcome.via}`,card,'muted');
   conditionList(card,outcome.conditions);
   if(outcome.page){el('p',`${outcome.page.inputs.length} inputs / controls`,card,'muted');const button=el('button','Open page and inputs',card,'input-detail-button');button.addEventListener('click',()=>inspect(outcome.page));}
   else el('p',outcome.edge.target_status==='missing'?'Source file is missing.':'Destination is outside this recorded form.',card,'muted');
   const source=el('details',undefined,card);el('summary','Source condition and location',source);
   el('p',(outcome.edge.conditions||[]).join('\nAND ')||'No source condition',source,'source-expression');
   el('p',`${outcome.edge.source_file||outcome.via||outcome.edge.source}:${outcome.edge.source_line||'inferred'}`,source,'muted');
  }
  return outcomes.length;
 }
 function pageChoices() {
  $('page').replaceChildren();$('page').disabled=false;
  for(const [label,predicate] of [['Input pages',page=>page.method==='INPUT'],['Confirmation dialogs',page=>page.method==='CONFIRMATION'],['PHP handlers',page=>!['INPUT','CONFIRMATION'].includes(page.method)]]){
   const pages=graph.pages.filter(predicate);if(!pages.length)continue;
   const group=el('optgroup',undefined,$('page'));group.label=label;
   for(const page of pages){const option=el('option',`${page.id} (${page.inputs.length} inputs)`,group);option.value=page.id;}
  }
  $('page-count').textContent=`${graph.pages.filter(page=>page.method==='INPUT').length} input pages available`;
  const match=graph.starting_page.match(/([^/]+?)(?:_?done|_?summary)\.html?$/i);
  const expected=match?.[1];$('recording-notice').replaceChildren();$('recording-notice').hidden=!expected||expected.toLowerCase()===graph.form_type.toLowerCase();
  if(!$('recording-notice').hidden){
   el('div',`This recording is saved as ${graph.form_type}, but ${graph.starting_page} belongs to ${expected}. That mismatch can exclude the other form pages.`, $('recording-notice'));
   if(builds.some(build=>build.form_type.toLowerCase()===expected.toLowerCase())){const button=el('button',`Load ${expected} recording`,$('recording-notice'));button.addEventListener('click',safely(async()=>{$('form').value=expected;starts();await view();}));}
  }
 }
 function inspect(page) {
  activePageId=page.id;$('page').value=page.id;
  $('detail-title').textContent=page.id;$('detail').replaceChildren();
  el('p',page.source_path,$('detail'),'muted');
  el('span',`${page.method} · ${page.inputs.length} inputs`,$('detail'),'pill');
  const tabs=el('div',undefined,$('detail'),'detail-tabs');tabs.setAttribute('role','tablist');tabs.setAttribute('aria-label','Selected page information');
  const inputButton=el('button',`Inputs (${page.inputs.length})`,tabs),nextButton=el('button','Next pages and conditions',tabs);
  const inputPanel=el('div',undefined,$('detail')),nextPanel=el('div',undefined,$('detail'));
  for(const button of [inputButton,nextButton]){button.type='button';button.setAttribute('role','tab');}
  const choose=next=>{inputPanel.hidden=next;nextPanel.hidden=!next;inputButton.setAttribute('aria-selected',String(!next));nextButton.setAttribute('aria-selected',String(next));};
  inputButton.addEventListener('click',()=>choose(false));nextButton.addEventListener('click',()=>choose(true));
  const nextCount=nextPageDetails(nextPanel,page);nextButton.textContent=`Next pages and conditions (${nextCount})`;choose(!page.inputs.length);
  const table=el('table',undefined,el('div',undefined,inputPanel,'scroll input-list'));
  const head=el('tr',undefined,el('thead',undefined,table));['Input label / name','Type','Options','Details'].forEach(t=>el('th',t,head));
  const body=el('tbody',undefined,table);
  const selected=el('section',undefined,inputPanel,'input-detail-card');selected.setAttribute('aria-label','Selected input details');
  const buttons=[];
  for(const input of page.inputs){
   const model=SoftwareFlowInputMetadata.describe(input),row=el('tr',undefined,body),name=el('td',undefined,row);
   el('strong',model.displayLabel,name);el('div',model.name,name,'muted');el('div',`Line ${model.line}`,name,'muted');
   el('td',model.type,row);el('td',model.options.length?`${model.options.length} option${model.options.length===1?'':'s'}`:model.noOptions,row);
   const button=el('button','View details',el('td',undefined,row),'input-detail-button');button.type='button';button.setAttribute('aria-pressed','false');buttons.push({button,row});
   button.addEventListener('click',event=>{buttons.forEach(item=>{item.button.setAttribute('aria-pressed',String(item.button===button));item.row.classList.toggle('selected-input',item.button===button);});inputDetails(selected,input,page);if(event.isTrusted)selected.scrollIntoView({block:'nearest',behavior:'smooth'});});
  }
  if(buttons.length)buttons[0].button.click();else{selected.hidden=true;el('p','No inputs were recorded on this page. Select an input page from the page selector.', inputPanel,'muted');}
  const visibility=el('details',undefined,inputPanel);el('summary','JavaScript visibility behavior',visibility);
  visibilityDetails(visibility,page.visibility_analysis?.rules||[],page.visibility_analysis?.notes||[]);
  details(visibility,'Advanced: recorded JavaScript',page.javascript);
  details(inputPanel,'Edit / Delete and navigation actions',page.navigation || []);
  details(inputPanel,'Incoming selected-record and request context',page.entry_contexts || []);
  if(page.confirmation)details(inputPanel,'Confirmation source and Yes / No behavior',page.confirmation);
  details(inputPanel,'Parent div/span groups',page.groups);
  details(inputPanel,'Validation and SQL evidence',{validation:page.validation,sql:page.sql});
  details(inputPanel,'Complete page metadata',page);
 }
 function draw() {
  $('chart').replaceChildren();if(!graph)return;
  const ns='http://www.w3.org/2000/svg';
  const svgTag=(tag,attrs={},parent)=>{const n=document.createElementNS(ns,tag);Object.entries(attrs).forEach(([k,v])=>n.setAttribute(k,String(v)));if(parent)parent.append(n);return n;};
  let edges=graph.edges.filter(e=>$('external').checked || e.target_status==='internal');
  const nodes=graph.pages.map(p=>({id:p.id,page:p}));
  if($('external').checked)for(const edge of edges)if(!nodes.some(n=>n.id===edge.target))nodes.push({id:edge.target,status:edge.target_status});
  const hasModal=nodes.some(n=>n.page?.method==='CONFIRMATION'),positions=new Map(),rows=[0,0,0,0];
  for(const node of nodes){const col=!node.page?(hasModal?3:2):node.page.method==='INPUT'?0:node.page.method==='CONFIRMATION'?1:(hasModal?2:1);const row=rows[col]++;positions.set(node.id,{x:30+col*340,y:60+row*160,node});}
  const width=($('external').checked?3:2)*340+(hasModal?340:0)+40,height=Math.max(...rows)*160+70;
  const svg=svgTag('svg',{viewBox:`0 0 ${width} ${height}`,role:'img','aria-label':`${graph.form_type} page flow`},$('chart'));
  const marker=svgTag('marker',{id:'sf-arrow',viewBox:'0 0 10 10',refX:10,refY:5,markerWidth:7,markerHeight:7,orient:'auto-start-reverse'},svgTag('defs',{},svg));svgTag('path',{d:'M0 0 L10 5 L0 10 Z',fill:'#64748b'},marker);
  for(const edge of edges){const a=positions.get(edge.source),b=positions.get(edge.target);if(!a||!b)continue;
   const forward=a.x<=b.x,x1=a.x+(forward?250:0),x2=b.x+(forward?0:250),y1=a.y+32,y2=b.y+32;
   const bend=forward?45:-65;const group=svgTag('g',{tabindex:0,role:'button','aria-label':`${edge.source} to ${edge.target}`},svg);
   const curve=`M${x1} ${y1} C${x1+bend} ${y1},${x2-bend} ${y2},${x2} ${y2}`;
   svgTag('path',{d:curve,stroke:'transparent',fill:'none','stroke-width':12},group);
   svgTag('path',{d:curve,stroke:edge.kind.includes('delete')?'#dc2626':edge.kind==='edit'?'#7c3aed':edge.kind==='submit'?'#94a3b8':'#2563eb',fill:'none','stroke-width':2,'stroke-dasharray':edge.server_request===false?'5 4':'none','marker-end':'url(#sf-arrow)'},group);
   const title=svgTag('title',{},group);title.textContent=`${edge.label||edge.kind} ${edge.choice||''}: ${edge.conditions.join(' AND ') || 'unconditional'}\nLine ${edge.source_line||'inferred'}`;
   const show=()=>{$('detail-title').textContent='Transition details';$('detail').replaceChildren();transitionDetails($('detail'),edge);};group.addEventListener('click',show);group.addEventListener('keydown',e=>{if(e.key==='Enter')show();});
  }
  for(const {x,y,node} of positions.values()){const group=svgTag('g',{class:'node',tabindex:0,role:'button','aria-label':node.id},svg);svgTag('rect',{x,y,width:250,height:66,rx:8,fill:!node.page?'#f1f5f9':node.page.method==='INPUT'?'#eff6ff':node.page.method==='CONFIRMATION'?'#f5f3ff':'#ecfdf5',stroke:!node.page?'#cbd5e1':node.page.method==='INPUT'?'#93c5fd':node.page.method==='CONFIRMATION'?'#c4b5fd':'#6ee7b7'},group);
   const text=svgTag('text',{x:x+12,y:y+26,'font-size':12,fill:'#0f172a'},group);text.textContent=node.id.length>32?node.id.slice(0,29)+'…':node.id;
   const sub=svgTag('text',{x:x+12,y:y+47,'font-size':11,fill:'#64748b'},group);sub.textContent=node.page?`${node.page.method} · ${node.page.inputs.length} inputs`:node.status;
   svgTag('title',{},group).textContent=node.id;
   const show=()=>{if(node.page)inspect(node.page);};group.addEventListener('click',show);group.addEventListener('keydown',e=>{if(e.key==='Enter')show();});
  }
 }
 async function view() {
  message('Reading graph and metadata from the vector database…');
  const result=await api('/view?'+new URLSearchParams(selection()));graph=result.graph;$('export').disabled=false;
  $('stats').replaceChildren();for(const [label,value] of Object.entries({'Source files':graph.manifest.pages,Confirmations:graph.manifest.confirmations||0,Inputs:graph.manifest.inputs,Transitions:graph.edges.length,Warnings:graph.warnings.length})){const d=el('div',undefined,$('stats'));el('strong',value,d);el('span',label,d,'muted');}
  pageChoices();
  $('transitions').replaceChildren();for(const edge of graph.edges){const d=el('details',undefined,$('transitions'));el('summary',`${edge.label||edge.kind}: ${edge.source} → ${edge.target} (${edge.target_status})`,d);transitionDetails(d,edge);}
  $('warnings').textContent=graph.warnings.join('\n')||'No source warnings.';draw();if(graph.pages.length)inspect(graph.pages.find(page=>page.id===graph.starting_page)||graph.pages[0]);message(`Loaded ${graph.form_type} · Built ${new Date(graph.built_at).toLocaleString()} · ${graph.embedding_model}`);
 }
 async function build() {
  if(busy)return;busy=true;$('build').disabled=true;
  document.querySelectorAll('#scope input,#scope select,#scope button,[data-tab]').forEach(n=>n.disabled=true);
  try{const mode=tab==='update'?'update':'create';const result=await api('/build',{...selection(),starting_page:$('start').value.trim(),mode});
   while(true){const status=await api('/status/'+result.job_id);message(status.message,status.status==='failed');if(status.status==='failed')throw Error(status.message);if(status.status==='complete')break;await new Promise(resolve=>setTimeout(resolve,1200));}
   await options();switchTab('view');await view();
  }finally{busy=false;$('build').disabled=false;document.querySelectorAll('#scope input,#scope select,#scope button,[data-tab]').forEach(n=>n.disabled=false);}
 }
 const safely=fn=>async()=>{try{await fn();}catch(error){message(error.message,true);}};
 document.querySelectorAll('[data-tab]').forEach(button=>button.addEventListener('click',()=>switchTab(button.dataset.tab)));
 ['year','product','state'].forEach(id=>$(id).addEventListener('change',safely(async()=>{clearView();$('form').value='';await options();})));
 $('form').addEventListener('change',()=>{clearView();starts();});$('refresh').addEventListener('click',safely(options));
 $('build').addEventListener('click',safely(build));$('view').addEventListener('click',safely(view));$('external').addEventListener('change',()=>{draw();const page=graph?.pages.find(page=>page.id===activePageId);if(page)inspect(page);});
 $('page').addEventListener('change',()=>{const page=graph?.pages.find(page=>page.id===$('page').value);if(page)inspect(page);});
 $('search').addEventListener('click',safely(async()=>{message('Searching recorded page and input evidence…');const result=await api('/search',{...selection(),query:$('query').value});$('results').replaceChildren();for(const item of result.results){const div=el('div',undefined,$('results'),'result');const m=item.metadata;el('strong',`${m.kind} · ${m.page_id||m.form_type} · score ${item.score.toFixed(3)}`,div);if(m.kind==='input')inputDetails(el('section',undefined,div,'input-detail-card'),m.data,{id:m.page_id,filename:m.filename});else{el('p',m.text,div);details(div,'Stored metadata',m);}}message(`${result.results.length} results`);}));
 $('export').addEventListener('click',()=>{if(!graph)return;const url=URL.createObjectURL(new Blob([JSON.stringify(graph,null,2)],{type:'application/json'}));const a=el('a');a.href=url;a.download=`${graph.taxyear}-${graph.form_type}-software-flow.json`;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);});
 safely(options)();
})();
