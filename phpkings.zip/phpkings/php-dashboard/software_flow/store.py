"""Generation-based local Qdrant persistence with real BGE embeddings."""
from __future__ import annotations

import json
import os
from datetime import datetime, timezone
from pathlib import Path
from threading import RLock
from uuid import NAMESPACE_URL, uuid4, uuid5

from .scanner import scope
import php_flow_scanner as existing

DATA_ROOT = existing.PHPDATA_ROOT / "software flow"
MODEL = "BAAI/bge-small-en-v1.5"
COLLECTION = "software_flow"
LOCK = RLock()
_model = None


def embed(texts, query=False):
    global _model
    # FastEmbed runs the actual ONNX BGE model; never substitute synthetic vectors.
    from fastembed import TextEmbedding
    with LOCK:
        if _model is None:
            cache = DATA_ROOT / ".models"
            cache.mkdir(parents=True, exist_ok=True)
            _model = TextEmbedding(model_name=MODEL, cache_dir=str(cache), threads=2)
        method = _model.query_embed if query else _model.passage_embed
        return [vector.tolist() for vector in method(texts)]


def directory(year, product, jurisdiction, form):
    year, product, jurisdiction = scope(year, product, jurisdiction)
    from .scanner import safe_file
    if not form or "/" in form or "\\" in form or form in {".", ".."}:
        raise ValueError("Invalid form name")
    return safe_file(DATA_ROOT / year / product / jurisdiction, form)


def records_for(graph):
    common = {key: graph[key] for key in ("taxyear", "product", "fed_or_state", "form_type")}
    yield {**common, "kind": "graph", "data": {k: v for k, v in graph.items() if k != "pages"},
           "text": f"{graph['form_type']} flow starting at {graph['starting_page']}"}
    for page in graph["pages"]:
        base = {**common, "filename": page["filename"], "page_id": page["id"], "source_path": page["source_path"]}
        yield {**base, "kind": "page", "data": page,
               "text": f"{page['id']} {page['method']} {graph['form_type']} inputs " +
                       "; ".join(f"{i['name']} {i['label']}" for i in page["inputs"])}
        for i, control in enumerate(page["inputs"]):
            yield {**base, "kind": "input", "input_index": i, "data": control,
                   "text": f"{graph['form_type']} {page['id']} {control['name']} {control['label']} {control['input_type']} " +
                           json.dumps({key: control.get(key) for key in ("options", "conditions", "post_validation", "parent_groups")}, ensure_ascii=False)}
        for i, action in enumerate(page.get("navigation", [])):
            yield {**base, "kind": "action", "action_index": i, "data": action,
                   "text": f"{graph['form_type']} {page['id']} {action['operation']} selected record " +
                           action["url_template"] + " " + json.dumps(action.get("confirmation", {}))}
        for i, script in enumerate(page["javascript"]):
            code = script["code"]
            for part in range(0, max(len(code), 1), 1400):
                yield {**base, "kind": "javascript", "script_index": i, "chunk": part // 1400,
                       "data": script if len(code) <= 1400 else {**script, "code": code[part:part + 1400]},
                       "text": f"{graph['form_type']} {page['id']} javascript {script['src']} " + code[part:part + 1400]}
    for index, edge in enumerate(graph["edges"]):
        yield {**common, "kind": "transition", "edge_index": index, "data": edge,
               "text": f"{graph['form_type']} {edge['source']} -> {edge['target']} {edge['kind']} {edge.get('label', '')} {edge.get('choice', '')} " +
                       " AND ".join(edge["conditions"]) + " " + json.dumps(edge.get("query_parameters", {}))}


def save(graph, *, update=False, progress=None, embedder=None):
    from qdrant_client import QdrantClient, models
    base = directory(graph["taxyear"], graph["product"], graph["fed_or_state"], graph["form_type"])
    embedder = embedder or embed
    with LOCK:
        pointer = base / "current.json"
        if pointer.exists() and not update:
            raise ValueError("This form already has a recording. Use Update to rescan it.")
        if update and not pointer.exists():
            raise ValueError("No recording exists. Use Create first.")
        generation = uuid4().hex
        folder = base / "generations" / generation
        folder.mkdir(parents=True)
        created = datetime.now(timezone.utc).isoformat()
        graph = {**graph, "built_at": created, "embedding_model": MODEL, "generation": generation}
        records = list(records_for(graph))
        if progress:
            progress(f"Embedding {len(records)} records with {MODEL}; first use may download the model")
        client = QdrantClient(path=str(folder / "qdrant"))
        try:
            client.create_collection(COLLECTION, vectors_config=models.VectorParams(size=384, distance=models.Distance.COSINE))
            for offset in range(0, len(records), 32):
                batch = records[offset:offset + 32]
                vectors = embedder([record["text"] for record in batch])
                if len(vectors) != len(batch) or any(len(v) != 384 for v in vectors):
                    raise ValueError("BGE embedding result has an invalid count or dimension")
                client.upsert(COLLECTION, points=[models.PointStruct(
                    id=str(uuid5(NAMESPACE_URL, f"{generation}/{offset + i}")), vector=vector,
                    payload={**record, "embedding_model": MODEL, "built_at": created})
                    for i, (record, vector) in enumerate(zip(batch, vectors))], wait=True)
                if progress:
                    progress(f"Stored {min(offset + 32, len(records))}/{len(records)} records")
            if client.count(COLLECTION, exact=True).count != len(records):
                raise RuntimeError("Stored record count does not match the completed build")
        finally:
            client.close()
        (folder / "metadata.json").write_text(json.dumps(graph, ensure_ascii=False, indent=2), encoding="utf-8")
        manifest = {"generation": generation, "built_at": created, "embedding_model": MODEL,
                    "records": len(records), "pages": sum(p["method"] != "CONFIRMATION" for p in graph["pages"]),
                    "nodes": len(graph["pages"]), "confirmations": sum(p["method"] == "CONFIRMATION" for p in graph["pages"]),
                    "inputs": sum(len(p["inputs"]) for p in graph["pages"]),
                    "starting_page": graph["starting_page"], "form_type": graph["form_type"],
                    "warnings": len(graph["warnings"])}
        temporary = base / f"current-{generation}.tmp"
        temporary.write_text(json.dumps(manifest, indent=2), encoding="utf-8")
        os.replace(temporary, pointer)
        return manifest


def _current(year, product, jurisdiction, form):
    base = directory(year, product, jurisdiction, form)
    pointer = base / "current.json"
    if not pointer.exists():
        raise FileNotFoundError("No recording exists for the selected form")
    manifest = json.loads(pointer.read_text(encoding="utf-8"))
    generation = manifest["generation"]
    if len(generation) != 32 or any(c not in "0123456789abcdef" for c in generation):
        raise ValueError("Invalid saved generation")
    return base / "generations" / generation / "qdrant", manifest


def list_builds(year, product, jurisdiction):
    year, product, jurisdiction = scope(year, product, jurisdiction)
    base = DATA_ROOT / year / product / jurisdiction
    with LOCK:
        return [json.loads(path.read_text(encoding="utf-8")) for path in sorted(base.glob("*/current.json"))]


def load(year, product, jurisdiction, form):
    from qdrant_client import QdrantClient
    with LOCK:
        path, manifest = _current(year, product, jurisdiction, form)
        client = QdrantClient(path=str(path))
        try:
            pages, graph, offset = [], None, None
            while True:
                points, offset = client.scroll(COLLECTION, limit=100, offset=offset, with_vectors=False)
                for point in points:
                    payload = point.payload
                    if payload["kind"] == "graph":
                        graph = payload["data"]
                    elif payload["kind"] == "page":
                        pages.append(payload["data"])
                if offset is None:
                    break
            if graph is None:
                raise ValueError("Recording has no graph metadata")
            return {**graph, "pages": sorted(pages, key=lambda p: p["id"] != graph["starting_page"]), "manifest": manifest}
        finally:
            client.close()


def search(year, product, jurisdiction, form, query, limit=10, embedder=None):
    from qdrant_client import QdrantClient
    if not str(query).strip() or len(query) > 2000:
        raise ValueError("Enter a search question of 1 to 2000 characters")
    with LOCK:
        path, _ = _current(year, product, jurisdiction, form)
        vectors = (embedder or embed)([query], query=True)
        client = QdrantClient(path=str(path))
        try:
            result = client.query_points(COLLECTION, query=vectors[0], limit=min(max(int(limit), 1), 50), with_payload=True)
            return [{"score": point.score, "metadata": point.payload} for point in result.points]
        finally:
            client.close()
