const {test}=require('node:test');
const assert=require('node:assert/strict');
const {describe,conditionText,nextPages}=require('./static/input_metadata.js');

test('radio options and source-backed properties use readable values, including zero',()=>{
 const model=describe({name:'whose_int',label:'Recipient',id:'recipient',input_type:'radio',source_line:42,
  options:[{label:'Primary <b>taxpayer</b>',value:0},{label:'Spouse',value:'1'}],
  attributes:{$radioBtnDef:[{value:'0'}],maxlength:[{value:12}],value:[{value:'$whose_int'}]},parent_groups:['formwindow']});
 assert.equal(model.type,'Radio buttons');
 assert.equal(model.options[0].value,'0');
 assert.equal(model.options[0].label,'Primary taxpayer');
 assert.deepEqual(model.properties,[{label:'Maximum length',value:'12'},{label:'Default option',value:'0'},{label:'Value from source',value:'$whose_int'}]);
 assert.equal(model.name,'whose_int');
 assert.equal(model.line,42);
});

test('unlabeled text area distinguishes nearby text from an explicit label',()=>{
 const model=describe({name:'nominee_div_expln',label:'',nearby_text:'Nominee Capital Gains Explanation',input_type:'textarea',options:[],attributes:{}});
 assert.equal(model.label,'');
 assert.equal(model.displayLabel,'Nominee Capital Gains Explanation');
 assert.equal(model.labelOrigin,'Nearby page text');
 assert.equal(model.type,'Text area');
 assert.equal(model.noOptions,'Free entry; no fixed options');
});

test('older dropdown metadata and validation messages are rendered without nested JSON',()=>{
 const model=describe({name:'state',input_type:'SELECTCOMBO',attributes:{
  'opt.option1.value':[{value:'CA'}],'opt.option1.text':[{value:'California'}],
  errMsg:[{value:'Choose a state',conditions:['($state_err == 1)']}],required:''},
  events:{onchange:[{value:'ShowState()'}]}});
 assert.deepEqual(model.options,[{label:'California',value:'CA',event:''}]);
 assert.deepEqual(model.messages,[{message:'Choose a state',conditions:['($state_err == 1)']}]);
 assert.deepEqual(model.events,[{name:'onchange',handler:'ShowState()'}]);
 assert.equal(model.type,'Dropdown');
 assert.deepEqual(model.properties,[{label:'Required',value:'Yes (attribute present)'}]);
});

test('next-page view follows the save handler to conditional input pages',()=>{
 const graph={pages:[{id:'html/1099int.html'},{id:'oltproc/olt_1099int.php'},{id:'html/1099int_stexempt.html',inputs:[{name:'state'}]}],edges:[
  {source:'html/1099int.html',target:'oltproc/olt_1099int.php',kind:'submit',target_status:'internal'},
  {source:'oltproc/olt_1099int.php',target:'html/1099int_stexempt.html',kind:'render',target_status:'internal',conditions:['($tax_exempt_1099int > 0)']},
  {source:'oltproc/olt_1099int.php',target:'html/other.html',kind:'render',target_status:'external',conditions:['($other == 1)']}
 ]};
 const result=nextPages(graph,'html/1099int.html');
 assert.equal(result.length,1);
 assert.equal(result[0].via,'oltproc/olt_1099int.php');
 assert.equal(result[0].target,'html/1099int_stexempt.html');
 assert.deepEqual(result[0].conditions,['($tax_exempt_1099int > 0)']);
 assert.equal(result[0].page.inputs[0].name,'state');
 assert.equal(nextPages(graph,'html/1099int.html',true).length,2);
});

test('conditions show input labels and option labels instead of unexplained variables',()=>{
 const inputs=[{name:'more',label:'What next?',options:[{value:'1',label:'Add a new 1099-INT'}]},
  {name:'more',label:'',input_type:'hidden'}, {name:'tax_exempt_1099int',label:'8. Tax-exempt interest'}];
 assert.equal(conditionText('($more == 1)',inputs),'(What next? is "Add a new 1099-INT")');
 assert.equal(conditionText('($tax_exempt_1099int > 0)',inputs),'(8. Tax-exempt interest > 0)');
 assert.equal(conditionText('($err_flag == 0)',inputs),'($err_flag == 0)');
});
