import unittest

from software_flow.visibility import explain_page


def page(script, controls):
    return {"id": "html/example.html", "source_path": "example.html", "javascript": [{"line": 10, "code": script}], "inputs": controls}


class VisibilityTests(unittest.TestCase):
    def test_checked_and_unchecked_enable_and_disable_a_field(self):
        controller={"name":"allow", "id":"allow", "label":"Enter interest", "input_type":"checkbox", "events":{"onchange":"toggle(this.checked)"}}
        target={"name":"amount", "id":"amount", "label":"Interest amount", "input_type":"text"}
        result=explain_page(page("function toggle(checked){document.getElementById('amount').disabled=!checked;}",[controller,target]))
        rules=result["visibility_analysis"]["rules"]
        self.assertEqual([r["effect"] for r in rules],["enabled","disabled"])
        self.assertIn('When you check',rules[0]["sentence"])
        self.assertIn('Interest amount',rules[0]["sentence"])
        self.assertIn('When you uncheck',rules[1]["sentence"])
        self.assertEqual(len(target["visibility_behaviors"]),2)
        self.assertEqual(rules[0]["source_line"],10)

    def test_radio_ids_aliases_and_boolean_flag_show_or_hide_a_group(self):
        controller={"name":"state_exempt", "label":"Is this state exempt?", "input_type":"radio",
                    "attributes":{"$radioBtnId[]":[{"value":"stateYes"},{"value":"stateNo"}]},
                    "options":[{"value":"1","label":"Yes","onclick":"showState()"},{"value":"0","label":"No","onclick":"showState()"}]}
        target={"name":"state_amount", "label":"State amount", "input_type":"text", "parent_groups":["StateInputs"]}
        result=explain_page(page("""function showState(){
var area=document.getElementById('StateInputs');
if(document.getElementById('stateYes').checked) a=1;else a=0;
if(a){area.classList.remove('is-hidden');}else{area.classList.add('is-hidden');}
}""",[controller,target]))
        rules=result["visibility_analysis"]["rules"]
        self.assertEqual([r["effect"] for r in rules],["shown","hidden"])
        self.assertIn('select “Yes”',rules[0]["sentence"])
        self.assertIn('select “No”',rules[1]["sentence"])
        self.assertEqual(rules[0]["affected_inputs"],["state_amount"])

    def test_jquery_descendant_disable_and_plain_visibility_remain_distinct(self):
        controller={"name":"skip", "label":"Skip details", "input_type":"checkbox", "events":{"onclick":"change(this.checked)"}}
        target={"name":"detail", "id":"detail", "label":"Detail", "input_type":"text", "parent_groups":["details"]}
        result=explain_page(page("function change(skip){$('#details').find('input').prop('disabled',skip);if(skip){$('#details').hide();}else{$('#details').show();}}",[controller,target]))
        effects={r["effect"] for r in result["visibility_analysis"]["rules"]}
        self.assertEqual(effects,{"enabled","disabled","shown","hidden"})

    def test_comments_are_excluded_and_missing_function_is_reported(self):
        controller={"name":"flag", "label":"Flag", "input_type":"checkbox", "events":{"onclick":"local(this.checked);external()"}}
        target={"name":"amount", "id":"amount", "label":"Amount", "input_type":"text"}
        result=explain_page(page("""function local(flag){
// document.getElementById('amount').disabled=true;
/* document.getElementById('amount').style.display='none'; */
document.getElementById('amount').readOnly=flag;
}""",[controller,target]))
        self.assertEqual({r["effect"] for r in result["visibility_analysis"]["rules"]},{"read-only","editable"})
        self.assertTrue(any('external()' in n for n in controller["visibility_notes"]))

    def test_current_state_branch_is_an_additional_condition(self):
        controller={"name":"more", "id":"button", "input_type":"button", "attributes":{"value":"Advanced options"}, "events":{"onclick":"expand()"}}
        target={"name":"details", "label":"Advanced detail", "input_type":"text", "parent_groups":["advanced"]}
        result=explain_page(page("function expand(){var area=document.getElementById('advanced');if(area.style.display=='block'){area.style.display='none';}else{area.style.display='block';}}",[controller,target]))
        rules=result["visibility_analysis"]["rules"]
        self.assertEqual({r['effect'] for r in rules},{'shown','hidden'})
        self.assertTrue(all(r['additional_conditions'] for r in rules))
        self.assertTrue(all('provided that' in r['sentence'] for r in rules))

    def test_radio_value_and_nested_helper_functions(self):
        controller={"name":"type", "label":"Interest type", "input_type":"radio", "options":[
            {"label":"Taxable", "value":"1", "onclick":"outer(this.value)"},
            {"label":"Other", "value":"0", "onclick":"outer(this.value)"}]}
        target={"name":"amount", "id":"amount", "label":"Amount", "input_type":"text"}
        result=explain_page(page("function outer(value){inner(value=='1');} function inner(on){document.getElementById('amount').disabled=!on;}",[controller,target]))
        self.assertEqual([r['effect'] for r in result['visibility_analysis']['rules']],['enabled','disabled'])

    def test_unknown_server_value_is_not_treated_as_an_enabled_or_disabled_state(self):
        controller={"name":"button", "label":"Button", "input_type":"button", "events":{"onclick":"change()"}}
        target={"name":"amount", "id":"amount", "label":"Amount", "input_type":"text"}
        result=explain_page(page("var setting='          ';function change(){document.getElementById('amount').disabled=setting;}",[controller,target]))
        self.assertEqual(result['visibility_analysis']['rules'],[])
        self.assertTrue(controller['visibility_notes'])

    def test_registered_event_callbacks_use_event_target_and_checkbox_state(self):
        controller={'name':'allow','id':'allow','label':'Allow details','input_type':'checkbox'}
        target={'name':'amount','id':'amount','label':'Amount','input_type':'text'}
        result=explain_page(page("document.getElementById('allow').addEventListener('change', (event)=>{document.getElementById('amount').disabled=!event.target.checked;});",[controller,target]))
        self.assertEqual([r['effect'] for r in result['visibility_analysis']['rules']],['enabled','disabled'])

    def test_jquery_registered_change_callback_and_this_reference(self):
        controller={'name':'allow','id':'allow','label':'Allow details','input_type':'checkbox'}
        target={'name':'amount','id':'amount','label':'Amount','input_type':'text'}
        result=explain_page(page("$('#allow').on('change',function(){document.getElementById('amount').disabled=!this.checked;});",[controller,target]))
        self.assertEqual([r['effect'] for r in result['visibility_analysis']['rules']],['enabled','disabled'])

    def test_early_return_does_not_emit_unreachable_visibility_change(self):
        controller={'name':'allow','id':'allow','label':'Allow details','input_type':'checkbox','events':{'onclick':'change(this.checked)'}}
        target={'name':'amount','id':'amount','label':'Amount','input_type':'text'}
        result=explain_page(page("function change(checked){if(!checked)return;document.getElementById('amount').disabled=false;}",[controller,target]))
        self.assertEqual(len(result['visibility_analysis']['rules']),1)
        self.assertIn('When you check',result['visibility_analysis']['rules'][0]['sentence'])

    def test_javascript_boolean_comparison_with_numeric_one(self):
        controller={'name':'allow','id':'allow','label':'Allow details','input_type':'checkbox','events':{'onclick':'change(this.checked)'}}
        target={'name':'amount','id':'amount','label':'Amount','input_type':'text'}
        result=explain_page(page("function change(checked){if(checked==1){document.getElementById('amount').disabled=false;}else{document.getElementById('amount').disabled=true;}}",[controller,target]))
        self.assertEqual([r['effect'] for r in result['visibility_analysis']['rules']],['enabled','disabled'])

    def test_jquery_checked_state_and_native_attribute_changes(self):
        controller={'name':'allow','id':'allow','label':'Allow details','input_type':'checkbox','events':{'onclick':"change($(this).is(':checked'))"}}
        target={'name':'amount','id':'amount','label':'Amount','input_type':'text'}
        result=explain_page(page("function change(checked){var box=document.getElementById('amount');if(checked){box.removeAttribute('disabled');}else{box.setAttribute('disabled','disabled');}}",[controller,target]))
        self.assertEqual([r['effect'] for r in result['visibility_analysis']['rules']],['enabled','disabled'])

    def test_class_toggle_force_argument_tracks_checked_state(self):
        controller={'name':'hide','id':'hide','label':'Hide details','input_type':'checkbox','events':{'onclick':'change(this.checked)'}}
        target={'name':'amount','id':'amount','label':'Amount','input_type':'text','parent_groups':['details']}
        result=explain_page(page("function change(checked){document.getElementById('details').classList.toggle('is-hidden',checked);}",[controller,target]))
        self.assertEqual([r['effect'] for r in result['visibility_analysis']['rules']],['hidden','shown'])


if __name__ == '__main__':
    unittest.main()
