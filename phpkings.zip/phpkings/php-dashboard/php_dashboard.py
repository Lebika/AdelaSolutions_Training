import os
import logging
import base64
import json
import re
from zipfile import ZIP_DEFLATED, ZipFile
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen
from datetime import datetime, timezone
from io import BytesIO
from pathlib import Path
from threading import Thread
from uuid import uuid4
from flask import Flask, jsonify, render_template, request, send_file
from openpyxl import Workbook
app = Flask(__name__, static_url_path='/phphelper/static')
import threading

VECTORDB_BUILD_LOCK = threading.Lock()
CANCELLED_BUILDS = set()
CANCEL_LOCK = threading.Lock()


def _is_cancelled(build_id):
    with CANCEL_LOCK:
        return build_id in CANCELLED_BUILDS


def _clear_cancelled(build_id):
    with CANCEL_LOCK:
        CANCELLED_BUILDS.discard(build_id)
from php_flow_scanner import (
    BASE_FOLDERS,
    PROBASE_FOLDERS,
    PARTNER_FOLDERS,
    CP_FOLDERS,
    FOLDERS,
    MAIN_FOLDERS,
    MO_FOLDERS,
    source_folder_path,
    code_move_root_path,
    collect_modified_files,
    add_qdrant_metadata_file,
    build_missing_files_report,
    build_vector_store,
    compare_metadata_to_filesystem,
    compare_metadata_manifest_to_filesystem,
    compare_metadata_records_to_filesystem,
    delete_qdrant_metadata,
    load_missing_files_report,
    update_missing_files_report_for_folders,
    load_folder_counts,
    load_qdrant_store,
    update_qdrant_metadata_method,
    list_mergeable_qdrant_dbs,
    existing_merged_qdrant_folders,
    merge_qdrant_dbs,
    rebuild_qdrant_metadata_files,
    rebuild_code_move_files,
    summarize,
    folder_needs_references,
    folders_for_taxyear,
    partner_folder_needs_references,
)


from query_chunk_scanner import (
    BuildCancelled,
    build_query_chunk_store,
    discover_folders,
    discover_tax_years,
    list_query_chunk_dbs,
    load_query_chunk_metadata,
    delete_query_chunk_build,
    delete_query_chunk_file,
    delete_query_chunk_taxyear,
    get_query_chunk_report,
    build_query_chunk_report,
    folder_already_built,
    update_query_chunk_file,
    update_query_chunk_folder, 
    list_files_for_build, 
    build_query_chunk_verification,
    build_query_chunk_summary,
    rebuild_code_move_query_chunks,
    FOLDERS as QC_SCANNER_FOLDERS,
    BASE_FOLDERS as QC_SCANNER_BASE_FOLDERS,
    PROBASE_FOLDERS as QC_SCANNER_PROBASE_FOLDERS,
    PARTNER_FOLDERS as QC_SCANNER_PARTNER_FOLDERS,
    CP_FOLDERS as QC_SCANNER_CP_FOLDERS,
    MAIN_FOLDERS as QC_SCANNER_MAIN_FOLDERS,
    MO_FOLDERS as QC_SCANNER_MO_FOLDERS,
)
from analyse_qt_user import build_qt_user_id_analysis, build_qt_user_id_export_rows
from analyse_mo_business import (
    MO_BUSINESS_FOLDERS,
    MO_TAXYEAR,
    build_mo_business_analysis,
    build_mo_business_export_rows,
)
from input_validation_analyzer import SQL_ROOT, analyse_input_validation as run_input_validation_analysis
from post_file_included_analyzer import (
    analyse_get_file_includes,
    analyse_post_file_includes,
    post_file_include_export_rows,
)

QUERY_CHUNK_FOLDERS = QC_SCANNER_FOLDERS
QUERY_CHUNK_BASE_FOLDERS = QC_SCANNER_BASE_FOLDERS
QUERY_CHUNK_PROBASE_FOLDERS = QC_SCANNER_PROBASE_FOLDERS
QUERY_CHUNK_PARTNER_FOLDERS = QC_SCANNER_PARTNER_FOLDERS
QUERY_CHUNK_CP_FOLDERS = QC_SCANNER_CP_FOLDERS
QUERY_CHUNK_MAIN_FOLDERS = QC_SCANNER_MAIN_FOLDERS
QUERY_CHUNK_MO_FOLDERS = QC_SCANNER_MO_FOLDERS

ANALYSE_USER_ID_FOLDERS = QC_SCANNER_FOLDERS
ANALYSE_USER_ID_BASE_FOLDERS = QC_SCANNER_BASE_FOLDERS
ANALYSE_USER_ID_PROBASE_FOLDERS = QC_SCANNER_PROBASE_FOLDERS
ANALYSE_USER_ID_PARTNER_FOLDERS = QC_SCANNER_PARTNER_FOLDERS
ANALYSE_USER_ID_CP_FOLDERS = QC_SCANNER_CP_FOLDERS
ANALYSE_USER_ID_MAIN_FOLDERS = QC_SCANNER_MAIN_FOLDERS
ANALYSE_USER_ID_MO_FOLDERS = QC_SCANNER_MO_FOLDERS

ANALYSE_EMAIL_EXCLUDED_FOLDERS = {
    "efile", "efilebank", "efilepartner", "staffolt"
}

from email_report_config import (
    EMAIL_API_URL,
    EMAIL_API_KEY,
    EMAIL_TO,
    EMAIL_CC,
    EMAIL_BCC,
    EMAIL_REPLY_TO,
    EMAIL_SUBJECT,
    EMAIL_CONTENT,
    EMAIL_IS_HTML,
    EMAIL_TIMEOUT_SECONDS,
)
app = Flask(__name__)
BUILD_STATUS = {}
CODE_MOVE_STATUS = {}
FILE_GRABBER_STATUS = {}
QUERY_CHUNK_CODE_MOVE_STATUS = {}


def _query_chunk_build_folders(taxyear):
    """Folders with persisted Query Chunk Scanner builds for a tax year/root."""
    return [
        str(item.get("folder", "")).strip()
        for item in list_query_chunk_dbs(str(taxyear))
        if str(item.get("folder", "")).strip()
    ]


def _analyse_email_build_folders(taxyear):
    """Query Chunk folders offered by the Email pages."""
    return [
        folder for folder in _query_chunk_build_folders(taxyear)
        if folder.lower() not in ANALYSE_EMAIL_EXCLUDED_FOLDERS
    ]


def _analyse_build_folders(taxyear):
    """Query Chunk folders offered and processed by the Analyse pages."""
    return [
        folder for folder in _query_chunk_build_folders(taxyear)
        if folder.lower() not in ANALYSE_EMAIL_EXCLUDED_FOLDERS
    ]


def _post_file_included_folders(taxyear):
    """Folders with a persisted Qdrant metadata database for a tax year."""
    return sorted({
        str(item.get("folder", "")).strip()
        for item in list_mergeable_qdrant_dbs(str(taxyear)).get("items", [])
        if str(item.get("folder", "")).strip()
    }, key=str.lower)


def _build_folders(taxyear, folder):
    available_folders = folders_for_taxyear(taxyear)
    return [
        item for item in (list(available_folders) if folder.lower() == "all" else [folder])
        if item in available_folders
        if source_folder_path(taxyear, item).exists()
    ]


_QUERY_CHUNK_FOLDER_SETS_BY_TAXYEAR = {
    "base": QUERY_CHUNK_BASE_FOLDERS,
    "probase": QUERY_CHUNK_PROBASE_FOLDERS,
    "partner": QUERY_CHUNK_PARTNER_FOLDERS,
    "cp": QUERY_CHUNK_CP_FOLDERS,
    "main": QUERY_CHUNK_MAIN_FOLDERS,
    "mo": QUERY_CHUNK_MO_FOLDERS,
}


def _query_chunk_build_folders_for_all(taxyear, folder):
    if folder.lower() != "all":
        return [folder]
    candidate_folders = _QUERY_CHUNK_FOLDER_SETS_BY_TAXYEAR.get(str(taxyear).strip().lower(), QUERY_CHUNK_FOLDERS)
    on_disk = set(discover_folders(taxyear))
    return [item for item in candidate_folders if item in on_disk]


def _set_build_status(status_id, **updates):
    BUILD_STATUS[status_id] = {
        **BUILD_STATUS.get(status_id, {}),
        **updates,
        "updated_at": datetime.now(timezone.utc).isoformat(),
    }


def _set_code_move_status(status_id, **updates):
    CODE_MOVE_STATUS[status_id] = {
        **CODE_MOVE_STATUS.get(status_id, {}),
        **updates,
        "updated_at": datetime.now(timezone.utc).isoformat(),
    }


def _run_code_move_rebuild(status_id):
    if not VECTORDB_BUILD_LOCK.acquire(blocking=False):
        message = "Another vector DB build is already running. Please wait for it to finish."
        _set_code_move_status(status_id, state="error", message=message, error=message)
        return

    def progress(entry, current, total):
        file_name = entry.get("target_file") or entry.get("code_move_file") or ""
        _set_code_move_status(
            status_id,
            state="processing",
            file_name=file_name,
            current=current,
            total=total,
            message=f"Processing Code Move file {file_name} ({current}/{total})",
        )

    try:
        result = rebuild_code_move_files(progress=progress)
        message = (
            f"Code Move complete: {result['added']} new files added, "
            f"{result['rebuilt']} existing ANALYSE/zero-byte files rebuilt, "
            f"{result['skipped']} existing files skipped, {result['failed']} failed."
            if result["total"]
            else f"No files found in {result['code_move_root']}."
        )
        _set_code_move_status(status_id, **result, state="complete", message=message)
    except Exception as exc:
        app.logger.exception("Failed to rebuild Code Move files")
        _set_code_move_status(status_id, state="error", message=str(exc), error=str(exc))
    finally:
        VECTORDB_BUILD_LOCK.release()


def _set_query_chunk_code_move_status(status_id, **updates):
    QUERY_CHUNK_CODE_MOVE_STATUS[status_id] = {
        **QUERY_CHUNK_CODE_MOVE_STATUS.get(status_id, {}),
        **updates,
        "updated_at": datetime.now(timezone.utc).isoformat(),
    }


def _run_query_chunk_code_move_rebuild(status_id):
    def progress(entry, current, total):
        file_name = entry.get("target_file") or entry.get("code_move_file") or ""
        if total and current >= total:
            message = f"Finalizing: writing chunk data and updating the vector DB ({current}/{total} files processed)..."
        else:
            message = f"Processing Code Move file {file_name} ({current}/{total})"
        _set_query_chunk_code_move_status(
            status_id,
            state="processing",
            file_name=file_name,
            current=current,
            total=total,
            message=message,
        )

    try:
        result = rebuild_code_move_query_chunks(progress=progress)
        message = (
            f"Code Move complete: {result['added']} new files added, "
            f"{result['rebuilt']} existing files re-scanned, "
            f"{result['skipped']} skipped (no build for folder), {result['failed']} failed."
            if result["total"]
            else f"No files found in {result['code_move_root']}."
        )
        _set_query_chunk_code_move_status(status_id, **result, state="complete", message=message)
    except Exception as exc:
        app.logger.exception("Failed to rebuild Code Move query chunks")
        _set_query_chunk_code_move_status(status_id, state="error", message=str(exc), error=str(exc))


def _set_file_grabber_status(status_id, **updates):
    FILE_GRABBER_STATUS[status_id] = {
        **FILE_GRABBER_STATUS.get(status_id, {}),
        **updates,
        "updated_at": datetime.now(timezone.utc).isoformat(),
    }


def _run_file_grabber(status_id, source_folder, modified_from, modified_to):
    def progress(file_name, current, total):
        _set_file_grabber_status(
            status_id,
            state="processing",
            file_name=file_name,
            current=current,
            total=total,
            message=f"Collecting {file_name} ({current}/{total})",
        )

    try:
        result = collect_modified_files(
            source_folder,
            modified_from,
            modified_to,
            progress=progress,
        )
        message = (
            f"Collection complete: {result['copied']} copied, "
            f"{result['overwritten']} overwritten, {result['failed']} failed."
            if result["total"]
            else "No files matched the selected modified-date range."
        )
        _set_file_grabber_status(status_id, **result, state="complete", message=message)
    except Exception as exc:
        app.logger.exception("File Grabber failed")
        _set_file_grabber_status(status_id, state="error", message=str(exc), error=str(exc))


def _init_build_status(build_id, taxyear, folder, selected_folders):
    _set_build_status(
        build_id,
        state="processing",
        taxyear=taxyear,
        folder=folder,
        folders=selected_folders,
        file_name="",
        current=0,
        total=0,
        message=f"Processing {taxyear}/{folder}. Waiting for first file...",
    )


def _run_vectordb_build(build_id, taxyear, folder, selected_folders):
    def progress(folder_name, file_name, current, total, folder_index=None, total_folders=None):
        folder_part = (
            f"folder {folder_index}/{total_folders}, "
            if folder_index and total_folders
            else ""
        )
        display_name = file_name or ""
        _set_build_status(
            build_id,
            state="processing",
            phase="scanning",
            taxyear=taxyear,
            folder=folder_name,
            file_name=display_name,
            current=current,
            total=total,
            current_folder_index=folder_index or 0,
            total_folders=total_folders or 0,
            message=(
                f"Processing {folder_part}{folder_name}/{display_name} ({current}/{total})"
                if display_name
                else f"Processing {folder_part}{folder_name} ({current}/{total})"
            ),
        )

    def qdrant_progress(folder_name, file_name, current, total):
        _set_build_status(
            build_id,
            state="processing",
            phase="writing",
            taxyear=taxyear,
            folder=folder_name,
            file_name=file_name,
            current=current,
            total=total,
            message=f"{file_name} ({current}/{total})",
        )
    
    if not VECTORDB_BUILD_LOCK.acquire(blocking=False):
        message = "Another vector DB build is already running. Please wait for it to finish."
        _set_build_status(
            build_id,
            state="error",
            taxyear=taxyear,
            folder=folder,
            message=message,
            error=message,
        )
        return {
            "ok": False,
            "build_id": build_id,
            "taxyear": taxyear,
            "folder": folder,
            "folders": selected_folders,
            "error": message,
        }

    try:
        build_results = []
        total_folders = len(selected_folders)
        for folder_index, folder_name in enumerate(selected_folders, start=1):
            if folder_name == "Original":
                preparing_message = (
                    f"Scanning Original PDF references for {taxyear}/{folder_name} "
                    f"({folder_index}/{total_folders})..."
                )
            else:
                preparing_message = (
                f"Scanning references for {taxyear}/{folder_name} ({folder_index}/{total_folders}). File progress will start shortly..."
                if (
                    taxyear.lower() == "partner" and partner_folder_needs_references(folder_name)
                ) or (
                    taxyear.lower() != "partner" and folder_needs_references(folder_name)
                )
                else f"Listing files for {taxyear}/{folder_name} ({folder_index}/{total_folders}). File progress will start shortly..."
                )
            _set_build_status(
                build_id,
                state="processing",
                taxyear=taxyear,
                folder=folder_name,
                file_name="",
                current=0,
                total=0,
                current_folder_index=folder_index,
                total_folders=total_folders,
                message=preparing_message,
            )
            result = build_vector_store(
                taxyear,
                folder_name,
                progress=lambda file_name, current, total, folder_name=folder_name, folder_index=folder_index, total_folders=total_folders: progress(folder_name, file_name, current, total, folder_index, total_folders),
                qdrant_progress=lambda file_name, current, total, folder_name=folder_name: qdrant_progress(folder_name, file_name, current, total),
            )
            build_results.append(result)

        report_folders = folders_for_taxyear(taxyear) if folder.lower() == "all" else selected_folders
        
        missing_report = (
            build_missing_files_report(taxyear, folders_for_taxyear(taxyear))
            if folder.lower() == "all"
            else update_missing_files_report_for_folders(taxyear, selected_folders)
        )
       
        counts = load_folder_counts(taxyear, report_folders)
        response_summary = counts["summary"] if folder.lower() == "all" else build_results[-1]["summary"]
        collections = sorted({
            item.get("qdrant", {}).get("collection", "")
            for item in build_results
            if item.get("qdrant", {}).get("collection")
        })
        qdrant_by_folder = {
            item["folder"]: item.get("qdrant", {})
            for item in build_results
        }
        response_qdrant = (
            {
                "status": "ok",
                "collection": ", ".join(collections),
                "folders": selected_folders,
                "by_folder": qdrant_by_folder,
            }
            if folder.lower() == "all"
            else build_results[-1].get("qdrant", {})
        )
        result = {
            "ok": True,
            "build_id": build_id,
            "taxyear": taxyear,
            "folder": folder,
            "folders": selected_folders,
            "summary": response_summary,
            "qdrant": response_qdrant,
            "missing_report": {
                "updated_at": missing_report.get("updated_at", ""),
                "folders": len(missing_report.get("folders", [])),
            },
        }
        _set_build_status(
            build_id,
            **result,
            state="complete",
            message=f"Build complete for {taxyear}/{folder}",
        )
        return result
    except Exception as exc:
        _set_build_status(
            build_id,
            state="error",
            message=str(exc),
            error=str(exc),
        )
        raise
    finally:
        VECTORDB_BUILD_LOCK.release()


@app.route("/")
@app.route("/phphelper/")
def dashboard():
    return render_template(
        "dashboard.html",
        folders=FOLDERS,
        base_folders=BASE_FOLDERS,
        probase_folders=PROBASE_FOLDERS,
        partner_folders=PARTNER_FOLDERS,
        cp_folders=CP_FOLDERS,
        main_folders=MAIN_FOLDERS,
        mo_folders=MO_FOLDERS,
    )

@app.route("/phphelper/vectordb")
def vectordb():
    return render_template(
        "vectordb.html",
        folders=FOLDERS,
        base_folders=BASE_FOLDERS,
        probase_folders=PROBASE_FOLDERS,
        partner_folders=PARTNER_FOLDERS,
        cp_folders=CP_FOLDERS,
        main_folders=MAIN_FOLDERS,
        mo_folders=MO_FOLDERS,
        metadata_email_to=", ".join(_configured_email_addresses(EMAIL_TO)),
        metadata_email_cc=", ".join(_configured_email_addresses(EMAIL_CC)),
    )


@app.route("/phphelper/email")
@app.route("/phphelper/email/vectordb")
def email_vectordb():
    return render_template("email.html", email_section="vectordb")


@app.route("/phphelper/email/sql")
def email_sql():
    return render_template("email.html", email_section="sql")


@app.route("/phphelper/email/post-file-included")
def email_post_file_included():
    return render_template("email.html", email_section="post_file_included")

@app.route("/phphelper/query_chunk")
def query_chunk_page():
    return render_template(
        "query_chunk.html",
        years=discover_tax_years(),
        folders=QUERY_CHUNK_FOLDERS,
        base_folders=QUERY_CHUNK_BASE_FOLDERS,
        probase_folders=QUERY_CHUNK_PROBASE_FOLDERS,
        partner_folders=QUERY_CHUNK_PARTNER_FOLDERS,
        cp_folders=QUERY_CHUNK_CP_FOLDERS,
        main_folders=QUERY_CHUNK_MAIN_FOLDERS,
        mo_folders=QUERY_CHUNK_MO_FOLDERS,
        code_move_root=str(code_move_root_path()),
    )

@app.route("/phphelper/file-grabber")
def file_grabber():
    return render_template("file_grabber.html", destination=str(code_move_root_path()))


@app.route("/phphelper/analyse/user-id")
def analyse_user_id():
    return render_template(
        "analyse.html",
        analyse_title="User ID",
        analyse_description="Analyse user ID usage across PHP application flows.",
        analyse_mode="user_id",
        years=discover_tax_years(),
        folders=ANALYSE_USER_ID_FOLDERS,
        base_folders=ANALYSE_USER_ID_BASE_FOLDERS,
        probase_folders=ANALYSE_USER_ID_PROBASE_FOLDERS,
        partner_folders=ANALYSE_USER_ID_PARTNER_FOLDERS,
        cp_folders=ANALYSE_USER_ID_CP_FOLDERS,
        main_folders=ANALYSE_USER_ID_MAIN_FOLDERS,
        mo_folders=ANALYSE_USER_ID_MO_FOLDERS,
    )


@app.route("/phphelper/analyse/mo-issues")
def analyse_mo_issues():
    return render_template(
        "mo_issues.html",
        analyse_title="MO Issues",
        analyse_description="Analyse MO business queries across PHP application flows.",
        mo_taxyear=MO_TAXYEAR,
        mo_folders=MO_BUSINESS_FOLDERS,
    )


@app.route("/phphelper/analyse/input-validation")
def analyse_input_validation():
    return render_template("input_validation.html")


@app.route("/phphelper/analyse/post-file-included")
def analyse_post_file_included_page():
    return render_template("post_file_included.html")


@app.route("/phphelper/analyse/get-file-included")
def analyse_get_file_included_page():
    return render_template("get_file_included.html")


@app.route("/phphelper/api/analyse/qt_user_id", methods=["GET"])
def analyse_qt_user_id():
    taxyear = request.args.get("taxyear", "").strip()
    if not taxyear:
        return jsonify({"ok": False, "error": "taxyear is required"}), 400
    folder = request.args.get("folder", "").strip() or None
    available_folders = _analyse_build_folders(taxyear)
    if folder and folder not in available_folders:
        return jsonify({"ok": False, "error": f"No Query Chunk build found for {taxyear}/{folder}"}), 400
    mode = request.args.get("mode", "missing").strip().lower()
    if mode not in ("missing", "rearranged"):
        mode = "missing"
    try:
        analysis = (
            build_qt_user_id_analysis(taxyear, folder, mode)
            if folder
            else [
                entry
                for listed_folder in available_folders
                for entry in build_qt_user_id_analysis(taxyear, listed_folder, mode)
            ]
        )
        return jsonify({
            "ok": True,
            "taxyear": taxyear,
            "folder": folder,
            "mode": mode,
            "analysis": analysis,
        })
    except Exception as exc:
        return jsonify({"ok": False, "error": str(exc)}), 500


@app.route("/phphelper/api/analyse/mo_business", methods=["GET"])
def analyse_mo_business():
    folder = request.args.get("folder", "").strip() or None
    if folder and folder not in MO_BUSINESS_FOLDERS:
        return jsonify({"ok": False, "error": f"Unknown MO folder: {folder}"}), 400
    try:
        analysis = build_mo_business_analysis(folder)
        return jsonify({
            "ok": True,
            "taxyear": MO_TAXYEAR,
            "folder": folder,
            "analysis": analysis,
        })
    except Exception as exc:
        return jsonify({"ok": False, "error": str(exc)}), 500


def _mo_business_export_workbook(folder=None):
    columns, rows = build_mo_business_export_rows(folder)
    rows = [
        row for row in rows
        if any(str(value or "").strip() for value in row[1:])
    ]
    workbook_bytes = _qt_user_id_workbook(columns, rows, "MO Business Queries")
    folder_part = re.sub(r"[^a-z0-9_-]+", "_", folder, flags=re.IGNORECASE) if folder else "ALL"
    filename = f"{MO_TAXYEAR}_{folder_part}_business_queries.xlsx"
    return filename, workbook_bytes, len(rows)


@app.route("/phphelper/api/analyse/mo_business/export", methods=["GET"])
def analyse_mo_business_export():
    folder = request.args.get("folder", "").strip() or None
    if folder and folder not in MO_BUSINESS_FOLDERS:
        return jsonify({"ok": False, "error": f"Unknown MO folder: {folder}"}), 400
    try:
        download_name, workbook_bytes, _row_count = _mo_business_export_workbook(folder)
    except Exception as exc:
        return jsonify({"ok": False, "error": str(exc)}), 500

    buffer = BytesIO(workbook_bytes)
    buffer.seek(0)
    return send_file(
        buffer,
        as_attachment=True,
        download_name=download_name,
        mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    )


@app.route("/phphelper/api/analyse/folders", methods=["GET"])
def analyse_folders():
    taxyear = request.args.get("taxyear", "").strip()
    if not taxyear:
        return jsonify({"ok": False, "error": "taxyear is required"}), 400
    return jsonify({
        "ok": True,
        "taxyear": taxyear,
        "folders": _analyse_build_folders(taxyear),
    })

def _qt_user_id_workbook(columns, rows, sheet_name):
    workbook = Workbook()
    sheet = workbook.active
    sheet.title = sheet_name[:31]
    sheet.append(columns)
    for row in rows:
        sheet.append(row)

    for column_cells in sheet.columns:
        max_length = max((len(str(cell.value)) for cell in column_cells if cell.value is not None), default=0)
        sheet.column_dimensions[column_cells[0].column_letter].width = min(max(max_length + 2, 10), 60)

    buffer = BytesIO()
    workbook.save(buffer)
    return buffer.getvalue()


def _qt_user_id_export_workbook(taxyear, folder=None, mode="missing"):
    if folder:
        columns, rows = build_qt_user_id_export_rows(taxyear, folder, mode)
    else:
        columns = ["Folder", "File", "Line(s)", "Table(s)", "Reconstructed SQL"]
        rows = []
        for listed_folder in _analyse_build_folders(taxyear):
            columns, folder_rows = build_qt_user_id_export_rows(
                taxyear, listed_folder, mode
            )
            rows.extend(folder_rows)
    # build_qt_user_id_export_rows uses a folder-only placeholder when a build
    # has no issues. It is useful for some on-screen summaries, but it is not a
    # report row and must not make an empty email workbook look non-empty.
    rows = [
        row for row in rows
        if any(str(value or "").strip() for value in row[1:])
    ]
    sheet_name = "Missing" if mode == "missing" else "Rearranged"
    workbook_bytes = _qt_user_id_workbook(columns, rows, sheet_name)
    folder_part = re.sub(r"[^a-z0-9_-]+", "_", folder, flags=re.IGNORECASE) if folder else "ALL"
    filename = f"{taxyear}_{folder_part}_qt_user_id_{mode}.xlsx"
    return filename, workbook_bytes, len(rows)


@app.route("/phphelper/api/analyse/qt_user_id/export", methods=["GET"])
def analyse_qt_user_id_export():
    taxyear = request.args.get("taxyear", "").strip()
    if not taxyear:
        return jsonify({"ok": False, "error": "taxyear is required"}), 400
    folder = request.args.get("folder", "").strip() or None
    if folder and folder not in _analyse_build_folders(taxyear):
        return jsonify({"ok": False, "error": f"No Query Chunk build found for {taxyear}/{folder}"}), 400
    mode = request.args.get("mode", "missing").strip().lower()
    if mode not in ("missing", "rearranged"):
        mode = "missing"
    try:
        download_name, workbook_bytes, _row_count = _qt_user_id_export_workbook(
            taxyear, folder, mode
        )
    except Exception as exc:
        return jsonify({"ok": False, "error": str(exc)}), 500

    buffer = BytesIO(workbook_bytes)
    buffer.seek(0)
    return send_file(
        buffer,
        as_attachment=True,
        download_name=download_name,
        mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    )

@app.route("/phphelper/api/input-validation/options", methods=["GET"])
def input_validation_options():
    years = []
    if SQL_ROOT.is_dir():
        years = sorted(
            (item.name for item in SQL_ROOT.iterdir() if item.is_dir()),
            reverse=True,
        )
    requested_year = request.args.get("taxyear", "").strip()
    selected_year = requested_year or (years[0] if years else "")
    folders = _analyse_build_folders(selected_year) if selected_year else []
    return jsonify({
        "ok": True,
        "years": years,
        "taxyear": selected_year,
        "folders": folders,
    })


@app.route("/phphelper/api/input-validation/analyse", methods=["POST"])
def input_validation_analyse():
    payload = request.get_json(silent=True) or request.form
    taxyear = str(payload.get("taxyear", "")).strip()
    folder = str(payload.get("folder", "")).strip()
    if not taxyear or not folder:
        return jsonify({"ok": False, "error": "taxyear and folder are required"}), 400
    if folder not in _analyse_build_folders(taxyear):
        return jsonify({"ok": False, "error": f"No Query Chunk build found for {taxyear}/{folder}"}), 400
    try:
        sample_files = int(payload.get("sample_files", 5))
        result = run_input_validation_analysis(taxyear, folder, sample_files=sample_files)
        return jsonify({"ok": True, **result})
    except FileNotFoundError as exc:
        return jsonify({"ok": False, "error": str(exc)}), 404
    except (TypeError, ValueError) as exc:
        return jsonify({"ok": False, "error": str(exc)}), 400
    except Exception as exc:
        app.logger.exception("Input-validation analysis failed for %s/%s", taxyear, folder)
        return jsonify({"ok": False, "error": str(exc)}), 500


def _post_file_included_result(taxyear, folder):
    records = load_qdrant_store(str(taxyear), str(folder)).get("records", [])
    return analyse_post_file_includes(records, str(folder))


def _get_file_included_result(taxyear, folder):
    records = load_qdrant_store(str(taxyear), str(folder)).get("records", [])
    return analyse_get_file_includes(records, str(folder))


def _post_file_included_workbook(taxyear, folder):
    result = _post_file_included_result(taxyear, folder)
    columns, rows = post_file_include_export_rows(result)
    workbook_bytes = _qt_user_id_workbook(columns, rows, "POST File Included")
    safe_folder = re.sub(r"[^A-Za-z0-9_.-]+", "_", str(folder)).strip("_") or "folder"
    filename = f"{taxyear}_{safe_folder}_post_file_included.xlsx"
    return filename, workbook_bytes, len(rows), result


def _get_file_included_workbook(taxyear, folder):
    result = _get_file_included_result(taxyear, folder)
    columns, rows = post_file_include_export_rows(result)
    workbook_bytes = _qt_user_id_workbook(columns, rows, "GET File Included")
    safe_folder = re.sub(r"[^A-Za-z0-9_.-]+", "_", str(folder)).strip("_") or "folder"
    filename = f"{taxyear}_{safe_folder}_get_file_included.xlsx"
    return filename, workbook_bytes, len(rows), result


def _resolve_post_source_file(taxyear, folder, requested_file):
    requested_key = str(requested_file).replace("\\", "/").strip().lower()
    records = load_qdrant_store(str(taxyear), str(folder)).get("records", [])
    record = next((
        item for item in records
        if str(item.get("method", "")).strip().upper() == "POST"
        and requested_key in {
            str(item.get("file_name") or "").replace("\\", "/").strip().lower(),
            str(item.get("base_name") or "").replace("\\", "/").strip().lower(),
        }
    ), None)
    if not record:
        raise FileNotFoundError("The requested POST file is not present in the selected Qdrant database")

    folder_root = source_folder_path(str(taxyear), str(folder)).resolve()
    stored_name = str(record.get("file_name") or record.get("base_name") or "").replace("\\", "/").lstrip("/")
    prefix = f"{taxyear}/{folder}/"
    relative_name = stored_name[len(prefix):] if stored_name.lower().startswith(prefix.lower()) else str(record.get("base_name") or stored_name)
    source_path = (folder_root / Path(relative_name.replace("/", os.sep))).resolve()
    if not source_path.is_relative_to(folder_root) or not source_path.is_file():
        raise FileNotFoundError(f"Source file was not found: {record.get('file_name') or relative_name}")
    return source_path


@app.route("/phphelper/api/post-file-included/options", methods=["GET"])
def post_file_included_options():
    years = discover_tax_years()
    requested_year = request.args.get("taxyear", "").strip()
    selected_year = requested_year or (years[0] if years else "")
    try:
        folders = _post_file_included_folders(selected_year) if selected_year else []
        return jsonify({
            "ok": True,
            "years": years,
            "taxyear": selected_year,
            "folders": folders,
        })
    except Exception as exc:
        return jsonify({"ok": False, "error": str(exc)}), 500


@app.route("/phphelper/api/post-file-included/analyse", methods=["POST"])
def post_file_included_analyse():
    payload = request.get_json(silent=True) or request.form
    taxyear = str(payload.get("taxyear", "")).strip()
    folder = str(payload.get("folder", "")).strip()
    if not taxyear or not folder:
        return jsonify({"ok": False, "error": "taxyear and folder are required"}), 400
    try:
        if folder not in _post_file_included_folders(taxyear):
            return jsonify({"ok": False, "error": f"No Qdrant database found for {taxyear}/{folder}"}), 400
        return jsonify({"ok": True, "taxyear": taxyear, **_post_file_included_result(taxyear, folder)})
    except Exception as exc:
        app.logger.exception("POST-file include analysis failed for %s/%s", taxyear, folder)
        return jsonify({"ok": False, "error": str(exc)}), 500


@app.route("/phphelper/api/get-file-included/analyse", methods=["POST"])
def get_file_included_analyse():
    payload = request.get_json(silent=True) or request.form
    taxyear = str(payload.get("taxyear", "")).strip()
    folder = str(payload.get("folder", "")).strip()
    if not taxyear or not folder:
        return jsonify({"ok": False, "error": "taxyear and folder are required"}), 400
    try:
        if folder not in _post_file_included_folders(taxyear):
            return jsonify({"ok": False, "error": f"No Qdrant database found for {taxyear}/{folder}"}), 400
        return jsonify({"ok": True, "taxyear": taxyear, **_get_file_included_result(taxyear, folder)})
    except Exception as exc:
        app.logger.exception("GET-file include analysis failed for %s/%s", taxyear, folder)
        return jsonify({"ok": False, "error": str(exc)}), 500


@app.route("/phphelper/api/post-file-included/export", methods=["GET"])
def post_file_included_export():
    taxyear = request.args.get("taxyear", "").strip()
    folder = request.args.get("folder", "").strip()
    if not taxyear or not folder:
        return jsonify({"ok": False, "error": "taxyear and folder are required"}), 400
    try:
        if folder not in _post_file_included_folders(taxyear):
            return jsonify({"ok": False, "error": f"No Qdrant database found for {taxyear}/{folder}"}), 400
        download_name, workbook_bytes, _row_count, _result = _post_file_included_workbook(taxyear, folder)
        return send_file(
            BytesIO(workbook_bytes),
            as_attachment=True,
            download_name=download_name,
            mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        )
    except Exception as exc:
        return jsonify({"ok": False, "error": str(exc)}), 500


@app.route("/phphelper/api/get-file-included/export", methods=["GET"])
def get_file_included_export():
    taxyear = request.args.get("taxyear", "").strip()
    folder = request.args.get("folder", "").strip()
    if not taxyear or not folder:
        return jsonify({"ok": False, "error": "taxyear and folder are required"}), 400
    try:
        if folder not in _post_file_included_folders(taxyear):
            return jsonify({"ok": False, "error": f"No Qdrant database found for {taxyear}/{folder}"}), 400
        download_name, workbook_bytes, _row_count, _result = _get_file_included_workbook(taxyear, folder)
        return send_file(
            BytesIO(workbook_bytes), as_attachment=True, download_name=download_name,
            mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        )
    except Exception as exc:
        return jsonify({"ok": False, "error": str(exc)}), 500


@app.route("/phphelper/api/post-file-included/file", methods=["GET"])
def post_file_included_file():
    taxyear = request.args.get("taxyear", "").strip()
    folder = request.args.get("folder", "").strip()
    file_name = request.args.get("file", "").strip()
    if not taxyear or not folder or not file_name:
        return jsonify({"ok": False, "error": "taxyear, folder, and file are required"}), 400
    try:
        source_path = _resolve_post_source_file(taxyear, folder, file_name)
        return send_file(source_path, as_attachment=True, download_name=source_path.name)
    except FileNotFoundError as exc:
        return jsonify({"ok": False, "error": str(exc)}), 404
    except Exception as exc:
        return jsonify({"ok": False, "error": str(exc)}), 500


@app.route("/phphelper/api/create_vectordb", methods=["POST"])
def create_vectordb():
    payload = request.get_json(silent=True) or request.form
    taxyear = str(payload.get("taxyear", "2025")).strip()
    folder = str(payload.get("folder", "oltproc")).strip()
    selected_folders = _build_folders(taxyear, folder)
    if not selected_folders:
        return jsonify({"ok": False, "error": f"No build folders found for {taxyear}/{folder}"}), 400
    build_id = str(payload.get("build_id") or uuid4()).strip()
    _init_build_status(build_id, taxyear, folder, selected_folders)
    try:
        return jsonify(_run_vectordb_build(build_id, taxyear, folder, selected_folders))
    except Exception as exc:
        return jsonify({"ok": False, "error": str(exc)}), 500


@app.route("/phphelper/api/create_vectordb_start", methods=["POST"])
def create_vectordb_start():
    payload = request.get_json(silent=True) or request.form
    taxyear = str(payload.get("taxyear", "2025")).strip()
    folder = str(payload.get("folder", "oltproc")).strip()
    selected_folders = _build_folders(taxyear, folder)
    if not selected_folders:
        return jsonify({"ok": False, "error": f"No build folders found for {taxyear}/{folder}"}), 400
    build_id = str(payload.get("build_id") or uuid4()).strip()
    _init_build_status(build_id, taxyear, folder, selected_folders)
    Thread(
        target=_run_vectordb_build,
        args=(build_id, taxyear, folder, selected_folders),
        daemon=True,
    ).start()
    return jsonify(
        {
            "ok": True,
            "build_id": build_id,
            "taxyear": taxyear,
            "folder": folder,
            "folders": selected_folders,
            "message": BUILD_STATUS[build_id]["message"],
        }
    )


@app.route("/phphelper/api/create_vectordb_status", methods=["GET"])
def create_vectordb_status():
    build_id = request.args.get("build_id", "").strip()
    status = BUILD_STATUS.get(build_id)
    if not status:
        return jsonify({"ok": False, "error": "Build status not found"}), 404
    return jsonify({"ok": True, **status})


@app.route("/phphelper/api/rebuild_codemove_start", methods=["POST"])
def rebuild_codemove_start():
    payload = request.get_json(silent=True) or request.form
    status_id = str(payload.get("status_id") or uuid4()).strip()
    _set_code_move_status(
        status_id,
        state="processing",
        current=0,
        total=0,
        file_name="",
        code_move_root=str(code_move_root_path()),
        message=f"Reading Code Move files from {code_move_root_path()}...",
    )
    Thread(target=_run_code_move_rebuild, args=(status_id,), daemon=True).start()
    return jsonify({"ok": True, "status_id": status_id, **CODE_MOVE_STATUS[status_id]})


@app.route("/phphelper/api/rebuild_codemove_status", methods=["GET"])
def rebuild_codemove_status():
    status_id = request.args.get("status_id", "").strip()
    status = CODE_MOVE_STATUS.get(status_id)
    if not status:
        return jsonify({"ok": False, "error": "Code Move status not found"}), 404
    return jsonify({"ok": True, "status_id": status_id, **status})


@app.route("/phphelper/api/query_chunk/rebuild_codemove_start", methods=["POST"])
def query_chunk_rebuild_codemove_start():
    payload = request.get_json(silent=True) or request.form
    status_id = str(payload.get("status_id") or uuid4()).strip()
    _set_query_chunk_code_move_status(
        status_id,
        state="processing",
        current=0,
        total=0,
        file_name="",
        code_move_root=str(code_move_root_path()),
        message=f"Reading Code Move files from {code_move_root_path()}...",
    )
    Thread(target=_run_query_chunk_code_move_rebuild, args=(status_id,), daemon=True).start()
    return jsonify({"ok": True, "status_id": status_id, **QUERY_CHUNK_CODE_MOVE_STATUS[status_id]})


@app.route("/phphelper/api/query_chunk/rebuild_codemove_status", methods=["GET"])
def query_chunk_rebuild_codemove_status():
    status_id = request.args.get("status_id", "").strip()
    status = QUERY_CHUNK_CODE_MOVE_STATUS.get(status_id)
    if not status:
        return jsonify({"ok": False, "error": "Code Move status not found"}), 404
    return jsonify({"ok": True, "status_id": status_id, **status})


@app.route("/phphelper/api/file_grabber_start", methods=["POST"])
def file_grabber_start():
    payload = request.get_json(silent=True) or request.form
    source_folder = str(payload.get("source_folder", "")).strip()
    modified_from = str(payload.get("modified_from", "")).strip()
    modified_to = str(payload.get("modified_to", "")).strip()
    if not source_folder:
        return jsonify({"ok": False, "error": "Source folder path is required"}), 400
    if not modified_from or not modified_to:
        return jsonify({"ok": False, "error": "Modified From and To dates are required"}), 400

    status_id = str(payload.get("status_id") or uuid4()).strip()
    _set_file_grabber_status(
        status_id,
        state="processing",
        source_folder=source_folder,
        destination=str(code_move_root_path()),
        modified_from=modified_from,
        modified_to=modified_to,
        current=0,
        total=0,
        file_name="",
        message="Finding files in the selected modified-date range...",
    )
    Thread(
        target=_run_file_grabber,
        args=(status_id, source_folder, modified_from, modified_to),
        daemon=True,
    ).start()
    return jsonify({"ok": True, "status_id": status_id, **FILE_GRABBER_STATUS[status_id]})


@app.route("/phphelper/api/file_grabber_status", methods=["GET"])
def file_grabber_status():
    status_id = request.args.get("status_id", "").strip()
    status = FILE_GRABBER_STATUS.get(status_id)
    if not status:
        return jsonify({"ok": False, "error": "File Grabber status not found"}), 404
    return jsonify({"ok": True, "status_id": status_id, **status})


@app.route("/phphelper/api/folder_counts", methods=["GET"])
def folder_counts():
    taxyear = request.args.get("taxyear", "2025").strip()
    try:
        result = load_folder_counts(taxyear, folders_for_taxyear(taxyear))
        return jsonify({"ok": True, **result})
    except Exception as exc:
        return jsonify({"ok": False, "error": str(exc)}), 500


@app.route("/phphelper/api/missing_files", methods=["GET"])
def missing_files():
    taxyear = request.args.get("taxyear", "2025").strip()
    folder = request.args.get("folder", "").strip()
    folders = [folder] if folder else list(folders_for_taxyear(taxyear))
    refresh = request.args.get("refresh", "").strip().lower() in {"1", "true", "yes"}
    try:
        report = (
            None
            if refresh or folder
            else load_missing_files_report(taxyear, folders_for_taxyear(taxyear))
        )
        if report is None:
            if folder:
                report = update_missing_files_report_for_folders(taxyear, folders)
            else:
                report = build_missing_files_report(taxyear, folders)
        return jsonify({"ok": True, **report})
    except Exception as exc:
        return jsonify({"ok": False, "error": str(exc)}), 500


def _filtered_metadata_records(taxyear, folder, method, state, filename):
    if folder.lower() == "all":
        records = []
        for source_folder in folders_for_taxyear(taxyear):
            records.extend(load_qdrant_store(taxyear, source_folder)["records"])
        result = {
            "taxyear": str(taxyear),
            "folder": "All",
            "records": records,
            "summary": summarize(records),
        }
    else:
        result = load_qdrant_store(taxyear, folder)
        records = result["records"]
    if folder and folder.lower() != "all":
        records = [record for record in records if record.get("folder") == folder]
    if method:
        records = [record for record in records if record.get("method") == method]
    if state:
        records = [record for record in records if record.get("fed_or_state") == state]
    if filename:
        records = [
            record for record in records
            if filename in " ".join([
                str(record.get("base_name") or ""),
                str(record.get("file_name") or ""),
                str(record.get("base_name") or record.get("file_name") or "").replace("\\", "/"),
            ]).lower()
        ]
    return result, records


def _metadata_workbook(records):
    workbook = Workbook()
    sheet = workbook.active
    sheet.title = "Metadata"
    headers = ["File", "Method", "Flow", "Fed/State", "GET Args", "POST Vars", "Called By"]
    sheet.append(headers)
    for record in records:
        sheet.append([
            record.get("file_name", ""),
            record.get("method", ""),
            record.get("called_from_flow", ""),
            record.get("fed_or_state", ""),
            ", ".join(record.get("allowed_get_arguments") or []),
            ", ".join(record.get("post_body_variables") or []),
            record.get("called_by_count", 0),
        ])

    for column_cells in sheet.columns:
        max_length = max((len(str(cell.value)) for cell in column_cells if cell.value is not None), default=0)
        sheet.column_dimensions[column_cells[0].column_letter].width = min(max(max_length + 2, 10), 60)

    buffer = BytesIO()
    workbook.save(buffer)
    return buffer.getvalue()


def _email_report_method(folder):
    folder_key = str(folder).lower()
    if folder_key in {"efilebank", "efilepartner"}:
        return "GET"
    if folder_key == "error":
        return "DEAD"
    return "ANALYSE"


def _email_report_attachments(taxyear, folders=None):
    attachments = []
    folder_results = []
    report_folders = list(folders) if folders else _analyse_email_build_folders(taxyear)
    report_folders = [
        folder for folder in report_folders
        if str(folder).lower() not in ANALYSE_EMAIL_EXCLUDED_FOLDERS
    ]
    for folder in report_folders:
        method = _email_report_method(folder)
        empty_get_args_only = str(folder).lower() in {"efilebank", "efilepartner"}
        records = [
            record
            for record in load_qdrant_store(taxyear, folder)["records"]
            if str(record.get("method", "")).upper() == method
            and (not empty_get_args_only or not record.get("allowed_get_arguments"))
        ]
        if not records:
            continue
        safe_folder = re.sub(r"[^A-Za-z0-9_.-]+", "_", str(folder)).strip("_") or "folder"
        filename = f"metadata_{taxyear}_{safe_folder}_{method.lower()}.xlsx"
        attachments.append({
            "filename": filename,
            "content_base64": base64.b64encode(_metadata_workbook(records)).decode("ascii"),
            "content_type": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        })
        folder_results.append({"folder": folder, "method": method, "files": len(records), "filename": filename})
    return attachments, folder_results


def _configured_email_addresses(value):
    if isinstance(value, str):
        value = re.split(r"[,;]", value)
    addresses = []
    for item in value or []:
        addresses.extend(re.split(r"[,;]", str(item)))
    return [item.strip() for item in addresses if item.strip()]


def _post_email(payload):
    request_data = json.dumps(payload).encode("utf-8")
    headers = {"Content-Type": "application/json", "X-API-Key": str(EMAIL_API_KEY).strip()}
    email_request = Request(EMAIL_API_URL, data=request_data, headers=headers, method="POST")
    try:
        with urlopen(email_request, timeout=EMAIL_TIMEOUT_SECONDS) as response:
            response_text = response.read().decode("utf-8", errors="replace")
            if not response_text:
                return {"status": response.status}
            try:
                return json.loads(response_text)
            except json.JSONDecodeError:
                return {"status": response.status, "response": response_text}
    except HTTPError as exc:
        details = exc.read().decode("utf-8", errors="replace")
        if exc.code == 500 and "server not connected" in details.lower():
            raise RuntimeError(
                "The email service SMTP connection is not connected. "
                "Restart the emailagent service, then send the report again."
            ) from exc
        raise RuntimeError(f"Email API returned HTTP {exc.code}: {details or exc.reason}") from exc
    except URLError as exc:
        raise RuntimeError(f"Unable to reach email API: {exc.reason}") from exc


def send_metadata_report_email(taxyear, folders=None):
    recipients = _configured_email_addresses(EMAIL_TO)
    if not recipients:
        raise ValueError("EMAIL_TO is not configured in email_report_config.py")
    if not str(EMAIL_API_KEY).strip():
        raise ValueError("EMAIL_API_KEY is not configured in email_report_config.py")

    attachments, folder_results = _email_report_attachments(taxyear, folders)
    if not attachments:
        raise ValueError(f"No matching metadata files were found for {taxyear}; no email was sent")

    zip_buffer = BytesIO()
    with ZipFile(zip_buffer, "w", ZIP_DEFLATED) as archive:
        for attachment in attachments:
            archive.writestr(
                attachment["filename"],
                base64.b64decode(attachment["content_base64"]),
            )
    delivery_attachments = [{
        "filename": f"metadata_{taxyear}_reports.zip",
        "content_base64": base64.b64encode(zip_buffer.getvalue()).decode("ascii"),
        "content_type": "application/zip",
    }]

    payload = {
        "subject": EMAIL_SUBJECT.format(taxyear=taxyear),
        "content": EMAIL_CONTENT.format(taxyear=taxyear),
        "to": recipients,
        "cc": _configured_email_addresses(EMAIL_CC),
        "bcc": _configured_email_addresses(EMAIL_BCC),
        "reply_to": _configured_email_addresses(EMAIL_REPLY_TO),
        "is_html": bool(EMAIL_IS_HTML),
        "attachments": delivery_attachments,
    }
    api_response = _post_email(payload)
    return {
        "taxyear": str(taxyear),
        "attachments": folder_results,
        "attachment_count": len(folder_results),
        "file_count": sum(item["files"] for item in folder_results),
        "email_count": 1,
        "packaged_as_zip": True,
        "api_responses": [api_response],
    }


def send_filtered_metadata_email(
    taxyear,
    folder,
    method="",
    state="",
    filename="",
    to=None,
    cc=None,
    content="",
):
    recipients = _configured_email_addresses(to)
    if not recipients:
        raise ValueError("At least one To address is required")
    if not str(EMAIL_API_KEY).strip():
        raise ValueError("EMAIL_API_KEY is not configured in email_report_config.py")

    _, records = _filtered_metadata_records(
        str(taxyear), str(folder), str(method), str(state), str(filename).lower()
    )
    if not records:
        raise ValueError("No metadata records match the selected filters; no email was sent")

    safe_folder = re.sub(r"[^A-Za-z0-9_.-]+", "_", str(folder)).strip("_") or "all"
    workbook_filename = f"metadata_{taxyear}_{safe_folder}_filtered.xlsx"
    message = str(content or "").strip() or (
        f"Attached is the filtered PHP Flow Scanner metadata workbook for "
        f"{taxyear}/{folder}."
    )
    payload = {
        "subject": f"PHP Flow Scanner filtered metadata - {taxyear}/{folder}",
        "content": message,
        "to": recipients,
        "cc": _configured_email_addresses(cc),
        "bcc": _configured_email_addresses(EMAIL_BCC),
        "reply_to": _configured_email_addresses(EMAIL_REPLY_TO),
        "is_html": bool(EMAIL_IS_HTML),
        "attachments": [{
            "filename": workbook_filename,
            "content_base64": base64.b64encode(_metadata_workbook(records)).decode("ascii"),
            "content_type": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        }],
    }
    api_response = _post_email(payload)
    return {
        "taxyear": str(taxyear),
        "folder": str(folder),
        "workbook": workbook_filename,
        "file_count": len(records),
        "email_count": 1,
        "api_responses": [api_response],
    }
def send_sql_report_email(taxyear, folder=None, mode="missing"):
    recipients = _configured_email_addresses(EMAIL_TO)
    if not recipients:
        raise ValueError("EMAIL_TO is not configured in email_report_config.py")
    if not str(EMAIL_API_KEY).strip():
        raise ValueError("EMAIL_API_KEY is not configured in email_report_config.py")

    all_years = str(taxyear) == "__all__"
    years = discover_tax_years() if all_years else [str(taxyear)]
    year_label = "All years" if all_years else str(taxyear)
    if isinstance(folder, (list, tuple, set)):
        selected_folders = [str(item).strip() for item in folder if str(item).strip()]
    elif folder:
        selected_folders = [str(folder).strip()]
    else:
        selected_folders = list(dict.fromkeys(
            item for year in years for item in _analyse_email_build_folders(year)
        ))

    if not selected_folders:
        raise ValueError(f"No Query Chunk builds were found for {year_label}; no email was sent")

    workbooks = []
    included_folders = []
    for year in years:
        available_folders = set(_analyse_email_build_folders(year)) if all_years else set(selected_folders)
        for selected_folder in selected_folders:
            if selected_folder not in available_folders:
                continue
            workbook = _qt_user_id_export_workbook(year, selected_folder, mode)
            if workbook[2] <= 0:
                continue
            workbooks.append(workbook)
            if selected_folder not in included_folders:
                included_folders.append(selected_folder)

    if not workbooks:
        raise ValueError(
            f"No matching {mode} rows were found for {year_label}; no email was sent"
        )
    selection_part = selected_folders[0] if len(selected_folders) == 1 else "ALL" if not folder else "SELECTED"
    safe_selection = re.sub(r"[^a-z0-9_-]+", "_", selection_part, flags=re.IGNORECASE)
    zip_year = "ALL_YEARS" if all_years else taxyear
    zip_filename = f"{zip_year}_{safe_selection}_qt_user_id_{mode}.zip"
    zip_buffer = BytesIO()
    with ZipFile(zip_buffer, "w", ZIP_DEFLATED) as archive:
        for workbook_filename, workbook_bytes, _row_count in workbooks:
            archive.writestr(workbook_filename, workbook_bytes)
    row_count = sum(item[2] for item in workbooks)

    includes_oltpro = any(str(item).lower() == "oltpro" for item in included_folders)
    id_name = "QT_USER_ID or OLTPRO_masterID" if includes_oltpro else "QT_USER_ID"
    if mode == "rearranged":
        subject = f"PHP Flow Scanner SQL report - {id_name} Rearranged - {year_label}"
        report_name = f"{id_name} Rearranged"
    else:
        subject = f"PHP Flow Scanner SQL report - Missing {id_name} - {year_label}"
        report_name = f"Missing {id_name}"
    if includes_oltpro and mode == "rearranged":
        workbook_word = "workbooks"
        list_verb = "list"
    else:
        workbook_word = "workbook" if len(workbooks) == 1 else "workbooks"
        list_verb = "lists" if len(workbooks) == 1 else "list"
    content = (
        f"Attached is a ZIP file containing the PHP Flow Scanner {report_name} reports "
        f"for {year_label} related to SQL queries. The {workbook_word} inside the ZIP {list_verb} the "
        "files that require SQL query review."
    )

    payload = {
        "subject": subject,
        "content": content,
        "to": recipients,
        "cc": _configured_email_addresses(EMAIL_CC),
        "bcc": _configured_email_addresses(EMAIL_BCC),
        "reply_to": _configured_email_addresses(EMAIL_REPLY_TO),
        "is_html": bool(EMAIL_IS_HTML),
        "attachments": [{
            "filename": zip_filename,
            "content_base64": base64.b64encode(zip_buffer.getvalue()).decode("ascii"),
            "content_type": "application/zip",
        }],
    }
    api_response = _post_email(payload)
    return {
        "taxyear": str(taxyear),
        "folder": included_folders[0] if folder and len(included_folders) == 1 else "All folders" if not folder else "Selected folders",
        "folders": included_folders,
        "mode": mode,
        "workbook": workbooks[0][0] if len(workbooks) == 1 else None,
        "workbooks": [item[0] for item in workbooks],
        "row_count": row_count,
        "email_count": 1,
        "packaged_as_zip": True,
        "api_responses": [api_response],
    }


def send_post_file_included_email(taxyear, folder):
    recipients = _configured_email_addresses(EMAIL_TO)
    if not recipients:
        raise ValueError("EMAIL_TO is not configured in email_report_config.py")
    if not str(EMAIL_API_KEY).strip():
        raise ValueError("EMAIL_API_KEY is not configured in email_report_config.py")

    workbook_filename, workbook_bytes, row_count, result = _post_file_included_workbook(
        taxyear, folder
    )
    if row_count <= 0:
        raise ValueError(
            f"No POST files included with include/require were found for {taxyear}/{folder}; no email was sent"
        )
    safe_folder = re.sub(r"[^A-Za-z0-9_.-]+", "_", str(folder)).strip("_") or "folder"
    zip_filename = f"{taxyear}_{safe_folder}_post_file_included.zip"
    zip_buffer = BytesIO()
    with ZipFile(zip_buffer, "w", ZIP_DEFLATED) as archive:
        archive.writestr(workbook_filename, workbook_bytes)

    payload = {
        "subject": f"PHP Flow Scanner POST FILE INCLUDED report - {taxyear}/{folder}",
        "content": (
            f"Attached is a ZIP file containing the PHP Flow Scanner POST FILE INCLUDED "
            f"report for {taxyear}/{folder}. The workbook lists POST files referenced by "
            "include or require statements."
        ),
        "to": recipients,
        "cc": _configured_email_addresses(EMAIL_CC),
        "bcc": _configured_email_addresses(EMAIL_BCC),
        "reply_to": _configured_email_addresses(EMAIL_REPLY_TO),
        "is_html": bool(EMAIL_IS_HTML),
        "attachments": [{
            "filename": zip_filename,
            "content_base64": base64.b64encode(zip_buffer.getvalue()).decode("ascii"),
            "content_type": "application/zip",
        }],
    }
    api_response = _post_email(payload)
    return {
        "taxyear": str(taxyear),
        "folder": str(folder),
        "workbook": workbook_filename,
        "row_count": row_count,
        "post_file_count": result["post_file_count"],
        "included_file_count": result["included_file_count"],
        "email_count": 1,
        "packaged_as_zip": True,
        "api_responses": [api_response],
    }


@app.route("/phphelper/api/metadata", methods=["GET"])
def metadata():
    taxyear = request.args.get("taxyear", "2025").strip()
    folder = request.args.get("folder", "oltproc").strip()
    method = request.args.get("method", "").strip()
    state = request.args.get("state", "").strip().upper()
    filename = request.args.get("filename", "").strip().lower()
    limit = min(max(int(request.args.get("limit", "500")), 1), 5000)
    offset = max(int(request.args.get("offset", "0")), 0)
    try:
        result, records = _filtered_metadata_records(taxyear, folder, method, state, filename)
    except Exception as exc:
        return jsonify({"ok": False, "error": str(exc)}), 500

    total_filtered = len(records)
    page_records = records[offset:offset + limit]
    return jsonify({
        "ok": True,
        "summary": result["summary"],
        "records": page_records,
        "total_filtered": total_filtered,
        "offset": offset,
        "limit": limit,
        "has_next": offset + limit < total_filtered,
        "has_prev": offset > 0,
    })


@app.route("/phphelper/api/export_metadata", methods=["GET"])
def export_metadata():
    taxyear = request.args.get("taxyear", "2025").strip()
    folder = request.args.get("folder", "oltproc").strip()
    method = request.args.get("method", "").strip()
    state = request.args.get("state", "").strip().upper()
    filename = request.args.get("filename", "").strip().lower()
    try:
        _, records = _filtered_metadata_records(taxyear, folder, method, state, filename)
    except Exception as exc:
        return jsonify({"ok": False, "error": str(exc)}), 500

    buffer = BytesIO(_metadata_workbook(records))
    buffer.seek(0)
    safe_folder = folder or "all"
    download_name = f"metadata_{taxyear}_{safe_folder}.xlsx"
    return send_file(
        buffer,
        as_attachment=True,
        download_name=download_name,
        mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    )


@app.route("/phphelper/api/email_metadata_reports", methods=["POST"])
def email_metadata_reports():
    payload = request.get_json(silent=True) or request.form
    taxyear = str(payload.get("taxyear", "")).strip()
    if not taxyear:
        return jsonify({"ok": False, "error": "taxyear is required"}), 400
    if taxyear.lower() not in {str(item).lower() for item in (
        *range(2015, 2026), "base", "probase", "partner", "cp", "main", "MO"
    )}:
        return jsonify({"ok": False, "error": f"Unsupported tax year/root: {taxyear}"}), 400
    requested_folders = payload.get("folders")
    if isinstance(requested_folders, str):
        requested_folders = [item.strip() for item in requested_folders.split(",") if item.strip()]
    requested_folders = [str(item).strip() for item in (requested_folders or []) if str(item).strip()]
    available_folders = _analyse_email_build_folders(taxyear)
    invalid_folders = [item for item in requested_folders if item not in available_folders]
    if invalid_folders:
        return jsonify({"ok": False, "error": f"Unknown folder(s): {', '.join(invalid_folders)}"}), 400
    try:
        if requested_folders:
            result = send_metadata_report_email(taxyear, requested_folders)
        else:
            result = send_metadata_report_email(taxyear)
        return jsonify({"ok": True, **result})
    except ValueError as exc:
        return jsonify({"ok": False, "error": str(exc)}), 400
    except Exception as exc:
        app.logger.exception("Metadata report email failed for %s", taxyear)
        return jsonify({"ok": False, "error": str(exc)}), 502


@app.route("/phphelper/api/email_filtered_metadata", methods=["POST"])
def email_filtered_metadata():
    payload = request.get_json(silent=True) or request.form
    taxyear = str(payload.get("taxyear", "")).strip()
    folder = str(payload.get("folder", "")).strip()
    if not taxyear or not folder:
        return jsonify({"ok": False, "error": "taxyear and folder are required"}), 400
    try:
        result = send_filtered_metadata_email(
            taxyear=taxyear,
            folder=folder,
            method=str(payload.get("method", "")).strip(),
            state=str(payload.get("state", "")).strip().upper(),
            filename=str(payload.get("filename", "")).strip(),
            to=payload.get("to"),
            cc=payload.get("cc"),
            content=payload.get("content", ""),
        )
        return jsonify({"ok": True, **result})
    except ValueError as exc:
        return jsonify({"ok": False, "error": str(exc)}), 400
    except Exception as exc:
        app.logger.exception(
            "Filtered metadata email failed for %s/%s", taxyear, folder
        )
        return jsonify({"ok": False, "error": str(exc)}), 502
@app.route("/phphelper/api/email_report_folders", methods=["GET"])
def email_report_folders():
    taxyear = request.args.get("taxyear", "").strip()
    if not taxyear:
        return jsonify({"ok": False, "error": "taxyear is required"}), 400
    try:
        return jsonify({
            "ok": True,
            "taxyear": taxyear,
            "folders": _analyse_email_build_folders(taxyear),
        })
    except Exception as exc:
        return jsonify({"ok": False, "error": str(exc)}), 500


@app.route("/phphelper/api/email_sql_report", methods=["POST"])
def email_sql_report():
    payload = request.get_json(silent=True) or request.form
    taxyear = str(payload.get("taxyear", "")).strip()
    requested_folders = payload.get("folders")
    if requested_folders is None:
        requested_folders = payload.get("folder", "")
    if isinstance(requested_folders, str):
        requested_folders = [item.strip() for item in requested_folders.split(",") if item.strip()]
    requested_folders = [str(item).strip() for item in (requested_folders or []) if str(item).strip()]
    mode = str(payload.get("mode", "missing")).strip().lower()
    if not taxyear:
        return jsonify({"ok": False, "error": "taxyear is required"}), 400
    if mode not in {"missing", "rearranged"}:
        return jsonify({"ok": False, "error": "mode must be missing or rearranged"}), 400
    available_years = set(discover_tax_years())
    if taxyear != "__all__" and taxyear not in available_years:
        return jsonify({"ok": False, "error": f"Unsupported tax year: {taxyear}"}), 400
    years = available_years if taxyear == "__all__" else [taxyear]
    available_folders = {
        item for year in years for item in _analyse_email_build_folders(year)
    }
    invalid_folders = [item for item in requested_folders if item not in available_folders]
    if invalid_folders:
        return jsonify({"ok": False, "error": f"No Query Chunk build found for {taxyear}/{', '.join(invalid_folders)}"}), 400
    folder_selection = (
        None if not requested_folders
        else requested_folders[0] if len(requested_folders) == 1
        else requested_folders
    )
    try:
        return jsonify({
            "ok": True,
            **send_sql_report_email(taxyear, folder_selection, mode),
        })
    except ValueError as exc:
        return jsonify({"ok": False, "error": str(exc)}), 400
    except Exception as exc:
        app.logger.exception(
            "SQL report email failed for %s/%s (%s)", taxyear, requested_folders or "All", mode
        )
        return jsonify({"ok": False, "error": str(exc)}), 502


@app.route("/phphelper/api/email_post_file_included", methods=["POST"])
def email_post_file_included_report():
    payload = request.get_json(silent=True) or request.form
    taxyear = str(payload.get("taxyear", "")).strip()
    folder = str(payload.get("folder", "")).strip()
    if not taxyear or not folder:
        return jsonify({"ok": False, "error": "taxyear and folder are required"}), 400
    try:
        if folder not in _post_file_included_folders(taxyear):
            return jsonify({"ok": False, "error": f"No Qdrant database found for {taxyear}/{folder}"}), 400
        return jsonify({
            "ok": True,
            **send_post_file_included_email(taxyear, folder),
        })
    except ValueError as exc:
        return jsonify({"ok": False, "error": str(exc)}), 400
    except Exception as exc:
        app.logger.exception(
            "POST FILE INCLUDED email failed for %s/%s", taxyear, folder
        )
        return jsonify({"ok": False, "error": str(exc)}), 502


@app.route("/phphelper/api/update_metadata_method", methods=["POST"])
def update_metadata_method():
    payload = request.get_json(silent=True) or request.form
    taxyear = str(payload.get("taxyear", "2025")).strip()
    folder = str(payload.get("folder", "oltproc")).strip()
    file_name = str(payload.get("file_name", "")).strip()
    method = str(payload.get("method", "")).strip()
    if not file_name:
        return jsonify({"ok": False, "error": "File name is required"}), 400
    if not method:
        return jsonify({"ok": False, "error": "Method is required"}), 400
    try:
        result = update_qdrant_metadata_method(taxyear, folder, file_name, method)
        return jsonify({"ok": True, **result})
    except Exception as exc:
        return jsonify({"ok": False, "error": str(exc)}), 500


@app.route("/phphelper/api/delete_metadata", methods=["POST"])
def delete_metadata():
    payload = request.get_json(silent=True) or request.form
    taxyear = str(payload.get("taxyear", "2025")).strip()
    folder = str(payload.get("folder", "oltproc")).strip()
    file_name = str(payload.get("file_name", "")).strip()
    try:
        result = delete_qdrant_metadata(taxyear, folder, file_name)
        return jsonify({"ok": True, **result})
    except Exception as exc:
        return jsonify({"ok": False, "error": str(exc)}), 500


@app.route("/phphelper/api/add_metadata_file", methods=["POST"])
def add_metadata_file():
    payload = request.get_json(silent=True) or request.form
    taxyear = str(payload.get("taxyear", "2025")).strip()
    folder = str(payload.get("folder", "oltproc")).strip()
    file_name = str(payload.get("file_name", "")).strip()
    metadata = payload.get("metadata", {}) if hasattr(payload, "get") else {}
    if not file_name:
        return jsonify({"ok": False, "error": "File name is required"}), 400
    try:
        result = add_qdrant_metadata_file(taxyear, folder, file_name, metadata)
        return jsonify({"ok": True, **result})
    except Exception as exc:
        app.logger.exception(
            "Failed to add metadata file %s/%s/%s",
            taxyear,
            folder,
            file_name,
        )
        return jsonify({"ok": False, "error": str(exc)}), 500


@app.route("/phphelper/api/rebuild_metadata_file", methods=["POST"])
def rebuild_metadata_file():
    payload = request.get_json(silent=True) or request.form
    taxyear = str(payload.get("taxyear", "2025")).strip()
    folder = str(payload.get("folder", "oltproc")).strip()
    file_name = str(payload.get("file_name", "")).strip()
    if not file_name:
        return jsonify({"ok": False, "error": "File name is required"}), 400
    try:
        result = rebuild_qdrant_metadata_files(taxyear, folder, file_name)
        return jsonify({"ok": True, **result})
    except Exception as exc:
        app.logger.exception(
            "Failed to rebuild metadata file %s/%s/%s",
            taxyear,
            folder,
            file_name,
        )
        return jsonify({"ok": False, "error": str(exc)}), 500


@app.route("/phphelper/api/qdrant_dbs", methods=["GET"])
def qdrant_dbs():
    taxyear = request.args.get("taxyear", "2025").strip()
    try:
        result = list_mergeable_qdrant_dbs(taxyear)
        return jsonify({"ok": True, **result})
    except Exception as exc:
        return jsonify({"ok": False, "error": str(exc)}), 500


@app.route("/phphelper/api/merge_qdrant", methods=["POST"])
def merge_qdrant():
    payload = request.get_json(silent=True) or request.form
    taxyear = str(payload.get("taxyear", "2025")).strip()
    sources = payload.get("sources", [])
    if isinstance(sources, str):
        sources = [item.strip() for item in sources.split(",") if item.strip()]
    try:
        result = merge_qdrant_dbs(taxyear, sources)
        return jsonify({"ok": True, **result})
    except Exception as exc:
        return jsonify({"ok": False, "error": str(exc)}), 500
# ==== Query Begins from here ========================================================

@app.route("/phphelper/api/query_chunk/years", methods=["GET"])
def query_chunk_years():
    try:
        return jsonify({"ok": True, "years": discover_tax_years()})
    except Exception as exc:
        return jsonify({"ok": False, "error": str(exc)}), 500


@app.route("/phphelper/api/query_chunk/folders", methods=["GET"])
def query_chunk_folders():
    taxyear = request.args.get("taxyear", "").strip()
    if not taxyear:
        return jsonify({"ok": False, "error": "taxyear is required"}), 400
    try:
        return jsonify({"ok": True, "taxyear": taxyear, "folders": discover_folders(taxyear)})
    except Exception as exc:
        return jsonify({"ok": False, "error": str(exc)}), 500


@app.route("/phphelper/api/query_chunk/check_build", methods=["GET"])
def query_chunk_check_build():
    taxyear = request.args.get("taxyear", "").strip()
    folder = request.args.get("folder", "").strip()
    if not taxyear or not folder:
        return jsonify({"ok": False, "error": "taxyear and folder are required"}), 400
    try:
        if folder.lower() == "all":
            selected_folders = _query_chunk_build_folders_for_all(taxyear, folder)
            already_built = bool(selected_folders) and all(
                folder_already_built(taxyear, item) for item in selected_folders
            )
        else:
            already_built = folder_already_built(taxyear, folder)
        return jsonify({"ok": True, "taxyear": taxyear, "folder": folder,
                         "already_built": already_built})
    except Exception as exc:
        return jsonify({"ok": False, "error": str(exc)}), 500


@app.route("/phphelper/api/query_chunk/create", methods=["POST"])
def query_chunk_create():
    payload = request.get_json(silent=True) or request.form
    taxyear = str(payload.get("taxyear", "")).strip()
    folder = str(payload.get("folder", "")).strip()
    if not taxyear or not folder:
        return jsonify({"ok": False, "error": "taxyear and folder are required"}), 400
    try:
        result = build_query_chunk_store(taxyear, folder)
        return jsonify(
            {
                "ok": True,
                "taxyear": taxyear,
                "folder": folder,
                "summary": result["summary"],
                "qdrant": result.get("qdrant", {}),
            }
        )
    except FileNotFoundError as exc:
        return jsonify({"ok": False, "error": str(exc)}), 404
    except Exception as exc:
        return jsonify({"ok": False, "error": str(exc)}), 500

@app.route("/phphelper/api/query_chunk/delete", methods=["POST"])
def query_chunk_delete():
    payload = request.get_json(silent=True) or request.form
    taxyear = str(payload.get("taxyear", "")).strip()
    folder = str(payload.get("folder", "")).strip()
    if not taxyear or not folder:
        return jsonify({"ok": False, "error": "taxyear and folder are required"}), 400
    try:
        result = delete_query_chunk_build(taxyear, folder)
        return jsonify({"ok": True, **result})
    except Exception as exc:
        return jsonify({"ok": False, "error": str(exc)}), 500


@app.route("/phphelper/api/query_chunk/delete_file", methods=["POST"])
def query_chunk_delete_file():
    payload = request.get_json(silent=True) or request.form
    taxyear = str(payload.get("taxyear", "")).strip()
    folder = str(payload.get("folder", "")).strip()
    file_name = str(payload.get("file_name", "")).strip()
    if not taxyear or not folder or not file_name:
        return jsonify({"ok": False, "error": "taxyear, folder and file_name are required"}), 400
    try:
        result = delete_query_chunk_file(taxyear, folder, file_name)
        return jsonify({"ok": True, **result})
    except Exception as exc:
        return jsonify({"ok": False, "error": str(exc)}), 500




@app.route("/phphelper/api/query_chunk/delete_taxyear", methods=["POST"])
def query_chunk_delete_taxyear():
    payload = request.get_json(silent=True) or request.form
    taxyear = str(payload.get("taxyear", "")).strip()
    if not taxyear:
        return jsonify({"ok": False, "error": "taxyear is required"}), 400
    try:
        result = delete_query_chunk_taxyear(taxyear)
        return jsonify({"ok": True, **result})
    except Exception as exc:
        return jsonify({"ok": False, "error": str(exc)}), 500


@app.route("/phphelper/api/query_chunk/update_file", methods=["POST"])
def query_chunk_update_file():
    payload = request.get_json(silent=True) or request.form
    taxyear = str(payload.get("taxyear", "")).strip()
    folder = str(payload.get("folder", "")).strip()
    file_name = str(payload.get("file_name", "")).strip()
    if not taxyear or not folder or not file_name:
        return jsonify({"ok": False, "error": "taxyear, folder and file_name are required"}), 400
    try:
        result = update_query_chunk_file(taxyear, folder, file_name)
        return jsonify({"ok": True, **result})
    except FileNotFoundError as exc:
        return jsonify({"ok": False, "error": str(exc)}), 404
    except Exception as exc:
        return jsonify({"ok": False, "error": str(exc)}), 500


@app.route("/phphelper/api/query_chunk/update_folder", methods=["POST"])
def query_chunk_update_folder():
    payload = request.get_json(silent=True) or request.form
    taxyear = str(payload.get("taxyear", "")).strip()
    folder = str(payload.get("folder", "")).strip()
    if not taxyear or not folder:
        return jsonify({"ok": False, "error": "taxyear and folder are required"}), 400
    try:
        result = update_query_chunk_folder(taxyear, folder)
        return jsonify({"ok": True, **result})
    except FileNotFoundError as exc:
        return jsonify({"ok": False, "error": str(exc)}), 404
    except Exception as exc:
        return jsonify({"ok": False, "error": str(exc)}), 500

@app.route("/phphelper/api/query_chunk/dbs", methods=["GET"])
def query_chunk_dbs():
    taxyear = request.args.get("taxyear", "").strip()
    if not taxyear:
        return jsonify({"ok": False, "error": "taxyear is required"}), 400
    try:
        return jsonify({"ok": True, "taxyear": taxyear, "builds": list_query_chunk_dbs(taxyear)})
    except Exception as exc:
        return jsonify({"ok": False, "error": str(exc)}), 500





@app.route("/phphelper/api/query_chunk/summary", methods=["GET"])
def query_chunk_summary():
    taxyear = request.args.get("taxyear", "").strip()
    if not taxyear:
        return jsonify({"ok": False, "error": "taxyear is required"}), 400
    try:
        return jsonify({"ok": True, **build_query_chunk_summary(taxyear)})
    except Exception as exc:
        return jsonify({"ok": False, "error": str(exc)}), 500


@app.route("/phphelper/api/query_chunk/files_for_build", methods=["GET"])
def query_chunk_files_for_build():
    taxyear = request.args.get("taxyear", "").strip()
    folder = request.args.get("folder", "").strip()
    if not taxyear or not folder:
        return jsonify({"ok": False, "error": "taxyear and folder are required"}), 400
    try:
        return jsonify({
            "ok": True, "taxyear": taxyear, "folder": folder,
            "files": list_files_for_build(taxyear, folder),
        })
    except Exception as exc:
        return jsonify({"ok": False, "error": str(exc)}), 500

@app.route("/phphelper/api/query_chunk/view", methods=["GET"])
def query_chunk_view():
    taxyear = request.args.get("taxyear", "").strip()
    if not taxyear:
        return jsonify({"ok": False, "error": "taxyear is required"}), 400

    folder = request.args.get("folder", "").strip() or None
    query_type = request.args.get("query_type", "").strip() or None
    state = request.args.get("state", "").strip() or None
    search = request.args.get("search", "").strip() or None
    limit = min(max(int(request.args.get("limit", "100")), 1), 2000)
    offset = max(int(request.args.get("offset", "0")), 0)

    try:
        result = load_query_chunk_metadata(
            taxyear=taxyear,
            folder=folder,
            query_type=query_type,
            state=state,
            search=search,
            limit=limit,
            offset=offset,
        )
        return jsonify({"ok": True, **result})
    except Exception as exc:
        return jsonify({"ok": False, "error": str(exc)}), 500
    
def _run_query_chunk_build(build_id, taxyear, folder):
    if folder.lower() == "all":
        return _run_query_chunk_build_all(build_id, taxyear, folder)

    # Checked up front, before build_query_chunk_store does anything --
    # purely so the "cancelled" status message below can tell the user
    # correctly whether their existing DB was protected or there was
    # nothing to protect in the first place.
    was_existing_build = folder_already_built(taxyear, folder)

    def progress(file_name, current, total, chunk_count):
        if file_name == "__embedding__":
            _set_build_status(
                build_id, state="embedding", taxyear=taxyear, folder=folder,
                file_name="", current=current, total=total, chunk_count=chunk_count,
                embedded=0, embed_total=chunk_count,
                message=f"Scanned {total} files, {chunk_count} chunks - embedding & writing to Qdrant...",
            )
            return
        _set_build_status(
            build_id,
            state="processing",
            taxyear=taxyear,
            folder=folder,
            file_name=file_name,
            current=current,
            total=total,
            chunk_count=chunk_count,
            message=f"{file_name} ({current}/{total})  {chunk_count} chunks so far",
        )

    def embed_progress(stored, total):
        # Live running count during embedding, tracked purely from our own
        # loop counters -- never re-queries Qdrant to check progress.
        _set_build_status(
            build_id, state="embedding", taxyear=taxyear, folder=folder,
            embedded=stored, embed_total=total,
            message=f"Embedding & writing to Qdrant... {stored}/{total} chunks",
        )

    def cancel_check():
        return _is_cancelled(build_id)

    try:
        result = build_query_chunk_store(
            taxyear, folder, progress=progress,
            embed_progress=embed_progress, cancel_check=cancel_check,
        )
        payload = {
            "ok": True, "build_id": build_id, "taxyear": taxyear, "folder": folder,
            "summary": result["summary"], "qdrant": result.get("qdrant", {}),
        }
        _set_build_status(build_id, **payload, state="complete", message="Build complete")
        return payload
    except BuildCancelled:
        message = (
            "Build cancelled existing DB restored, unchanged."
            if was_existing_build else
            "Build cancelled new DB removed."
        )
        _set_build_status(
            build_id, state="cancelled", taxyear=taxyear, folder=folder,
            message=message,
        )
    except Exception as exc:
        # Log the real error server-side only. The UI is not shown a live
        # error while the process is still running -- it will simply see
        # this build_id settle into a "completed" (here: failed) status once
        # polling picks it up, per the "handle errors in the log, not the
        # frontend, until the process ends" requirement.
        app.logger.exception("query_chunk build failed (build_id=%s, %s/%s)", build_id, taxyear, folder)
        _set_build_status(build_id, state="error", message="Build did not complete. See server log.", error=str(exc))
    finally:
        _clear_cancelled(build_id)


def _run_query_chunk_build_all(build_id, taxyear, folder):
    selected_folders = _query_chunk_build_folders_for_all(taxyear, folder)
    if not selected_folders:
        _set_build_status(build_id, state="error", taxyear=taxyear, folder=folder,
                           message=f"No build folders found for {taxyear}/All", error="No folders")
        return

    by_folder = {}
    total_folders = len(selected_folders)
    for idx, source_folder in enumerate(selected_folders, start=1):
        was_existing_build = folder_already_built(taxyear, source_folder)

        def progress(file_name, current, total, chunk_count, source_folder=source_folder, idx=idx):
            _set_build_status(
                build_id, state="processing", taxyear=taxyear, folder=folder,
                file_name=file_name, current=current, total=total, chunk_count=chunk_count,
                message=f"[{idx}/{total_folders}] {source_folder}: {file_name} ({current}/{total})",
            )

        def embed_progress(stored, total, source_folder=source_folder, idx=idx):
            _set_build_status(
                build_id, state="embedding", taxyear=taxyear, folder=folder,
                embedded=stored, embed_total=total,
                message=f"[{idx}/{total_folders}] {source_folder}: embedding {stored}/{total} chunks",
            )

        def cancel_check():
            return _is_cancelled(build_id)

        try:
            result = build_query_chunk_store(
                taxyear, source_folder, progress=progress,
                embed_progress=embed_progress, cancel_check=cancel_check,
            )
            by_folder[source_folder] = {"summary": result["summary"], "qdrant": result.get("qdrant", {})}
        except BuildCancelled:
            message = (
                "Build cancelled -- folders already completed were kept, remaining folders skipped."
                if by_folder else
                "Build cancelled -- new DB removed."
            )
            _set_build_status(build_id, state="cancelled", taxyear=taxyear, folder=folder, message=message)
            _clear_cancelled(build_id)
            return
        except Exception as exc:
            app.logger.exception("query_chunk build failed (build_id=%s, %s/%s)", build_id, taxyear, source_folder)
            _set_build_status(build_id, state="error", message=f"Build failed on {source_folder}. See server log.", error=str(exc))
            _clear_cancelled(build_id)
            return

    aggregate_summary = {
        "files_scanned": sum(info["summary"].get("files_scanned", 0) for info in by_folder.values()),
        "chunks_created": sum(info["summary"].get("chunks_created", 0) for info in by_folder.values()),
        "created_at": max((info["summary"].get("created_at") or "" for info in by_folder.values()), default=""),
        "collection_path": os.path.dirname(next(iter(by_folder.values()))["qdrant"].get("collection_path", "")) if by_folder else "",
        "folders_built": len(by_folder),
    }
    aggregate_qdrant = {
        "stored": sum(info["qdrant"].get("stored", 0) for info in by_folder.values()),
        "by_folder": {name: info["qdrant"] for name, info in by_folder.items()},
    }
    payload = {
        "ok": True, "build_id": build_id, "taxyear": taxyear, "folder": folder,
        "by_folder": by_folder, "summary": aggregate_summary, "qdrant": aggregate_qdrant,
    }
    _set_build_status(build_id, **payload, state="complete", message=f"Build complete for {len(by_folder)} folder(s)")
    _clear_cancelled(build_id)
    return payload


@app.route("/phphelper/api/query_chunk/create_start", methods=["POST"])
def query_chunk_create_start():
    payload = request.get_json(silent=True) or request.form
    taxyear = str(payload.get("taxyear", "")).strip()
    folder = str(payload.get("folder", "")).strip()
    if not taxyear or not folder:
        return jsonify({"ok": False, "error": "taxyear and folder are required"}), 400
    build_id = str(payload.get("build_id") or uuid4()).strip()
    _set_build_status(build_id, state="processing", taxyear=taxyear, folder=folder,
                       file_name="", current=0, total=0, chunk_count=0,
                       message=f"Processing {taxyear}/{folder}. Waiting for first file...")
    Thread(target=_run_query_chunk_build, args=(build_id, taxyear, folder), daemon=True).start()
    return jsonify({"ok": True, "build_id": build_id, "taxyear": taxyear, "folder": folder,
                     "message": BUILD_STATUS[build_id]["message"]})


@app.route("/phphelper/api/query_chunk/create_cancel", methods=["POST"])
def query_chunk_create_cancel():
    payload = request.get_json(silent=True) or request.form
    build_id = str(payload.get("build_id", "")).strip()
    if not build_id:
        return jsonify({"ok": False, "error": "build_id is required"}), 400
    with CANCEL_LOCK:
        CANCELLED_BUILDS.add(build_id)
    _set_build_status(build_id, state="cancelling", message="Cancelling...")
    return jsonify({"ok": True, "build_id": build_id})


@app.route("/phphelper/api/query_chunk/create_status", methods=["GET"])
def query_chunk_create_status():
    build_id = request.args.get("build_id", "").strip()
    status = BUILD_STATUS.get(build_id)
    if not status:
        return jsonify({"ok": False, "error": "Build status not found"}), 404
    return jsonify({"ok": True, **status})

@app.route("/phphelper/api/query_chunk/report", methods=["GET"])
def query_chunk_report():
    taxyear = request.args.get("taxyear", "").strip()
    if not taxyear:
        return jsonify({"ok": False, "error": "taxyear is required"}), 400
    refresh = request.args.get("refresh", "").strip().lower() in {"1", "true", "yes"}
    try:
        return jsonify({
            "ok": True, "taxyear": taxyear,
            "report": get_query_chunk_report(taxyear, refresh=refresh),
        })
    except Exception as exc:
        return jsonify({"ok": False, "error": str(exc)}), 500


@app.route("/phphelper/api/query_chunk/verify", methods=["GET"])
def query_chunk_verify():
    taxyear = request.args.get("taxyear", "").strip()
    if not taxyear:
        return jsonify({"ok": False, "error": "taxyear is required"}), 400
    folder = request.args.get("folder", "").strip() or None
    try:
        return jsonify({
            "ok": True,
            "taxyear": taxyear,
            "folder": folder,
            "verification": build_query_chunk_verification(taxyear, folder),
        })
    except Exception as exc:
        return jsonify({"ok": False, "error": str(exc)}), 500
from software_flow import register as register_software_flow
register_software_flow(app)

if __name__ == "__main__":
    host = os.getenv("PHP_DASHBOARD_HOST", "127.0.0.1")
    port = int(os.getenv("PHP_DASHBOARD_PORT", "5095"))
    app.run(host=host, port=port, debug=True)
