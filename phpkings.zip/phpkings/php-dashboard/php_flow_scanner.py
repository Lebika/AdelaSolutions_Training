import hashlib,logging
import importlib.util
import json
import math
import os
import shutil
import re
import subprocess
import time
from contextlib import contextmanager
from functools import wraps
from collections import Counter, defaultdict
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass, field
from datetime import date, datetime, timezone
from pathlib import Path
from threading import RLock, local
from typing import Callable, Dict, Iterable, List, Optional, Sequence, Set, Tuple
from urllib.parse import parse_qsl, urlparse
from pathlib import Path
app = None


def logger():
    return app.logger if app is not None else logging.getLogger(__name__)


REPO_ROOT = Path(__file__).resolve().parents[2]
PHPDATA_ROOT = REPO_ROOT / "phpdata"
DEFAULT_SITE_ASP_ROOT = Path(r"E:\online-taxes\site-asp")
DEFAULT_SITE_ASP_PROTECTED_ROOT = Path(r"E:\online-taxes\Site-ASP-Protected")
SITE_ASP_ROOT = DEFAULT_SITE_ASP_ROOT
SITE_ASP_PROTECTED_ROOT = DEFAULT_SITE_ASP_PROTECTED_ROOT
CODE_MOVE_DIR_NAME = "code_move"
QDRANT_ROOT = PHPDATA_ROOT / "Qdrant"
QDRANT_ACCESS_LOCK = RLock()
_QDRANT_BATCH_STATE = local()


def serialized_qdrant_access(func):
    """Prevent concurrent embedded Qdrant clients from opening local storage."""
    @wraps(func)
    def wrapped(*args, **kwargs):
        with QDRANT_ACCESS_LOCK:
            return func(*args, **kwargs)

    return wrapped


@contextmanager
def qdrant_write_batch():
    """Reuse embedded Qdrant clients and defer manifest writes within one job."""
    previous = getattr(_QDRANT_BATCH_STATE, "value", None)
    if previous is not None:
        yield previous
        return

    state = {"clients": {}, "manifests": {}}
    _QDRANT_BATCH_STATE.value = state
    try:
        # An embedded client keeps the local storage locked for the whole
        # batch, so other dashboard operations must not open it between files.
        with QDRANT_ACCESS_LOCK:
            try:
                yield state
            finally:
                try:
                    for (taxyear, folder), (manifest, records) in state["manifests"].items():
                        _write_manifest_summary(taxyear, folder, manifest, records)
                finally:
                    for client in state["clients"].values():
                        close = getattr(client, "close", None)
                        if callable(close):
                            close()
    finally:
        _QDRANT_BATCH_STATE.value = previous


FOLDERS = (
    "html", "oltproc", "inc", "jscripts", "styles", "images",
    "csr_tax_links", "csr_links", "tip_msg", "image", "csr_page_info", "err_msg",
    "code_bg_img", "fonts", "Original",
    "csr_examples", "csr_glossary", "csr_guide_pages", "tips_resources", "tool_tips",
    "DB", "error", "include", "page_info", "showreturn", "states","Staffolt", "wfi", "efile", "OLTPRO","efilebank", "efilePartner", "barcode"
)
BASE_FOLDERS = ("csr", "css", "error", "html", "images", "js", "oltproc", "page_info", "tool_tips")
PROBASE_FOLDERS = ("css", "html", "images", "js", "oltproc", "Original")
PARTNER_FOLDERS = (
    "partner",
    "BDServices", "crypt", "DB", "ExcelLibrary", "Fonts", "froala", "g2fa", "geo",
    "IRSRefundStatus", "mail", "OFX", "OLTPROVPSService", "owasp", "PDF", "Pdflib",
    "PHPWord", "ProtectionPlus", "references", "RGraph", "SC", "schema", "SMS",
    "SoapLibrary", "SSI", "SSP", "styles", "TBarCode", "TMS", "vps", "wsdl-cache",
    "XMPPHP",
)
CP_FOLDERS = ("css", "fonts", "home", "html", "oltproc", "images", "js")
MO_FOLDERS = ("csr", "db", "help", "home", "html", "jscripts", "images", "oltproc", "original", "page_info", "styles")
MAIN_FOLDERS = ("FFOLT", "FFOLTIN", "freefile", "ftax", "home", "OLTFREE", "OLTFREESTATE", "OLTSTATEFF", "pro", "VITA", "qtx")
MAIN_RECURSIVE_FLOW_FOLDERS = {
    "FFOLT", "FFOLTIN", "freefile", "ftax", "home", "OLTFREE", "OLTFREESTATE", "OLTSTATEFF", "pro", "VITA", "qtx"
}
METHOD_PRIORITY = ("POST", "GET", "INPUT", "MENU", "PAGEINFO", "HELP", "Common", "BATCH", "DEAD", "ANALYSE")
MANUAL_METHODS = ("ANALYSE", "DEAD", "BATCH", "GET", "POST", "INPUT", "MENU", "PAGEINFO", "HELP", "Common", "HEAD")
STATIC_GET_EXTENSIONS = (".ico", ".png", ".jpg", ".svg",".gif")
FOLDER_BY_LOWER = {folder.lower(): folder for folder in FOLDERS}
DEAD_FOLDERS = {"csr_links", "tip_msg", "image", "csr_page_info", "err_msg"}
GET_FOLDERS = {"code_bg_img", "fonts",  "jscripts", "styles"}
COMMON_FOLDERS = {"include", "barcode"}
HELP_FOLDERS = {"csr_examples", "csr_glossary", "tips_resources", "tool_tips"}
DB_FOLDERS = {"DB"}
OLTPRO_SUBFOLDERS = {
    "code_bg_img", "efile", "err_msg", "error", "help", "html", "image", "images",
    "inc", "js", "jscripts", "oltproc", "page_info", "phplot", "Refundo",
    "showreturn", "states", "States Tax Table", "styles", "tip_msg", "TMS",
}
OLTPRO_SUBFOLDER_BY_LOWER = {folder.lower(): folder for folder in OLTPRO_SUBFOLDERS}
BASE_FOLDER_BY_LOWER = {folder.lower(): folder for folder in BASE_FOLDERS}
PROBASE_FOLDER_BY_LOWER = {folder.lower(): folder for folder in PROBASE_FOLDERS}
PARTNER_FOLDER_BY_LOWER = {folder.lower(): folder for folder in PARTNER_FOLDERS}
CP_FOLDER_BY_LOWER = {folder.lower(): folder for folder in CP_FOLDERS}
MO_FOLDER_BY_LOWER = {folder.lower(): folder for folder in MO_FOLDERS}
MAIN_FOLDER_BY_LOWER = {folder.lower(): folder for folder in MAIN_FOLDERS}
REFERENCE_FOLDER_BY_LOWER = {
    **FOLDER_BY_LOWER,
    **OLTPRO_SUBFOLDER_BY_LOWER,
    **BASE_FOLDER_BY_LOWER,
    **PROBASE_FOLDER_BY_LOWER,
    **PARTNER_FOLDER_BY_LOWER,
    **CP_FOLDER_BY_LOWER,
    **MO_FOLDER_BY_LOWER,
    **MAIN_FOLDER_BY_LOWER,
}
FORCED_FOLDER_METHODS = {
    **{folder: "DEAD" for folder in DEAD_FOLDERS},
    **{folder: "GET" for folder in GET_FOLDERS},
    **{folder: "HELP" for folder in HELP_FOLDERS},
    **{folder: "Common" for folder in DB_FOLDERS},
    **{folder: "Common" for folder in COMMON_FOLDERS},
}


def folders_for_taxyear(taxyear: str) -> Tuple[str, ...]:
    taxyear_key = str(taxyear).strip().lower()
    if taxyear_key == "base":
        return BASE_FOLDERS
    if taxyear_key == "probase":
        return PROBASE_FOLDERS
    if taxyear_key == "partner":
        return PARTNER_FOLDERS
    if taxyear_key == "cp":
        return CP_FOLDERS
    if taxyear_key == "mo":
        return MO_FOLDERS
    if taxyear_key == "main":
        return MAIN_FOLDERS
    return FOLDERS


def is_supported_folder(taxyear: str, folder: str) -> bool:
    return folder in folders_for_taxyear(taxyear)


def source_folder_path(
    taxyear: str, folder: str, *, site_root: Optional[Path] = None,
    protected_root: Optional[Path] = None,
) -> Path:
    """Return the filesystem directory represented by a dashboard folder."""
    taxyear = str(taxyear)
    site_root = SITE_ASP_ROOT if site_root is None else Path(site_root)
    protected_root = SITE_ASP_PROTECTED_ROOT if protected_root is None else Path(protected_root)
    protected_folder = (
        (taxyear.lower() in {"2025", "2026", "base"} and (folder.lower() == "html" or folder.lower() == "barcode"))
        or (taxyear.lower() == "partner" and folder.lower() == "db")
    )
    if protected_folder:
        # Keep isolated/test deployments that override only SITE_ASP_ROOT
        # self-contained. Production uses the explicit protected root above.
        if (
            site_root != DEFAULT_SITE_ASP_ROOT
            and protected_root == DEFAULT_SITE_ASP_PROTECTED_ROOT
        ):
            protected_root = site_root
        return protected_root / taxyear / folder
    if taxyear.lower() == "partner" and folder.lower() == "partner":
        # The Partner/partner selector represents files directly in Partner,
        # rather than a nested Partner/partner directory.
        return site_root / taxyear
    return site_root / taxyear / folder


def code_move_root_path() -> Path:
    return SITE_ASP_ROOT / CODE_MOVE_DIR_NAME


def _path_is_within(path: Path, parent: Path) -> bool:
    try:
        path.resolve().relative_to(parent.resolve())
        return True
    except ValueError:
        return False


def collect_modified_files(
    source_folder: str,
    modified_from,
    modified_to,
    destination: Optional[Path] = None,
    progress: Optional[Callable[[str, int, int], None]] = None,
) -> Dict:
    """Copy files modified in an inclusive date range while preserving paths."""
    source = Path(str(source_folder or "").strip()).resolve()
    destination_root = Path(destination) if destination is not None else code_move_root_path()
    destination_root = destination_root.resolve()
    if not source.exists():
        raise FileNotFoundError(f"Source folder not found: {source}")
    if not source.is_dir():
        raise NotADirectoryError(f"Source path is not a directory: {source}")
    if source == destination_root or _path_is_within(source, destination_root):
        raise ValueError("Source folder cannot be the Code Move destination or a folder inside it")

    from_date = modified_from if isinstance(modified_from, date) else date.fromisoformat(str(modified_from))
    to_date = modified_to if isinstance(modified_to, date) else date.fromisoformat(str(modified_to))
    if from_date > to_date:
        raise ValueError("Modified From date cannot be after Modified To date")

    site_root = SITE_ASP_ROOT.resolve()
    source_name = source.name.lower()
    is_site_root_folder = bool(re.fullmatch(r"\d{4}", source.name)) or source_name in {
        "base", "probase", "partner", "cp", "main", "mo",
    }
    if _path_is_within(source, site_root):
        relative_root = site_root
    elif is_site_root_folder:
        relative_root = source.parent
    else:
        # For an external site-asp mirror or a generic container, preserve the
        # directory tree below the selected source without adding its wrapper.
        relative_root = source
    matches: List[Path] = []
    pending = [source]
    while pending:
        directory = pending.pop()
        files = []
        children = []
        # DirEntry caches metadata returned by directory enumeration (including
        # modification times on Windows). Prune excluded trees before entering
        # them, and avoid resolving every ordinary file's path on disk.
        with os.scandir(directory) as entries:
            for entry in entries:
                if entry.name.lower() == ".svn":
                    continue
                path = Path(entry.path)
                if path == destination_root:
                    continue
                if entry.is_symlink() or getattr(entry, "is_junction", lambda: False)():
                    if entry.is_dir() or _path_is_within(path, destination_root):
                        continue
                if entry.is_dir(follow_symlinks=False):
                    children.append(path)
                elif entry.is_file():
                    files.append((entry.stat().st_mtime, path))

        files.sort(key=lambda item: item[0], reverse=True)
        for modified_time, path in files:
            modified_date = datetime.fromtimestamp(modified_time).date()
            if modified_date < from_date:
                break
            if modified_date <= to_date:
                matches.append(path)
        # Directory timestamps do not describe the age of their contents.
        # Always scan child folders, even after this folder's date cutoff.
        pending.extend(sorted(children, reverse=True))

    results: List[Dict] = []
    total = len(matches)
    for index, source_path in enumerate(matches, start=1):
        relative_name = source_path.relative_to(relative_root)
        target_path = destination_root / relative_name
        if progress:
            progress(relative_name.as_posix(), index, total)
        try:
            existed = target_path.exists()
            target_path.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(source_path, target_path)
            results.append({
                "source_file": str(source_path),
                "destination_file": str(target_path),
                "relative_file": relative_name.as_posix(),
                "status": "overwritten" if existed else "copied",
            })
        except Exception as exc:
            results.append({
                "source_file": str(source_path),
                "destination_file": str(target_path),
                "relative_file": relative_name.as_posix(),
                "status": "failed",
                "error": str(exc),
            })

    counts = Counter(item["status"] for item in results)
    return {
        "source_folder": str(source),
        "destination": str(destination_root),
        "modified_from": from_date.isoformat(),
        "modified_to": to_date.isoformat(),
        "total": total,
        "copied": counts.get("copied", 0),
        "overwritten": counts.get("overwritten", 0),
        "failed": counts.get("failed", 0),
        "results": results,
    }

try:
    from php_flow_method_overrides import FORCED_FILE_METHODS
except ImportError:
    override_path = Path(__file__).with_name("php_flow_method_overrides.py")
    if override_path.exists():
        override_spec = importlib.util.spec_from_file_location("php_flow_method_overrides", override_path)
        override_module = importlib.util.module_from_spec(override_spec)
        override_spec.loader.exec_module(override_module)
        FORCED_FILE_METHODS = getattr(override_module, "FORCED_FILE_METHODS", [])
    else:
        FORCED_FILE_METHODS = []

OVERRIDE_FILE_PATH = Path(__file__).with_name("php_flow_method_overrides.py")

STATES = {
    "AL", "AK", "AZ", "AR", "CA", "CO", "CT", "DE", "DC", "FL", "GA", "HI",
    "ID", "IL", "IN", "IA", "KS", "KY", "LA", "ME", "MD", "MA", "MI", "MN",
    "MS", "MO", "MT", "NE", "NV", "NH", "NJ", "NM", "NY", "NC", "ND", "OH",
    "OK", "OR", "PA", "RI", "SC", "SD", "TN", "TX", "UT", "VT", "VA", "WA",
    "WV", "WI", "WY",
}

FILENAME_RE = re.compile(r"(?P<name>[A-Za-z0-9_.-]+\.(?:php|html))", re.IGNORECASE)
PHP_FRAGMENT_RE = re.compile(r"<\?.*?\?>", re.IGNORECASE)
INCLUDE_RE = re.compile(r"\b(?:include|include_once|require|require_once)\s*\(?\s*[\"']([^\"']+\.(?:php|html))[\"']", re.IGNORECASE)
CONCAT_INCLUDE_RE = re.compile(
    r"\b(?:include|include_once|require|require_once)\s*\(?\s*"
    r"(?:"
    r"\$[A-Za-z_][A-Za-z0-9_]*|"
    r"__DIR__|"
    r"GetPHPSERV\s*\(\s*[\"'][^\"']+[\"']\s*\)"
    r")\s*\.\s*"
    r"[\"']([^\"']+\.(?:php|html))[\"']",
    re.IGNORECASE,
)
BASE_INCLUDE_FUNC_ASSIGN_RE = re.compile(
    r"\$includeFunc\s*=\s*"
    r"(?:\$[A-Za-z_][A-Za-z0-9_]*|__DIR__)\s*\.\s*"
    r"[\"']([^\"']+\.(?:php|html))[\"']",
    re.IGNORECASE,
)
PATH_VAR_ASSIGN_RE = re.compile(
    r"\$([A-Za-z_][A-Za-z0-9_]*)\s*=\s*[^;\r\n]*?\.\s*"
    r"([\"'])([^\"']+\.(?:php|html))\2\s*;",
    re.IGNORECASE,
)
VARIABLE_INCLUDE_RE = re.compile(
    r"\b(?:include|include_once|require|require_once)\s*\(?\s*"
    r"(?:UDF_trim\s*\(\s*)?\$([A-Za-z_][A-Za-z0-9_]*)",
    re.IGNORECASE,
)
PHP_VARIABLE_ASSIGNMENT_RE = re.compile(
    r"\$([A-Za-z_][A-Za-z0-9_]*)\s*=\s*([^;\r\n]*);",
    re.IGNORECASE,
)
PHP_VARIABLE_TOKEN_RE = re.compile(r"\$([A-Za-z_][A-Za-z0-9_]*)")
FORM_RE = re.compile(r"<form\b[^>]*>", re.IGNORECASE)
ATTR_RE = re.compile(r"([A-Za-z_:.-]+)\s*=\s*([\"'])(.*?)\2", re.IGNORECASE | re.DOTALL)
UNQUOTED_ATTR_RE = re.compile(r"([A-Za-z_:.-]+)\s*=\s*([^\"'\s>]+)", re.IGNORECASE)
URL_ATTR_RE = re.compile(
    r"\b(?:href|src|url|data-url)\s*=\s*([\"'])"
    r"([^\"']+\.(?:php|html)(?:[?#][^\"']*)?)\s*\1",
    re.IGNORECASE,
)
UNQUOTED_URL_ATTR_RE = re.compile(
    r"\b(?:href|src|url|data-url)\s*=\s*"
    r"([^\s>\"']+\.(?:php|html)(?:[?#][^\s>\"']*)?)",
    re.IGNORECASE,
)

IFRAME_RE = re.compile(
    r"<iframe\\b[^>]*\\bsrc\\s*=\\s*([\"\'])([^\"\']+\\.(?:php|html)(?:\\?[^\"\']*)?)\\1",
    re.IGNORECASE,
)
JS_NAV_RE = re.compile(
    r"\b(?:(?:top|parent|window)\.)?"
    r"(?:location(?:\.(?:href|assign|replace))?|open|navigate)"
    r"\s*(?:=|\()\s*([\"'])([^\"']+\.(?:php|html)(?:[?#][^\"']*)?)\s*\1",
    re.IGNORECASE,
)
BR_WINDOW_RE = re.compile(
    r"\b(?:MM_openBrWindow|openBrWindow|BRwindow|BrWindow|brWindow)\s*\(\s*([\"\'])([^\"\']+\.(?:php|html)(?:\?[^\"\']*)?)\1",
    re.IGNORECASE,
)
BUILD_SECURE_URL_RE = re.compile(
    r"\bBuildSecureURL\s*\(\s*([\"\'])([^\"\']+\.(?:php|html)(?:\?[^\"\']*)?)\1",
    re.IGNORECASE,
)
JS_NAV_CALL_RE = re.compile(
    r"\b(?:(?:top|parent|window)\.)?"
    r"(?:location(?:\.(?:href|assign|replace))?|open|navigate)\s*(?:=|\()",
    re.IGNORECASE,
)
PHP_URL_VAR_ASSIGN_RE = re.compile(
    r"\$([A-Za-z_][A-Za-z0-9_]*)\s*=\s*([\"'])([^\"']+\.(?:php|html)(?:\?[^\"']*)?)\2",
    re.IGNORECASE,
)
PHP_BR_WINDOW_VAR_ASSIGN_RE = re.compile(
    r"\$([A-Za-z_][A-Za-z0-9_]*)\s*=\s*([\"']).*?"
    r"\b(?:MM_openBrWindow|openBrWindow|BRwindow|BrWindow|brWindow)\s*\(\s*"
    r"([\"'])([^\"']+\.(?:php|html)(?:\?[^\"']*)?)\3",
    re.IGNORECASE,
)
PHP_ECHO_VAR_RE = re.compile(
    r"<\?\s*(?:php\s+)?(?:echo\s+)?\$([A-Za-z_][A-Za-z0-9_]*)\s*;?\s*\?>|<\?=\s*\$([A-Za-z_][A-Za-z0-9_]*)\s*\?>",
    re.IGNORECASE,
)
HREF_ECHO_VAR_RE = re.compile(
    r"\bhref\s*=\s*([\"'])\s*(?:"
    r"<\?\s*(?:php\s+)?(?:echo\s+)?\$([A-Za-z_][A-Za-z0-9_]*)\s*;?\s*\?>"
    r"|<\?=\s*\$([A-Za-z_][A-Za-z0-9_]*)\s*\?>"
    r")\s*\1",
    re.IGNORECASE,
)
XHR_OPEN_RE = re.compile(
    r"\.open\s*\(\s*([\"'])(GET|POST)\1\s*,\s*([\"'])([^\"']+\.(?:php|html)(?:\?[^\"']*)?)\3",
    re.IGNORECASE,
)
JQUERY_POST_RE = re.compile(
    r"\$\.post\s*\(\s*([\"\'])([^\"\']+\.(?:php|html)(?:\?[^\"\']*)?)\1",
    re.IGNORECASE,
)
JQUERY_AJAX_START_RE = re.compile(r"\$\.ajax\s*\(", re.IGNORECASE)
JQUERY_AJAX_TYPE_RE = re.compile(r"\b(?:type|method)\s*:\s*([\"\'])(GET|POST)\1", re.IGNORECASE)
JQUERY_AJAX_URL_RE = re.compile(r"\burl\s*:\s*([\"\'])([^\"\']+\.(?:php|html)(?:\?[^\"\']*)?)\1", re.IGNORECASE)
PHP_LOCATION_RE = re.compile(
    r"\bheader\s*\(\s*[\"']\s*Location\s*:\s*"
    r"([^\"']+\.(?:php|html)(?:\?[^\"']*)?)",
    re.IGNORECASE,
)
MO_GEN_IMAGE_RE = re.compile(
    r"\bgenImage\s*\(\s*([\"'])[^\"']*\1\s*,\s*"
    r"([\"'])([^\"']+\.(?:php|html)(?:[?#][^\"']*)?)\2",
    re.IGNORECASE,
)
COMMON_INCLUDE_CONTEXT_RE = re.compile(r"\b(?:include|include_once|require|require_once)\s*\(?", re.IGNORECASE)
COMMON_GET_CONTEXT_RE = re.compile(
    r"(?:"
    r"<iframe\b|"
    r"\btop\.frames\s*\[|\bparent\.frames\s*\[|\bframes\s*\[|"
    r"\bhref\s*=|\bsrc\s*=|\burl\s*[:=]|\bdata-url\s*=|"
    r"\b(?:top\.|parent\.|window\.)?location"
    r"(?:\.(?:href|assign|replace))?\s*(?:=|\()|"
    r"\bheader\s*\(\s*['\"]?Location\s*:|"
    r"\bwindow\.open\s*\(|\bopen\s*\(|\bnavigate\s*\(|"
    r"\bBuildSecureURL\s*\(|\bfnGenIFrame\s*\(|"
    r"\.php\?|\.html\?"
    r")",
    re.IGNORECASE,
)
COMMON_POST_CONTEXT_RE = re.compile(
    r"(?:"
    r"<form\b[^>]*\bmethod\s*=\s*['\"]?post|"
    r"\$\.post\s*\(|"
    r"\.open\s*\(\s*['\"]POST['\"]|"
    r"\b(?:type|method)\s*:\s*['\"]POST['\"]|"
    r"\bsubmitForm\s*\("
    r")",
    re.IGNORECASE,
)
PARTNER_REFERENCE_TOKEN_RE = re.compile(
    r"(?P<path>(?:\.\.?[\\/])?(?:[A-Za-z0-9_. -]+[\\/])*[A-Za-z0-9_. -]+(?:\.[A-Za-z0-9_-]{1,16})?)"
)
PARTNER_QUERY_TARGET_RE = re.compile(
    r"(?P<path>(?:\.\.?[\\/])?(?:[A-Za-z0-9_. -]+[\\/])*[A-Za-z0-9_. -]+\.php)\?",
    re.IGNORECASE,
)
PARTNER_INCLUDE_TARGET_RE = re.compile(
    r"\b(?:include|include_once|require|require_once)\s*\(?\s*"
    r"(?:__DIR__\s*\.\s*)?[\"'](?P<path>[^\"']+\.(?:php|html))[\"']",
    re.IGNORECASE,
)
PARTNER_TEXT_SUFFIXES = {
    "", ".php", ".html", ".htm", ".js", ".css", *STATIC_GET_EXTENSIONS,
}
PARTNER_STATIC_GET_EXTENSIONS = {
    ".bmp", ".css", ".eot", ".gif", ".ico", ".jpeg", ".jpg", ".js", ".map",
    ".otf", ".pdf", ".png", ".svg", ".ttf", ".webp", ".woff", ".woff2",
}
PARTNER_ALL_COMMON_FOLDERS = {
    "ofx", "oltprovpsservice", "pdf", "phpword", "schema", "ssi", "ssp",
    "tbarcode",
}
PARTNER_ALL_GET_FOLDERS = {"fonts", "froala", "styles"}
PARTNER_COMMON_NESTED_FOLDERS = {
    "excellibrary", "owasp", "references", "sms", "xmpphp",
}
PARTNER_ANALYSE_AS_COMMON_FOLDERS = {"mail", "sms", "xmpphp"}
PARTNER_COMMON_FILENAME_CONTAINS = ("dm_extract",)
PARTNER_GET_FILENAME_SUFFIXES = ("inbound.php", "check.php", "track.php")
FLOW_VAR_RE = re.compile(
    r"(?<![A-Za-z0-9_])\$?(?:"
    r"navicall|next_call|nextphp|next_php|nextMenuPhp|"
    r"(?:nextcall|nexcall)[A-Za-z0-9_]*|"
    r"[A-Za-z_][A-Za-z0-9_]*(?:nextcall|nexcall)[A-Za-z0-9_]*|"
    r"BASELoadingHTML[A-Za-z0-9_]*|"
    r"[A-Za-z_][A-Za-z0-9_]*BASELoadingHTML[A-Za-z0-9_]*"
    r")\s*=\s*"
    r"[\"']?([A-Za-z0-9_.-]+(?:\.php)?)[\"']?(?=\s*(?:[;&]|$))",
    re.IGNORECASE,
)
CP_DUAL_FLOW_RE = re.compile(
    r"(?<![A-Za-z0-9_])\$?nextCall\s*={1,2}\s*[\"']?([A-Za-z0-9_.-]+)[\"']?",
    re.IGNORECASE,
)
PROBASE_DUAL_FLOW_RE = re.compile(
    r"(?<![A-Za-z0-9_])\$?(?:nextCall|nexcall)\s*={1,2}\s*[\"']?([A-Za-z0-9_.-]+)[\"']?",
    re.IGNORECASE,
)
BASE_LOADING_HTML_RE = re.compile(
    r"(?<![A-Za-z0-9_])\$?(?:"
    r"BASELoadingHTML[A-Za-z0-9_]*|"
    r"[A-Za-z_][A-Za-z0-9_]*BASELoadingHTML[A-Za-z0-9_]*"
    r")\s*=\s*[\"']([A-Za-z0-9_.-]+)[\"']",
    re.IGNORECASE,
)
BASE_LOADING_HTML_VALUE_RE = re.compile(
    r"\bBASELoadingHTML\s*=\s*([A-Za-z0-9_.-]+)",
    re.IGNORECASE,
)
NAVI_HTML_VALUE_RE = re.compile(
    r"\bnavihtml\s*=\s*[\"']?([A-Za-z0-9_.-]+\.html?)",
    re.IGNORECASE,
)
MO_LOADING_HTML_RE = re.compile(
    r"(?<![A-Za-z0-9_])\$?MOLoadingHTML[A-Za-z0-9_]*\s*=\s*"
    r"[\"']([A-Za-z0-9_.-]+)[\"']",
    re.IGNORECASE,
)
MO_ENCRYPTED_LOADING_HTML_RE = re.compile(
    r"(?<![A-Za-z0-9_])\$?MOLoadingHTML[A-Za-z0-9_]*\s*=\s*"
    r"[\"']?\.?\s*mcryptMOSessionEncrypt\s*\(\s*[\"']([A-Za-z0-9_.-]+)[\"']",
    re.IGNORECASE,
)
MO_QUERY_LOADING_HTML_RE = re.compile(
    r"\bMOLoadingHTML\b[^\r\n]*?"
    r"mcryptMOSessionEncrypt\s*\(\s*[\"']([A-Za-z0-9_.-]+)[\"']",
    re.IGNORECASE,
)
MO_EXTENSIONLESS_FLOW_RE = re.compile(
    r"(?<![A-Za-z0-9_])\$?(?:ReportIncludeFileName|genMOHelpPopUpPage)\s*=\s*"
    r"[\"']([A-Za-z0-9_.-]+)[\"']",
    re.IGNORECASE,
)
READ_ARG_RE = re.compile(r"\$_(?:GET|REQUEST)\s*\[\s*[\"']([^\"']+)[\"']\s*\]", re.IGNORECASE)
POST_ARG_RE = re.compile(r"\$_POST\s*\[\s*[\"']([^\"']+)[\"']\s*\]", re.IGNORECASE)
HIDDEN_DATA_RE = re.compile(r"\bBuildDynamicFormHiddenData\s*\(\s*([\"'])(.*?)\1", re.IGNORECASE)
SUBMIT_FORM_RE = re.compile(r"\bsubmitForm\s*\((.*?)\)", re.IGNORECASE)
UPDATE_FORM_RE = re.compile(r"\bupdateForm\s*\((.*?)\)", re.IGNORECASE)
MOBILE_MENU_RE = re.compile(r"\$mobileMenuArray\s*\[\]\s*=\s*array\s*\((.*?)\)", re.IGNORECASE)
MULTIPLE_INPUT_ACTION_RE = re.compile(
    r"\$multipleInputArray\s*\[\s*([\"'])(Edit|Delete)\1\s*\]\s*=\s*"
    r"([\"'])([A-Za-z0-9_.-]+\.(?:php|html)\?[^\"']*)\3",
    re.IGNORECASE,
)
STRING_ARG_RE = re.compile(r"([\"'])([^\"']+\.(?:php|html)(?:\?[^\"']*)?)\1", re.IGNORECASE)
QUERY_URL_RE = re.compile(
    r"(?<![A-Za-z0-9_])((?:\.\.?/|[A-Za-z0-9_./-])*[A-Za-z0-9_.-]+\.(?:php|html)\?[^\"'\s<>)]*)",
    re.IGNORECASE,
)
CONCAT_QUERY_URL_RE = re.compile(
    r"([\"'])((?:\.\.?/|[A-Za-z0-9_./-])*[A-Za-z0-9_.-]+\.(?:php|html))\1\s*\.\s*([\"'])\?([^\"']*)\3",
    re.IGNORECASE,
)
SHOWRETURN_REPLACE_RE = re.compile(
    r"UDF_str_replace\s*\(\s*"
    r"[\"\']href=\.\./returns/[\"\']\s*,\s*"
    r"[\"\']href=\.\./showreturn/([^?\"\']+\.php)(?:\?[^{}\"\']*)?[\"\']",
    re.IGNORECASE,
)
ORIGINAL_PDF_RE = re.compile(
    r'["\']?\s*\.\s*"ORIGINAL/([^"]+\.pdf)"',
    re.IGNORECASE,
)


@dataclass
class Evidence:
    source_file: str
    source_line: int
    method: str
    reason: str
    snippet: str
    args: Set[str] = field(default_factory=set)


def clean_snippet(line: str, max_len: int = 220) -> str:
    text = " ".join(line.strip().split())
    return text[:max_len]


def strip_code_comments(line: str, in_block_comment: bool = False) -> Tuple[str, bool]:
    """Remove PHP/JS comments while preserving comment markers inside strings."""
    output: List[str] = []
    quote = ""
    escaped = False
    index = 0
    while index < len(line):
        char = line[index]
        next_char = line[index + 1] if index + 1 < len(line) else ""

        if in_block_comment:
            if char == "*" and next_char == "/":
                in_block_comment = False
                index += 2
            else:
                index += 1
            continue

        if quote:
            output.append(char)
            if escaped:
                escaped = False
            elif char == "\\":
                escaped = True
            elif char == quote:
                quote = ""
            index += 1
            continue

        if char in {'"', "'"}:
            quote = char
            output.append(char)
            index += 1
            continue
        if char == "/" and next_char == "/":
            break
        if char == "/" and next_char == "*":
            in_block_comment = True
            index += 2
            continue
        if char == "#" and not "".join(output).strip():
            break
        output.append(char)
        index += 1

    return "".join(output), in_block_comment


def normalize_code_line(line: str) -> str:
    uncommented, _in_block_comment = strip_code_comments(line)
    return uncommented.replace('\\"', '"').replace("\\'", "'")


def uncomment_code_lines(lines: Iterable[str]) -> List[str]:
    """Strip comments from a complete source while tracking multiline blocks."""
    uncommented_lines: List[str] = []
    in_block_comment = False
    for line in lines:
        uncommented, in_block_comment = strip_code_comments(line, in_block_comment)
        uncommented_lines.append(uncommented)
    return uncommented_lines


def strip_php_fragments(text: str) -> str:
    return PHP_FRAGMENT_RE.sub("", text)


def normalize_target(raw: str, source_folder: str) -> Optional[Tuple[str, str]]:
    raw = strip_php_fragments(raw).strip().replace("\\", "/")
    if not raw or raw.startswith("#") or raw.lower().startswith(("mailto:", "javascript:", "http://", "https://")):
        return None
    parsed = urlparse(raw)
    path = parsed.path.strip().replace("\\", "/")
    if not path:
        return None
    name = Path(path).name
    if not FILENAME_RE.fullmatch(name):
        return None
    suffix = Path(name).suffix.lower()
    path_parts = [part for part in Path(path).parts if part not in {".", ".."}]
    folder = ""
    for part in reversed(path_parts[:-1]):
        # OLTPRO mirrors the normal year folders and also has virtual target
        # folders such as TMS.  Recognizing those path segments here lets the
        # shared GET/POST/INPUT/Common extractor classify OLTPRO references
        # without adding TMS (which is not a top-level scan folder) to FOLDERS.
        canonical = REFERENCE_FOLDER_BY_LOWER.get(part.lower())
        if canonical:
            folder = canonical
            break
    if not folder and suffix == ".html":
        folder = "html"
    elif not folder and suffix == ".php":
        folder = REFERENCE_FOLDER_BY_LOWER.get(source_folder.lower(), source_folder) if source_folder.lower() in REFERENCE_FOLDER_BY_LOWER else "oltproc"
    else:
        folder = folder or (
            REFERENCE_FOLDER_BY_LOWER.get(source_folder.lower(), source_folder)
            if source_folder.lower() in REFERENCE_FOLDER_BY_LOWER
            else ("html" if suffix == ".html" else "oltproc")
        )
    return folder, name


def has_explicit_folder(raw: str) -> bool:
    path = urlparse(strip_php_fragments(raw).strip().replace("\\", "/")).path.strip().replace("\\", "/")
    path_parts = [part for part in Path(path).parts if part not in {".", ".."}]
    return any(part.lower() in REFERENCE_FOLDER_BY_LOWER for part in path_parts[:-1])


def resolve_known_target(target: Optional[Tuple[str, str]], known: Set[Tuple[str, str]]) -> Optional[Tuple[str, str]]:
    if not target:
        return None
    if target in known:
        return target
    target_folder, target_name = target
    target_key = (target_folder.lower(), target_name.lower())
    for known_folder, known_name in known:
        if (known_folder.lower(), known_name.lower()) == target_key:
            return known_folder, known_name
    return None


def resolve_reference_target(raw: str, source_folder: str, known: Set[Tuple[str, str]], requested_target_folder: str) -> Optional[Tuple[str, str]]:
    if requested_target_folder:
        cleaned_path = urlparse(strip_php_fragments(raw).strip().replace("\\", "/")).path
        relative_name = "/".join(
            part for part in cleaned_path.strip("/").split("/")
            if part not in {"", ".", ".."}
        )
        requested_folder = FOLDER_BY_LOWER.get(requested_target_folder.lower(), requested_target_folder)
        relative_target = resolve_known_target((requested_folder, relative_name), known)
        if relative_target:
            return relative_target

    target = normalize_target(raw, source_folder)
    if target and requested_target_folder and not has_explicit_folder(raw):
        requested_folder = FOLDER_BY_LOWER.get(requested_target_folder.lower(), requested_target_folder)
        requested_target = resolve_known_target((requested_folder, target[1]), known)
        if requested_target:
            return requested_target
    return resolve_known_target(target, known)


def resolve_submit_form_target(raw: str, source_folder: str, known: Set[Tuple[str, str]], requested_target_folder: str) -> Optional[Tuple[str, str]]:
    """Resolve a submitForm PHP argument against the folder being scanned.

    Menu files commonly pass only a basename (for example,
    ``st_AL_pri_info_list.php``) even though the handler is in ``oltproc``.
    Do not let that basename inherit the menu file's source folder.
    """
    if not has_explicit_folder(raw) and requested_target_folder:
        name = Path(urlparse(strip_php_fragments(raw).strip().replace("\\", "/")).path).name
        requested_folder = FOLDER_BY_LOWER.get(requested_target_folder.lower(), requested_target_folder)
        requested_target = resolve_known_target((requested_folder, name), known)
        if requested_target:
            return requested_target
    return resolve_reference_target(raw, source_folder, known, requested_target_folder)


def resolve_filename_query_target(raw: str, source_folder: str, known: Set[Tuple[str, str]], requested_target_folder: str) -> Optional[Tuple[str, str]]:
    """Resolve a bare ``filename.php?...`` link as GET in the scanned folder."""
    cleaned = strip_php_fragments(raw).strip().replace("\\", "/")
    parsed = urlparse(cleaned)
    path = parsed.path.strip("/")
    if parsed.query and path and "/" not in path and requested_target_folder:
        requested_folder = FOLDER_BY_LOWER.get(requested_target_folder.lower(), requested_target_folder)
        requested_target = resolve_known_target((requested_folder, Path(path).name), known)
        if requested_target:
            return requested_target
    return resolve_reference_target(raw, source_folder, known, requested_target_folder)


def query_arg_names(raw: str) -> Set[str]:
    parsed = urlparse(strip_php_fragments(raw).strip())
    return {name for name, _value in parse_qsl(parsed.query, keep_blank_values=True) if name}


def inline_query_arg_names(raw: str) -> Set[str]:
    return set(re.findall(r"[?&]([A-Za-z_][A-Za-z0-9_-]*)\s*=", strip_php_fragments(raw)))


def has_common_query_url(line: str) -> bool:
    lower_line = line.lower()
    return (
        ".php?" in lower_line
        or ".html?" in lower_line
        or bool(QUERY_URL_RE.search(line))
        or bool(CONCAT_QUERY_URL_RE.search(line))
    )


def common_reference_method(line: str, default_method: str = "POST", default_reason: str = "plain PHP/HTML reference", prefix: str = "") -> Tuple[str, str]:
    parsed_line = normalize_code_line(line)
    context_line = strip_php_fragments(parsed_line)
    label = f"{prefix} " if prefix else ""
    if COMMON_INCLUDE_CONTEXT_RE.search(context_line):
        return "Common", f"{label}include/require".strip()
    if COMMON_POST_CONTEXT_RE.search(context_line):
        return "POST", f"{label}POST reference".strip()
    if COMMON_GET_CONTEXT_RE.search(context_line) or has_common_query_url(parsed_line):
        return "GET", f"{label}GET reference".strip()
    return default_method, f"{label}{default_reason}".strip()


def state_for_name(name: str) -> str:
    patterns = (
        r"st_([a-z]{2})_",
        r"([a-z]{2})_",
    )
    for pattern in patterns:
        match = re.match(pattern, name, re.IGNORECASE)
        if not match:
            continue
        state = match.group(1).upper()
        if state in STATES:
            return state
    return "FED"

def metadata_state(folder: str, relative_name: str, filename: str) -> str:
    """Derive WFI state from its area folder; use filename rules elsewhere."""
    if folder.lower() == "wfi":
        area = str(relative_name or "").replace("\\", "/").split("/", 1)[0]
        state = area.upper()
        return state if state in STATES else "FED"
    return state_for_name(filename)


STATE_OLTPROC_POST_SUFFIXES = ("_disclosure_flow",)
STATE_OLTPROC_COMMON_SUFFIXES = (
    "_verifyexamine",
    "_amended_process",
    "_verify_det",
    "_refund_meter_calc",
    "_reject_redirect",
    "_ext_info",
    "_mandatory_info",
    "_amd_organize",
    "cal_corp",
)
OLTPROC_POST_SUFFIXES = (
    "_nextcall_pri_sp",
    "_1040es_ques",
)
OLTPROC_COMMON_PREFIXES = ("copy_data_",)
OLTPROC_COMMON_SUFFIXES = (
    "_reject_info",
    "_soft_diag_check",
)


def state_oltproc_filename_method(taxyear: str, folder: str, path: Path) -> str:
    """Return deterministic filename methods for selected 2015-2025 handlers."""
    try:
        year = int(str(taxyear))
    except ValueError:
        return ""
    if not 2015 <= year <= 2025 or folder.lower() != "oltproc":
        return ""

    stem = path.stem.lower()
    if stem.endswith(OLTPROC_POST_SUFFIXES):
        return "POST"
    if stem.startswith(OLTPROC_COMMON_PREFIXES) or stem.endswith(OLTPROC_COMMON_SUFFIXES):
        return "Common"

    if state_for_name(path.name) == "FED":
        return ""
    if stem.endswith(STATE_OLTPROC_POST_SUFFIXES):
        return "POST"
    if stem.endswith(STATE_OLTPROC_COMMON_SUFFIXES):
        return "Common"
    return ""


def html_filename_method(taxyear: str, folder: str, path: Path) -> str:
    """Return deterministic methods for numeric tax-year html folders."""
    if not str(taxyear).strip().isdigit() or folder.lower() != "html":
        return ""
    if path.name.lower().endswith(("mandatory_info.html", "summary_view.html")):
        return "Common"
    return ""


def _normalize_override_method(method: str) -> str:
    method = str(method or "").strip()
    if method.upper() == "COMMON":
        return "Common"
    return method.upper() if method.upper() in {item for item in MANUAL_METHODS if item != "Common"} else method


def _normalize_override_filename(filename: str) -> str:
    return str(filename or "").strip().replace("\\", "/").lower()


def _normalize_override_folder(folder: str) -> str:
    value = str(folder or "").strip().replace("\\", "/").strip("/").lower()
    return "*" if value in {"all", "*"} else value


def _is_standard_taxyear(taxyear: str) -> bool:
    value = str(taxyear or "").strip()
    return value.isdigit() and 2015 <= int(value) <= 2026


def standard_inc_filename_method(taxyear: str, folder: str, path: Path) -> str:
    """Return Common for shared header/footer filenames in numeric-year inc folders."""
    filename = path.name.lower()
    if (
        str(taxyear or "").strip().isdigit()
        and folder.lower() == "inc"
        and any(token in filename for token in ("header", "footer", "hdr"))
    ):
        return "Common"
    return ""


def _oltpro_override_filename(taxyear: str, folder: str, filename: str) -> str:
    """Return the shared OLTPRO-relative filename for supported override forms."""
    taxyear_key = str(taxyear or "").strip().lower()
    folder_key = str(folder or "").strip().replace("\\", "/").strip("/")
    filename = str(filename or "").strip().replace("\\", "/").lstrip("/")
    if folder_key.lower() == "oltpro" and _is_standard_taxyear(taxyear):
        return filename
    if taxyear_key == "oltpro":
        if not folder_key or folder_key.lower() == "oltpro":
            return filename
        return f"{folder_key}/{filename}"
    return ""


def _override_identity(entry: Dict) -> Tuple[str, str, str]:
    taxyear = str(entry.get("taxyear", "*")).strip() or "*"
    folder = str(entry.get("folder", "")).strip()
    filename = str(entry.get("filename", "")).strip()
    oltpro_filename = _oltpro_override_filename(taxyear, folder, filename)
    if oltpro_filename:
        return "*", "oltpro", _normalize_override_filename(oltpro_filename)
    if _is_standard_taxyear(taxyear):
        return "*", _normalize_override_folder(folder), _normalize_override_filename(filename)
    return taxyear.lower(), _normalize_override_folder(folder), _normalize_override_filename(filename)


def _replace_override_file(temp_path: Path, path: Path) -> None:
    """Retry a transient Windows file lock while atomically saving overrides."""
    for attempt in range(5):
        try:
            os.replace(temp_path, path)
            return
        except PermissionError:
            if attempt == 4:
                raise
            time.sleep(0.02)


def _forced_file_method_index() -> Dict[Tuple[str, str, str], str]:
    index: Dict[Tuple[str, str, str], str] = {}
    for entry in FORCED_FILE_METHODS:
        taxyear = str(entry.get("taxyear", "*")).strip().lower() or "*"
        if taxyear == "all":
            taxyear = "*"
        folder = str(entry.get("folder", "")).strip()
        filename = _normalize_override_filename(entry.get("filename", ""))
        method = _normalize_override_method(entry.get("method", ""))
        oltpro_filename = _oltpro_override_filename(taxyear, folder, entry.get("filename", ""))
        if oltpro_filename:
            taxyear = "*"
            folder = "OLTPRO"
            filename = _normalize_override_filename(oltpro_filename)
        elif _is_standard_taxyear(taxyear):
            taxyear = "*"
        folder = _normalize_override_folder(folder)
        if not folder or not filename or not method:
            continue
        if method not in MANUAL_METHODS:
            raise ValueError(f"Unsupported forced file method for {folder}/{filename}: {method}")
        index[(taxyear, folder, filename)] = method
    return index


def forced_file_method(folder: str, relative_name: str, basename: str = "", taxyear: str = "") -> str:
    index = _forced_file_method_index()
    taxyear_key = str(taxyear or "").strip().lower()
    folder_key = _normalize_override_folder(folder)
    relative_key = _normalize_override_filename(relative_name)
    basename_key = _normalize_override_filename(basename or Path(relative_name).name)
    filename_keys = [relative_key, basename_key]
    for filename_key in tuple(filename_keys):
        suffix = Path(filename_key).suffix
        if suffix:
            extensionless_key = filename_key[:-len(suffix)]
            if extensionless_key not in filename_keys:
                filename_keys.append(extensionless_key)
    keys = []
    if taxyear_key:
        keys.extend((taxyear_key, folder_key, name) for name in filename_keys)
        keys.extend((taxyear_key, "*", name) for name in filename_keys)
    keys.extend(("*", folder_key, name) for name in filename_keys)
    keys.extend(("*", "*", name) for name in filename_keys)
    return next((index[key] for key in keys if key in index), "")


def persist_forced_file_method_override(
    taxyear: str,
    folder: str,
    filename: str,
    method: str,
) -> Dict:
    """Persist a dashboard method choice and activate it in this process."""
    taxyear = str(taxyear or "").strip()
    folder = str(folder or "").strip()
    filename = str(filename or "").strip().replace("\\", "/")
    method = _normalize_override_method(method)
    if not taxyear or not folder or not filename:
        raise ValueError("Tax year, folder, and filename are required for a method override.")
    if method not in MANUAL_METHODS:
        raise ValueError(f"Unsupported metadata method: {method}")

    oltpro_filename = _oltpro_override_filename(taxyear, folder, filename)
    entry = (
        {
            "folder": "OLTPRO" if oltpro_filename else folder,
            "filename": oltpro_filename or filename,
            "method": method,
        }
        if oltpro_filename or _is_standard_taxyear(taxyear)
        else {"taxyear": taxyear, "folder": folder, "filename": filename, "method": method}
    )
    entry_identity = _override_identity(entry)
    matching_indexes = [
        index for index, existing in enumerate(FORCED_FILE_METHODS)
        if _override_identity(existing) == entry_identity
    ]
    existing_method = (
        _normalize_override_method(FORCED_FILE_METHODS[matching_indexes[0]].get("method", ""))
        if matching_indexes
        else forced_file_method(folder, filename, Path(filename).name, taxyear=taxyear)
    )
    if not matching_indexes and existing_method:
        return {"added": False, "entry": entry, "existing_method": existing_method}

    path = OVERRIDE_FILE_PATH
    if not path.exists():
        raise RuntimeError(f"Method override file not found: {path}")
    source = path.read_bytes().decode("utf-8")
    closing_matches = list(re.finditer(r"(?m)^\s*\]\s*$", source))
    if not closing_matches or "FORCED_FILE_METHODS" not in source:
        raise RuntimeError(f"Could not locate FORCED_FILE_METHODS in {path}")

    newline = "\r\n" if "\r\n" in source else "\n"
    if matching_indexes:
        output_lines = []
        replaced = False
        for line in source.splitlines(keepends=True):
            stripped = line.strip().rstrip(",")
            try:
                source_entry = json.loads(stripped) if stripped.startswith("{") else None
            except json.JSONDecodeError:
                source_entry = None
            if isinstance(source_entry, dict) and _override_identity(source_entry) == entry_identity:
                if not replaced:
                    line_ending = "\r\n" if line.endswith("\r\n") else ("\n" if line.endswith("\n") else newline)
                    output_lines.append(f"    {json.dumps(entry, ensure_ascii=False)},{line_ending}")
                    replaced = True
                continue
            output_lines.append(line)
        if not replaced:
            raise RuntimeError(f"Could not locate existing method override in {path}")
        updated_source = "".join(output_lines)
        temp_path = path.with_name(f"{path.name}.tmp")
        temp_path.write_bytes(updated_source.encode("utf-8"))
        _replace_override_file(temp_path, path)
        first_index = matching_indexes[0]
        FORCED_FILE_METHODS[:] = [
            existing for existing in FORCED_FILE_METHODS
            if _override_identity(existing) != entry_identity
        ]
        FORCED_FILE_METHODS.insert(first_index, entry)
        return {
            "added": False,
            "updated": existing_method != method or len(matching_indexes) > 1,
            "entry": entry,
            "existing_method": existing_method,
        }

    closing = closing_matches[-1]
    entry_line = f"    {json.dumps(entry, ensure_ascii=False)},"
    updated_source = source[:closing.start()] + entry_line + newline + source[closing.start():]
    temp_path = path.with_name(f"{path.name}.tmp")
    temp_path.write_bytes(updated_source.encode("utf-8"))
    _replace_override_file(temp_path, path)
    FORCED_FILE_METHODS.append(entry)
    return {"added": True, "updated": False, "entry": entry, "existing_method": ""}


def all_candidate_methods_forced(
    folder: str,
    folder_path: Path,
    candidate_paths: Sequence[Path],
    taxyear: str = "",
) -> bool:
    if not candidate_paths:
        return False
    for path in candidate_paths:
        if not path.is_file():
            continue
        relative_name = relative_file_name(folder_path, path)
        if not forced_file_method(folder, relative_name, path.name, taxyear=taxyear):
            return False
    return True


def all_candidates_final_before_references(
    folder: str,
    folder_path: Path,
    candidate_paths: Sequence[Path],
    taxyear: str = "",
) -> bool:
    """Return whether every file is resolved by override or zero-byte DEAD."""
    if not candidate_paths:
        return False
    for path in candidate_paths:
        if not path.is_file():
            continue
        relative_name = relative_file_name(folder_path, path)
        if forced_file_method(
            folder, relative_name, path.name, taxyear=taxyear
        ):
            continue
        if path.stat().st_size == 0:
            continue
        return False
    return True


def rel_file(taxyear: str, folder: str, name: str) -> str:
    if not folder:
        return f"/{taxyear}/{name}"
    if str(taxyear).lower() == "partner" and folder.lower() == "partner":
        return f"/{taxyear}/{name}"
    return f"/{taxyear}/{folder}/{name}"


def relative_file_name(folder_path: Path, path: Path) -> str:
    try:
        return path.relative_to(folder_path).as_posix()
    except ValueError:
        return path.name


def normalize_requested_file_name(taxyear: str, folder: str, file_name: str) -> str:
    raw = str(file_name or "").strip().replace("\\", "/")
    raw = raw.lstrip("/")
    prefix = (
        f"{taxyear}/"
        if str(taxyear).lower() == "partner" and folder.lower() == "partner"
        else f"{taxyear}/{folder}/"
    )
    if raw.lower().startswith(prefix.lower()):
        raw = raw[len(prefix):]
    return raw


def resolve_source_file_path(taxyear: str, folder: str, folder_path: Path, file_name: str) -> Path:
    matches = resolve_source_file_paths(taxyear, folder, folder_path, file_name)
    if len(matches) == 1:
        return matches[0]
    relative_matches = ", ".join(relative_file_name(folder_path, path) for path in matches[:10])
    raise ValueError(
        f"Multiple files named {Path(file_name).name} found in {taxyear}/{folder}: "
        f"{relative_matches}"
    )


def resolve_source_file_paths(
    taxyear: str,
    folder: str,
    folder_path: Path,
    file_name: str,
) -> List[Path]:
    """Resolve an exact relative path or every match for a bare basename."""
    normalized_name = normalize_requested_file_name(str(taxyear), folder, file_name)
    source_path = (folder_path / normalized_name).resolve()
    folder_root = folder_path.resolve()
    try:
        source_path.relative_to(folder_root)
    except ValueError as exc:
        raise ValueError(f"Source file must be inside {taxyear}/{folder}: {file_name}") from exc
    if source_path.exists() and source_path.is_file():
        return [source_path]

    requested_basename = Path(normalized_name).name.lower()
    matches = [
        path
        for path in candidate_paths_for_folder(folder_path, folder)
        if path.is_file() and path.name.lower() == requested_basename
    ]
    if matches:
        return [path.resolve() for path in matches]
    raise FileNotFoundError(f"Source file not found: {source_path}")


def classify_primary(methods: Iterable[str]) -> str:
    method_set = set(methods)
    for method in METHOD_PRIORITY:
        if method in method_set:
            return method
    return "ANALYSE"


def is_included(evidence: Sequence[Evidence]) -> bool:
    return any(item.reason == "include/require" for item in evidence)


def is_html_page_info(evidence: Sequence[Evidence]) -> bool:
    return any(item.reason == "include/require" and "/html/" in item.source_file.lower() for item in evidence)


def is_showreturn_linked(evidence: Sequence[Evidence]) -> bool:
    return any(item.method == "GET" for item in evidence)

_ORIGINAL_PDF_REFS_CACHE: Dict[str, Dict[str, Dict[str, str]]] = {}

_ORIGINAL_PDF_REF_RE = re.compile(
    r'original\s*/\s*([^"\'\r\n]+?\.pdf)',
        re.IGNORECASE,
    )
_ORIGINAL_PDF_REF_BYTES_RE = re.compile(
    rb'original\s*/\s*([^"\'\r\n]+?\.pdf)',
    re.IGNORECASE,
)
_DYNAMIC_ORIGINAL_PDF_RE = re.compile(
    r'original\s*/\s*\$([A-Za-z_]\w*)\s*\.pdf',
    re.IGNORECASE,
)
_FOREACH_ARRAY_RE = re.compile(
    r'foreach\s*\(\s*\$([A-Za-z_]\w*)\s+as\s+\$([A-Za-z_]\w*)\s*\)',
    re.IGNORECASE,
)
_ORIGINAL_PDF_WINDOW_OPEN_RE = re.compile(
    r'onclick\s*=\s*["\']?\s*window\.open\s*\([^\r\n]*?'
    r'original\s*/\s*([^"\'\r\n]+?\.pdf)',
    re.IGNORECASE,
)
_ORIGINAL_PDF_LINK_ASSIGNMENT_RE = re.compile(
    r'\$(?=[A-Za-z_])(?=\w*link)\w+\s*=\s*(["\'])'
    r'[^"\'\r\n]*?original\s*/\s*([^"\'\r\n]+?\.pdf)\1',
    re.IGNORECASE,
)
_ORIGINAL_PDF_HREF_RE = re.compile(
    r'\bhref\s*=\s*\\?(["\'])[^"\'\r\n]*?'
    r'original\s*/\s*([^"\'\r\n?]+?\.pdf)(?:\?[^"\'\r\n]*)?\\?\1',
    re.IGNORECASE,
)
_ORIGINAL_PDF_BROWSER_CALL_RE = re.compile(
    r'\b(?:MM_openBrWindow|openBrWindow|window\.open)\s*\('
    r'[^\r\n]*?\\?(["\'])[^"\'\r\n]*?original\s*/\s*'
    r'([^"\'\r\n?]+?\.pdf)(?:\?[^"\'\r\n]*)?\\?\1',
    re.IGNORECASE,
)


def _original_pdf_refs_in_file(source_path: Path) -> Set[str]:
    """Extract literal and array-driven Original PDF references from PHP."""
    try:
        data = source_path.read_bytes()
    except OSError:
        return set()

    references = {
        Path(match.group(1).decode("utf-8", errors="ignore")).name.lower()
        for match in _ORIGINAL_PDF_REF_BYTES_RE.finditer(data)
    }
    text = data.decode("utf-8", errors="ignore")
    dynamic_names = {
        match.group(1).lower()
        for match in _DYNAMIC_ORIGINAL_PDF_RE.finditer(text)
    }
    if not dynamic_names:
        return references

    array_names = {
        array_name
        for array_name, item_name in _FOREACH_ARRAY_RE.findall(text)
        if item_name.lower() in dynamic_names
    }
    for array_name in array_names:
        assignment_re = re.compile(
            rf'\${re.escape(array_name)}\s*=\s*(?:array\s*\(|\[)(.*?)(?:\)|\])\s*;',
            re.IGNORECASE | re.DOTALL,
        )
        for assignment in assignment_re.finditer(text):
            for _quote, value in re.findall(r'(["\'])([^"\'$]+)\1', assignment.group(1)):
                pdf_name = Path(value.strip()).name
                if pdf_name and not pdf_name.lower().endswith(".pdf"):
                    pdf_name += ".pdf"
                if pdf_name.lower().endswith(".pdf"):
                    references.add(pdf_name.lower())
    return references


def _original_pdf_window_open_refs_in_file(source_path: Path) -> Set[str]:
    """Extract Original PDFs opened by an onclick=window.open(...) handler."""
    try:
        text = source_path.read_text(encoding="utf-8", errors="ignore")
    except OSError:
        return set()
    return {
        Path(match.group(1)).name.lower()
        for match in _ORIGINAL_PDF_WINDOW_OPEN_RE.finditer(text)
    }


def _original_pdf_link_assignment_refs_in_file(source_path: Path) -> Set[str]:
    """Extract Original PDFs assigned to a variable whose name contains link."""
    try:
        text = source_path.read_text(encoding="utf-8", errors="ignore")
    except OSError:
        return set()
    return {
        Path(match.group(2)).name.lower()
        for match in _ORIGINAL_PDF_LINK_ASSIGNMENT_RE.finditer(text)
    }


def _original_pdf_browser_link_refs_in_file(source_path: Path) -> Set[str]:
    """Extract literal Original PDFs opened through href or browser calls."""
    try:
        text = source_path.read_text(encoding="utf-8", errors="ignore")
    except OSError:
        return set()
    return {
        Path(match.group(2)).name.lower()
        for pattern in (_ORIGINAL_PDF_HREF_RE, _ORIGINAL_PDF_BROWSER_CALL_RE)
        for match in pattern.finditer(text)
    }


def _original_pdf_get_refs_in_file(source_path: Path) -> Tuple[Set[str], Set[str]]:
    """Return window.open and link-variable GET references from one source."""
    return (
        _original_pdf_window_open_refs_in_file(source_path),
        _original_pdf_link_assignment_refs_in_file(source_path),
    )


def _original_pdf_oltproc_get_refs_in_file(source_path: Path) -> Set[str]:
    """Extract browser-facing Original PDF references from normal oltproc."""
    return (
        _original_pdf_browser_link_refs_in_file(source_path)
        | _original_pdf_link_assignment_refs_in_file(source_path)
    )


def _original_pdf_pattern_source_files(
    source_roots: Sequence[Path],
    needles: Sequence[str],
) -> List[Path]:
    """Find likely Original-pattern files only in approved evidence roots."""
    existing_roots = [root for root in source_roots if root.exists()]
    if not existing_roots:
        return []
    rg_executable = shutil.which("rg")
    if rg_executable:
        command = [
            rg_executable,
            "--files-with-matches",
            "--ignore-case",
            "--fixed-strings",
            "--no-messages",
            "--glob",
            "*.php",
            "--glob",
            "*.html",
            "--glob",
            "*.js",
        ]
        for needle in needles:
            command.extend(("-e", needle))
        command.extend(str(root) for root in existing_roots)
        try:
            search = subprocess.run(
                command,
                capture_output=True,
                text=True,
                check=False,
            )
            if search.returncode in (0, 1):
                return sorted({
                    Path(line.strip())
                    for line in search.stdout.splitlines()
                    if line.strip()
                })
        except OSError:
            pass
    return [
        path
        for root in existing_roots
        for path in root.rglob("*")
        if path.is_file()
        and path.suffix.lower() in {".php", ".html", ".js"}
        and any(
            needle.lower() in read_file_text(path).lower()
            for needle in needles
        )
    ]


def _add_original_pdf_reference(
    references: Dict[str, Dict[str, str]],
    pdf_name: str,
    method: str,
    source: str,
) -> None:
    """Store one qualifying reference while retaining independent BANK evidence."""
    key = Path(pdf_name).name.lower()
    current = references.get(key)
    bank_evidence = source == "OLTPRO" or bool(current and current.get("bank") == "yes")
    priority = {
        "showreturn": 1,
        "OLTPRO": 2,
        "window.open": 3,
        "link variable": 3,
        "oltproc browser link": 3,
        "html browser link": 3,
    }
    if not current or priority.get(source, 0) >= priority.get(current.get("source", ""), 0):
        references[key] = {"method": method, "source": source}
        current = references[key]
    if bank_evidence and current is not None:
        current["bank"] = "yes"


def _collect_original_pdf_references(
    taxyear: str,
    reference_sources: Optional[Sequence[Dict]] = None,
    progress: Optional[Callable[[str, int, int], None]] = None,
) -> Dict[str, Dict[str, str]]:
    """Return Original PDF names mapped to their reference-based method.

    References in showreturn and, for 2015-2025, OLTPRO/html or OLTPRO/oltproc
    classify a non-empty PDF as Common. An onclick window.open reference or an
    Original PDF assigned to a variable containing ``link`` classifies it GET.
    Browser-facing references in the normal html and oltproc folders also
    classify it GET.
    """
    taxyear = str(taxyear)
    referenced = _ORIGINAL_PDF_REFS_CACHE.get(taxyear)
    if referenced is None:
        year_root = SITE_ASP_ROOT / taxyear
        referenced = {}

        showreturn_path = year_root / "showreturn"
        if showreturn_path.exists():
            showreturn_files = [path for path in showreturn_path.rglob("*.php") if path.is_file()]
            workers = min(32, max(4, (os.cpu_count() or 4) * 4))
            with ThreadPoolExecutor(max_workers=workers) as executor:
                extracted = executor.map(
                    _original_pdf_refs_in_file, showreturn_files, chunksize=32
                )
                for index, (source_path, file_refs) in enumerate(
                    zip(showreturn_files, extracted), start=1
                ):
                    if progress:
                        progress(
                            f"references: showreturn/{source_path.name}",
                            index,
                            len(showreturn_files),
                        )
                    for pdf_name in file_refs:
                        _add_original_pdf_reference(
                            referenced, pdf_name, "Common", "showreturn"
                        )

        if _is_standard_taxyear(taxyear):
            oltpro_source_files: List[Path] = []
            for source_subfolder in ("html", "oltproc"):
                source_root = year_root / "OLTPRO" / source_subfolder
                if not source_root.exists():
                    continue
                oltpro_source_files.extend(
                    path for path in source_root.rglob("*")
                    if path.is_file()
                    and path.suffix.lower() in {".php", ".html", ".js"}
                )
            if oltpro_source_files:
                workers = min(32, max(4, (os.cpu_count() or 4) * 4))
                with ThreadPoolExecutor(max_workers=workers) as executor:
                    extracted = executor.map(
                        _original_pdf_refs_in_file, oltpro_source_files, chunksize=32
                    )
                    for index, (source_path, file_refs) in enumerate(
                        zip(oltpro_source_files, extracted), start=1
                    ):
                        if progress:
                            source_name = os.path.relpath(
                                source_path, year_root / "OLTPRO"
                            ).replace(os.sep, "/")
                            progress(
                                f"references: OLTPRO/{source_name}",
                                index,
                                len(oltpro_source_files),
                            )
                        for pdf_name in file_refs:
                            _add_original_pdf_reference(
                                referenced, pdf_name, "Common", "OLTPRO"
                            )

        if progress:
            progress("searching Original GET patterns", 0, 1)
        get_pattern_files = _original_pdf_pattern_source_files(
            (
                year_root / "showreturn",
                year_root / "OLTPRO" / "html",
                year_root / "OLTPRO" / "oltproc",
            ),
            ("onclick", "Original/"),
        )
        if progress:
            progress("Original GET pattern search complete", 1, 1)
        if get_pattern_files:
            workers = min(32, max(4, (os.cpu_count() or 4) * 4))
            with ThreadPoolExecutor(max_workers=workers) as executor:
                extracted = executor.map(
                    _original_pdf_get_refs_in_file,
                    get_pattern_files,
                    chunksize=32,
                )
                for index, (source_path, file_refs) in enumerate(
                    zip(get_pattern_files, extracted), start=1
                ):
                    if progress:
                        progress(
                            f"GET patterns: {os.path.relpath(source_path, year_root).replace(os.sep, '/')}",
                            index,
                            len(get_pattern_files),
                        )
                    window_open_refs, link_assignment_refs = file_refs
                    for pdf_name in window_open_refs:
                        _add_original_pdf_reference(
                            referenced, pdf_name, "GET", "window.open"
                        )
                    for pdf_name in link_assignment_refs:
                        _add_original_pdf_reference(
                            referenced, pdf_name, "GET", "link variable"
                        )

        browser_get_files = _original_pdf_pattern_source_files(
            (year_root / "html", year_root / "oltproc"),
            ("Original/",),
        )
        if browser_get_files:
            workers = min(32, max(4, (os.cpu_count() or 4) * 4))
            with ThreadPoolExecutor(max_workers=workers) as executor:
                extracted = executor.map(
                    _original_pdf_oltproc_get_refs_in_file,
                    browser_get_files,
                    chunksize=32,
                )
                for source_path, file_refs in zip(browser_get_files, extracted):
                    source = (
                        "html browser link"
                        if source_path.is_relative_to(year_root / "html")
                        else "oltproc browser link"
                    )
                    for pdf_name in file_refs:
                        _add_original_pdf_reference(
                            referenced, pdf_name, "GET", source
                        )

        _ORIGINAL_PDF_REFS_CACHE[taxyear] = referenced
    elif progress:
        progress("references: cached", 1, 1)

    if not reference_sources:
        return referenced

    staged_references = dict(referenced)
    for entry in reference_sources:
        entry_folder = str(entry.get("folder", "")).lower()
        entry_file = str(entry.get("file_name", "")).replace("\\", "/").lower()
        is_oltpro_source = (
            entry_folder == "oltpro"
            and _is_standard_taxyear(taxyear)
            and entry_file.startswith(("html/", "oltproc/"))
        )
        is_browser_get_source = entry_folder in {"html", "oltproc"}
        is_target_evidence_source = entry_folder == "showreturn" or is_oltpro_source
        staged_path = Path(str(entry.get("staged_path", "")))
        if (
            is_browser_get_source
            and not entry.get("error")
            and str(entry.get("taxyear", "")).lower() == taxyear.lower()
            and staged_path.suffix.lower() in {".php", ".html", ".js"}
        ):
            for pdf_name in _original_pdf_oltproc_get_refs_in_file(staged_path):
                _add_original_pdf_reference(
                    staged_references,
                    pdf_name,
                    "GET",
                    f"{entry_folder} browser link",
                )
        if (
            is_target_evidence_source
            and staged_path.suffix.lower() in {".php", ".html", ".js"}
        ):
            for pdf_name in _original_pdf_window_open_refs_in_file(staged_path):
                _add_original_pdf_reference(
                    staged_references, pdf_name, "GET", "window.open"
                )
            for pdf_name in _original_pdf_link_assignment_refs_in_file(staged_path):
                _add_original_pdf_reference(
                    staged_references, pdf_name, "GET", "link variable"
                )
        if (
            entry.get("error")
            or str(entry.get("taxyear", "")).lower() != taxyear.lower()
            or (
                not is_target_evidence_source
            )
        ):
            continue
        source = "OLTPRO" if is_oltpro_source else entry_folder
        for pdf_name in _original_pdf_refs_in_file(staged_path):
            _add_original_pdf_reference(
                staged_references, pdf_name, "Common", source
            )
    return staged_references


def is_original_pdf_used(taxyear: str, pdf_name: str) -> bool:
    referenced = _collect_original_pdf_references(taxyear)
    return Path(pdf_name).name.lower() in referenced


def original_pdf_state(pdf_name: str) -> str:
    """Use a leading state abbreviation for Original PDFs; default to FED."""
    name = Path(pdf_name).name
    prefix = name[:2].upper()
    if prefix in STATES:
        return prefix
    return "FED"

# WFI scanner rules updated: Common/oltproc GET-by-navigation before POST-by-name.
WFI_STATE_FOLDERS = {"Federal", *STATES}
WFI_STANDARD_SUBFOLDERS = {"csr_tax_links", "html", "oltproc", "page_info"}
WFI_COMMON_SUBFOLDERS = {"html", "oltproc", "images"}
WFI_COMMON_FILENAME_SUFFIXES = (
    "_tree_array.php",
    "_load_file.php",
    "filedformslist.php",
    "auditsummary.php",
    "_refmtr_val.php",
    "precalculations.php",
    "auditcalculations.php",
    "ImportedFormsIdentification.php",
)
WFI_COMMON_FILENAME_PREFIXES = (
    "oltloadformdescview",
    "OLTFedMtdQuickRef",
)
MAIN_COMMON_FILENAME_PREFIXES = (
    "OrderForm_"
)
# These exact dispatchers have GET navigation evidence. Similarly named state
# and form variants still use the generic Common suffix/prefix rules.
WFI_COMMON_FILENAME_EXCLUSIONS = {
    "oltloadformdescview.php",
    "oltfiledformslist.php",
}
WFI_POST_STEM_SUFFIXES = ("close_return",)


def wfi_root(taxyear: str) -> Path:
    return SITE_ASP_ROOT / str(taxyear) / "wfi"


def read_file_text(path: Path) -> str:
    try:
        return path.read_text(encoding="utf-8", errors="ignore")
    except OSError:
        return ""

def wfi_file_role(path: Path, taxyear: str) -> Tuple[str, str, str]:
    """Return (area, subfolder, relative_name) for a file below <taxyear>/wfi."""
    try:
        parts = path.relative_to(wfi_root(taxyear)).parts
    except ValueError:
        return "", "", path.name
    if len(parts) < 3:
        return "", "", Path(*parts).as_posix() if parts else path.name
    area, subfolder = parts[0], parts[1]
    return area, subfolder, Path(*parts).as_posix()


def wfi_iter_files(base: Path, suffixes: Tuple[str, ...]) -> List[Path]:
    if not base.exists():
        return []
    return [path for path in sorted(base.rglob("*")) if path.is_file() and path.suffix.lower() in suffixes]


# WFI speed-up: read WFI source files once per tax year and reuse them.
_WFI_SOURCE_CACHE: Dict[str, List[Tuple[Path, List[str]]]] = {}
_WFI_SOURCE_MTIME_CACHE: Dict[str, float] = {}

# WFI heavy-folder speed-up:
# Federal/state folders were slow because nextCall/page_info checks rescanned
# the same Federal/html files once for every candidate file.
# These indexes are built once per tax year/area and then reused.
_WFI_NEXTCALL_INDEX_CACHE: Dict[Tuple[str, str], Dict[str, List[Evidence]]] = {}
_WFI_PAGE_INFO_INDEX_CACHE: Dict[Tuple[str, str], Dict[str, List[Evidence]]] = {}

# Cache WFI text lookups to avoid rescanning the same source files for every target.
_WFI_TEXT_LOOKUP_CACHE: Dict[Tuple[str, Tuple[str, ...], str], Tuple[bool, List[Evidence]]] = {}
_WFI_SOURCES_UNDER_CACHE: Dict[Tuple[str, Tuple[str, ...], Tuple[str, ...]], List[Tuple[Path, List[str]]]] = {}
_WFI_COMMON_REFERENCE_DIRS_CACHE: Dict[str, List[Path]] = {}
_WFI_COMMON_OLTPROC_REF_INDEX_CACHE: Dict[str, Dict[str, Dict[str, List[Evidence]]]] = {}
_WFI_INCLUDE_INDEX_CACHE: Dict[str, Dict[str, Dict[str, List[Evidence]]]] = {}
_WFI_LATEST_MTIME_CACHE: Dict[str, float] = {}
WFI_DISK_CACHE_VERSION = 5
WFI_NEXTCALL_RE = re.compile(
    r"(?<![A-Za-z0-9_])\$?(?:"
    r"nextcall[A-Za-z0-9_]*|"
    r"[A-Za-z_][A-Za-z0-9_]*nextcall[A-Za-z0-9_]*"
    r")\s*=\s*['\"]?([A-Za-z0-9_.-]+)",
    re.IGNORECASE,
)
WFI_LOADING_HTML_RE = re.compile(
    r"(?<![A-Za-z0-9_])\$?LoadingHtml\s*=\s*['\"]?([A-Za-z0-9_.-]+)",
    re.IGNORECASE,
)
WFI_INCLUDE_RE = re.compile(
    r"\b(?:include|include_once|require|require_once)\s*(?:\(\s*)?['\"]([^'\"]+\.(?:php|html))['\"]",
    re.IGNORECASE,
)


def wfi_flow_target_stems(line: str) -> Set[str]:
    """Return extensionless WFI nextCall/LoadingHtml target names from a line."""
    return {
        Path(match.group(1)).stem.lower()
        for pattern in (WFI_NEXTCALL_RE, WFI_LOADING_HTML_RE)
        for match in pattern.finditer(line)
        if match.group(1)
    }


def clear_wfi_cache(taxyear: Optional[str] = None) -> None:
    if taxyear is None:
        _WFI_SOURCE_CACHE.clear()
        _WFI_SOURCE_MTIME_CACHE.clear()
        _WFI_NEXTCALL_INDEX_CACHE.clear()
        _WFI_PAGE_INFO_INDEX_CACHE.clear()
        _WFI_TEXT_LOOKUP_CACHE.clear()
        _WFI_SOURCES_UNDER_CACHE.clear()
        _WFI_COMMON_REFERENCE_DIRS_CACHE.clear()
        _WFI_COMMON_OLTPROC_REF_INDEX_CACHE.clear()
        _WFI_INCLUDE_INDEX_CACHE.clear()
        _WFI_LATEST_MTIME_CACHE.clear()
        cache_root = PHPDATA_ROOT / "wfi_reference_cache"
        if cache_root.exists():
            shutil.rmtree(cache_root, ignore_errors=True)
        return
    key = str(taxyear)
    _WFI_SOURCE_CACHE.pop(key, None)
    _WFI_SOURCE_MTIME_CACHE.pop(key, None)
    _WFI_COMMON_REFERENCE_DIRS_CACHE.pop(key, None)
    _WFI_COMMON_OLTPROC_REF_INDEX_CACHE.pop(key, None)
    _WFI_INCLUDE_INDEX_CACHE.pop(key, None)
    _WFI_LATEST_MTIME_CACHE.pop(str(wfi_root(key)), None)
    cache_root = wfi_disk_cache_root(key)
    if cache_root.exists():
        shutil.rmtree(cache_root, ignore_errors=True)
    for k in list(_WFI_TEXT_LOOKUP_CACHE):
        if k[0]==key:
            _WFI_TEXT_LOOKUP_CACHE.pop(k,None)
    for k in list(_WFI_SOURCES_UNDER_CACHE):
        if k[0] == key:
            _WFI_SOURCES_UNDER_CACHE.pop(k, None)
    for cache in (_WFI_NEXTCALL_INDEX_CACHE, _WFI_PAGE_INFO_INDEX_CACHE):
        for k in list(cache):
            if k[0] == key:
                cache.pop(k, None)


def _wfi_latest_mtime(base: Path) -> float:
    cache_key = str(base)
    cached = _WFI_LATEST_MTIME_CACHE.get(cache_key)
    if cached is not None:
        return cached
    if not base.exists():
        return 0.0
    latest = 0.0
    for source in base.rglob("*"):
        if source.is_file() and source.suffix.lower() in (".html", ".php", ".js"):
            try:
                latest = max(latest, source.stat().st_mtime)
            except OSError:
                continue
    _WFI_LATEST_MTIME_CACHE[cache_key] = latest
    return latest


def wfi_disk_cache_root(taxyear: str) -> Path:
    return PHPDATA_ROOT / "wfi_reference_cache" / str(taxyear)


def wfi_disk_cache_file(taxyear: str, cache_name: str) -> Path:
    digest = hashlib.md5(cache_name.encode("utf-8")).hexdigest()
    return wfi_disk_cache_root(taxyear) / f"{digest}.json"


def serialize_evidence_map(index: Dict[str, List[Evidence]]) -> Dict:
    return {
        key: [serialize_evidence(item) for item in evidences]
        for key, evidences in index.items()
    }


def deserialize_evidence_map(data: Dict) -> Dict[str, List[Evidence]]:
    return {
        str(key): [deserialize_evidence(item) for item in evidences or []]
        for key, evidences in (data or {}).items()
    }


def serialize_nested_evidence_map(index: Dict[str, Dict[str, List[Evidence]]]) -> Dict:
    return {
        method: serialize_evidence_map(targets)
        for method, targets in index.items()
    }


def deserialize_nested_evidence_map(data: Dict) -> Dict[str, Dict[str, List[Evidence]]]:
    return {
        str(method): deserialize_evidence_map(targets)
        for method, targets in (data or {}).items()
    }


def load_wfi_disk_cache(taxyear: str, cache_name: str, nested: bool = False) -> Optional[Dict]:
    path = wfi_disk_cache_file(taxyear, cache_name)
    if not path.exists():
        return None
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return None
    if data.get("version") != WFI_DISK_CACHE_VERSION:
        return None
    if data.get("wfi_mtime") != _wfi_latest_mtime(wfi_root(taxyear)):
        return None
    payload = data.get("payload", {})
    return deserialize_nested_evidence_map(payload) if nested else deserialize_evidence_map(payload)


def save_wfi_disk_cache(taxyear: str, cache_name: str, index: Dict, nested: bool = False) -> None:
    path = wfi_disk_cache_file(taxyear, cache_name)
    payload = serialize_nested_evidence_map(index) if nested else serialize_evidence_map(index)
    data = {
        "version": WFI_DISK_CACHE_VERSION,
        "scanner_mtime": scanner_cache_token(),
        "wfi_mtime": _wfi_latest_mtime(wfi_root(taxyear)),
        "payload": payload,
    }
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(data, separators=(",", ":")), encoding="utf-8")
    except OSError:
        return


def wfi_source_index(taxyear: str) -> List[Tuple[Path, List[str]]]:
    taxyear = str(taxyear)
    base = wfi_root(taxyear)
    latest_mtime = _wfi_latest_mtime(base)
    cached = _WFI_SOURCE_CACHE.get(taxyear)
    if cached is not None and _WFI_SOURCE_MTIME_CACHE.get(taxyear) == latest_mtime:
        return cached

    indexed: List[Tuple[Path, List[str]]] = []
    if base.exists():
        for source in sorted(base.rglob("*")):
            if source.is_file() and source.suffix.lower() in (".html", ".php", ".js"):
                indexed.append((source, uncomment_code_lines(cached_file_lines(source))))

    _WFI_SOURCE_CACHE[taxyear] = indexed
    _WFI_SOURCE_MTIME_CACHE[taxyear] = latest_mtime
    return indexed


def wfi_sources_under(taxyear: str, dirs: Sequence[Path], suffixes: Tuple[str, ...] = (".html", ".php", ".js")) -> List[Tuple[Path, List[str]]]:
    roots: List[Path] = []
    for item in dirs:
        if not item.exists():
            continue
        try:
            roots.append(item.resolve())
        except OSError:
            continue
    roots = sorted(set(roots))
    cache_key = (str(taxyear), tuple(str(root) for root in roots), tuple(sorted(suffixes)))
    cached = _WFI_SOURCES_UNDER_CACHE.get(cache_key)
    if cached is not None:
        return cached

    matched: List[Tuple[Path, List[str]]] = []
    seen: Set[Path] = set()
    for root in roots:
        for source in sorted(root.rglob("*")):
            if not source.is_file() or source.suffix.lower() not in suffixes:
                continue
            try:
                source_resolved = source.resolve()
            except OSError:
                continue
            if source_resolved in seen:
                continue
            seen.add(source_resolved)
            matched.append((source, cached_file_lines(source)))
    _WFI_SOURCES_UNDER_CACHE[cache_key] = matched
    return matched


def wfi_common_reference_dirs(base: Path) -> List[Path]:
    """Search common plus Federal/state areas for references into wfi/common."""
    cache_key = str(base)
    cached = _WFI_COMMON_REFERENCE_DIRS_CACHE.get(cache_key)
    if cached is not None:
        return cached

    dirs: List[Path] = []
    for area in ("common", *sorted(WFI_STATE_FOLDERS)):
        area_dir = base / area
        for subfolder in ("oltproc", "html"):
            candidate = area_dir / subfolder
            if candidate.exists():
                dirs.append(candidate)
    _WFI_COMMON_REFERENCE_DIRS_CACHE[cache_key] = dirs
    return dirs


def wfi_include_index(taxyear: str, base: Path) -> Dict[str, Dict[str, List[Evidence]]]:
    """Build once: WFI html/oltproc files referenced by static include/require."""
    taxyear = str(taxyear)
    cached = _WFI_INCLUDE_INDEX_CACHE.get(taxyear)
    if cached is not None:
        return cached
    disk_cache_name = "wfi_html_oltproc_include_index"
    disk_cached = load_wfi_disk_cache(taxyear, disk_cache_name, nested=True)
    if disk_cached is not None:
        _WFI_INCLUDE_INDEX_CACHE[taxyear] = disk_cached
        return disk_cached

    index: Dict[str, Dict[str, List[Evidence]]] = {}
    targets: Dict[str, Tuple[str, str, str]] = {}
    if base.exists():
        for area_dir in sorted(path for path in base.iterdir() if path.is_dir()):
            area = area_dir.name
            if area.lower() not in {"common", "federal"} and area.upper() not in STATES:
                continue
            for subfolder, pattern in (("oltproc", "*.php"), ("html", "*.html")):
                for target in sorted((area_dir / subfolder).glob(pattern)):
                    if not target.is_file():
                        continue
                    targets[str(target.resolve()).lower()] = (
                        area.lower(),
                        target.name.lower(),
                        subfolder,
                    )

    for source, lines in wfi_sources_under(
        taxyear,
        wfi_common_reference_dirs(base),
        (".html", ".php", ".js"),
    ):
        try:
            source_area = source.relative_to(base).parts[0].lower()
        except (ValueError, IndexError):
            source_area = ""
        dynamic_include_templates: Dict[str, List[str]] = {}
        for line_no, line in enumerate(lines, start=1):
            parsed_line = normalize_code_line(line)
            for assignment in PHP_VARIABLE_ASSIGNMENT_RE.finditer(parsed_line):
                variable_name = assignment.group(1).lower()
                expression = assignment.group(2)
                fragments = [
                    literal.group(2)
                    for literal in PHP_STRING_LITERAL_RE.finditer(expression)
                    if literal.group(2)
                ]
                if PHP_VARIABLE_TOKEN_RE.search(expression) and fragments:
                    dynamic_include_templates[variable_name] = fragments
                else:
                    dynamic_include_templates.pop(variable_name, None)

            for match in WFI_INCLUDE_RE.finditer(line):
                raw_target = match.group(1).replace("\\", "/")
                try:
                    resolved_target = str((source.parent / raw_target).resolve()).lower()
                except OSError:
                    continue
                target = targets.get(resolved_target)
                if not target:
                    continue
                area, filename, subfolder = target
                index.setdefault(area, {}).setdefault(filename, []).append(
                    Evidence(
                        source.as_posix(),
                        line_no,
                        "Common",
                        f"wfi {subfolder} include/require",
                        clean_snippet(line),
                    )
                )

            for include_match in VARIABLE_INCLUDE_RE.finditer(parsed_line):
                fragments = dynamic_include_templates.get(
                    include_match.group(1).lower(), []
                )
                if not fragments:
                    continue
                for area, filename, subfolder in set(targets.values()):
                    if area != source_area or not _ordered_filename_fragments_match(
                        filename, fragments
                    ):
                        continue
                    index.setdefault(area, {}).setdefault(filename, []).append(
                        Evidence(
                            source.as_posix(),
                            line_no,
                            "Common",
                            f"wfi {subfolder} dynamic variable include/require",
                            clean_snippet(line),
                        )
                    )

    _WFI_INCLUDE_INDEX_CACHE[taxyear] = index
    save_wfi_disk_cache(taxyear, disk_cache_name, index, nested=True)
    return index


def wfi_area_flow_index(taxyear: str, base: Path, area: str) -> Dict[str, List[Evidence]]:
    """Build once: WFI area flow target stem -> evidence from html/oltproc."""
    taxyear = str(taxyear)
    cache_key = (taxyear, f"{area.lower()}:flow")
    cached = _WFI_NEXTCALL_INDEX_CACHE.get(cache_key)
    if cached is not None:
        return cached
    disk_cache_name = f"area_flow:{area.lower()}"
    disk_cached = load_wfi_disk_cache(taxyear, disk_cache_name)
    if disk_cached is not None:
        _WFI_NEXTCALL_INDEX_CACHE[cache_key] = disk_cached
        return disk_cached

    index: Dict[str, List[Evidence]] = {}
    verify_redirect_pattern = re.compile(
        r"\binclude\s*\(\s*['\"][^'\"]*common/oltproc/olt_verify_redirect\.php['\"]\s*\)",
        re.IGNORECASE,
    )

    for source, lines in wfi_sources_under(taxyear, [base / area / "html", base / area / "oltproc"], (".html", ".php", ".js")):
        pending_loading: List[Tuple[str, int, str]] = []
        for line_no, line in enumerate(lines, start=1):
            for match in WFI_NEXTCALL_RE.finditer(line):
                target = Path(match.group(1)).stem.lower()
                if target:
                    index.setdefault(target, []).append(
                        Evidence(source.as_posix(), line_no, "INPUT", "wfi nextCall", clean_snippet(line))
                    )

            for match in XHR_OPEN_RE.finditer(normalize_code_line(line)):
                method = match.group(2).upper()
                raw = match.group(4)
                target = Path(urlparse(strip_php_fragments(raw).replace("\\", "/")).path).stem.lower()
                if target:
                    index.setdefault(target, []).append(
                        Evidence(
                            source.as_posix(),
                            line_no,
                            method,
                            "wfi XMLHttpRequest open",
                            clean_snippet(line),
                            query_arg_names(raw) | inline_query_arg_names(line),
                        )
                    )

            for action, method, args in extract_form_refs(line):
                target = Path(urlparse(strip_php_fragments(action).replace("\\", "/")).path).stem.lower()
                if target:
                    index.setdefault(target, []).append(
                        Evidence(
                            source.as_posix(),
                            line_no,
                            method,
                            "wfi form action",
                            clean_snippet(line),
                            args,
                        )
                    )

            for match in WFI_LOADING_HTML_RE.finditer(line):
                target = Path(match.group(1)).stem.lower()
                if target:
                    index.setdefault(target, []).append(
                        Evidence(
                            source.as_posix(),
                            line_no,
                            "INPUT",
                            "wfi LoadingHtml",
                            clean_snippet(line),
                        )
                    )
                    pending_loading.append((target, line_no, clean_snippet(line)))

            if verify_redirect_pattern.search(line):
                for target, assign_line, assign_snippet in pending_loading:
                    if line_no - assign_line > 8:
                        continue
                    index.setdefault(target, []).append(
                        Evidence(
                            source.as_posix(),
                            assign_line,
                            "INPUT",
                            "wfi LoadingHtml verify redirect",
                            assign_snippet,
                        )
                    )
                pending_loading = []
            else:
                pending_loading = [
                    item for item in pending_loading
                    if line_no - item[1] <= 8
                ]

    _WFI_NEXTCALL_INDEX_CACHE[cache_key] = index
    save_wfi_disk_cache(taxyear, disk_cache_name, index)
    return index


def wfi_area_flow_found(taxyear: str, base: Path, area: str, stem: str) -> Tuple[bool, List[Evidence]]:
    evidence = wfi_area_flow_index(taxyear, base, area).get(stem.lower(), [])
    return bool(evidence), sorted(
        evidence,
        key=lambda item: METHOD_PRIORITY.index(item.method) if item.method in METHOD_PRIORITY else 99,
    )


def wfi_text_found(taxyear: str, search_dirs: Sequence[Path], needle: str, exclude: Optional[Path] = None) -> Tuple[bool, List[Evidence]]:
    roots=tuple(sorted(str(p.resolve()) for p in search_dirs))
    key=(str(taxyear),roots,needle.lower())
    if exclude is None and key in _WFI_TEXT_LOOKUP_CACHE:
        return _WFI_TEXT_LOOKUP_CACHE[key]

    needle_lower=needle.lower()
    evidence=[]
    exclude_resolved=exclude.resolve() if exclude else None
    for source,lines in wfi_sources_under(taxyear,search_dirs,('.html','.php','.js')):
        if exclude_resolved and source.resolve()==exclude_resolved:
            continue
        for line_no,line in enumerate(lines,1):
            if needle_lower in line.lower():
                evidence.append(Evidence(source.as_posix(),line_no,'POST','wfi common reference',clean_snippet(line)))
    if evidence:
        if exclude is None:
            _WFI_TEXT_LOOKUP_CACHE[key]=(True,evidence)
        return True,evidence
    if exclude is None:
        _WFI_TEXT_LOOKUP_CACHE[key]=(False,[])
    return False,[]


def wfi_common_oltproc_include_found(taxyear: str, search_dirs: Sequence[Path], path: Path) -> Tuple[bool, List[Evidence]]:
    """Classify wfi/common/oltproc files as Common when referenced by include/require."""
    evidence: List[Evidence] = []
    exclude_resolved = path.resolve()
    include_context = re.compile(r"\b(?:include|include_once|require|require_once)\s*\(?", re.IGNORECASE)
    target_name = path.name.lower()

    for source, lines in wfi_sources_under(taxyear, search_dirs, (".html", ".php", ".js")):
        if source.resolve() == exclude_resolved:
            continue
        for line_no, line in enumerate(lines, start=1):
            if target_name in line.lower() and include_context.search(line):
                evidence.append(Evidence(source.as_posix(), line_no, "Common", "wfi common include/require", clean_snippet(line)))
    return bool(evidence), evidence



def wfi_common_oltproc_reference_index(taxyear: str, base: Path) -> Dict[str, Dict[str, List[Evidence]]]:
    """Build once: wfi/common/oltproc filename -> all GET/Common/POST evidence."""
    taxyear = str(taxyear)
    cached = _WFI_COMMON_OLTPROC_REF_INDEX_CACHE.get(taxyear)
    if cached is not None:
        return cached
    disk_cache_name = "common_oltproc_reference_index"
    disk_cached = load_wfi_disk_cache(taxyear, disk_cache_name, nested=True)
    if disk_cached is not None:
        _WFI_COMMON_OLTPROC_REF_INDEX_CACHE[taxyear] = disk_cached
        return disk_cached

    target_dir = base / "common" / "oltproc"
    target_names = {
        path.name.lower()
        for path in target_dir.glob("*.php")
        if path.is_file()
    }
    target_by_stem = {Path(name).stem.lower(): name for name in target_names}
    index: Dict[str, Dict[str, List[Evidence]]] = {
        "GET": {},
        "Common": {},
        "POST": {},
        "Text": {},
    }
    if not target_names:
        _WFI_COMMON_OLTPROC_REF_INDEX_CACHE[taxyear] = index
        save_wfi_disk_cache(taxyear, disk_cache_name, index, nested=True)
        return index

    for source, lines in wfi_sources_under(taxyear, wfi_common_reference_dirs(base), (".html", ".php", ".js")):
        for line_no, line in enumerate(lines, start=1):
            lower_line = line.lower()
            mentioned = set()
            if ".php" in lower_line:
                mentioned.update(
                    match.group("name").lower()
                    for match in FILENAME_RE.finditer(lower_line)
                    if match.group("name").lower() in target_names
                )

            if mentioned:
                method, reason = common_reference_method(line, prefix="wfi common")

                for name in mentioned:
                    index[method].setdefault(name, []).append(
                        Evidence(source.as_posix(), line_no, method, reason, clean_snippet(line))
                    )

            for stem in wfi_flow_target_stems(line):
                target_name = target_by_stem.get(stem)
                if not target_name:
                    continue
                index["POST"].setdefault(target_name, []).append(
                    Evidence(
                        source.as_posix(),
                        line_no,
                        "POST",
                        "wfi common flow target",
                        clean_snippet(line),
                    )
                )

    _WFI_COMMON_OLTPROC_REF_INDEX_CACHE[taxyear] = index
    save_wfi_disk_cache(taxyear, disk_cache_name, index, nested=True)
    return index


def wfi_common_oltproc_get_found(taxyear: str, search_dirs: Sequence[Path], path: Path) -> Tuple[bool, List[Evidence]]:
    """
    wfi/Common/oltproc GET rule.
    For a file like wfi/Common/oltproc/abcd.php, mark GET when another
    Common html/oltproc file calls it through iframe, frame location,
    header(Location:), href, window.open/open, or direct location assignment.
    The current abcd.php file is excluded from the search.
    """
    names = {path.stem.lower(), path.name.lower()}
    evidence: List[Evidence] = []
    exclude_resolved = path.resolve()
    for source, lines in wfi_sources_under(taxyear, search_dirs, (".html", ".php", ".js")):
        if source.resolve() == exclude_resolved:
            continue
        for line_no, line in enumerate(lines, start=1):
            lower_line = line.lower()
            has_target = any(name in lower_line for name in names)
            method, _reason = common_reference_method(line, prefix="wfi common")
            if has_target and method == "GET":
                evidence.append(Evidence(source.as_posix(), line_no, "GET", "wfi common GET reference", clean_snippet(line)))
    return bool(evidence), evidence


def wfi_page_info_index(taxyear: str, wfi_base: Path, area: str) -> Dict[str, List[Evidence]]:
    """Build once: page_info filename -> evidence for one WFI area."""
    taxyear = str(taxyear)
    area_key = area.lower()
    cache_key = (taxyear, area_key)
    cached = _WFI_PAGE_INFO_INDEX_CACHE.get(cache_key)
    if cached is not None:
        return cached
    disk_cache_name = f"page_info:{area_key}"
    disk_cached = load_wfi_disk_cache(taxyear, disk_cache_name)
    if disk_cached is not None:
        _WFI_PAGE_INFO_INDEX_CACHE[cache_key] = disk_cached
        return disk_cached

    html_dir = wfi_base / area / "html"
    index: Dict[str, List[Evidence]] = {}
    page_info_re = re.compile(
        r"page_info/([A-Za-z0-9_.-]+\.(?:php|html))",
        re.IGNORECASE,
    )

    for source, lines in wfi_sources_under(taxyear, [html_dir], (".html", ".php", ".js")):
        for line_no, line in enumerate(lines, start=1):
            for match in page_info_re.finditer(line):
                target = match.group(1).lower()
                if target in index:
                    continue
                index[target] = [
                    Evidence(
                        source.as_posix(),
                        line_no,
                        "PAGEINFO",
                        "wfi page_info include",
                        clean_snippet(line),
                    )
                ]

    _WFI_PAGE_INFO_INDEX_CACHE[cache_key] = index
    save_wfi_disk_cache(taxyear, disk_cache_name, index)
    return index


def wfi_page_info_included(taxyear: str, wfi_base: Path, area: str, page_info_name: str) -> Tuple[bool, List[Evidence]]:
    evidence = wfi_page_info_index(taxyear, wfi_base, area).get(page_info_name.lower(), [])
    return bool(evidence), evidence[:1]

def wfi_common_filename_method(taxyear: str, path: Path) -> str:
    """Return a deterministic WFI filename method for tax years 2015-2025."""
    if not _is_standard_taxyear(taxyear):
        return ""
    filename = path.name.lower()
    if path.stem.lower().endswith(WFI_POST_STEM_SUFFIXES):
        return "POST"
    if filename in WFI_COMMON_FILENAME_EXCLUSIONS:
        return ""
    if filename.endswith(tuple(suffix.lower() for suffix in WFI_COMMON_FILENAME_SUFFIXES)):
        return "Common"
    if filename.startswith(
        tuple(prefix.lower() for prefix in WFI_COMMON_FILENAME_PREFIXES)
    ):
        return "Common"
    return ""

def wfi_state_1040es_method(
    taxyear: str,
    area: str,
    subfolder: str,
    path: Path,
) -> str:
    """Return the fixed state-only WFI method for files ending in 1040ES."""
    if not _is_standard_taxyear(taxyear) or area.upper() not in STATES:
        return ""
    if not path.stem.lower().endswith("1040es"):
        return ""
    if subfolder.lower() == "html" and path.suffix.lower() == ".html":
        return "INPUT"
    if subfolder.lower() == "oltproc" and path.suffix.lower() == ".php":
        return "POST"
    return ""

def wfi_method_for_path(taxyear: str, path: Path) -> Tuple[str, List[Evidence]]:
    base = wfi_root(taxyear)
    area, subfolder, _relative_name = wfi_file_role(path, taxyear)
    subfolder = subfolder.lower()
    if not area or not subfolder:
        return "ANALYSE", []

    state_1040es_method = wfi_state_1040es_method(
        taxyear, area, subfolder, path
    )
    if state_1040es_method:
        return state_1040es_method, []

    filename_method = wfi_common_filename_method(taxyear, path)
    if filename_method:
        return filename_method, []

    if area.lower() == "common":
        if subfolder == "images":
            return "GET", []
        if subfolder == "html" and path.suffix.lower() == ".html":
            include_evidence = (
                wfi_include_index(taxyear, base)
                .get(area.lower(), {})
                .get(path.name.lower(), [])
            )
            if include_evidence:
                return "Common", include_evidence
            found, evidence = wfi_text_found(taxyear, wfi_common_reference_dirs(base), path.stem)
            return ("INPUT" if found else "ANALYSE"), evidence
        if subfolder == "oltproc" and path.suffix.lower() == ".php":
            ref_index = wfi_common_oltproc_reference_index(taxyear, base)
            target_name = path.name.lower()
            get_evidence = ref_index["GET"].get(target_name, [])
            if get_evidence:
                return "GET", get_evidence
            post_evidence = ref_index["POST"].get(target_name, [])
            if post_evidence:
                return "POST", post_evidence
            include_evidence = ref_index["Common"].get(target_name, [])
            if include_evidence:
                return "Common", include_evidence
            text_evidence = ref_index["Text"].get(target_name, [])
            if text_evidence:
                return "POST", text_evidence
            return "ANALYSE", []
        return "ANALYSE", []

    if area in WFI_STATE_FOLDERS:
        if subfolder == "csr_tax_links":
            return "HELP", []
        if subfolder == "html" and path.suffix.lower() == ".html":
            include_evidence = (
                wfi_include_index(taxyear, base)
                .get(area.lower(), {})
                .get(path.name.lower(), [])
            )
            if include_evidence:
                return "Common", include_evidence
            found, evidence = wfi_area_flow_found(taxyear, base, area, path.stem)
            return ("INPUT" if found else "ANALYSE"), evidence
        if subfolder == "oltproc" and path.suffix.lower() == ".php":
            found, evidence = wfi_area_flow_found(taxyear, base, area, path.stem)
            if found:
                if any(item.method == "GET" for item in evidence):
                    return "GET", evidence
                for item in evidence:
                    item.method = "POST"
                return "POST", evidence
            include_evidence = (
                wfi_include_index(taxyear, base)
                .get(area.lower(), {})
                .get(path.name.lower(), [])
            )
            if include_evidence:
                return "Common", include_evidence
            return "ANALYSE", evidence
        if subfolder == "page_info":
            found, evidence = wfi_page_info_included(taxyear, base, area, path.name)
            return ("PAGEINFO" if found else "DEAD"), evidence
        return "ANALYSE", []

    return "ANALYSE", []


# Staffolt scanner rules updated: recurse subfolders and classify css/js/images/inc.
# Staffolt href GET fix: href/src/location/header references are never plain POST.
# Staffolt reference-search scope:
# Only these files are searched as callers/sources:
#   1) Staffolt/*.html
#   2) Staffolt/*.php
#   3) Staffolt/inc/*.php
# css/js/images remain target files to classify, but they are not scanned as source files.
STAFFOLT_TEXT_SUFFIXES = (".html", ".php")
STAFFOLT_IMAGE_SUFFIXES = (".png", ".jpg", ".jpeg", ".gif", ".svg", ".ico", ".webp")
STAFFOLT_BASE_LOADING_HTML_RE = re.compile(
    r"\$BASELoadingHTML\s*=\s*([\"'])([A-Za-z0-9_.-]+)\1\s*;",
    re.IGNORECASE,
)
STAFFOLT_BASE_LOADING_HTML_VALUE_RE = re.compile(
    r"(?<![$A-Za-z0-9_])BASELoadingHTML\s*=\s*([A-Za-z0-9_.-]+)",
    re.IGNORECASE,
)
PHP_STRING_LITERAL_RE = re.compile(r"([\"'])(.*?)\1")


def staffolt_root(taxyear: str) -> Path:
    return SITE_ASP_ROOT / str(taxyear) / "Staffolt"


def staffolt_role(path: Path, taxyear: str) -> Tuple[str, str]:
    """Return (subfolder, relative_name) for a file below <taxyear>/Staffolt."""
    try:
        parts = path.relative_to(staffolt_root(taxyear)).parts
    except ValueError:
        return "", path.name
    if not parts:
        return "", path.name
    if len(parts) == 1:
        return "", parts[0]
    return parts[0].lower(), Path(*parts).as_posix()


def staffolt_common_filename_method(taxyear: str, path: Path) -> str:
    """Return Common for deterministic filenames in numeric-year Staffolt."""
    if not str(taxyear).isdigit():
        return ""
    filename = path.name.lower()
    if filename.startswith("zqc") and filename.endswith("verify.php"):
        return "Common"
    if filename.startswith("copy_data_"):
        return "Common"
    return ""


def staffolt_iter_files(base: Path, suffixes: Tuple[str, ...]) -> List[Path]:
    if not base.exists():
        return []
    return [path for path in sorted(base.rglob("*")) if path.is_file() and path.suffix.lower() in suffixes]


# Staffolt rules updated: inc/*nav.php is Common; GET/POST flow wins before include/require.
# Staffolt speed-up: read only Staffolt/*.html, Staffolt/*.php, and Staffolt/inc/*.php once per tax year and reuse them.
# Without this limited cache, every Staffolt candidate scans too many Staffolt files again.
_STAFFOLT_SOURCE_CACHE: Dict[str, List[Tuple[Path, str, List[Tuple[int, str, str]]]]] = {}
_STAFFOLT_FAST_REF_CACHE: Dict[str, Dict[str, Dict[str, List[Evidence]]]] = {}
_STAFFOLT_BASE_FLOW_CACHE: Dict[str, Dict[str, List[Evidence]]] = {}
_STAFFOLT_DYNAMIC_INCLUDE_CACHE: Dict[str, Dict[str, List[Evidence]]] = {}
STAFFOLT_ANY_FILE_RE = re.compile(r"(?P<name>[A-Za-z0-9_.-]+\.(?:php|html?|js|css|ico|png|jpe?g|svg|gif))", re.IGNORECASE)


def staffolt_literal_include_name_counts(line: str) -> Counter:
    """Return literal include/require target basenames found on one line."""
    includes = list(INCLUDE_RE.findall(line))
    includes.extend(CONCAT_INCLUDE_RE.findall(line))
    return Counter(
        Path(raw.replace("\\", "/")).name.lower()
        for raw in includes
    )


def _staffolt_source_files_fast(taxyear: str) -> List[Path]:
    """Return the only caller/source files used for Staffolt classification.

    Scope is intentionally limited to <taxyear>/Staffolt (recursive) and
    <taxyear>/html (direct files), matching the Staffolt flow rules.
    """
    year_root = SITE_ASP_ROOT / str(taxyear)
    files: List[Path] = []
    staffolt = year_root / "Staffolt"
    if staffolt.exists():
        files.extend(
            path for path in staffolt.rglob("*")
            if path.is_file() and path.suffix.lower() in (".php", ".html", ".js")
        )
    html = source_folder_path(str(taxyear), "html")
    if html.exists():
        files.extend(
            path for path in html.iterdir()
            if path.is_file() and path.suffix.lower() in (".php", ".html", ".js", ".htm")
        )
    return sorted(dict.fromkeys(files))


def staffolt_fast_reference_index(taxyear: str) -> Dict[str, Dict[str, List[Evidence]]]:
    """Build Staffolt literal reference evidence once, then reuse per target.

    This replaces the old files x files search during a full Staffolt build.
    """
    key = str(taxyear)
    cached = _STAFFOLT_FAST_REF_CACHE.get(key)
    if cached is not None:
        return cached

    index: Dict[str, Dict[str, List[Evidence]]] = {
        "GET": defaultdict(list),
        "POST": defaultdict(list),
        "Common": defaultdict(list),
        "Text": defaultdict(list),
    }
    base_flow: Dict[str, List[Evidence]] = defaultdict(list)

    for source in _staffolt_source_files_fast(key):
        try:
            lines = uncomment_code_lines(read_file_text(source).splitlines())
        except OSError:
            continue
        pending_ajax_method = ""
        pending_ajax_ttl = 0
        for line_no, line in enumerate(lines, start=1):
            parsed = normalize_code_line(line)
            lower = parsed.lower()

            # Pre-index BASELoadingHTML assignments by target stem.
            assigned_values = [m.group(2) for m in STAFFOLT_BASE_LOADING_HTML_RE.finditer(parsed)]
            assigned_values.extend(m.group(1) for m in STAFFOLT_BASE_LOADING_HTML_VALUE_RE.finditer(parsed))
            for value in assigned_values:
                stem = Path(value).stem.lower()
                if stem:
                    base_flow[stem].append(Evidence(source.as_posix(), line_no, "FLOW", "Staffolt BASELoadingHTML", clean_snippet(line)))

            if JQUERY_AJAX_START_RE.search(parsed):
                pending_ajax_method = ""
                pending_ajax_ttl = 20
            if pending_ajax_ttl > 0:
                mm = JQUERY_AJAX_TYPE_RE.search(parsed)
                if mm:
                    pending_ajax_method = mm.group(2).upper()
                pending_ajax_ttl -= 1

            names = {m.group("name").lower() for m in STAFFOLT_ANY_FILE_RE.finditer(parsed)}
            if not names:
                continue

            # Staffolt precedence is based on the actual use of the target on
            # this line, not merely on the presence of a filename.  Explicit
            # include/require is Common.  Browser/navigation references are GET
            # even when PHP echo fragments appear inside the query string or the
            # href contains javascript:MM_openBrWindow(...).  Only an explicit
            # POST context may classify the target as POST.
            context = strip_php_fragments(parsed)
            included_name_counts = staffolt_literal_include_name_counts(parsed)
            include_line = bool(included_name_counts)
            get_line = bool(
                COMMON_GET_CONTEXT_RE.search(context)
                or has_common_query_url(parsed)
                or BR_WINDOW_RE.search(parsed)
                or JS_NAV_RE.search(parsed)
                or BUILD_SECURE_URL_RE.search(parsed)
            )
            post_line = bool(COMMON_POST_CONTEXT_RE.search(parsed))

            for name in names:
                # A legacy line can build a GET link for one target and include
                # a different target afterward. Classify each filename by its
                # own occurrence instead of applying include/require to every
                # filename found on the physical line. A second occurrence of
                # the same filename outside include(...) is flow evidence too.
                include_occurrences = included_name_counts.get(name, 0)
                has_non_include_occurrence = lower.count(name) > include_occurrences
                if get_line and has_non_include_occurrence:
                    method, reason = "GET", "staffolt GET reference"
                elif (post_line or pending_ajax_method == "POST") and has_non_include_occurrence:
                    method, reason = (
                        ("POST", "staffolt jQuery ajax")
                        if pending_ajax_method == "POST" and not post_line
                        else ("POST", "staffolt POST reference")
                    )
                elif include_line and include_occurrences:
                    method, reason = "Common", "staffolt include/require"
                else:
                    method, reason = "Text", "staffolt plain PHP reference"

                ev = Evidence(
                    source.as_posix(),
                    line_no,
                    method if method != "Text" else "POST",
                    reason,
                    clean_snippet(line),
                    inline_query_arg_names(parsed) if method == "GET" else set(),
                )
                index[method][name].append(ev)

    _STAFFOLT_FAST_REF_CACHE[key] = index
    _STAFFOLT_BASE_FLOW_CACHE[key] = dict(base_flow)
    return index


def clear_staffolt_cache(taxyear: Optional[str] = None) -> None:
    """Discard cached Staffolt caller/source text so rebuilds see changed links."""
    if taxyear is None:
        _STAFFOLT_SOURCE_CACHE.clear()
        _STAFFOLT_FAST_REF_CACHE.clear()
        _STAFFOLT_BASE_FLOW_CACHE.clear()
        _STAFFOLT_DYNAMIC_INCLUDE_CACHE.clear()
        return
    key = str(taxyear)
    _STAFFOLT_SOURCE_CACHE.pop(key, None)
    _STAFFOLT_FAST_REF_CACHE.pop(key, None)
    _STAFFOLT_BASE_FLOW_CACHE.pop(key, None)
    _STAFFOLT_DYNAMIC_INCLUDE_CACHE.pop(key, None)


def staffolt_reference_source_files(taxyear: str) -> List[Path]:
    """Return Staffolt caller sources: Staffolt recursively + html direct only."""
    return _staffolt_source_files_fast(str(taxyear))


def staffolt_target_source_index(
    taxyear: str,
    path: Path,
) -> List[Tuple[Path, str, List[Tuple[int, str, str]]]]:
    """Build a tiny recursive Staffolt source index for one target file.

    Prefer ripgrep when available so a one-file rebuild only opens files that
    actually mention the target basename. Fall back to a recursive Python scan.
    """
    year_root = SITE_ASP_ROOT / str(taxyear)
    source_roots = [year_root / "Staffolt", source_folder_path(str(taxyear), "html")]
    source_roots = [root for root in source_roots if root.exists()]
    if not source_roots:
        return []

    target_name = path.name.lower()
    target_stem = path.stem.lower()
    candidates: Optional[List[Path]] = None

    rg = shutil.which("rg")
    if rg:
        try:
            found: List[Path] = []
            for root in source_roots:
                search = subprocess.run(
                    [rg, "-l", "-i", "-F", target_name, str(root)],
                    capture_output=True,
                    text=True,
                    check=False,
                )
                if search.returncode in (0, 1):
                    found.extend(
                        Path(line.strip())
                        for line in search.stdout.splitlines()
                        if line.strip()
                        and Path(line.strip()).suffix.lower() in (".php", ".html", ".htm", ".js")
                    )
            candidates = sorted(dict.fromkeys(found))
        except OSError:
            candidates = None

    if candidates is None:
        candidates = []
        for root in source_roots:
            for source in root.rglob("*"):
                if not source.is_file() or source.suffix.lower() not in (".php", ".html", ".htm", ".js"):
                    continue
                try:
                    text = read_file_text(source)
                except OSError:
                    continue
                if target_name in text.lower():
                    candidates.append(source)

    # Some legacy Staffolt references omit .php/.html. Only broaden to the stem
    # when no exact basename reference exists.
    if not candidates and target_stem:
        for root in source_roots:
            for source in root.rglob("*"):
                if not source.is_file() or source.suffix.lower() not in (".php", ".html", ".htm", ".js"):
                    continue
                try:
                    text = read_file_text(source)
                except OSError:
                    continue
                if target_stem in text.lower():
                    candidates.append(source)

    index: List[Tuple[Path, str, List[Tuple[int, str, str]]]] = []
    for source in sorted(dict.fromkeys(candidates)):
        source_lines = uncomment_code_lines(read_file_text(source).splitlines())
        lower_text = "\n".join(source_lines).lower()
        lines = [(line_no, line, line.lower()) for line_no, line in enumerate(source_lines, start=1)]
        index.append((source, lower_text, lines))
    return index


def staffolt_source_index(taxyear: str) -> List[Tuple[Path, str, List[Tuple[int, str, str]]]]:
    taxyear = str(taxyear)
    if taxyear in _STAFFOLT_SOURCE_CACHE:
        return _STAFFOLT_SOURCE_CACHE[taxyear]

    index: List[Tuple[Path, str, List[Tuple[int, str, str]]]] = []
    for source in staffolt_reference_source_files(taxyear):
        source_lines = uncomment_code_lines(read_file_text(source).splitlines())
        lower_text = "\n".join(source_lines).lower()
        lines = [(line_no, line, line.lower()) for line_no, line in enumerate(source_lines, start=1)]
        index.append((source, lower_text, lines))

    _STAFFOLT_SOURCE_CACHE[taxyear] = index
    return index


def staffolt_reference_names(path: Path) -> Set[str]:
    names = {path.name.lower()}
    if path.suffix.lower() in (".php", ".html"):
        names.add(path.stem.lower())
    return names


def staffolt_find_reference(
    taxyear: str,
    path: Path,
    method: str,
    reason: str,
    context_re: Optional[re.Pattern] = None,
    exclude_self: bool = True,
    targeted: bool = False,
) -> Tuple[bool, List[Evidence]]:
    names = staffolt_reference_names(path)
    evidence: List[Evidence] = []
    exclude_resolved = path.resolve() if exclude_self else None

    source_index = (
        staffolt_target_source_index(taxyear, path)
        if targeted
        else staffolt_source_index(taxyear)
    )
    for source, lower_text, lines in source_index:
        if exclude_resolved and source.resolve() == exclude_resolved:
            continue

        # Fast file-level check before scanning line by line.
        if not any(name in lower_text for name in names):
            continue

        for line_no, line, lower_line in lines:
            if not any(name in lower_line for name in names):
                continue
            if context_re is not None and not context_re.search(line):
                continue

            # Mixed legacy statements may contain a navigation URL for one
            # file and include a different file on the same line. Keep the
            # requested target tied to its own occurrence for targeted scans.
            included_name_counts = staffolt_literal_include_name_counts(line)
            target_name = path.name.lower()
            include_occurrences = included_name_counts.get(target_name, 0)
            target_occurrences = lower_line.count(target_name)
            if method in {"GET", "POST"} and target_occurrences <= include_occurrences:
                continue
            if method == "Common" and not include_occurrences:
                continue

            evidence.append(Evidence(source.as_posix(), line_no, method, reason, clean_snippet(line)))
            return True, evidence
    return False, evidence


def staffolt_base_loading_html_found(
    taxyear: str,
    path: Path,
) -> Tuple[bool, List[Evidence]]:
    """O(1) BASELoadingHTML lookup using the prebuilt Staffolt flow index."""
    if not _is_standard_taxyear(taxyear) or path.suffix.lower() not in {".html", ".php"}:
        return False, []
    staffolt_fast_reference_index(str(taxyear))
    evidence = list(_STAFFOLT_BASE_FLOW_CACHE.get(str(taxyear), {}).get(path.stem.lower(), []))
    if not evidence:
        return False, []
    method = "INPUT" if path.suffix.lower() == ".html" else "POST"
    reason = "Staffolt BASELoadingHTML input" if method == "INPUT" else "Staffolt BASELoadingHTML POST"
    first = evidence[0]
    return True, [Evidence(first.source_file, first.source_line, method, reason, first.snippet)]


def _ordered_filename_fragments_match(filename: str, fragments: Sequence[str]) -> bool:
    """Return True when every nonempty literal fragment occurs in filename order."""
    offset = 0
    filename = filename.lower()
    for fragment in fragments:
        fragment = fragment.lower()
        if not fragment:
            continue
        position = filename.find(fragment, offset)
        if position < 0:
            return False
        offset = position + len(fragment)
    return offset > 0


def _staffolt_dynamic_include_index(taxyear: str) -> Dict[str, List[Evidence]]:
    """Build dynamic variable include evidence once for the whole Staffolt tree."""
    key = str(taxyear)
    cached = _STAFFOLT_DYNAMIC_INCLUDE_CACHE.get(key)
    if cached is not None:
        return cached

    patterns: List[Tuple[List[str], Evidence]] = []
    for source in _staffolt_source_files_fast(key):
        try:
            lines = uncomment_code_lines(read_file_text(source).splitlines())
        except OSError:
            continue
        assignments: Dict[str, Tuple[List[str], int, str]] = {}
        for line_no, line in enumerate(lines, start=1):
            parsed_line = normalize_code_line(line)
            for assignment in PHP_VARIABLE_ASSIGNMENT_RE.finditer(parsed_line):
                variable_name = assignment.group(1).lower()
                expression = assignment.group(2)
                fragments = [
                    match.group(2)
                    for match in PHP_STRING_LITERAL_RE.finditer(expression)
                    if match.group(2)
                ]
                if PHP_VARIABLE_TOKEN_RE.search(expression) and fragments:
                    assignments[variable_name] = (fragments, line_no, line)
                else:
                    assignments.pop(variable_name, None)

            for include_match in VARIABLE_INCLUDE_RE.finditer(parsed_line):
                assigned = assignments.get(include_match.group(1).lower())
                if not assigned:
                    continue
                fragments, _assign_line_no, assign_line = assigned
                patterns.append((
                    fragments,
                    Evidence(
                        source.as_posix(), line_no, "Common",
                        "staffolt dynamic variable include/require",
                        clean_snippet(f"{assign_line} {line}"),
                    ),
                ))

    result: Dict[str, List[Evidence]] = defaultdict(list)
    if patterns:
        base = staffolt_root(key)
        targets = [
            path for path in base.rglob("*.php") if path.is_file()
        ] if base.exists() else []
        for target in targets:
            name = target.name.lower()
            for fragments, evidence in patterns:
                if _ordered_filename_fragments_match(name, fragments):
                    result[name].append(evidence)
                    break

    final = dict(result)
    _STAFFOLT_DYNAMIC_INCLUDE_CACHE[key] = final
    return final


def staffolt_dynamic_variable_include_found(
    taxyear: str,
    path: Path,
) -> Tuple[bool, List[Evidence]]:
    """O(1) dynamic include lookup backed by a build-once reverse index."""
    if not _is_standard_taxyear(taxyear) or path.suffix.lower() != ".php":
        return False, []
    evidence = list(_staffolt_dynamic_include_index(str(taxyear)).get(path.name.lower(), []))
    return bool(evidence), evidence


def staffolt_find_plain_post_reference(taxyear: str, path: Path) -> Tuple[bool, List[Evidence]]:
    """Find a plain Staffolt PHP reference that is safe to classify as POST.

    Important: do NOT turn href/src/iframe/location/header/window.open
    references into POST. Those are navigation/link contexts and must stay GET.
    A small previous/current/next line window is checked so split anchor tags like
    <A ...
       HREF="file.php">
    are also protected from the plain POST fallback.
    """
    names = staffolt_reference_names(path)
    evidence: List[Evidence] = []
    exclude_resolved = path.resolve()

    for source, lower_text, lines in staffolt_source_index(taxyear):
        if source.resolve() == exclude_resolved:
            continue
        if not any(name in lower_text for name in names):
            continue

        for idx, (line_no, line, lower_line) in enumerate(lines):
            if not any(name in lower_line for name in names):
                continue

            prev_line = lines[idx - 1][1] if idx > 0 else ""
            next_line = lines[idx + 1][1] if idx + 1 < len(lines) else ""
            context = " ".join([prev_line, line, next_line])

            if STAFFOLT_GET_CONTEXT_RE.search(context):
                continue

            evidence.append(Evidence(source.as_posix(), line_no, "POST", "staffolt plain PHP reference", clean_snippet(line)))
            return True, evidence

    return False, evidence


def staffolt_find_ajax_reference(taxyear: str, path: Path) -> Tuple[bool, List[Evidence]]:
    names = staffolt_reference_names(path)
    evidence: List[Evidence] = []
    exclude_resolved = path.resolve()

    for source, lower_text, lines in staffolt_source_index(taxyear):
        if source.resolve() == exclude_resolved:
            continue
        if not any(name in lower_text for name in names) or "$.ajax" not in lower_text:
            continue

        pending_ajax_method = ""
        pending_ajax_start_line = 0
        pending_ajax_snippet = ""
        pending_ajax_ttl = 0

        for line_no, line, lower_line in lines:
            if JQUERY_AJAX_START_RE.search(line):
                pending_ajax_method = ""
                pending_ajax_start_line = line_no
                pending_ajax_snippet = clean_snippet(line)
                pending_ajax_ttl = 20

            if pending_ajax_ttl > 0:
                method_match = JQUERY_AJAX_TYPE_RE.search(line)
                if method_match:
                    pending_ajax_method = method_match.group(2).upper()

                url_match = JQUERY_AJAX_URL_RE.search(line)
                if url_match and any(name in lower_line for name in names):
                    method = pending_ajax_method or "GET"
                    if method == "POST":
                        evidence.append(
                            Evidence(
                                source.as_posix(),
                                pending_ajax_start_line or line_no,
                                "POST",
                                "staffolt jQuery ajax",
                                pending_ajax_snippet or clean_snippet(line),
                                query_arg_names(url_match.group(2)),
                            )
                        )
                        return True, evidence
                    pending_ajax_ttl = 0

                pending_ajax_ttl -= 1
                if pending_ajax_ttl == 0:
                    pending_ajax_method = ""
                    pending_ajax_start_line = 0
                    pending_ajax_snippet = ""

    return False, evidence


STAFFOLT_GET_CONTEXT_RE = COMMON_GET_CONTEXT_RE
STAFFOLT_POST_CONTEXT_RE = COMMON_POST_CONTEXT_RE
STAFFOLT_INCLUDE_CONTEXT_RE = COMMON_INCLUDE_CONTEXT_RE
STAFFOLT_SCRIPT_SRC_RE = re.compile(r"<script\b[^>]*\bsrc\s*=", re.IGNORECASE)
STAFFOLT_INCLUDE_OR_USE_RE = re.compile(
    r"(?:\binclude(?:_once)?\s*\(|\brequire(?:_once)?\s*\(|"
    r"\bhref\s*=|\bsrc\s*=|\burl\s*[:=]|\bsubmitForm\s*\(|\bopen\s*\(|"
    r"\blocation(?:\.(?:href|assign|replace))?\s*(?:=|\())",
    re.IGNORECASE,
)


def staffolt_include_found(taxyear: str, path: Path) -> Tuple[bool, List[Evidence]]:
    """Find an include/require of an oltproc file in allowed Staffolt sources."""
    dynamic_found, dynamic_evidence = staffolt_dynamic_variable_include_found(
        taxyear, path
    )
    if dynamic_found:
        return True, dynamic_evidence
    return staffolt_find_reference(
        taxyear,
        path,
        "Common",
        "staffolt include/require",
        context_re=STAFFOLT_INCLUDE_CONTEXT_RE,
        exclude_self=False,
    )


def _staffolt_fast_lookup(taxyear: str, path: Path, method: str) -> List[Evidence]:
    index = staffolt_fast_reference_index(str(taxyear))
    bucket = index.get(method, {})
    return list(bucket.get(path.name.lower(), []))


def staffolt_method_for_path(
    taxyear: str,
    path: Path,
    collected_evidence: Optional[Sequence[Evidence]] = None,
    targeted_single_file: bool = False,
) -> Tuple[str, List[Evidence]]:
    subfolder, _relative_name = staffolt_role(path, taxyear)
    suffix = path.suffix.lower()

    filename_method = staffolt_common_filename_method(taxyear, path)
    if filename_method:
        return filename_method, []

    flow_found, flow_evidence = staffolt_base_loading_html_found(taxyear, path)
    if flow_found:
        return flow_evidence[0].method, flow_evidence

    if subfolder == "css" and suffix == ".css":
        if targeted_single_file:
            found, evidence = staffolt_find_reference(taxyear, path, "GET", "staffolt css used", targeted=True)
            return ("GET" if found else "DEAD"), evidence
        evidence = _staffolt_fast_lookup(taxyear, path, "GET")
        return ("GET" if evidence else "DEAD"), evidence

    if subfolder == "js" and suffix == ".js":
        if targeted_single_file:
            found, evidence = staffolt_find_reference(
                taxyear, path, "GET", "staffolt script src",
                context_re=STAFFOLT_SCRIPT_SRC_RE, targeted=True,
            )
            return ("GET" if found else "DEAD"), evidence
        evidence = _staffolt_fast_lookup(taxyear, path, "GET")
        return ("GET" if evidence else "DEAD"), evidence

    if subfolder == "images" and suffix in STAFFOLT_IMAGE_SUFFIXES:
        if targeted_single_file:
            found, evidence = staffolt_find_reference(taxyear, path, "GET", "staffolt image used", targeted=True)
            return ("GET" if found else "DEAD"), evidence
        evidence = _staffolt_fast_lookup(taxyear, path, "GET")
        return ("GET" if evidence else "DEAD"), evidence

    if suffix == ".html":
        if targeted_single_file:
            found, evidence = staffolt_find_reference(
                taxyear, path, "INPUT", "staffolt html include/use",
                context_re=STAFFOLT_INCLUDE_OR_USE_RE, targeted=True,
            )
            return ("INPUT" if found else "ANALYSE"), evidence
        evidence = (
            _staffolt_fast_lookup(taxyear, path, "GET")
            or _staffolt_fast_lookup(taxyear, path, "Common")
        )
        if evidence:
            converted = [Evidence(e.source_file, e.source_line, "INPUT", "staffolt html include/use", e.snippet, set(e.args)) for e in evidence]
            return "INPUT", converted
        return "ANALYSE", []

    if suffix == ".php":
        # Staffolt rule: inc files ending with nav.php are shared/common includes.
        if subfolder == "inc" and path.name.lower().endswith("nav.php"):
            return "Common", []

        flow_evidence = [
            item for item in (collected_evidence or [])
            if item.method in {"GET", "POST"}
        ]
        if flow_evidence:
            return classify_primary(item.method for item in flow_evidence), flow_evidence

        if targeted_single_file:
            get_found, get_evidence = staffolt_find_reference(
                taxyear, path, "GET", "staffolt GET reference",
                context_re=STAFFOLT_GET_CONTEXT_RE, targeted=True,
            )
            if get_found:
                return "GET", get_evidence
            ajax_found, ajax_evidence = staffolt_find_ajax_reference(taxyear, path)
            if ajax_found:
                return "POST", ajax_evidence
            post_found, post_evidence = staffolt_find_reference(
                taxyear, path, "POST", "staffolt POST reference",
                context_re=STAFFOLT_POST_CONTEXT_RE, targeted=True,
            )
            if post_found:
                return "POST", post_evidence

            # Includes are a fallback classification. If this file is both
            # included and reached by an explicit GET/POST flow, the flow is
            # the stronger evidence and must win.
            dynamic_include_found, dynamic_include_evidence = (
                staffolt_dynamic_variable_include_found(taxyear, path)
            )
            if dynamic_include_found:
                return "Common", dynamic_include_evidence
            include_found, include_evidence = staffolt_find_reference(
                taxyear, path, "Common", "staffolt include/require",
                context_re=STAFFOLT_INCLUDE_CONTEXT_RE, targeted=True,
            )
            if include_found:
                return "Common", include_evidence
        else:
            get_evidence = _staffolt_fast_lookup(taxyear, path, "GET")
            if get_evidence:
                return "GET", get_evidence
            post_evidence = _staffolt_fast_lookup(taxyear, path, "POST")
            if post_evidence:
                return "POST", post_evidence
            plain_evidence = _staffolt_fast_lookup(taxyear, path, "Text")
            if plain_evidence:
                return "POST", plain_evidence

            dynamic_include_found, dynamic_include_evidence = (
                staffolt_dynamic_variable_include_found(taxyear, path)
            )
            if dynamic_include_found:
                return "Common", dynamic_include_evidence
            include_evidence = _staffolt_fast_lookup(taxyear, path, "Common")
            if include_evidence:
                return "Common", include_evidence

        return ("DEAD" if subfolder == "inc" else "ANALYSE"), []

    return "ANALYSE", []

# Efile scanner rules updated: direct files only; include/require => Common, otherwise GET.
def efile_root(taxyear: str) -> Path:
    return SITE_ASP_ROOT / str(taxyear) / "efile"


def efile_direct_files(taxyear: str) -> List[Path]:
    return cached_all_direct_files(str(taxyear), "efile")


_EFILE_SOURCE_CACHE: Dict[str, List[Tuple[Path, str, List[Tuple[int, str, str]]]]] = {}
_EFILE_SOURCE_MTIME_CACHE: Dict[str, float] = {}
_EFILE_INCLUDE_INDEX_CACHE: Dict[str, Tuple[float, Dict[str, List[Evidence]]]] = {}
_EFILE_REF_INDEX_CACHE: Dict[str, Tuple[float, Dict[str, List[Evidence]]]] = {}


def clear_efile_cache(taxyear: Optional[str] = None) -> None:
    if taxyear is None:
        _EFILE_SOURCE_CACHE.clear()
        _EFILE_SOURCE_MTIME_CACHE.clear()
        _EFILE_INCLUDE_INDEX_CACHE.clear()
        _EFILE_REF_INDEX_CACHE.clear()
        return
    key = str(taxyear)
    _EFILE_SOURCE_CACHE.pop(key, None)
    _EFILE_SOURCE_MTIME_CACHE.pop(key, None)
    _EFILE_INCLUDE_INDEX_CACHE.pop(key, None)
    _EFILE_REF_INDEX_CACHE.pop(key, None)


def _efile_latest_mtime(taxyear: str) -> float:
    latest = 0.0
    for source in efile_direct_files(str(taxyear)):
        if source.suffix.lower() not in (".php", ".html", ".js"):
            continue
        try:
            latest = max(latest, source.stat().st_mtime)
        except OSError:
            continue
    return latest


def efile_source_index(taxyear: str) -> List[Tuple[Path, str, List[Tuple[int, str, str]]]]:
    taxyear = str(taxyear)
    cached = _EFILE_SOURCE_CACHE.get(taxyear)
    if cached is not None:
        return cached

    latest_mtime = _efile_latest_mtime(taxyear)

    sources = [
        source for source in efile_direct_files(taxyear)
        if source.suffix.lower() in (".php", ".html", ".js")
    ]

    def load_source(source: Path) -> Tuple[Path, str, List[Tuple[int, str, str]]]:
        source_lines = uncomment_code_lines(read_file_text(source).splitlines())
        lower_text = "\n".join(source_lines).lower()
        lines = [(line_no, line, line.lower()) for line_no, line in enumerate(source_lines, start=1)]
        return source, lower_text, lines

    # Efile consists of thousands of moderately small files.  Concurrent
    # reads hide much of the per-file Windows/antivirus latency while map()
    # preserves deterministic source order.
    worker_count = min(8, max(1, os.cpu_count() or 1))
    with ThreadPoolExecutor(max_workers=worker_count) as executor:
        index = list(executor.map(load_source, sources))

    _EFILE_SOURCE_CACHE[taxyear] = index
    _EFILE_SOURCE_MTIME_CACHE[taxyear] = latest_mtime
    return index


def efile_include_index(taxyear: str) -> Dict[str, List[Evidence]]:
    taxyear = str(taxyear)
    cached = _EFILE_INCLUDE_INDEX_CACHE.get(taxyear)
    if cached is not None:
        return cached[1]

    latest_mtime = _efile_latest_mtime(taxyear)
    base = efile_root(taxyear)
    include_context = re.compile(r"\b(?:include|include_once|require|require_once)\s*\(?", re.IGNORECASE)
    index: Dict[str, List[Evidence]] = defaultdict(list)

    for source, _lower_text, lines in efile_source_index(taxyear):
        try:
            rel_source = source.relative_to(base).as_posix()
        except ValueError:
            rel_source = source.name

        for line_no, line, _lower_line in lines:
            if not include_context.search(line):
                continue
            for match in FILENAME_RE.finditer(line):
                target_name = match.group("name")
                evidence = Evidence(
                    rel_file(taxyear, "efile", rel_source),
                    line_no,
                    "Common",
                    "efile include/require",
                    clean_snippet(line),
                )
                index[target_name.lower()].append(evidence)

    _EFILE_INCLUDE_INDEX_CACHE[taxyear] = (latest_mtime, index)
    return index


def efile_include_found(taxyear: str, path: Path) -> Tuple[bool, List[Evidence]]:
    """Search only direct files inside <taxyear>/efile for include/require of path."""
    evidence = efile_include_index(taxyear).get(path.name.lower(), [])
    return bool(evidence), evidence[:1]


def efile_reference_index(taxyear: str) -> Dict[str, List[Evidence]]:
    """Build once: direct efile filename -> flow/include evidence."""
    taxyear = str(taxyear)
    latest_mtime = _efile_latest_mtime(taxyear)
    cached = _EFILE_REF_INDEX_CACHE.get(taxyear)
    if cached is not None and cached[0] == latest_mtime:
        return cached[1]

    base = efile_root(taxyear)
    known = {path.name.lower() for path in efile_direct_files(taxyear) if path.suffix.lower() in (".php", ".html")}
    index: Dict[str, List[Evidence]] = defaultdict(list)
    include_context = COMMON_INCLUDE_CONTEXT_RE

    def add_evidence(raw: str, source: Path, line_no: int, method: str, reason: str, line: str, args: Optional[Set[str]] = None) -> None:
        name = Path(urlparse(strip_php_fragments(raw).strip().replace("\\", "/")).path).name.lower()
        if not name or name not in known:
            return
        try:
            rel_source = source.relative_to(base).as_posix()
        except ValueError:
            rel_source = source.name
        # Efile endpoints commonly submit or navigate back to themselves.
        # Those are valid GET/POST flow signals.  Continue to ignore a file
        # including itself, since that is not evidence of shared use.
        if (
            Path(rel_source).name.lower() == name
            and method not in {"GET", "POST"}
        ):
            return
        index[name].append(
            Evidence(
                rel_file(taxyear, "efile", rel_source),
                line_no,
                method,
                reason,
                clean_snippet(line),
                args or query_arg_names(raw),
            )
        )

    for source, _lower_text, lines in efile_source_index(taxyear):
        pending_ajax_method = ""
        pending_ajax_start_line = 0
        pending_ajax_snippet = ""
        pending_ajax_ttl = 0
        dynamic_include_templates: Dict[str, List[str]] = {}

        for line_no, line, lower_line in lines:
            parsed_line = normalize_code_line(line)
            for assignment in PHP_VARIABLE_ASSIGNMENT_RE.finditer(parsed_line):
                variable_name = assignment.group(1).lower()
                expression = assignment.group(2)
                fragments = [
                    literal.group(2)
                    for literal in PHP_STRING_LITERAL_RE.finditer(expression)
                    if literal.group(2)
                ]
                if PHP_VARIABLE_TOKEN_RE.search(expression) and fragments:
                    dynamic_include_templates[variable_name] = fragments
                else:
                    dynamic_include_templates.pop(variable_name, None)

            relevant_line = pending_ajax_ttl > 0 or any(
                marker in lower_line
                for marker in (
                    "<form", "xmlhttprequest", "$.post", "$.ajax",
                    "brwindow", "openbrwindow", ".php?", ".html?",
                    '".', "'.", "href", "src", "url", "data-url",
                    "location", "open(", "navigate", "header",
                    "include", "require",
                )
            )
            if not relevant_line:
                continue

            if "<form" in lower_line and "action" in lower_line:
                for action, method, args in extract_form_refs(parsed_line):
                    add_evidence(action, source, line_no, method, "form action", line, args)

            for match in XHR_OPEN_RE.finditer(parsed_line):
                method = match.group(2).upper()
                raw = match.group(4)
                add_evidence(raw, source, line_no, method, "XMLHttpRequest open", line, query_arg_names(raw) | inline_query_arg_names(parsed_line))

            for match in JQUERY_POST_RE.finditer(parsed_line):
                raw = match.group(2)
                add_evidence(raw, source, line_no, "POST", "jQuery post", line)

            if JQUERY_AJAX_START_RE.search(parsed_line):
                pending_ajax_method = ""
                pending_ajax_start_line = line_no
                pending_ajax_snippet = clean_snippet(line)
                pending_ajax_ttl = 20

            if pending_ajax_ttl > 0:
                method_match = JQUERY_AJAX_TYPE_RE.search(parsed_line)
                if method_match:
                    pending_ajax_method = method_match.group(2).upper()

                url_match = JQUERY_AJAX_URL_RE.search(parsed_line)
                if url_match:
                    raw = url_match.group(2)
                    method = pending_ajax_method or "GET"
                    add_evidence(raw, source, pending_ajax_start_line or line_no, method, "jQuery ajax", pending_ajax_snippet or line)
                    pending_ajax_method = ""
                    pending_ajax_start_line = 0
                    pending_ajax_snippet = ""
                    pending_ajax_ttl = 0

            if "brwindow" in lower_line or "openbrwindow" in lower_line:
                for match in BR_WINDOW_RE.finditer(parsed_line):
                    raw = match.group(2)
                    add_evidence(raw, source, line_no, "GET", "browser window function", line)

            if ".php?" in lower_line or ".html?" in lower_line:
                for match in QUERY_URL_RE.finditer(parsed_line):
                    raw = match.group(1)
                    add_evidence(raw, source, line_no, "GET", "query string URL", line)

            if '".' in lower_line or "'." in lower_line:
                for match in CONCAT_QUERY_URL_RE.finditer(parsed_line):
                    raw = match.group(2) + "?" + match.group(4)
                    add_evidence(raw, source, line_no, "GET", "concatenated query string URL", line)

            if any(marker in lower_line for marker in ("href", "src", "url", "data-url")):
                for match in URL_ATTR_RE.finditer(parsed_line):
                    raw = match.group(2)
                    add_evidence(raw, source, line_no, "GET", "url attribute", line)
                for match in UNQUOTED_URL_ATTR_RE.finditer(parsed_line):
                    raw = match.group(1)
                    add_evidence(raw, source, line_no, "GET", "url attribute", line)

            if any(marker in lower_line for marker in ("location", "open(", "navigate")):
                for match in JS_NAV_RE.finditer(parsed_line):
                    raw = match.group(2)
                    add_evidence(raw, source, line_no, "GET", "javascript navigation", line)

            if "header" in lower_line and "location" in lower_line:
                for match in PHP_LOCATION_RE.finditer(parsed_line):
                    raw = match.group(1)
                    add_evidence(raw, source, line_no, "GET", "header location", line)

            if "include" in lower_line or "require" in lower_line:
                if not include_context.search(parsed_line):
                    continue
                for match in FILENAME_RE.finditer(parsed_line):
                    add_evidence(match.group("name"), source, line_no, "Common", "efile include/require", line, set())
                for include_match in VARIABLE_INCLUDE_RE.finditer(parsed_line):
                    fragments = dynamic_include_templates.get(
                        include_match.group(1).lower(), []
                    )
                    for target_name in known:
                        if fragments and _ordered_filename_fragments_match(
                            target_name, fragments
                        ):
                            add_evidence(
                                target_name,
                                source,
                                line_no,
                                "Common",
                                "efile dynamic variable include/require",
                                line,
                                set(),
                            )

            if pending_ajax_ttl > 0:
                pending_ajax_ttl -= 1
                if pending_ajax_ttl == 0:
                    pending_ajax_method = ""
                    pending_ajax_start_line = 0
                    pending_ajax_snippet = ""

    _EFILE_REF_INDEX_CACHE[taxyear] = (latest_mtime, index)
    return index


def efile_method_for_path(
    taxyear: str,
    path: Path,
    reference_index: Optional[Dict[str, List[Evidence]]] = None,
) -> Tuple[str, List[Evidence]]:
    name_lower = path.name.lower()
    if name_lower.endswith(
        (
            "_ext_mef.php",
            "pship_mef.php",
            "1041_mef.php",
            "ccorp_mef.php",
            "scorp_mef.php",
        )
    ):
        return "Common", []
    if name_lower.endswith("_affected_users.php") or Path(name_lower).stem.endswith("_affected"):
        return "GET", []
    if path.stat().st_size == 0:
        return "DEAD", []
    # A folder build supplies the already-validated index.  Without this,
    # efile_reference_index() checks every source mtime once for every record,
    # turning a build with N files into roughly N-squared filesystem stats.
    if reference_index is None:
        reference_index = efile_reference_index(taxyear)
    evidence = reference_index.get(name_lower, [])
    if evidence:
        return classify_primary(item.method for item in evidence), evidence[:25]
    if any(target in name_lower for target in ("_prep_table_mef", "_patsusers_mef")):
        return "GET", []
    if name_lower.endswith(("prod_attachments_mef.php", "pats_attachments_mef.php", "_1040_mef.php")):
        return "Common", []
    if any(keyword in name_lower for keyword in ("pats", "prod", "batch", "build", "trans")):
        return "GET", []
    
    return "ANALYSE", []


_OLTPRO_REF_INDEX_CACHE: Dict[str, Dict[str, List[Evidence]]] = {}
OLTPRO_DUAL_FLOW_RE = re.compile(
    r"(?<![A-Za-z0-9_])\$?(?:nextCall|BASELoadingHTML)\s*=\s*"
    r"[\"']?([A-Za-z0-9_.-]+)[\"']?",
    re.IGNORECASE,
)
OLTPRO_STATES_TAX_TABLE_PDF_RE = re.compile(
    r"(?:\.\.?[\\/])?States\s+Tax\s+Table[\\/]"
    r"([A-Za-z0-9_.-]+\.pdf)",
    re.IGNORECASE,
)


def oltpro_root(taxyear: str) -> Path:
    return SITE_ASP_ROOT / str(taxyear) / "OLTPRO"


def oltpro_relative_name(taxyear: str, path: Path) -> str:
    try:
        return path.relative_to(oltpro_root(taxyear)).as_posix()
    except ValueError:
        return path.name


def oltpro_file_role(taxyear: str, path: Path) -> Tuple[str, str]:
    relative_name = oltpro_relative_name(taxyear, path)
    parts = Path(relative_name).parts
    if not parts:
        return "", relative_name
    subfolder = OLTPRO_SUBFOLDER_BY_LOWER.get(parts[0].lower(), parts[0])
    return subfolder, relative_name


def oltpro_common_filename_method(taxyear: str, path: Path) -> str:
    """Return Common for deterministic filenames in numeric-year OLTPRO."""
    if not str(taxyear).isdigit():
        return ""

    filename = path.name.lower()
    if filename.startswith(("oltpro_hidden", "oltpro_update")):
        return "Common"
    if filename.startswith("tms_") and filename.endswith(
        ("_config.php", "_config_summary.php")
    ):
        return "Common"
    if filename.startswith("oltpro_") and filename.endswith("_return_import.php"):
        return "Common"
    return ""


def oltpro_reference_method(line: str) -> Tuple[str, str]:
    return common_reference_method(line, prefix="OLTPRO")


def oltpro_source_subfolders_for_target(target_subfolder: str) -> Set[str]:
    """Return OLTPRO-local source folders using the normal folder rules."""
    target_lower = str(target_subfolder or "").lower()
    if target_lower == "tms":
        # TMS files and their callers may be nested.  Search recursive TMS
        # sources in addition to the OLTPRO html and oltproc entry points.
        return {"html", "oltproc", "tms"}
    if target_lower == "help":
        return {"html"}

    normal_folder = FOLDER_BY_LOWER.get(target_lower, target_subfolder)
    source_folders = {
        folder.lower()
        for folder in source_folders_for_target(normal_folder)
        if folder.lower() in OLTPRO_SUBFOLDER_BY_LOWER
    }
    if target_lower == "oltproc":
        source_folders.add("js")
    return source_folders


def oltpro_target_source_files(
    base: Path,
    allowed_subfolders: Set[str],
    target_relative_name: str,
) -> List[Path]:
    """Find OLTPRO callers containing one target name without parsing all files."""
    roots = [
        base / OLTPRO_SUBFOLDER_BY_LOWER[subfolder]
        for subfolder in sorted(allowed_subfolders)
        if subfolder in OLTPRO_SUBFOLDER_BY_LOWER
        and (base / OLTPRO_SUBFOLDER_BY_LOWER[subfolder]).exists()
    ]
    target_stem = Path(target_relative_name).stem
    rg_path = shutil.which("rg")
    if rg_path and roots and target_stem:
        command = [
            rg_path,
            "-l",
            "-i",
            "-F",
            "--glob", "*.php",
            "--glob", "*.PHP",
            "--glob", "*.html",
            "--glob", "*.HTML",
            "--glob", "*.js",
            "--glob", "*.JS",
            "--",
            target_stem,
            *(str(root) for root in roots),
        ]
        try:
            completed = subprocess.run(
                command,
                capture_output=True,
                text=True,
                check=False,
            )
            if completed.returncode in (0, 1):
                return sorted(
                    {
                        Path(line.strip())
                        for line in completed.stdout.splitlines()
                        if line.strip()
                    },
                    key=lambda path: str(path).lower(),
                )
        except OSError:
            pass

    return [
        path
        for path in candidate_paths_for_folder(base, "OLTPRO")
        if path.suffix.lower() in (".php", ".html", ".js")
        and oltpro_file_role(base.parent.name, path)[0].lower() in allowed_subfolders
    ]


def oltpro_reference_index(
    taxyear: str,
    only_relative_name: str = "",
) -> Dict[str, List[Evidence]]:
    """Build OLTPRO references, optionally for one rebuild target only.

    Full-folder builds retain the shared in-memory index.  A single-file
    rebuild limits the target map and source scope so it does not construct
    evidence lists for every OLTPRO file before updating one Qdrant point.
    """
    taxyear = str(taxyear)
    cached = _OLTPRO_REF_INDEX_CACHE.get(taxyear)
    if cached is not None:
        return cached

    requested_relative_name = str(only_relative_name or "").replace("\\", "/").lower()

    base = oltpro_root(taxyear)
    targets: Dict[str, List[str]] = defaultdict(list)
    targets_by_basename: Dict[str, List[str]] = defaultdict(list)
    target_subfolders: Dict[str, str] = {}
    known: Set[Tuple[str, str]] = set()
    if base.exists():
        for path in candidate_paths_for_folder(base, "OLTPRO"):
            subfolder, relative_name = oltpro_file_role(taxyear, path)
            is_states_tax_table_pdf = (
                subfolder.lower() == "states tax table"
                and path.suffix.lower() == ".pdf"
            )
            if path.suffix.lower() not in (".php", ".html") and not is_states_tax_table_pdf:
                continue
            if requested_relative_name and relative_name.lower() != requested_relative_name:
                continue
            target = (subfolder, path.name)
            known.add(target)
            target_subfolders[relative_name] = subfolder
            lower_rel = relative_name.lower()
            targets[lower_rel].append(relative_name)
            targets[f"{subfolder.lower()}/{path.name.lower()}"].append(relative_name)
            targets_by_basename[path.name.lower()].append(relative_name)

    index: Dict[str, List[Evidence]] = defaultdict(list)
    # Scan only files under OLTPRO.  Evidence is filtered below using the same
    # per-target source-folder scope as the corresponding normal 2025 folder.
    allowed_source_subfolders: Set[str] = set()
    if requested_relative_name:
        for target_subfolder in target_subfolders.values():
            allowed_source_subfolders.update(
                oltpro_source_subfolders_for_target(target_subfolder)
            )

    if requested_relative_name:
        source_files = oltpro_target_source_files(
            base,
            allowed_source_subfolders,
            requested_relative_name,
        )
    else:
        source_files = [
            path
            for path in candidate_paths_for_folder(base, "OLTPRO")
            if path.suffix.lower() in (".php", ".html", ".js")
        ]

    for source in source_files:
        source_rel = oltpro_relative_name(taxyear, source)
        source_is_html = source.parent.name.lower() == "html"

        # Use the normal folder extractor first.  This is important for HTML
        # input templates: an include that follows a form is INPUT, while a
        # standalone include remains Common.  It also keeps XHR, ajax, form,
        # iframe, navigation, query-string, and flow-variable handling aligned
        # with the normal 2025 html/oltproc rules.
        source_subfolder, _ = oltpro_file_role(taxyear, source)
        extracted, _local_args = _extract_file_references(
            source,
            source_subfolder,
            source.name,
            f"/{taxyear}/OLTPRO/{source_rel}",
            known,
            "",
            path_variable_include_rules=_is_standard_taxyear(taxyear),
        )
        extracted_targets: Set[str] = set()
        extracted_flow_targets: Set[str] = set()
        for (target_subfolder, target_name), evidences in extracted.items():
            lookup_key = f"{target_subfolder.lower()}/{target_name.lower()}"
            for target_relative_name in targets.get(lookup_key, []):
                allowed_sources = oltpro_source_subfolders_for_target(
                    target_subfolders.get(target_relative_name, "")
                )
                if source_subfolder.lower() not in allowed_sources:
                    continue
                index[target_relative_name].extend(evidences)
                extracted_targets.add(target_relative_name)
                if any(item.reason == "flow variable" for item in evidences):
                    extracted_flow_targets.add(target_relative_name)

        # Preserve the legacy plain-reference fallback for OLTPRO code that
        # names a PHP/HTML file without one of the normal syntactic contexts.
        # Do not add it when the full extractor already supplied stronger
        # evidence, otherwise its default POST could override a valid GET or
        # INPUT classification.
        for line_no, line in enumerate(
            uncomment_code_lines(cached_file_lines(source)), start=1
        ):
            parsed_line = normalize_code_line(line)

            # OLTPRO uses one extensionless flow name for a PHP handler and
            # its matching HTML input template.  Resolve both sides of that
            # pair explicitly because the normal extractor resolves flow
            # variables to PHP only.
            for value in dict.fromkeys(OLTPRO_DUAL_FLOW_RE.findall(parsed_line)):
                stem = Path(value).stem
                for target_subfolder, target_name, method, reason in (
                    ("oltproc", f"{stem}.php", "POST", "OLTPRO flow variable POST"),
                    ("html", f"{stem}.html", "INPUT", "OLTPRO flow variable input"),
                ):
                    lookup_key = f"{target_subfolder}/{target_name.lower()}"
                    for target in targets.get(lookup_key, []):
                        if target == source_rel:
                            continue
                        allowed_sources = oltpro_source_subfolders_for_target(
                            target_subfolders.get(target, "")
                        )
                        if source_subfolder.lower() not in allowed_sources:
                            continue
                        index[target].append(
                            Evidence(
                                f"/{taxyear}/OLTPRO/{source_rel}",
                                line_no,
                                method,
                                reason,
                                clean_snippet(line),
                            )
                        )
                        extracted_targets.add(target)
                        if method == "POST":
                            extracted_flow_targets.add(target)

            # The normal scanner knows which top-level folder is currently
            # being built, so a bare flow variable can resolve into that
            # target folder.  OLTPRO builds several subfolders together; fan
            # the same POST evidence out to matching OLTPRO-local basenames
            # whose normal source-folder scope permits this caller.
            for value in FLOW_VAR_RE.findall(parsed_line):
                target_name = value if value.lower().endswith(".php") else f"{value}.php"
                for target in targets_by_basename.get(target_name.lower(), []):
                    if target == source_rel or target in extracted_flow_targets:
                        continue
                    allowed_sources = oltpro_source_subfolders_for_target(
                        target_subfolders.get(target, "")
                    )
                    if source_subfolder.lower() not in allowed_sources:
                        continue
                    index[target].append(
                        Evidence(
                            f"/{taxyear}/OLTPRO/{source_rel}",
                            line_no,
                            "POST",
                            "flow variable",
                            clean_snippet(line),
                        )
                    )
                    extracted_targets.add(target)

            lower_line = line.lower().replace("\\", "/")
            method, reason = oltpro_reference_method(line)
            mentioned_keys: Set[str] = set()

            if method == "GET":
                for pdf_name in OLTPRO_STATES_TAX_TABLE_PDF_RE.findall(parsed_line):
                    lookup_key = f"states tax table/{pdf_name.lower()}"
                    for target in targets.get(lookup_key, []):
                        if target == source_rel:
                            continue
                        allowed_sources = oltpro_source_subfolders_for_target(
                            target_subfolders.get(target, "")
                        )
                        if source_subfolder.lower() not in allowed_sources:
                            continue
                        if target in extracted_targets or index[target]:
                            continue
                        index[target].append(
                            Evidence(
                                f"/{taxyear}/OLTPRO/{source_rel}",
                                line_no,
                                "GET",
                                "OLTPRO States Tax Table PDF GET",
                                clean_snippet(line),
                                inline_query_arg_names(line),
                            )
                        )

            for match in FILENAME_RE.finditer(lower_line):
                name = match.group("name").lower()
                for key in (
                    f"html/{name}",
                    f"oltproc/{name}",
                    f"inc/{name}",
                    f"error/{name}",
                    f"page_info/{name}",
                    f"showreturn/{name}",
                    f"states/{name}",
                    f"efile/{name}",
                    f"tms/{name}",
                    f"help/{name}",
                ):
                    if key in lower_line:
                        if key.startswith("help/") and not source_is_html:
                            continue
                        mentioned_keys.add(key)

            for key in mentioned_keys:
                for target in targets.get(key, []):
                    if target == source_rel:
                        continue
                    allowed_sources = oltpro_source_subfolders_for_target(
                        target_subfolders.get(target, "")
                    )
                    if source_subfolder.lower() not in allowed_sources:
                        continue
                    if target in extracted_targets or index[target]:
                        continue
                    index[target].append(
                        Evidence(
                            f"/{taxyear}/OLTPRO/{source_rel}",
                            line_no,
                            method,
                            reason,
                            clean_snippet(line),
                            inline_query_arg_names(line),
                        )
                    )

    result = dict(index)
    if not requested_relative_name:
        _OLTPRO_REF_INDEX_CACHE[taxyear] = result
        return _OLTPRO_REF_INDEX_CACHE[taxyear]
    return result


def oltpro_method_for_path(
    taxyear: str,
    path: Path,
    target_only: bool = False,
) -> Tuple[str, List[Evidence]]:
    filename_method = oltpro_common_filename_method(taxyear, path)
    if filename_method:
        return filename_method, []
    if path.name.lower().startswith("oltpro_logout"):
        return "GET", []
    if path.stat().st_size == 0:
        return "DEAD", []

    subfolder, relative_name = oltpro_file_role(taxyear, path)
    subfolder_lower = subfolder.lower()
    suffix = path.suffix.lower()
    if subfolder_lower == "tms" and suffix in {".css", ".js"}:
        return "GET", []
    if subfolder_lower == "images" and suffix == ".jpeg":
        return "GET", []
    evidence = oltpro_reference_index(
        taxyear,
        relative_name if target_only else "",
    ).get(relative_name, [])

    if subfolder_lower == "js":
        return "GET", evidence
    if subfolder_lower == "help":
        return (classify_primary(item.method for item in evidence) if evidence else "DEAD"), evidence
    if subfolder_lower == "page_info":
        return "PAGEINFO", evidence
    if subfolder_lower == "html" and any(
        item.method == "INPUT" and item.reason == "OLTPRO flow variable input"
        for item in evidence
    ):
        return "INPUT", evidence

    # Apply the same folder-level rules as the corresponding normal year
    # folder (code_bg_img, jscripts, styles, image, error, states,
    # page_info, showreturn, and so on).  TMS and OLTPRO-only folders have no
    # top-level rule, so their PHP/HTML files use the extracted flow evidence.
    normal_folder = FOLDER_BY_LOWER.get(subfolder_lower, subfolder)
    normal_method = folder_rule_method(normal_folder, path, evidence)
    if normal_method:
        return normal_method, evidence
    if subfolder_lower == "states tax table" and suffix == ".pdf":
        return (
            "GET" if any(item.method == "GET" for item in evidence) else "ANALYSE"
        ), evidence
    if suffix in STATIC_GET_EXTENSIONS:
        return "GET", evidence
    if suffix in (".php", ".html"):
        return (classify_primary(item.method for item in evidence) if evidence else "ANALYSE"), evidence
    return "ANALYSE", evidence

def efilebank_root(taxyear: str) -> Path:
    return SITE_ASP_ROOT / str(taxyear) / "efilebank"


def efilebank_direct_files(taxyear: str) -> List[Path]:
    return cached_all_direct_files(str(taxyear), "efilebank")


_EFILEBANK_SOURCE_CACHE: Dict[str, List[Tuple[Path, str, List[Tuple[int, str, str]]]]] = {}
_EFILEBANK_SOURCE_MTIME_CACHE: Dict[str, float] = {}
_EFILEBANK_REFERENCE_INDEX_CACHE: Dict[str, Tuple[float, Dict[str, List[Evidence]]]] = {}


def clear_efilebank_cache(taxyear: Optional[str] = None) -> None:
    if taxyear is None:
        _EFILEBANK_SOURCE_CACHE.clear()
        _EFILEBANK_SOURCE_MTIME_CACHE.clear()
        _EFILEBANK_REFERENCE_INDEX_CACHE.clear()
        return
    key = str(taxyear)
    _EFILEBANK_SOURCE_CACHE.pop(key, None)
    _EFILEBANK_SOURCE_MTIME_CACHE.pop(key, None)
    _EFILEBANK_REFERENCE_INDEX_CACHE.pop(key, None)


def _efilebank_latest_mtime(taxyear: str) -> float:
    latest = 0.0
    for source in efilebank_direct_files(str(taxyear)):
        if source.suffix.lower() not in (".php", ".html", ".js"):
            continue
        try:
            latest = max(latest, source.stat().st_mtime)
        except OSError:
            continue
    return latest


def efilebank_source_index(taxyear: str) -> List[Tuple[Path, str, List[Tuple[int, str, str]]]]:
    taxyear = str(taxyear)
    cached = _EFILEBANK_SOURCE_CACHE.get(taxyear)
    if cached is not None:
        return cached

    latest_mtime = _efilebank_latest_mtime(taxyear)

    index: List[Tuple[Path, str, List[Tuple[int, str, str]]]] = []
    for source in efilebank_direct_files(taxyear):
        if source.suffix.lower() not in (".php", ".html", ".js"):
            continue
        source_lines = uncomment_code_lines(read_file_text(source).splitlines())
        lower_text = "\n".join(source_lines).lower()
        lines = [(line_no, line, line.lower()) for line_no, line in enumerate(source_lines, start=1)]
        index.append((source, lower_text, lines))

    _EFILEBANK_SOURCE_CACHE[taxyear] = index
    _EFILEBANK_SOURCE_MTIME_CACHE[taxyear] = latest_mtime
    return index


def efilebank_reference_index(taxyear: str) -> Dict[str, List[Evidence]]:
    taxyear = str(taxyear)
    latest_mtime = _efilebank_latest_mtime(taxyear)
    cached = _EFILEBANK_REFERENCE_INDEX_CACHE.get(taxyear)
    if cached is not None and cached[0] == latest_mtime:
        return cached[1]

    known = {
        ("efilebank", path.name)
        for path in efilebank_direct_files(taxyear)
        if path.suffix.lower() in (".php", ".html")
    }
    index: Dict[str, List[Evidence]] = defaultdict(list)

    for source in efilebank_direct_files(taxyear):
        if source.suffix.lower() not in (".php", ".html", ".js"):
            continue
        references, _local_args = _extract_file_references(
            source,
            "efilebank",
            source.name,
            rel_file(taxyear, "efilebank", source.name),
            known,
            "efilebank",
            path_variable_include_rules=_is_standard_taxyear(taxyear),
        )
        for (_target_folder, target_name), evidence in references.items():
            index[target_name.lower()].extend(evidence)

    _EFILEBANK_REFERENCE_INDEX_CACHE[taxyear] = (latest_mtime, index)
    return index


def efilebank_include_index(taxyear: str) -> Dict[str, List[Evidence]]:
    """Compatibility view containing only include/require evidence."""
    return {
        name: [item for item in evidence if item.method == "Common"]
        for name, evidence in efilebank_reference_index(taxyear).items()
        if any(item.method == "Common" for item in evidence)
    }


def efilebank_include_found(taxyear: str, path: Path) -> Tuple[bool, List[Evidence]]:
    """Search only direct files inside <taxyear>/efilebank for include/require of path."""
    evidence = efilebank_include_index(taxyear).get(path.name.lower(), [])
    return bool(evidence), evidence[:1]


def efilebank_method_for_path(taxyear: str, path: Path) -> Tuple[str, List[Evidence]]:
    evidence = efilebank_reference_index(taxyear).get(path.name.lower(), [])
    flow_evidence = [item for item in evidence if item.method in {"GET", "POST"}]
    if flow_evidence:
        return classify_primary(item.method for item in flow_evidence), evidence[:25]
    if path.stat().st_size == 0:
        return "DEAD", []
    include_evidence = [item for item in evidence if item.method == "Common"]
    if include_evidence:
        return "Common", include_evidence[:25]
    return "GET", []

def efilepartner_root(taxyear: str) -> Path:
    return SITE_ASP_ROOT / str(taxyear) / "efilePartner"


def efilepartner_direct_files(taxyear: str) -> List[Path]:
    return cached_all_direct_files(str(taxyear), "efilePartner")


_EFILEPARTNER_SOURCE_CACHE: Dict[str, List[Tuple[Path, str, List[Tuple[int, str, str]]]]] = {}
_EFILEPARTNER_SOURCE_MTIME_CACHE: Dict[str, float] = {}
_EFILEPARTNER_INCLUDE_INDEX_CACHE: Dict[str, Tuple[float, Dict[str, List[Evidence]]]] = {}


def clear_efilepartner_cache(taxyear: Optional[str] = None) -> None:
    if taxyear is None:
        _EFILEPARTNER_SOURCE_CACHE.clear()
        _EFILEPARTNER_SOURCE_MTIME_CACHE.clear()
        _EFILEPARTNER_INCLUDE_INDEX_CACHE.clear()
        return
    key = str(taxyear)
    _EFILEPARTNER_SOURCE_CACHE.pop(key, None)
    _EFILEPARTNER_SOURCE_MTIME_CACHE.pop(key, None)
    _EFILEPARTNER_INCLUDE_INDEX_CACHE.pop(key, None)


def _efilepartner_latest_mtime(taxyear: str) -> float:
    latest = 0.0
    for source in efilepartner_direct_files(str(taxyear)):
        if source.suffix.lower() not in (".php", ".html", ".js"):
            continue
        try:
            latest = max(latest, source.stat().st_mtime)
        except OSError:
            continue
    return latest


def efilepartner_source_index(taxyear: str) -> List[Tuple[Path, str, List[Tuple[int, str, str]]]]:
    taxyear = str(taxyear)
    cached = _EFILEPARTNER_SOURCE_CACHE.get(taxyear)
    if cached is not None:
        return cached

    latest_mtime = _efilepartner_latest_mtime(taxyear)

    index: List[Tuple[Path, str, List[Tuple[int, str, str]]]] = []
    for source in efilepartner_direct_files(taxyear):
        if source.suffix.lower() not in (".php", ".html", ".js"):
            continue
        source_lines = uncomment_code_lines(read_file_text(source).splitlines())
        lower_text = "\n".join(source_lines).lower()
        lines = [(line_no, line, line.lower()) for line_no, line in enumerate(source_lines, start=1)]
        index.append((source, lower_text, lines))

    _EFILEPARTNER_SOURCE_CACHE[taxyear] = index
    _EFILEPARTNER_SOURCE_MTIME_CACHE[taxyear] = latest_mtime
    return index


def efilepartner_include_index(taxyear: str) -> Dict[str, List[Evidence]]:
    taxyear = str(taxyear)
    cached = _EFILEPARTNER_INCLUDE_INDEX_CACHE.get(taxyear)
    if cached is not None:
        return cached[1]

    latest_mtime = _efilepartner_latest_mtime(taxyear)
    base = efilepartner_root(taxyear)
    include_context = re.compile(r"\b(?:include|include_once|require|require_once)\s*\(?", re.IGNORECASE)
    known = {
        path.name.lower()
        for path in efilepartner_direct_files(taxyear)
        if path.suffix.lower() in (".php", ".html")
    }
    index: Dict[str, List[Evidence]] = defaultdict(list)

    for source, _lower_text, lines in efilepartner_source_index(taxyear):
        try:
            rel_source = source.relative_to(base).as_posix()
        except ValueError:
            rel_source = source.name

        dynamic_include_templates: Dict[str, List[str]] = {}
        for line_no, line, _lower_line in lines:
            parsed_line = normalize_code_line(line)
            for assignment in PHP_VARIABLE_ASSIGNMENT_RE.finditer(parsed_line):
                variable_name = assignment.group(1).lower()
                expression = assignment.group(2)
                fragments = [
                    literal.group(2)
                    for literal in PHP_STRING_LITERAL_RE.finditer(expression)
                    if literal.group(2)
                ]
                if PHP_VARIABLE_TOKEN_RE.search(expression) and fragments:
                    dynamic_include_templates[variable_name] = fragments
                else:
                    dynamic_include_templates.pop(variable_name, None)

            if not include_context.search(line):
                continue
            for match in FILENAME_RE.finditer(line):
                target_name = match.group("name")
                evidence = Evidence(
                    rel_file(taxyear, "efilePartner", rel_source),
                    line_no,
                    "Common",
                    "efilepartner include/require",
                    clean_snippet(line),
                )
                index[target_name.lower()].append(evidence)
            for include_match in VARIABLE_INCLUDE_RE.finditer(parsed_line):
                fragments = dynamic_include_templates.get(
                    include_match.group(1).lower(), []
                )
                for target_name in known:
                    if not fragments or not _ordered_filename_fragments_match(
                        target_name, fragments
                    ):
                        continue
                    index[target_name].append(
                        Evidence(
                            rel_file(taxyear, "efilePartner", rel_source),
                            line_no,
                            "Common",
                            "efilepartner dynamic variable include/require",
                            clean_snippet(line),
                        )
                    )

    _EFILEPARTNER_INCLUDE_INDEX_CACHE[taxyear] = (latest_mtime, index)
    return index


def efilepartner_include_found(taxyear: str, path: Path) -> Tuple[bool, List[Evidence]]:
    """Search only direct files inside <taxyear>/efilePartner for include/require of path."""
    evidence = efilepartner_include_index(taxyear).get(path.name.lower(), [])
    return bool(evidence), evidence[:1]


def efilepartner_method_for_path(taxyear: str, path: Path) -> Tuple[str, List[Evidence]]:
    if path.stat().st_size == 0:
        return "DEAD", []
    found, evidence = efilepartner_include_found(taxyear, path)
    if found:
        return "Common", evidence
    return "GET", []
def folder_rule_method(folder: str, path: Path, evidence: Sequence[Evidence], fallback: str = "") -> str:
    flow_methods = [item.method for item in evidence if item.method in {"GET", "POST", "INPUT"}]
    if folder == "csr_guide_pages":
        guide_methods = [item.method for item in evidence if item.method in {"GET", "POST"}]
        return fallback or (classify_primary(guide_methods) if guide_methods else "HELP")
    if folder == "Original" and path.suffix.lower() == ".pdf":
        return fallback or "DEAD"
    if folder == "page_info":
        if path.stat().st_size == 0:
            return "DEAD"
        return "PAGEINFO" if is_html_page_info(evidence) else "ANALYSE"
    if folder == "showreturn" and "genpdfonrequest" in path.name.lower():
        return "GET"
    if folder == "showreturn" and path.stem.lower().endswith(("_forms_view", "_amd_view")):
        return "GET"
    if folder == "showreturn" and path.name.lower().endswith("_view.php"):
        return "GET"
    if folder == "showreturn" and path.name.lower().startswith("batch_"):
        return "GET"
    if folder == "csr_tax_links":
        return "DEAD" if path.stat().st_size == 0 else "HELP"

    if folder in FORCED_FOLDER_METHODS:
        return FORCED_FOLDER_METHODS[folder]
    if path.stat().st_size == 0:
        return "DEAD"
    if folder == "oltproc" and path.name.lower().startswith("sitesettings"):
        return "Common"
    if folder == "jscripts":
        if path.suffix.lower() == ".html":
            return "Common" if is_included(evidence) else "DEAD"
        return fallback
    if folder == "styles":
        return fallback if path.suffix.lower() == ".css" else "DEAD"
    if folder in DEAD_FOLDERS:
        return "DEAD"
    if folder in GET_FOLDERS:
        return "GET"
    if folder in HELP_FOLDERS:
        return "HELP"
    if folder == "DB":
        return "Common"
    if folder == "error":
        if flow_methods:
            return classify_primary(flow_methods)
        return "Common" if is_included(evidence) else "DEAD"
    if folder == "states":
        if flow_methods:
            return classify_primary(flow_methods)
        return "Common" if is_included(evidence) else "DEAD"
    if folder == "include":
        return "Common" if is_included(evidence) else "DEAD"
    if folder == "showreturn":
        if fallback:                  
            return fallback
        if flow_methods:
            return classify_primary(flow_methods)
        return "Common" if is_included(evidence) else "ANALYSE"
    return fallback


# ---------------------------------------------------------------------------
# oltproc file-list cache - populated on the first scan, reused by all
# Key: taxyear string.  Value: sorted list of Path objects.
# ---------------------------------------------------------------------------
_OLTPROC_FILE_CACHE: Dict[str, List[Path]] = {}
_FOLDER_FILE_CACHE: Dict[Tuple[str, str, Tuple[str, ...]], List[Path]] = {}
_SOURCE_LINES_CACHE: Dict[str, Tuple[float, int, List[str]]] = {}
_EXISTING_TARGETS_CACHE: Dict[str, Set[Tuple[str, str]]] = {}


def clear_generic_scan_cache(taxyear: Optional[str] = None) -> None:
    if taxyear is None:
        _FOLDER_FILE_CACHE.clear()
        _SOURCE_LINES_CACHE.clear()
        _EXISTING_TARGETS_CACHE.clear()
        return
    key = str(taxyear)
    for cache_key in list(_FOLDER_FILE_CACHE):
        if cache_key[0] == key:
            _FOLDER_FILE_CACHE.pop(cache_key, None)
    for path_key in list(_SOURCE_LINES_CACHE):
        if f"/{key}/" in path_key.replace("\\", "/"):
            _SOURCE_LINES_CACHE.pop(path_key, None)
    _EXISTING_TARGETS_CACHE.pop(key, None)


def cached_direct_files(taxyear: str, folder: str, suffixes: Tuple[str, ...]) -> List[Path]:
    taxyear = str(taxyear)
    suffixes = tuple(suffix.lower() for suffix in suffixes)
    cache_key = (taxyear, folder, suffixes)
    cached = _FOLDER_FILE_CACHE.get(cache_key)
    if cached is not None:
        return cached

    folder_path = source_folder_path(taxyear, folder)
    if not folder_path.exists():
        result: List[Path] = []
    else:
        result = sorted(
            path for path in folder_path.iterdir()
            if path.is_file() and path.suffix.lower() in suffixes
        )
    _FOLDER_FILE_CACHE[cache_key] = result
    return result


def cached_all_direct_files(taxyear: str, folder: str) -> List[Path]:
    cache_key = (str(taxyear), folder, ("*",))
    cached = _FOLDER_FILE_CACHE.get(cache_key)
    if cached is not None:
        return cached
    folder_path = source_folder_path(str(taxyear), folder)
    if not folder_path.exists():
        result: List[Path] = []
    else:
        result = sorted(path for path in folder_path.iterdir() if path.is_file())
    _FOLDER_FILE_CACHE[cache_key] = result
    return result


def cached_file_lines(path: Path) -> List[str]:
    cache_key = str(path)
    try:
        stat = path.stat()
    except OSError:
        return []
    cached = _SOURCE_LINES_CACHE.get(cache_key)
    if cached is not None and cached[0] == stat.st_mtime and cached[1] == stat.st_size:
        return cached[2]
    lines = read_file_text(path).splitlines()
    _SOURCE_LINES_CACHE[cache_key] = (stat.st_mtime, stat.st_size, lines)
    return lines


def _oltproc_files(taxyear: str) -> List[Path]:
    """Return (and cache) the list of PHP/HTML/JS files inside oltproc/.
    Disk is read only on the FIRST call for a given tax year.
    Every subsequent call returns the cached list instantly."""
    key = str(taxyear)
    if key in _OLTPROC_FILE_CACHE:
        logger().info(f"oltproc cache HIT for {taxyear} - skipping disk scan")
        return _OLTPROC_FILE_CACHE[key]

    folder_path = SITE_ASP_ROOT / key / "oltproc"
    result: List[Path] = []
    if folder_path.exists():
        result = sorted(
            p for p in folder_path.iterdir()
            if p.is_file() and p.suffix.lower() in (".php", ".html", ".js")
        )
    logger().warning(f"oltproc cache MISS for {taxyear} - scanned {len(result)} files from disk")
    _OLTPROC_FILE_CACHE[key] = result
    return result


def clear_oltproc_cache(taxyear: Optional[str] = None) -> None:
    """Invalidate the oltproc cache (call after files change on disk)."""
    if taxyear is None:
        _OLTPROC_FILE_CACHE.clear()
    else:
        _OLTPROC_FILE_CACHE.pop(str(taxyear), None)
    clear_generic_scan_cache(taxyear)


def unique_source_folders(*folders: str) -> List[str]:
    result: List[str] = []
    seen: Set[str] = set()
    for folder in folders:
        if folder in FOLDERS and folder not in seen:
            result.append(folder)
            seen.add(folder)
    return result


def source_folders_for_target(target_folder: str) -> Sequence[str]:
    if target_folder == "csr_guide_pages":
        return ["csr_guide_pages"]
    if target_folder == "inc":
        return ["inc"]
    if target_folder == "oltproc":
        return ["oltproc", "html", "inc", "jscripts", "showreturn", "Staffolt"]
    if target_folder == "html":
        return ["html", "oltproc", "inc"]
    if target_folder == "error":
        return ["html", "oltproc"]
    if target_folder == "page_info":
        return ["html"]
    if target_folder == "showreturn":
        return ["showreturn"]
    if target_folder == "states":
        return ["states", "html", "oltproc", "showreturn", "efile"]
    if target_folder == "Staffolt":
        return ["Staffolt", "html"]
    if target_folder == "Original":
        return ["showreturn", "oltproc", "html", "OLTPRO/html", "OLTPRO/oltproc"]
    if target_folder == "efile":
        return ["efile"]
    if target_folder == "efilebank":
        return ["efilebank"]
    if target_folder == "efilePartner":
        return ["efilePartner"]
    return FOLDERS


def base_source_folders_for_target(target_folder: str) -> Sequence[str]:
    scopes = {
        "csr": ("csr",),
        "error": ("oltproc",),
        "html": ("html", "oltproc"),
        "js": ("html", "oltproc"),
        "oltproc": ("html", "oltproc", "csr","js"),
        "page_info": ("html",),
        "images": BASE_FOLDERS,
    }
    return scopes.get(target_folder, (target_folder,))


def probase_source_folders_for_target(target_folder: str) -> Sequence[str]:
    scopes = {
        "html": ("html", "oltproc"),
        "js": ("html", "oltproc"),
        "oltproc": ("html", "oltproc", "js"),
        "images": PROBASE_FOLDERS,
    }
    return scopes.get(target_folder, (target_folder,))


def mo_source_folders_for_target(target_folder: str) -> Sequence[str]:
    scopes = {
        "csr": ("csr",),
        "db": ("oltproc",),
        "html": ("html", "oltproc", "home"),
        "oltproc": ("html", "oltproc", "csr", "home"),
        "page_info": ("html",),
        "home": ("html", "oltproc", "home"),
        "images": MO_FOLDERS,
    }
    return scopes.get(target_folder, (target_folder,))


def cp_source_folders_for_target(target_folder: str) -> Sequence[str]:
    if target_folder in {"home", "html", "oltproc"}:
        return ("home", "html", "oltproc")
    return (target_folder,)


def main_source_folders_for_target(target_folder: str) -> Sequence[str]:
    # main/home is self-contained: its PHP flow references are searched only
    # inside home and its descendants.
    return (target_folder,)


def source_folders_for_taxyear_target(taxyear: str, target_folder: str) -> Sequence[str]:
    taxyear_key = str(taxyear).lower()
    if taxyear_key == "base":
        return base_source_folders_for_target(target_folder)
    if taxyear_key == "probase":
        return probase_source_folders_for_target(target_folder)
    if taxyear_key == "cp":
        return cp_source_folders_for_target(target_folder)
    if taxyear_key == "mo":
        return mo_source_folders_for_target(target_folder)
    if taxyear_key == "main":
        return main_source_folders_for_target(target_folder)
    return source_folders_for_target(target_folder)


def iter_source_files(taxyear: str, target_folder: str) -> List[Path]:
    files: List[Path] = []
    source_folders = source_folders_for_taxyear_target(taxyear, target_folder)
    for folder in source_folders:
        if folder == "oltproc":
            # Use cache - no disk read if already scanned this tax year
            files.extend(_oltproc_files(taxyear))
        else:
            source_suffixes = (".php", ".html", ".js")
            if target_folder == "page_info" and folder == "html":
                source_suffixes = (".php", ".html", ".htm", ".js")
            files.extend(cached_direct_files(str(taxyear), folder, source_suffixes))
    if str(taxyear).lower() == "mo":
        mo_root = SITE_ASP_ROOT / str(taxyear)
        if mo_root.exists():
            files.extend(
                path
                for path in sorted(mo_root.iterdir())
                if path.is_file() and path.suffix.lower() in (".php", ".html", ".js")
            )
    if target_folder == "Staffolt":
        staffolt_inc = SITE_ASP_ROOT / str(taxyear) / "Staffolt" / "inc"
        if staffolt_inc.exists():
            files.extend(
                path for path in sorted(staffolt_inc.iterdir())
                if path.is_file() and path.suffix.lower() == ".php"
            )
    logger().warning(f"Total source files found: {len(files)} for target_folder: {target_folder}")
    return sorted(files)


def folder_for_path(path: Path, taxyear: str) -> str:
    protected_folder = source_folder_path(str(taxyear), "html")
    if _path_is_within(path, protected_folder):
        return "html"
    try:
        relative_parts = path.relative_to(SITE_ASP_ROOT / str(taxyear)).parts
        if str(taxyear).lower() == "mo" and len(relative_parts) == 1:
            return ""
        return relative_parts[0]
    except Exception:
        return path.parent.name


def existing_targets(taxyear: str) -> Set[Tuple[str, str]]:
    taxyear = str(taxyear)
    cached = _EXISTING_TARGETS_CACHE.get(taxyear)
    if cached is not None:
        return cached
    targets: Set[Tuple[str, str]] = set()
    for folder in folders_for_taxyear(taxyear):
        folder_path = source_folder_path(taxyear, folder)
        if folder_path.exists():
            for path in folder_path.iterdir():
                if not path.is_file():
                    continue

                suffix = path.suffix.lower()

                if suffix in (".php", ".html"):
                    targets.add((folder, path.name))
                elif folder == "Original" and suffix == ".pdf":
                    targets.add((folder, path.name))

    _EXISTING_TARGETS_CACHE[taxyear] = targets
    return targets


def extract_form_refs(line: str) -> List[Tuple[str, str, Set[str]]]:
    refs: List[Tuple[str, str, Set[str]]] = []
    parsed_line = strip_php_fragments(normalize_code_line(line))
    for form_match in FORM_RE.finditer(parsed_line):
        attrs = {key.lower(): value for key, _quote, value in ATTR_RE.findall(form_match.group(0))}
        for key, value in UNQUOTED_ATTR_RE.findall(form_match.group(0)):
            attrs.setdefault(key.lower(), value)
        action = attrs.get("action", "")
        if not action:
            continue
        method = "POST" if attrs.get("method", "").lower() == "post" else "GET"
        refs.append((action, method, query_arg_names(action)))
    return refs


def extract_hidden_data_args(line: str) -> Set[str]:
    args: Set[str] = set()
    for _quote, value in HIDDEN_DATA_RE.findall(normalize_code_line(line)):
        args.update(query_arg_names(f"hidden.php?{value}"))
    return args


def extract_menu_refs(line: str) -> List[Tuple[str, str, str, Set[str]]]:
    refs: List[Tuple[str, str, str, Set[str]]] = []
    parsed_line = normalize_code_line(line)
    for pattern, reason in ((SUBMIT_FORM_RE, "menu submitForm"), (MOBILE_MENU_RE, "mobile menu array")):
        for call_match in pattern.finditer(parsed_line):
            for _quote, raw in STRING_ARG_RE.findall(call_match.group(1)):
                lower_raw = raw.lower()
                if lower_raw.endswith(".php") or ".php?" in lower_raw:
                    refs.append((raw, "POST", reason, query_arg_names(raw)))
                elif lower_raw.endswith(".html") or ".html?" in lower_raw:
                    refs.append((raw, "INPUT", reason, query_arg_names(raw)))

    # updateForm(token, serial, php_target, html_target, ...) uses fixed
    # positional arguments.  Its PHP target is sometimes followed directly by
    # ampersand-delimited data instead of a question mark, so deliberately keep
    # only the filename through .php.  The fourth argument is the INPUT screen.
    for call_match in UPDATE_FORM_RE.finditer(parsed_line):
        arguments = [match.group(2) for match in PHP_STRING_LITERAL_RE.finditer(call_match.group(1))]
        if len(arguments) < 4:
            continue

        php_match = FILENAME_RE.search(arguments[2])
        if php_match and php_match.group("name").lower().endswith(".php"):
            refs.append((php_match.group("name"), "POST", "updateForm PHP target", set()))

        html_match = FILENAME_RE.search(arguments[3])
        if html_match and html_match.group("name").lower().endswith(".html"):
            refs.append((html_match.group("name"), "INPUT", "updateForm HTML target", set()))
    return refs


# ---------------------------------------------------------------------------
# Full evidence cache (stronger than the line-only cache above).
#
# cached_file_lines() above only saves the disk read -- the entire ~20-regex
# extraction loop still re-runs on every build for every file, cache hit or
# not. This cache saves the ACTUAL expensive step: on a hit, the file is
# neither read nor regex-scanned again; the previously extracted evidence is
# reused as-is.
#
# Key: absolute file path + target folder. Valid as long as the cache version,
# source mtime, and source size are unchanged. REFERENCE_CACHE_VERSION is the
# explicit invalidation switch when reference-extraction behavior changes;
# unrelated edits to this scanner must not discard a freshly built folder cache.
# ---------------------------------------------------------------------------
_FILE_REFERENCE_CACHE: Dict[str, Dict] = {}
REFERENCE_CACHE_VERSION = 22
_SCANNER_CACHE_TOKEN: Optional[float] = None


def reference_cache_root(taxyear: str) -> Path:
    return PHPDATA_ROOT / "reference_cache" / str(taxyear)


def reference_cache_file(taxyear: str, cache_key: str) -> Path:
    digest = hashlib.md5(cache_key.encode("utf-8")).hexdigest()
    return reference_cache_root(taxyear) / digest[:2] / f"{digest}.json"


def scanner_cache_token() -> float:
    global _SCANNER_CACHE_TOKEN
    if _SCANNER_CACHE_TOKEN is not None:
        return _SCANNER_CACHE_TOKEN
    try:
        _SCANNER_CACHE_TOKEN = Path(__file__).stat().st_mtime
    except OSError:
        _SCANNER_CACHE_TOKEN = 0.0
    return _SCANNER_CACHE_TOKEN


def serialize_evidence(item: Evidence) -> Dict:
    return {
        "source_file": item.source_file,
        "source_line": item.source_line,
        "method": item.method,
        "reason": item.reason,
        "snippet": item.snippet,
        "args": sorted(item.args),
    }


def deserialize_evidence(item: Dict) -> Evidence:
    return Evidence(
        str(item.get("source_file", "")),
        int(item.get("source_line", 0) or 0),
        str(item.get("method", "")),
        str(item.get("reason", "")),
        str(item.get("snippet", "")),
        set(item.get("args", []) or []),
    )


def serialize_file_reference_entry(mtime: float, size: int, refs: Dict[Tuple[str, str], List[Evidence]], local_args: Dict[str, Set[str]]) -> Dict:
    return {
        "version": REFERENCE_CACHE_VERSION,
        "scanner_mtime": scanner_cache_token(),
        "mtime": mtime,
        "size": size,
        "refs": [
            {
                "target": [folder, name],
                "evidence": [serialize_evidence(item) for item in evidences],
            }
            for (folder, name), evidences in refs.items()
        ],
        "local_args": {
            "get": sorted(local_args.get("get", set())),
            "post": sorted(local_args.get("post", set())),
        },
    }


def deserialize_file_reference_entry(data: Dict) -> Dict:
    refs: Dict[Tuple[str, str], List[Evidence]] = defaultdict(list)
    for item in data.get("refs", []) or []:
        target = item.get("target", [])
        if len(target) != 2:
            continue
        refs[(str(target[0]), str(target[1]))].extend(
            deserialize_evidence(evidence)
            for evidence in item.get("evidence", []) or []
        )
    local_args = data.get("local_args", {}) or {}
    return {
        "mtime": data.get("mtime", 0),
        "size": data.get("size", 0),
        "refs": refs,
        "local_args": {
            "get": set(local_args.get("get", []) or []),
            "post": set(local_args.get("post", []) or []),
        },
    }


def load_disk_file_reference_cache(taxyear: str, cache_key: str, mtime: float, size: int) -> Optional[Dict]:
    path = reference_cache_file(taxyear, cache_key)
    if not path.exists():
        return None
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return None
    if data.get("version") != REFERENCE_CACHE_VERSION:
        return None
    if data.get("mtime") != mtime or data.get("size") != size:
        return None
    return deserialize_file_reference_entry(data)


def save_disk_file_reference_cache(taxyear: str, cache_key: str, mtime: float, size: int, refs: Dict[Tuple[str, str], List[Evidence]], local_args: Dict[str, Set[str]]) -> None:
    path = reference_cache_file(taxyear, cache_key)
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(
            json.dumps(serialize_file_reference_entry(mtime, size, refs, local_args), separators=(",", ":")),
            encoding="utf-8",
        )
    except OSError:
        return


def source_files_fingerprint(paths: Sequence[Path]) -> str:
    digest = hashlib.sha256()
    for path in paths:
        try:
            stat = path.stat()
        except OSError:
            continue
        digest.update(str(path).encode("utf-8", errors="replace"))
        digest.update(f":{stat.st_mtime_ns}:{stat.st_size}\n".encode("ascii"))
    return digest.hexdigest()


def load_error_reference_cache(taxyear: str, fingerprint: str) -> Optional[Dict[Tuple[str, str], List[Evidence]]]:
    path = reference_cache_root(taxyear) / "error_index.json"
    if not path.exists():
        return None
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return None
    if (
        data.get("version") != REFERENCE_CACHE_VERSION
        or data.get("fingerprint") != fingerprint
    ):
        return None
    references: Dict[Tuple[str, str], List[Evidence]] = defaultdict(list)
    for item in data.get("refs", []) or []:
        target = item.get("target", [])
        if len(target) != 2:
            continue
        references[(str(target[0]), str(target[1]))].extend(
            deserialize_evidence(evidence)
            for evidence in item.get("evidence", []) or []
        )
    return references


def save_error_reference_cache(
    taxyear: str,
    fingerprint: str,
    references: Dict[Tuple[str, str], List[Evidence]],
) -> None:
    path = reference_cache_root(taxyear) / "error_index.json"
    payload = {
        "version": REFERENCE_CACHE_VERSION,
        "scanner_mtime": scanner_cache_token(),
        "fingerprint": fingerprint,
        "refs": [
            {
                "target": [folder, name],
                "evidence": [serialize_evidence(item) for item in evidence],
            }
            for (folder, name), evidence in references.items()
        ],
    }
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(payload, separators=(",", ":")), encoding="utf-8")
    except OSError:
        return


def clear_file_reference_cache(taxyear: Optional[str] = None) -> None:
    """Invalidate the full-evidence cache (call after files change on disk)."""
    if taxyear is None:
        _FILE_REFERENCE_CACHE.clear()
        cache_root = PHPDATA_ROOT / "reference_cache"
        if cache_root.exists():
            shutil.rmtree(cache_root, ignore_errors=True)
        return
    prefixes = {
        str(SITE_ASP_ROOT / str(taxyear)),
        str(source_folder_path(str(taxyear), "html")),
        str(source_folder_path(str(taxyear), "DB")),
    }
    for k in [
        k for k in _FILE_REFERENCE_CACHE
        if any(k.startswith(prefix) for prefix in prefixes)
    ]:
        _FILE_REFERENCE_CACHE.pop(k, None)
    cache_root = reference_cache_root(str(taxyear))
    if cache_root.exists():
        shutil.rmtree(cache_root, ignore_errors=True)


def _extract_file_references(
    source_path: Path,
    source_folder: str,
    source_name: str,
    source_rel: str,
    known: Set[Tuple[str, str]],
    requested_target_folder: str,
    base_loading_html_rules: bool = False,
    mo_loading_html_rules: bool = False,
    cp_dual_flow_rules: bool = False,
    probase_dual_flow_rules: bool = False,
    path_variable_include_rules: bool = False,
) -> Tuple[Dict[Tuple[str, str], List[Evidence]], Dict[str, Set[str]]]:
    """Run the full regex evidence extraction for exactly one source file.

    This is the expensive, cacheable unit of work pulled out of
    collect_references()'s main loop so its result can be cached per file
    instead of recomputed on every build.
    """
    file_refs: Dict[Tuple[str, str], List[Evidence]] = defaultdict(list)
    file_local_args: Dict[str, Set[str]] = {"get": set(), "post": set()}

    lines = cached_file_lines(source_path)
    if not lines:
        return file_refs, file_local_args

    references = file_refs
    local_args = {(source_folder, source_name): file_local_args}
    source_key = (source_folder, source_name)

    pending_form_method = ""
    pending_form_target: Optional[Tuple[str, str]] = None
    pending_form_ttl = 0
    pending_ajax_method = ""
    pending_ajax_start_line = 0
    pending_ajax_snippet = ""
    pending_ajax_ttl = 0
    url_vars: Dict[str, Tuple[str, int, str]] = {}
    include_path_vars: Dict[str, Set[str]] = {}
    include_path_templates: Dict[str, List[str]] = {}

    in_block_comment = False
    for line_number, line in enumerate(lines, start=1):
        parsed_line, in_block_comment = strip_code_comments(line, in_block_comment)
        parsed_line = parsed_line.replace('\\"', '"').replace("\\'", "'")
        line_post_form_targets: Set[Tuple[str, str]] = set()

        local_args[source_key]["get"].update(READ_ARG_RE.findall(parsed_line))
        local_args[source_key]["post"].update(POST_ARG_RE.findall(parsed_line))

        for match in PHP_URL_VAR_ASSIGN_RE.finditer(parsed_line):
            url_vars[match.group(1)] = (match.group(3), line_number, clean_snippet(line))
        for match in PHP_BR_WINDOW_VAR_ASSIGN_RE.finditer(parsed_line):
            url_vars[match.group(1)] = (match.group(4), line_number, clean_snippet(line))

        if path_variable_include_rules:
            for match in PATH_VAR_ASSIGN_RE.finditer(parsed_line):
                include_path_vars[match.group(1).lower()] = {match.group(3)}

            assignment_matches = list(PHP_VARIABLE_ASSIGNMENT_RE.finditer(parsed_line))
            for match in assignment_matches:
                variable_name = match.group(1).lower()
                expression = match.group(2)
                assigned_paths = {
                    filename.group("name")
                    for filename in FILENAME_RE.finditer(expression)
                }
                for referenced_name in PHP_VARIABLE_TOKEN_RE.findall(expression):
                    assigned_paths.update(
                        include_path_vars.get(referenced_name.lower(), set())
                    )
                if assigned_paths:
                    include_path_vars[variable_name] = assigned_paths
                else:
                    include_path_vars.pop(variable_name, None)

                literal_fragments = [
                    literal.group(2)
                    for literal in PHP_STRING_LITERAL_RE.finditer(expression)
                    if literal.group(2)
                ]
                if PHP_VARIABLE_TOKEN_RE.search(expression) and literal_fragments:
                    include_path_templates[variable_name] = literal_fragments
                else:
                    include_path_templates.pop(variable_name, None)

            for match in VARIABLE_INCLUDE_RE.finditer(parsed_line):
                included_variable = match.group(1).lower()
                for raw in include_path_vars.get(included_variable, set()):
                    target = resolve_reference_target(
                        raw,
                        source_folder,
                        known,
                        requested_target_folder,
                    )
                    if target:
                        references[target].append(
                            Evidence(
                                source_rel,
                                line_number,
                                "Common",
                                "variable include/require",
                                clean_snippet(line),
                            )
                        )

                fragments = include_path_templates.get(included_variable, [])
                if fragments:
                    for target in sorted(known):
                        target_folder, target_name = target
                        if (
                            requested_target_folder
                            and target_folder.lower() != requested_target_folder.lower()
                        ):
                            continue
                        if not _ordered_filename_fragments_match(
                            Path(target_name).name,
                            fragments,
                        ):
                            continue
                        references[target].append(
                            Evidence(
                                source_rel,
                                line_number,
                                "Common",
                                "dynamic variable include/require",
                                clean_snippet(line),
                            )
                        )

            referenced_variables = {
                name.lower() for name in PHP_VARIABLE_TOKEN_RE.findall(parsed_line)
                if name.lower() in include_path_vars
            }
            variable_method = ""
            variable_reason = ""
            if (
                COMMON_POST_CONTEXT_RE.search(parsed_line)
                or re.search(
                    r"<form\b.*\bmethod\s*=\s*['\"]?post\b",
                    parsed_line,
                    re.IGNORECASE,
                )
            ):
                variable_method = "POST"
                variable_reason = "variable POST reference"
            elif COMMON_GET_CONTEXT_RE.search(parsed_line):
                variable_method = "GET"
                variable_reason = "variable GET reference"
            else:
                for assignment in assignment_matches:
                    left_name = assignment.group(1)
                    expression_variables = {
                        name.lower()
                        for name in PHP_VARIABLE_TOKEN_RE.findall(assignment.group(2))
                    }
                    if (
                        expression_variables & referenced_variables
                        and FLOW_VAR_RE.search(f'{left_name}="target.php";')
                    ):
                        variable_method = "POST"
                        variable_reason = "variable POST flow"
                        referenced_variables = expression_variables & referenced_variables
                        break

            if variable_method:
                for variable_name in referenced_variables:
                    for raw in include_path_vars[variable_name]:
                        target = resolve_reference_target(
                            raw,
                            source_folder,
                            known,
                            requested_target_folder,
                        )
                        if target:
                            references[target].append(
                                Evidence(
                                    source_rel,
                                    line_number,
                                    variable_method,
                                    variable_reason,
                                    clean_snippet(line),
                                    query_arg_names(raw)
                                    if variable_method == "GET"
                                    else set(),
                                )
                            )

        if JS_NAV_CALL_RE.search(parsed_line):
            for match in PHP_ECHO_VAR_RE.finditer(parsed_line):
                var_name = match.group(1) or match.group(2)
                var_url = url_vars.get(var_name)
                if not var_url:
                    continue
                raw, assign_line, assign_snippet = var_url
                target = resolve_reference_target(raw, source_folder, known, requested_target_folder)

                if target:
                    references[target].append(
                        Evidence(
                            source_rel,
                            assign_line,
                            "GET",
                            "javascript navigation variable",
                            assign_snippet,
                            query_arg_names(raw)
                        )
                    )

        for match in HREF_ECHO_VAR_RE.finditer(parsed_line):
            var_name = match.group(2) or match.group(3)
            var_url = url_vars.get(var_name)
            if not var_url:
                continue
            raw, assign_line, assign_snippet = var_url
            target = resolve_reference_target(raw, source_folder, known, requested_target_folder)

            if target:
                references[target].append(
                    Evidence(
                        source_rel,
                        assign_line,
                        "GET",
                        "href variable",
                        assign_snippet,
                        query_arg_names(raw)
                    )
                )

        for action, method, args in extract_form_refs(line):
            target = resolve_reference_target(action, source_folder, known, requested_target_folder)
            if target:
                references[target].append(
                    Evidence(source_rel, line_number, method, "form action", clean_snippet(line), args)
                )
                if method == "POST":
                    line_post_form_targets.add(target)
                pending_form_method = method
                pending_form_target = target
                pending_form_ttl = 8

        if pending_form_target and pending_form_ttl > 0:
            hidden_args = extract_hidden_data_args(line)
            if hidden_args:
                references[pending_form_target].append(
                    Evidence(
                        source_rel,
                        line_number,
                        pending_form_method or "POST",
                        "dynamic hidden form data",
                        clean_snippet(line),
                        hidden_args
                    )
                )

        for raw, method, reason, args in extract_menu_refs(line):
            target = (
                resolve_submit_form_target(raw, source_folder, known, requested_target_folder)
                if reason in {"menu submitForm", "updateForm PHP target"} and method == "POST"
                else resolve_reference_target(raw, source_folder, known, requested_target_folder)
            )
            if target:
                references[target].append(
                    Evidence(source_rel, line_number, method, reason, clean_snippet(line), args)
                )

        includes = list(INCLUDE_RE.findall(parsed_line))
        includes.extend(CONCAT_INCLUDE_RE.findall(parsed_line))
        for include in dict.fromkeys(includes):
            target = resolve_reference_target(include, source_folder, known, requested_target_folder)

            if target:
                target_folder = target[0]
                target_filename = target[1]
                target_filename_lower = target_filename.lower()

                if target_folder == "html":
                    include_method = (
                        "INPUT"
                        if (
                            (pending_form_method and pending_form_ttl > 0)
                            or target_filename_lower.endswith("nv.html")
                        )
                        else "Common"
                    )
                    reason = "input template include" if include_method == "INPUT" else "include/require"

                elif target_folder == "inc":
                    include_method = (
                        "MENU"
                        if (
                            target_filename_lower.endswith("_sitehdrnav.php")
                            or source_folder == "inc"
                        )
                        else "MENU"
                    )
                    reason = "menu include" if include_method == "MENU" else "include/require"

                else:
                    include_method = "Common"
                    reason = "include/require"

                references[target].append(
                    Evidence(source_rel, line_number, include_method, reason, clean_snippet(line))
                )

        if base_loading_html_rules:
            for include in dict.fromkeys(BASE_INCLUDE_FUNC_ASSIGN_RE.findall(parsed_line)):
                target = resolve_reference_target(
                    include,
                    source_folder,
                    known,
                    requested_target_folder,
                )
                if target:
                    references[target].append(
                        Evidence(
                            source_rel,
                            line_number,
                            "Common",
                            "include/require",
                            clean_snippet(line),
                        )
                    )

        for match in XHR_OPEN_RE.finditer(parsed_line):
            method = match.group(2).upper()
            raw = match.group(4)
            target = resolve_reference_target(raw, source_folder, known, requested_target_folder)

            if target:
                references[target].append(
                    Evidence(
                        source_rel,
                        line_number,
                        method,
                        "XMLHttpRequest open",
                        clean_snippet(line),
                        query_arg_names(raw) | inline_query_arg_names(parsed_line)
                    )
                )

        for match in JQUERY_POST_RE.finditer(parsed_line):
            raw = match.group(2)
            target = resolve_reference_target(raw, source_folder, known, requested_target_folder)

            if target:
                references[target].append(
                    Evidence(
                        source_rel,
                        line_number,
                        "POST",
                        "jQuery post",
                        clean_snippet(line),
                        query_arg_names(raw)
                    )
                )

        for match in MULTIPLE_INPUT_ACTION_RE.finditer(parsed_line):
            action = match.group(2).capitalize()
            raw = match.group(4)
            target = resolve_filename_query_target(raw, source_folder, known, requested_target_folder)
            if target:
                references[target].append(
                    Evidence(
                        source_rel,
                        line_number,
                        "GET",
                        f"multiple input {action}",
                        clean_snippet(line),
                        query_arg_names(raw) | inline_query_arg_names(parsed_line),
                    )
                )

        if JQUERY_AJAX_START_RE.search(parsed_line):
            pending_ajax_method = ""
            pending_ajax_start_line = line_number
            pending_ajax_snippet = clean_snippet(line)
            pending_ajax_ttl = 20

        if pending_ajax_ttl > 0:
            method_match = JQUERY_AJAX_TYPE_RE.search(parsed_line)
            if method_match:
                pending_ajax_method = method_match.group(2).upper()

            url_match = JQUERY_AJAX_URL_RE.search(parsed_line)
            if url_match:
                raw = url_match.group(2)
                method = pending_ajax_method or "GET"
                target = resolve_reference_target(raw, source_folder, known, requested_target_folder)

                if target:
                    references[target].append(
                        Evidence(
                            source_rel,
                            pending_ajax_start_line or line_number,
                            method,
                            "jQuery ajax",
                            pending_ajax_snippet or clean_snippet(line),
                            query_arg_names(raw)
                        )
                    )
                pending_ajax_method = ""
                pending_ajax_start_line = 0
                pending_ajax_snippet = ""
                pending_ajax_ttl = 0

        for match in IFRAME_RE.finditer(parsed_line):
            raw = match.group(2)
            target = resolve_reference_target(raw, source_folder, known, requested_target_folder)
            if target:
                references[target].append(
                    Evidence(
                        source_rel,
                        line_number,
                        "GET",
                        "iframe",
                        clean_snippet(line),
                        query_arg_names(raw),
                    )
                )
        for match in SHOWRETURN_REPLACE_RE.finditer(parsed_line):
            raw = "../showreturn/" + match.group(1)
            target = resolve_reference_target(raw, source_folder, known, requested_target_folder)
            if target:
                references[target].append(
                    Evidence(
                        source_rel,
                        line_number,
                        "GET",
                        "showreturn replacement",
                        clean_snippet(line),
                        query_arg_names(raw),
                    )
                )
        for match in BR_WINDOW_RE.finditer(parsed_line):
            raw = match.group(2)
            target = resolve_reference_target(raw, source_folder, known, requested_target_folder)
            if target:
                references[target].append(
                    Evidence(
                        source_rel,
                        line_number,
                        "GET",
                        "browser window function",
                        clean_snippet(line),
                        query_arg_names(raw),
                    )
                )
        for match in BUILD_SECURE_URL_RE.finditer(parsed_line):
            raw = match.group(2)
            target = resolve_reference_target(raw, source_folder, known, requested_target_folder)
            if target:
                references[target].append(
                    Evidence(
                        source_rel,
                        line_number,
                        "GET",
                        "BuildSecureURL",
                        clean_snippet(line),
                        query_arg_names(raw),
                    )
                )
        for match in QUERY_URL_RE.finditer(parsed_line):
            raw = match.group(1)
            target = resolve_filename_query_target(raw, source_folder, known, requested_target_folder)
            if target and target not in line_post_form_targets:
                references[target].append(
                    Evidence(
                        source_rel,
                        line_number,
                        "GET",
                        "query string URL",
                        clean_snippet(line),
                        query_arg_names(raw),
                    )
                )

        for match in CONCAT_QUERY_URL_RE.finditer(parsed_line):
            raw = match.group(2) + "?" + match.group(4)
            target = resolve_reference_target(raw, source_folder, known, requested_target_folder)
            if target and target not in line_post_form_targets:
                references[target].append(
                    Evidence(
                        source_rel,
                        line_number,
                        "GET",
                        "concatenated query string URL",
                        clean_snippet(line),
                        query_arg_names(raw) | inline_query_arg_names(parsed_line),
                    )
                )

        for pattern, reason in (
            (URL_ATTR_RE, "url attribute"),
            (JS_NAV_RE, "javascript navigation"),
            (PHP_LOCATION_RE, "header location"),
        ):
            for match in pattern.finditer(parsed_line):
                raw = match.group(2) if pattern is not PHP_LOCATION_RE else match.group(1)
                target = resolve_reference_target(raw, source_folder, known, requested_target_folder)

                if target:
                    references[target].append(
                        Evidence(
                            source_rel,
                            line_number,
                            "GET",
                            reason,
                            clean_snippet(line),
                            query_arg_names(raw)
                        )
                    )

        for match in UNQUOTED_URL_ATTR_RE.finditer(parsed_line):
            raw = match.group(1)
            target = resolve_reference_target(raw, source_folder, known, requested_target_folder)

            if target:
                references[target].append(
                    Evidence(
                        source_rel,
                        line_number,
                        "GET",
                        "url attribute",
                        clean_snippet(line),
                        query_arg_names(raw),
                    )
                )

        for value in FLOW_VAR_RE.findall(parsed_line):
            raw = value if value.lower().endswith(".php") else f"{value}.php"
            target = resolve_reference_target(raw, source_folder, known, requested_target_folder)

            if target:
                references[target].append(
                    Evidence(source_rel, line_number, "POST", "flow variable", clean_snippet(line))
                )

        if requested_target_folder == "html":
            for value in dict.fromkeys(NAVI_HTML_VALUE_RE.findall(parsed_line)):
                target = resolve_reference_target(
                    value,
                    source_folder,
                    known,
                    requested_target_folder,
                )
                if target:
                    references[target].append(
                        Evidence(
                            source_rel,
                            line_number,
                            "INPUT",
                            "navihtml input",
                            clean_snippet(line),
                        )
                    )

        if cp_dual_flow_rules and requested_target_folder in {"html", "oltproc"}:
            for value in dict.fromkeys(CP_DUAL_FLOW_RE.findall(parsed_line)):
                stem = Path(value).stem
                target_spec = (
                    ("html", f"{stem}.html", "INPUT", "CP nextCall input")
                    if requested_target_folder == "html"
                    else ("oltproc", f"{stem}.php", "POST", "CP nextCall POST")
                )
                target = resolve_known_target((target_spec[0], target_spec[1]), known)
                if target:
                    references[target].append(
                        Evidence(
                            source_rel,
                            line_number,
                            target_spec[2],
                            target_spec[3],
                            clean_snippet(line),
                        )
                    )

        if probase_dual_flow_rules and requested_target_folder in {"html", "oltproc"}:
            for value in dict.fromkeys(PROBASE_DUAL_FLOW_RE.findall(parsed_line)):
                stem = Path(value).stem
                target_spec = (
                    ("html", f"{stem}.html", "INPUT", "probase nextCall input")
                    if requested_target_folder == "html"
                    else ("oltproc", f"{stem}.php", "POST", "probase nextCall POST")
                )
                target = resolve_known_target((target_spec[0], target_spec[1]), known)
                if target:
                    references[target].append(
                        Evidence(
                            source_rel,
                            line_number,
                            target_spec[2],
                            target_spec[3],
                            clean_snippet(line),
                        )
                    )

        if base_loading_html_rules and requested_target_folder in {"html", "js", "csr"}:
            for value in BASE_LOADING_HTML_RE.findall(parsed_line):
                if Path(value).suffix:
                    continue
                raw = f"{value}.html"
                target = resolve_reference_target(raw, source_folder, known, requested_target_folder)
                if target:
                    references[target].append(
                        Evidence(
                            source_rel,
                            line_number,
                            "INPUT",
                            "base BASELoadingHTML input",
                            clean_snippet(line),
                        )
                    )

        if base_loading_html_rules:
            for value in BASE_LOADING_HTML_VALUE_RE.findall(parsed_line):
                if Path(value).suffix:
                    continue
                target_specs = (
                    [
                        (f"{value}.html", "INPUT", "base BASELoadingHTML input"),
                        (f"{value}.php", "POST", "base BASELoadingHTML POST"),
                    ]
                    if requested_target_folder == "csr"
                    else [
                        (f"{value}.html", "INPUT", "base BASELoadingHTML input")
                        if requested_target_folder in {"html", "js"}
                        else (f"{value}.php", "POST", "base BASELoadingHTML POST")
                    ]
                )
                for raw, method, reason in target_specs:
                    target = resolve_reference_target(
                        raw,
                        source_folder,
                        known,
                        requested_target_folder,
                    )
                    if target:
                        references[target].append(
                            Evidence(
                                source_rel,
                                line_number,
                                method,
                                reason,
                                clean_snippet(line),
                            )
                        )

        if mo_loading_html_rules:
            for match in MO_GEN_IMAGE_RE.finditer(parsed_line):
                raw = match.group(3)
                target = resolve_reference_target(
                    raw,
                    source_folder,
                    known,
                    requested_target_folder,
                )
                if target:
                    references[target].append(
                        Evidence(
                            source_rel,
                            line_number,
                            "GET",
                            "MO genImage second argument",
                            clean_snippet(line),
                            query_arg_names(raw),
                        )
                    )

            mo_loading_values = dict.fromkeys(
                MO_LOADING_HTML_RE.findall(parsed_line)
                + MO_ENCRYPTED_LOADING_HTML_RE.findall(parsed_line)
                + MO_QUERY_LOADING_HTML_RE.findall(parsed_line)
            )
            mo_flow_values = dict.fromkeys(MO_EXTENSIONLESS_FLOW_RE.findall(parsed_line))
            value_reasons = [
                (value, "MO MOLoadingHTML input", "MO MOLoadingHTML POST")
                for value in mo_loading_values
            ] + [
                (value, "MO extensionless flow input", "MO extensionless flow POST")
                for value in mo_flow_values
                if value not in mo_loading_values
            ]
            for value, input_reason, post_reason in value_reasons:
                if Path(value).suffix:
                    continue
                for raw, method, reason in (
                    (f"{value}.html", "INPUT", input_reason),
                    (f"{value}.php", "POST", post_reason),
                ):
                    target = resolve_reference_target(
                        raw,
                        source_folder,
                        known,
                        requested_target_folder,
                    )
                    if target:
                        references[target].append(
                            Evidence(
                                source_rel,
                                line_number,
                                method,
                                reason,
                                clean_snippet(line),
                            )
                        )

        if pending_form_ttl > 0:
            pending_form_ttl -= 1
        else:
            pending_form_method = ""
            pending_form_target = None

        if pending_ajax_ttl > 0:
            pending_ajax_ttl -= 1
            if pending_ajax_ttl == 0:
                pending_ajax_method = ""
                pending_ajax_start_line = 0
                pending_ajax_snippet = ""

    return file_refs, file_local_args


def extract_error_file_references(
    source_path: Path,
    source_folder: str,
    source_rel: str,
    target_names: Dict[str, str],
) -> Dict[Tuple[str, str], List[Evidence]]:
    """Extract references to concrete error filenames with minimal parsing."""
    references: Dict[Tuple[str, str], List[Evidence]] = defaultdict(list)
    include_context = COMMON_INCLUDE_CONTEXT_RE
    for line_number, line in enumerate(
        uncomment_code_lines(cached_file_lines(source_path)), start=1
    ):
        lower_line = line.lower()
        matched_targets = [
            canonical_name
            for lower_name, canonical_name in target_names.items()
            if lower_name in lower_line
        ]
        if not matched_targets:
            continue

        if include_context.search(line):
            method, reason = "Common", "include/require"
        elif "<form" in lower_line:
            method = "POST" if re.search(r"\bmethod\s*=\s*['\"]?post\b", lower_line) else "GET"
            reason = "error form action"
        elif any(
            marker in lower_line
            for marker in ("$.post", "method: 'post'", 'method: "post"', "type: 'post'", 'type: "post"')
        ):
            method, reason = "POST", "error AJAX reference"
        else:
            method, reason = "GET", "error URL reference"

        for target_name in matched_targets:
            references[("error", target_name)].append(
                Evidence(
                    source_rel,
                    line_number,
                    method,
                    reason,
                    clean_snippet(line),
                    query_arg_names(line),
                )
            )
    return references


def collect_references(
    taxyear: str,
    target_folder: str,
    progress: Optional[Callable[[str, int, int], None]] = None,
    target_file_name: str = "",
) -> Tuple[Dict[Tuple[str, str], List[Evidence]], Dict[Tuple[str, str], Dict[str, Set[str]]]]:
    targeted_single_file = bool(target_file_name and target_folder != "error")
    known = (
        {(target_folder, Path(target_file_name).name)}
        if targeted_single_file
        else existing_targets(taxyear)
    )
    references: Dict[Tuple[str, str], List[Evidence]] = defaultdict(list)
    local_args: Dict[Tuple[str, str], Dict[str, Set[str]]] = defaultdict(lambda: {"get": set(), "post": set()})
    source_files = [] if targeted_single_file else iter_source_files(taxyear, target_folder)
    target_needles: Set[str] = set()
    error_fingerprint = ""
    if target_folder == "error":
        error_fingerprint = source_files_fingerprint(source_files)
        cached_error_references = load_error_reference_cache(taxyear, error_fingerprint)
        if cached_error_references is not None:
            return cached_error_references, local_args
        # Error references are intentionally limited to html + oltproc.  Most
        # files in those large folders do not mention an error target at all,
        # so avoid the full multi-regex parser and per-file disk-cache write
        # unless a target filename (or its extensionless stem) is present.
        error_target_names = {
            name.lower(): name
            for known_folder, name in known
            if known_folder == target_folder
        }
        # Generic error references contain the concrete PHP/HTML filename.
        # Searching broad extensionless stems (for example "navigate") pulls
        # thousands of unrelated sources into the expensive detailed parser.
        target_needles = set(error_target_names)
        if target_needles:
            rg_executable = shutil.which("rg")
            filtered_sources: Optional[List[Path]] = None
            if rg_executable:
                source_roots = sorted({str(path.parent) for path in source_files})
                command = [
                    rg_executable,
                    "--files-with-matches",
                    "--ignore-case",
                    "--fixed-strings",
                    "--no-messages",
                    "--max-depth",
                    "1",
                ]
                for needle in sorted(target_needles):
                    command.extend(("-e", needle))
                command.extend(source_roots)
                search = subprocess.run(
                    command,
                    capture_output=True,
                    text=True,
                    check=False,
                )
                if search.returncode in (0, 1):
                    matched_paths = {
                        os.path.normcase(os.path.abspath(line.strip()))
                        for line in search.stdout.splitlines()
                        if line.strip()
                    }
                    filtered_sources = [
                        path for path in source_files
                        if os.path.normcase(os.path.abspath(str(path))) in matched_paths
                    ]

            if filtered_sources is None:
                def mentions_error_target(source_path: Path) -> bool:
                    source_text = read_file_text(source_path).lower()
                    return any(needle in source_text for needle in target_needles)

                worker_count = min(8, max(1, os.cpu_count() or 1))
                with ThreadPoolExecutor(max_workers=worker_count) as executor:
                    mentioned = executor.map(mentions_error_target, source_files)
                    filtered_sources = [
                        source_path
                        for source_path, has_target in zip(source_files, mentioned)
                        if has_target
                    ]
            source_files = filtered_sources

    if targeted_single_file:
        target_name = Path(target_file_name).name.lower()
        target_stem = Path(target_file_name).stem.lower()
        needles = {value for value in (target_name, target_stem) if value}
        filtered_sources: Optional[List[Path]] = None
        source_roots = [
            source_folder_path(str(taxyear), folder)
            for folder in source_folders_for_taxyear_target(taxyear, target_folder)
            if source_folder_path(str(taxyear), folder).is_dir()
        ]
        year_root = SITE_ASP_ROOT / str(taxyear)
        if str(taxyear).lower() == "mo" and year_root.is_dir():
            source_roots.append(year_root)
        rg_executable = shutil.which("rg")
        if rg_executable and needles and source_roots:
            command = [
                rg_executable,
                "--files-with-matches",
                "--ignore-case",
                "--fixed-strings",
                "--no-ignore",
                "--no-messages",
                "--iglob",
                "*.php",
                "--iglob",
                "*.html",
                "--iglob",
                "*.js",
                "--max-depth",
                "1",
            ]
            for needle in sorted(needles):
                command.extend(("-e", needle))
            command.extend(str(root) for root in source_roots)
            try:
                search = subprocess.run(
                    command,
                    capture_output=True,
                    text=True,
                    check=False,
                )
                if search.returncode in (0, 1):
                    filtered_sources = sorted({
                        Path(line.strip())
                        for line in search.stdout.splitlines()
                        if line.strip()
                        and Path(line.strip()).suffix.lower() in (".php", ".html", ".js")
                    })
            except OSError:
                filtered_sources = None

        if filtered_sources is None:
            candidates = [
                path
                for root in source_roots
                for path in root.iterdir()
                if path.is_file() and path.suffix.lower() in (".php", ".html", ".js")
            ]
            filtered_sources = [
                path for path in candidates
                if any(needle in read_file_text(path).lower() for needle in needles)
            ]

        # Always parse the target itself so its local GET/POST variables are
        # collected even when it does not reference its own filename.
        target_path = source_folder_path(str(taxyear), target_folder) / Path(target_file_name).name
        target_sources = [target_path] if target_path.is_file() else []
        source_files = sorted(dict.fromkeys([*filtered_sources, *target_sources]))
    total_sources = len(source_files)
    memory_cache_hits = 0
    disk_cache_hits = 0
    cache_misses = 0

    if target_folder == "error":
        def extract_error_source(source_path: Path) -> Tuple[Path, Dict[Tuple[str, str], List[Evidence]]]:
            source_folder = folder_for_path(source_path, taxyear)
            source_rel = rel_file(taxyear, source_folder, source_path.name)
            return source_path, extract_error_file_references(
                source_path,
                source_folder,
                source_rel,
                error_target_names,
            )

        worker_count = min(8, max(1, os.cpu_count() or 1))
        with ThreadPoolExecutor(max_workers=worker_count) as executor:
            extracted_sources = executor.map(extract_error_source, source_files)
            for source_idx, (source_path, file_refs) in enumerate(extracted_sources, start=1):
                if progress:
                    progress(
                        f"references: {folder_for_path(source_path, taxyear)}/{source_path.name}",
                        source_idx,
                        total_sources,
                    )
                for target, evidences in file_refs.items():
                    references[target].extend(evidences)

        print(
            f"[SCAN SUMMARY] {target_folder}: targeted scan of {total_sources} matching file(s)",
            flush=True,
        )
        save_error_reference_cache(taxyear, error_fingerprint, references)
        return references, local_args

    for source_idx, source_path in enumerate(source_files, start=1):
        source_folder = folder_for_path(source_path, taxyear)
        source_name = source_path.name
        source_rel = rel_file(taxyear, source_folder, source_name)
        if progress:
            progress(f"references: {source_folder}/{source_name}", source_idx, total_sources)

        cache_key = f"{source_path}|target={target_folder}"
        try:
            stat = source_path.stat()
        except OSError:
            continue

        # A full folder build writes complete evidence for this source and
        # target folder. A targeted rebuild only consumes the matching target
        # from that complete entry, so the same fresh cache is safe to reuse.
        cached_entry = _FILE_REFERENCE_CACHE.get(cache_key)
        if (
            cached_entry is not None
            and cached_entry["mtime"] == stat.st_mtime
            and cached_entry["size"] == stat.st_size
        ):
            memory_cache_hits += 1
            file_refs, file_local_args = cached_entry["refs"], cached_entry["local_args"]
        else:
            disk_entry = load_disk_file_reference_cache(
                taxyear, cache_key, stat.st_mtime, stat.st_size
            )
            if disk_entry is not None:
                disk_cache_hits += 1
                file_refs, file_local_args = disk_entry["refs"], disk_entry["local_args"]
                _FILE_REFERENCE_CACHE[cache_key] = disk_entry
            else:
                cache_misses += 1
                file_refs, file_local_args = _extract_file_references(
                    source_path,
                    source_folder,
                    source_name,
                    source_rel,
                    known,
                    target_folder,
                    base_loading_html_rules=str(taxyear).lower() in {"base", "probase"},
                    mo_loading_html_rules=str(taxyear).lower() == "mo",
                    cp_dual_flow_rules=str(taxyear).lower() == "cp",
                    probase_dual_flow_rules=str(taxyear).lower() == "probase",
                    path_variable_include_rules=str(taxyear).strip().isdigit(),
                )
                if not targeted_single_file:
                    # Targeted extraction uses a one-file ``known`` set. Do not
                    # overwrite the complete folder cache with that partial
                    # evidence; the next full build will refresh any miss.
                    _FILE_REFERENCE_CACHE[cache_key] = {
                        "mtime": stat.st_mtime,
                        "size": stat.st_size,
                        "refs": file_refs,
                        "local_args": file_local_args,
                    }
                    save_disk_file_reference_cache(
                        taxyear,
                        cache_key,
                        stat.st_mtime,
                        stat.st_size,
                        file_refs,
                        file_local_args,
                    )

        source_key = (source_folder, source_name)
        for target, evidences in file_refs.items():
            references[target].extend(evidences)
        local_args[source_key]["get"].update(file_local_args.get("get", set()))
        local_args[source_key]["post"].update(file_local_args.get("post", set()))

    print(
        f"[SCAN SUMMARY] {target_folder}: {memory_cache_hits} memory cache hit(s), "
        f"{disk_cache_hits} disk cache hit(s), {cache_misses} cache miss(es), "
        f"{total_sources} file(s) total",
        flush=True,
    )
    if target_folder == "error":
        save_error_reference_cache(taxyear, error_fingerprint, references)
    return references, local_args


def collect_main_folder_references(
    folder: str,
    progress: Optional[Callable[[str, int, int], None]] = None,
) -> Tuple[Dict[Tuple[str, str], List[Evidence]], Dict[Tuple[str, str], Dict[str, Set[str]]]]:
    """Collect flow evidence for files in a recursively scanned main folder.

    PHP targets may be in the root or a configured subfolder. Callers are
    PHP, HTML, and JavaScript files anywhere below the folder. The regular
    reference extractor supplies the GET/POST/include and AJAX handling.
    """
    folder_root = SITE_ASP_ROOT / "main" / folder
    target_paths = [
        path for path in candidate_paths_for_folder(folder_root, folder)
        if path.suffix.lower() in {".php", ".html"}
    ]
    known = {
        (folder, relative_file_name(folder_root, path))
        for path in target_paths
    }
    references: Dict[Tuple[str, str], List[Evidence]] = defaultdict(list)
    local_args: Dict[Tuple[str, str], Dict[str, Set[str]]] = defaultdict(
        lambda: {"get": set(), "post": set()}
    )
    source_paths = [
        path for path in sorted(folder_root.rglob("*"))
        if path.is_file() and path.suffix.lower() in {".php", ".html", ".js"}
    ]
    extra_oltproc_root = SITE_ASP_ROOT / "2025" / "OLTPRO" / "oltproc"
    if extra_oltproc_root.exists():
        source_paths += [
            path for path in sorted(extra_oltproc_root.glob("*"))
            if path.is_file() and path.suffix.lower() in {".php", ".html", ".js"}
        ]
    total_sources = len(source_paths)
    for source_idx, source_path in enumerate(source_paths, start=1):
        if extra_oltproc_root.exists() and _path_is_within(source_path, extra_oltproc_root):
            source_name = source_path.name
            source_rel = rel_file("2025", "OLTPRO/oltproc", source_name)
        else:
            source_name = relative_file_name(folder_root, source_path)
            source_rel = rel_file("main", folder, source_name)
        if progress:
            progress(f"references: {folder}/{source_name}", source_idx, total_sources)
        file_refs, file_local_args = _extract_file_references(
            source_path,
            folder,
            source_name,
            source_rel,
            known,
            folder,
        )
        for target, evidences in file_refs.items():
            references[target].extend(evidences)
        source_key = (folder, source_name)
        local_args[source_key]["get"].update(file_local_args.get("get", set()))
        local_args[source_key]["post"].update(file_local_args.get("post", set()))
    return references, local_args


def collect_code_move_references(
    taxyear: str,
    target_folder: str,
    target_file_name: str,
    staged_entries: Sequence[Dict],
) -> Tuple[Dict[Tuple[str, str], List[Evidence]], Dict[Tuple[str, str], Dict[str, Set[str]]]]:
    """Collect one target's evidence only from staged Code Move files."""
    taxyear_key = str(taxyear).lower()
    allowed_source_folders = {
        str(folder).lower()
        for folder in (
            (target_folder,)
            if taxyear_key == "partner"
            else source_folders_for_taxyear_target(taxyear, target_folder)
        )
    }
    target_name = str(target_file_name).replace("\\", "/")
    known = {(target_folder, target_name)}
    references: Dict[Tuple[str, str], List[Evidence]] = defaultdict(list)
    local_args: Dict[Tuple[str, str], Dict[str, Set[str]]] = defaultdict(
        lambda: {"get": set(), "post": set()}
    )

    for entry in staged_entries:
        if entry.get("error") or str(entry.get("taxyear", "")).lower() != taxyear_key:
            continue
        source_folder = str(entry.get("folder", ""))
        if source_folder.lower() not in allowed_source_folders:
            continue
        source_path = Path(str(entry.get("staged_path", "")))
        if (
            not source_path.is_file()
            or source_path.suffix.lower() not in {".php", ".html", ".js"}
        ):
            continue

        source_name = str(entry.get("file_name") or source_path.name).replace("\\", "/")
        source_rel = rel_file(str(taxyear), source_folder, source_name)
        file_refs, file_local_args = _extract_file_references(
            source_path,
            source_folder,
            source_name,
            source_rel,
            known,
            target_folder,
            base_loading_html_rules=taxyear_key in {"base", "probase"},
            mo_loading_html_rules=taxyear_key == "mo",
            cp_dual_flow_rules=taxyear_key == "cp",
            probase_dual_flow_rules=taxyear_key == "probase",
            path_variable_include_rules=str(taxyear).strip().isdigit(),
        )
        for target, evidences in file_refs.items():
            references[target].extend(evidences)
        source_key = (source_folder, source_name)
        local_args[source_key]["get"].update(file_local_args.get("get", set()))
        local_args[source_key]["post"].update(file_local_args.get("post", set()))

    return references, local_args


def metadata_record(
    taxyear: str,
    folder: str,
    path: Path,
    evidence: Sequence[Evidence],
    local_args: Dict[str, Set[str]],
    forced_method: str = "",
    relative_name: str = "",
    apply_folder_rule: bool = True,
) -> Dict:
    relative_name = relative_name or path.name
    if apply_folder_rule:
        forced_method = folder_rule_method(folder, path, evidence, forced_method)
    methods = [forced_method] if forced_method else sorted({item.method for item in evidence}, key=lambda m: METHOD_PRIORITY.index(m) if m in METHOD_PRIORITY else 99)
    method = forced_method or classify_primary(methods)
    query_args = sorted(set().union(*(item.args for item in evidence)) | local_args.get("get", set()))
    post_args = sorted(local_args.get("post", set()))
    callers = sorted({item.source_file for item in evidence})
    called_from_flow = any(item.method in {"GET", "POST", "INPUT"} for item in evidence)
    static_no_flow = folder in {"jscripts", "styles", "images", "image", "code_bg_img", "fonts", "Original"} or path.suffix.lower() in STATIC_GET_EXTENSIONS
    if forced_method in {"GET", "POST", "INPUT"} and not static_no_flow:
        called_from_flow = True
    if method == "HEAD":
        called_from_flow = True
    return {
        "taxyear": str(taxyear),
        "folder": folder,
        "file_name": rel_file(str(taxyear), folder, relative_name),
        "base_name": relative_name,
        "method": method,
        "methods": methods or ["ANALYSE"],
        "called_from_flow": "yes" if called_from_flow else "No",
        "fed_or_state": metadata_state(folder, relative_name, path.name),
        "allowed_get_arguments": query_args,
        "post_querystring_arguments": sorted(set().union(*(item.args for item in evidence if item.method == "POST"))),
        "post_body_variables": post_args,
        "called_by_count": len(callers),
        "called_by": callers[:50],
        "evidence": [
            {
                "source_file": item.source_file,
                "source_line": item.source_line,
                "method": item.method,
                "reason": item.reason,
                "snippet": item.snippet,
                "args": sorted(item.args),
            }
            for item in evidence[:25]
        ],
        "size_bytes": path.stat().st_size,
        "updated_at": datetime.now(timezone.utc).isoformat(),
    }


def candidate_paths_for_folder(folder_path: Path, folder: str) -> List[Path]:
    if folder.lower() == "partner" and folder_path.name.lower() == "partner":
        # The special Partner selector includes only files directly under the
        # Partner root; its top-level library directories are built separately.
        return [path for path in sorted(folder_path.iterdir()) if path.is_file()]

    if folder_path.parent.name.lower() == "partner":
        # Partner libraries are selected by top-level directory, but every file
        # below that directory is a build candidate.
        return [path for path in sorted(folder_path.rglob("*")) if path.is_file()]

    if folder_path.parent.name.lower() == "cp" and folder in {"css", "fonts", "images", "js"}:
        return [path for path in sorted(folder_path.iterdir()) if path.is_file()]

    if folder_path.parent.name.lower() == "main" and folder in MAIN_RECURSIVE_FLOW_FOLDERS:
        records: List[Path] = [
            path for path in sorted(folder_path.iterdir())
            if path.is_file() and path.suffix.lower() == ".php"
        ]
        estimator_filter = lambda path: (
                path.parent == folder_path / "estimator" and path.suffix.lower() == ".php"
            ) or (
                len(path.relative_to(folder_path / "estimator").parts) >= 2
                and path.relative_to(folder_path / "estimator").parts[0] in {str(year) for year in range(2018, 2026)}
            )
        if folder == "home":
            configured = {
                "cobrand": lambda path: path.suffix.lower() == ".css",
                "js": lambda path: True,
                "fonts": lambda path: path.suffix.lower() in (".ttf", ".svg", ".woff", ".woff2", ".otf"),
                "estimator": estimator_filter,
                "images": lambda path: True,
                "meta": lambda path: True,
                "common": lambda path: True,
                "css": lambda path: True,
            }
        elif folder == "pro":
            configured = {
                "estimator": estimator_filter,
                "inc": lambda path: True,
                "js": lambda path: True,
                "images": lambda path: True,
                "meta": lambda path: True,
                "css": lambda path: True,
                "styles": lambda path: True,
                "TaxMart": lambda path: True,
                "original": lambda path: True,
                "fonts": lambda path: True,
            }
        else:
            configured = {
                "css": lambda path: True,
                "estimator": estimator_filter,
                "fonts": lambda path: True,
                "images": lambda path: True,
                "js": lambda path: True,
            }
            if folder != "ftax":
                configured.update({
                    "common": lambda path: True,
                    "meta": lambda path: True,
                })
        for subfolder, include_path in configured.items():
            subfolder_path = folder_path / subfolder
            if not subfolder_path.exists():
                continue
            records.extend(
                path for path in sorted(subfolder_path.rglob("*"))
                if path.is_file() and include_path(path)
            )
        return sorted(dict.fromkeys(records))

    if folder_path.parent.name.lower() in {"base", "probase"}:
        if folder == "js":
            return [
                path for path in sorted(folder_path.iterdir())
                if path.is_file() and path.suffix.lower() in (".js", ".html", *STATIC_GET_EXTENSIONS)
            ]
        if folder == "images":
            return [
                path for path in sorted(folder_path.iterdir())
                if path.is_file() and path.suffix.lower() in (".php", ".html", *STATIC_GET_EXTENSIONS)
            ]

    if folder_path.parent.name.lower() == "mo":
        if folder == "help":
            return [
                path for path in sorted(folder_path.iterdir())
                if path.is_file() and path.suffix.lower() == ".png"
            ]
        if folder == "jscripts":
            return [
                path for path in sorted(folder_path.iterdir())
                if path.is_file() and path.suffix.lower() in (".js", ".html", *STATIC_GET_EXTENSIONS)
            ]
        if folder == "images":
            return [
                path for path in sorted(folder_path.iterdir())
                if path.is_file() and path.suffix.lower() in (".php", ".html", *STATIC_GET_EXTENSIONS)
            ]

    if folder == "efile":
        # Efile has no subdirectories for scanning; record direct files only.
        return cached_all_direct_files(folder_path.parent.name, folder)
    if folder == "efilebank":
        # Efilebank has no subdirectories for scanning; record direct files only.
        return cached_all_direct_files(folder_path.parent.name, folder)
    
    if folder == "efilePartner":
        # Efilepartner has no subdirectories for scanning; record direct files only.
        return cached_all_direct_files(folder_path.parent.name, folder)

    if folder == "OLTPRO":
        records: List[Path] = []
        if not folder_path.exists():
            return records
        for subfolder in sorted(OLTPRO_SUBFOLDERS):
            subfolder_path = folder_path / subfolder
            if not subfolder_path.exists():
                continue
            if subfolder == "TMS":
                records.extend(path for path in sorted(subfolder_path.rglob("*")) if path.is_file())
            else:
                records.extend(path for path in sorted(subfolder_path.iterdir()) if path.is_file())
        return records
    if folder == "wfi":
        allowed_suffixes = (".php", ".html", *STATIC_GET_EXTENSIONS)
        results = []
        for path in sorted(folder_path.rglob("*")):
            if not path.is_file() or path.suffix.lower() not in allowed_suffixes:
                continue
            parts = path.relative_to(folder_path).parts
            if len(parts) < 3:
                continue
            area, subfolder = parts[0], parts[1].lower()
            if area.lower() == "common" and subfolder in WFI_COMMON_SUBFOLDERS:
                results.append(path)
            elif area in WFI_STATE_FOLDERS and subfolder in WFI_STANDARD_SUBFOLDERS:
                results.append(path)
        return results
    if folder == "Staffolt":
        # Staffolt record scope: include only direct Staffolt/*.html,
        # direct Staffolt/*.php, and direct files in these allowed
        # subfolders: css, images, js, inc. Skip all other subfolders
        # so create_vectordb does not waste time recording unrelated files.
        records: List[Path] = []
        if folder_path.exists():
            records.extend(
                path for path in sorted(folder_path.iterdir())
                if path.is_file() and path.suffix.lower() in (".html", ".php")
            )

            allowed_subfolders = {
                "css": (".css",),
                "images": STAFFOLT_IMAGE_SUFFIXES,
                "js": (".js",),
                "inc": (".php",),
            }
            for subfolder, suffixes in allowed_subfolders.items():
                subfolder_path = folder_path / subfolder
                if not subfolder_path.exists():
                    continue
                records.extend(
                    path for path in sorted(subfolder_path.iterdir())
                    if path.is_file() and path.suffix.lower() in suffixes
                )
        return records
    if folder == "tool_tips":
        return [path for path in sorted(folder_path.rglob("*")) if path.is_file()]
    if folder == "inc":
        return cached_direct_files(folder_path.parent.name, folder, (".php", ".html", ".js"))
    if folder == "jscripts":
        return [
            path for path in sorted(folder_path.iterdir())
            if path.is_file() and path.suffix.lower() in (".js", ".html", *STATIC_GET_EXTENSIONS)
        ]
    if folder == "styles":
        return [path for path in sorted(folder_path.iterdir()) if path.is_file()]
    if folder == "Original":
        return [path for path in sorted(folder_path.iterdir()) if path.is_file() and path.suffix.lower() == ".pdf"]
    if folder not in {"html", "oltproc", "images"}:
        return [path for path in sorted(folder_path.iterdir()) if path.is_file()]
    return [
        path for path in sorted(folder_path.iterdir())
        if path.is_file() and path.suffix.lower() in (".php", ".html", *STATIC_GET_EXTENSIONS)
    ]



def folder_needs_references(folder: str) -> bool:
    if folder in {"wfi", "efile", "OLTPRO", "efilebank", "efilePartner"}:
        return False
    if folder == "csr_tax_links":
        return False
    if folder == "Original":
        # Original/*.pdf method is decided purely by is_original_pdf_used()
        # (a targeted lookup in showreturn and OLTPRO/html or OLTPRO/oltproc).
        # The generic flow-evidence pass is not used for this folder.
        return False
    if folder in FORCED_FOLDER_METHODS:
        return False
    return True


def base_folder_needs_references(folder: str) -> bool:
    return folder not in {"css", "tool_tips"}


def mo_folder_needs_references(folder: str) -> bool:
    return folder not in {"help", "jscripts", "styles"}


def cp_folder_needs_references(folder: str) -> bool:
    return folder not in {"css", "fonts", "images", "js"}


def image_candidates_need_references(candidate_paths: Sequence[Path]) -> bool:
    """Return whether an images build contains a flow-sensitive handler.

    Static assets are always GET.  A conventional images/index.php is also a
    direct GET landing/redirect endpoint, so neither case benefits from the
    expensive tax-year-wide reference scan.  Other PHP/HTML candidates retain
    the existing evidence-based classification.
    """
    return any(
        path.suffix.lower() not in STATIC_GET_EXTENSIONS
        and path.name.lower() != "index.php"
        for path in candidate_paths
    )


def cp_method_for_path(
    folder: str,
    evidence: Sequence[Evidence],
) -> Tuple[str, List[Evidence]]:
    evidence_list = list(evidence)
    if folder in {"css", "fonts", "images", "js"}:
        return "GET", evidence_list
    if folder == "html" and any(
        item.method == "INPUT" and item.reason == "CP nextCall input"
        for item in evidence
    ):
        return "INPUT", evidence_list
    flow_evidence = [item for item in evidence if item.method in {"GET", "POST"}]
    if flow_evidence:
        return classify_primary(item.method for item in flow_evidence), evidence_list
    if is_included(evidence):
        return "Common", evidence_list
    return "ANALYSE", evidence_list


def main_folder_method_for_path(
    folder: str,
    path: Path,
    relative_name: str,
    evidence: Sequence[Evidence],
) -> Tuple[str, List[Evidence]]:
    """Apply the explicit rules for a recursively analysed main folder."""
    evidence_list = list(evidence)
    filename = path.name.lower()
    if path.exists() and path.stat().st_size == 0:
        return "DEAD", evidence_list
    if folder == "pro" and path.name.lower().endswith("state.php"):
        return "GET", evidence_list
    if path.name.lower().startswith("sessionended"):
        return "GET", evidence_list
    if path.name.lower().startswith(
        ("getstarted", "continuereturn", "logout_new")
    ):
        return "GET", evidence_list

    if filename.lower().startswith(
        tuple(prefix.lower() for prefix in MAIN_COMMON_FILENAME_PREFIXES)
    ):
        return "GET", evidence_list

    file_stem = path.stem.lower()
    if folder == "pro" and file_stem.endswith(("_login", "createaccount")):
        return "GET", evidence_list

    parts = Path(relative_name).parts
    if len(parts) == 1 and path.suffix.lower() == ".php":
        flow_evidence = [item for item in evidence if item.method in {"GET", "POST"}]
        if flow_evidence:
            return classify_primary(item.method for item in flow_evidence), evidence_list
        if is_included(evidence):
            return "Common", evidence_list
        return "ANALYSE", evidence_list

    top_folder = parts[0].lower() if len(parts) > 1 else ""
    if folder == "home":
        get_folders = {"cobrand", "js", "fonts", "images", "css"}
        common_folders = {"meta", "common"}
    elif folder == "pro":
        get_folders = {"css", "styles", "taxmart", "fonts", "js", "images", "original"}
        common_folders = {"meta", "inc"}
    else:
        get_folders = {"css", "fonts", "images", "js"}
        common_folders = {"common", "meta"}
    if top_folder in get_folders:
        return "GET", evidence_list
    if top_folder in common_folders:
        flow_evidence = [item for item in evidence if item.method in {"GET", "POST"}]
        if flow_evidence:
            return classify_primary(item.method for item in flow_evidence), evidence_list
        return "Common", evidence_list
    if top_folder == "estimator":
        if len(parts) == 2 and path.suffix.lower() == ".php":
            return "GET", evidence_list
        if len(parts) >= 3 and parts[1] in {str(year) for year in range(2018, 2026)}:
            return ("GET" if path.name.lower() == "estimate.php" else "Common"), evidence_list
    return "ANALYSE", evidence_list


def mo_method_for_path(folder: str, path: Path, evidence: Sequence[Evidence]) -> Tuple[str, List[Evidence]]:
    """Classify a SITE_ASP_ROOT/MO folder using MO-local reference scopes."""
    evidence_list = list(evidence)
    if path.stat().st_size == 0:
        return "DEAD", evidence_list
    if path.suffix.lower() in (*STATIC_GET_EXTENSIONS, ".css", ".js", ".pdf"):
        return "GET", evidence_list
    if folder == "page_info":
        return (
            "PAGEINFO" if is_html_page_info(evidence_list) else "ANALYSE",
            evidence_list,
        )
    if folder == "csr" and path.suffix.lower() == ".css":
        return "GET", evidence_list
    if folder == "styles" and path.name.lower().startswith("mo_styles"):
        return "GET", evidence_list
    if folder == "help":
        return "GET", evidence_list
    if folder in {"styles", "jscripts"}:
        return "GET", evidence_list
    if path.suffix.lower() in STATIC_GET_EXTENSIONS:
        return "GET", evidence_list

    if path.suffix.lower() == ".html" and any(
        item.method == "INPUT"
        and item.reason in {"MO MOLoadingHTML input", "MO extensionless flow input"}
        for item in evidence
    ):
        return "INPUT", evidence_list

    flow_evidence = [item for item in evidence if item.method in {"GET", "POST", "INPUT"}]
    if flow_evidence:
        return classify_primary(item.method for item in flow_evidence), evidence_list
    if is_included(evidence):
        return "Common", evidence_list
    return "ANALYSE", evidence_list


def base_method_for_path(folder: str, path: Path, evidence: Sequence[Evidence]) -> Tuple[str, List[Evidence]]:
    """Classify a SITE_ASP_ROOT/base folder using its normal-folder analogue."""
    if path.stat().st_size == 0:
        return "DEAD", list(evidence)
    if folder == "page_info":
        evidence_list = list(evidence)
        return (
            "PAGEINFO" if is_html_page_info(evidence_list) else "ANALYSE",
            evidence_list,
        )

    if folder == "oltproc" and path.name.lower().startswith("sitesettings"):
        return "Common", list(evidence)

    is_base_html = folder == "html" or (
        folder in {"js", "csr"} and path.suffix.lower() == ".html"
    )
    if is_base_html and any(
        item.method == "INPUT"
        and item.reason in {"base BASELoadingHTML input", "probase nextCall input"}
        for item in evidence
    ):
        # BASELoadingHTML explicitly identifies the HTML input template.  A
        # separate link to the same file must not promote it to GET.
        return "INPUT", list(evidence)

    normal_folder = (
        "html"
        if is_base_html
        else {"css": "styles", "js": "jscripts"}.get(folder, folder)
    )
    normal_method = folder_rule_method(normal_folder, path, evidence)
    if normal_method:
        return normal_method, list(evidence)
    if path.suffix.lower() in STATIC_GET_EXTENSIONS:
        return "GET", list(evidence)

    flow_evidence = [item for item in evidence if item.method in {"GET", "POST", "INPUT"}]
    if flow_evidence:
        return classify_primary(item.method for item in flow_evidence), list(evidence)
    if is_included(evidence):
        return "Common", list(evidence)
    return "ANALYSE", list(evidence)


def partner_deterministic_method(folder: str, relative_name: str, path: Path) -> str:
    """Return a fixed Partner method, or blank when evidence scanning is needed."""
    folder_key = folder.lower()
    relative_parts = relative_name.split("/")
    is_nested = len(relative_parts) > 1
    top_subfolder = relative_parts[0].lower()

    if folder_key in PARTNER_ALL_GET_FOLDERS:
        return "GET"
    if path.suffix.lower() in PARTNER_STATIC_GET_EXTENSIONS:
        return "GET"
    filename_method = partner_filename_method(path)
    if filename_method:
        return filename_method
    if folder_key in PARTNER_ALL_COMMON_FOLDERS:
        return "Common"
    if folder_key in PARTNER_COMMON_NESTED_FOLDERS and is_nested:
        return "Common"
    if folder_key == "g2fa" and is_nested and top_subfolder == "phpqrcode":
        return "Common"
    if folder_key == "geo" and is_nested and top_subfolder == "db":
        return "Common"
    if folder_key == "rgraph" and is_nested and path.suffix.lower() == ".js":
        return "GET"
    if path.suffix.lower() not in PARTNER_TEXT_SUFFIXES:
        return "Common"
    return ""


def partner_filename_method(path: Path) -> str:
    """Return the deterministic Partner method implied by a filename."""
    filename = path.name.lower()
    if any(token in filename for token in PARTNER_COMMON_FILENAME_CONTAINS):
        return "Common"
    if filename.endswith(PARTNER_GET_FILENAME_SUFFIXES):
        return "GET"
    return ""


def partner_folder_needs_references(folder: str) -> bool:
    folder_key = folder.lower()
    return folder_key not in PARTNER_ALL_COMMON_FOLDERS | PARTNER_ALL_GET_FOLDERS


def collect_partner_references(
    folder: str,
    folder_path: Path,
    candidate_paths: Sequence[Path],
    progress: Optional[Callable[[str, int, int], None]] = None,
) -> Tuple[Dict[Tuple[str, str], List[Evidence]], Dict[Tuple[str, str], Dict[str, Set[str]]]]:
    """Collect GET/POST/Common evidence only inside one Partner directory tree."""
    relative_targets: Dict[str, str] = {}
    basename_targets: Dict[str, List[str]] = defaultdict(list)
    for path in candidate_paths:
        relative_name = relative_file_name(folder_path, path)
        if partner_deterministic_method(folder, relative_name, path):
            # Deterministic Partner records do not participate as reference
            # sources or targets; only the remaining files are scanned.
            continue
        if forced_file_method(folder, relative_name, path.name, taxyear="partner"):
            continue
        relative_targets[relative_name.lower()] = relative_name
        basename_targets[path.name.lower()].append(relative_name)

    def resolve_partner_token(token: str) -> Set[str]:
        token = token.strip(" \t\r\n\"'()[]{}<>,;:").replace("\\", "/")
        while token.startswith("../") or token.startswith("./"):
            token = token.split("/", 1)[1]
        token_key = token.lstrip("/").lower()
        if not token_key:
            return set()
        exact = relative_targets.get(token_key)
        if exact:
            return {exact}
        token_parts = token_key.split("/")
        suffix_match = next(
            (
                relative_targets["/".join(token_parts[offset:])]
                for offset in range(1, len(token_parts))
                if "/".join(token_parts[offset:]) in relative_targets
            ),
            "",
        )
        if suffix_match:
            return {suffix_match}
        return set(basename_targets.get(Path(token_key).name.lower(), ()))

    references: Dict[Tuple[str, str], List[Evidence]] = defaultdict(list)
    seen: Set[Tuple[str, str, int, str]] = set()
    source_paths = [
        path for path in candidate_paths
        if path.suffix.lower() in PARTNER_TEXT_SUFFIXES
    ]
    total = len(source_paths)
    for index, source_path in enumerate(source_paths, start=1):
        if progress:
            progress(f"Scanning {relative_file_name(folder_path, source_path)}", index, total)
        source_relative = relative_file_name(folder_path, source_path)
        source_is_deterministic = bool(
            partner_deterministic_method(folder, source_relative, source_path)
        )
        for line_number, line in enumerate(
            uncomment_code_lines(cached_file_lines(source_path)), start=1
        ):
            method, reason = common_reference_method(
                line,
                default_method="",
                default_reason="",
                prefix="partner",
            )
            if not method:
                continue
            query_targets = set().union(*(
                resolve_partner_token(match.group("path"))
                for match in PARTNER_QUERY_TARGET_RE.finditer(normalize_code_line(line))
            ))
            include_targets = set().union(*(
                resolve_partner_token(match.group("path"))
                for match in PARTNER_INCLUDE_TARGET_RE.finditer(normalize_code_line(line))
            ))
            matched_targets: Set[str] = query_targets | include_targets
            if not source_is_deterministic:
                for match in PARTNER_REFERENCE_TOKEN_RE.finditer(normalize_code_line(line)):
                    matched_targets.update(resolve_partner_token(match.group("path")))

            for target_relative in matched_targets:
                if target_relative in query_targets:
                    target_method = "GET"
                    target_reason = "partner query string URL"
                elif target_relative in include_targets:
                    target_method = "Common"
                    target_reason = "partner include/require"
                else:
                    target_method = method
                    target_reason = reason
                dedupe_key = (
                    target_relative.lower(),
                    source_relative.lower(),
                    line_number,
                    target_method,
                )
                if dedupe_key in seen:
                    continue
                seen.add(dedupe_key)
                references[(folder, target_relative)].append(Evidence(
                    source_file=rel_file("partner", folder, source_relative),
                    source_line=line_number,
                    method=target_method,
                    reason=target_reason,
                    snippet=clean_snippet(line),
                    args=inline_query_arg_names(line),
                ))
    return dict(references), {}


def partner_method_for_path(
    folder: str,
    relative_name: str,
    path: Path,
    evidence: Sequence[Evidence],
) -> Tuple[str, List[Evidence]]:
    evidence_list = list(evidence)
    deterministic_method = partner_deterministic_method(folder, relative_name, path)
    if deterministic_method:
        return deterministic_method, evidence_list
    flow_evidence = [item for item in evidence_list if item.method in {"GET", "POST"}]
    if flow_evidence:
        return classify_primary(item.method for item in flow_evidence), evidence_list
    if any(item.method == "Common" for item in evidence_list):
        return "Common", evidence_list
    if folder.lower() in PARTNER_ANALYSE_AS_COMMON_FOLDERS:
        return "Common", evidence_list
    return "ANALYSE", evidence_list


def scan_folder(taxyear: str, folder: str, progress: Optional[Callable[[str, int, int], None]] = None) -> Dict:
    taxyear = str(taxyear)
    if not is_supported_folder(taxyear, folder):
        raise ValueError(f"Unsupported folder: {folder}")
    folder_path = source_folder_path(taxyear, folder)
    if not folder_path.exists():
        raise FileNotFoundError(f"Folder not found: {folder_path}")

    candidate_paths = candidate_paths_for_folder(folder_path, folder)
    forced_folder_method = FORCED_FOLDER_METHODS.get(folder, "")
    if taxyear.lower() == "partner":
        needs_references = partner_folder_needs_references(folder)
    elif taxyear.lower() in {"base", "probase"}:
        needs_references = base_folder_needs_references(folder)
    elif taxyear.lower() == "cp":
        needs_references = cp_folder_needs_references(folder)
    elif taxyear.lower() == "mo":
        needs_references = mo_folder_needs_references(folder)
    elif taxyear.lower() == "main" and folder in MAIN_RECURSIVE_FLOW_FOLDERS:
        needs_references = True
    else:
        needs_references = folder_needs_references(folder)
    if folder == "images" and not image_candidates_need_references(candidate_paths):
        needs_references = False
    if folder == "Staffolt":
        # Staffolt builds use one precomputed reverse evidence index over only
        # Staffolt + html. Rebuild it for every folder scan so references added
        # or changed since an earlier request cannot leave files as ANALYSE.
        # Avoid the generic reference collector entirely.
        clear_staffolt_cache(taxyear)
        staffolt_fast_reference_index(taxyear)
        references, local_args = {}, {}
    elif needs_references and not all_candidates_final_before_references(
            folder,
            folder_path,
            candidate_paths,
            taxyear=taxyear,
        ):
        if taxyear.lower() == "partner":
            references, local_args = collect_partner_references(
                folder, folder_path, candidate_paths, progress=progress
            )
        elif taxyear.lower() == "main" and folder in MAIN_RECURSIVE_FLOW_FOLDERS:
            references, local_args = collect_main_folder_references(folder, progress=progress)
        else:
            references, local_args = collect_references(taxyear, folder, progress=progress)
    else:
        references, local_args = {}, {}
    efile_references = efile_reference_index(taxyear) if folder == "efile" else None
    records = []
    total_candidates = len(candidate_paths)
    original_pdf_refs = (
        _collect_original_pdf_references(taxyear, progress=progress)
        if folder == "Original"
        else set()
    )
    for idx, path in enumerate(candidate_paths, start=1):
        if not path.is_file():
            continue
        if progress:
            progress(relative_file_name(folder_path, path), idx, total_candidates)
        records.append(build_metadata_record_for_path(
            taxyear,
            folder,
            folder_path,
            path,
            references,
            local_args,
            forced_folder_method=forced_folder_method,
            original_pdf_refs=original_pdf_refs,
            efile_references=efile_references,
        ))

    summary = summarize(records)
    return {"taxyear": taxyear, "folder": folder, "records": records, "summary": summary}


def build_metadata_record_for_path(
    taxyear: str,
    folder: str,
    folder_path: Path,
    path: Path,
    references: Dict[Tuple[str, str], List[Evidence]],
    local_args: Dict[Tuple[str, str], Dict[str, Set[str]]],
    forced_folder_method: str = "",
    original_pdf_refs: Optional[Dict[str, Dict[str, str]]] = None,
    efile_references: Optional[Dict[str, List[Evidence]]] = None,
    single_file: bool = False,
) -> Dict:
    relative_name = relative_file_name(folder_path, path)
    key = (folder, relative_name)
    path_evidence = references.get(key, [])
    original_reference = (
        (original_pdf_refs or {}).get(path.name.lower())
        if folder == "Original" and path.suffix.lower() == ".pdf"
        else None
    )
    forced_file_method_value = forced_file_method(
        folder,
        relative_name,
        path.name,
        taxyear=taxyear,
    )
    classification_is_final = bool(forced_file_method_value)
    if forced_file_method_value:
        forced_method = forced_file_method_value
        path_evidence = []
    elif path.stat().st_size == 0:
        forced_method = "DEAD"
        path_evidence = []
        classification_is_final = True
    else:
        state_oltproc_method = state_oltproc_filename_method(taxyear, folder, path)
        standard_inc_method = standard_inc_filename_method(taxyear, folder, path)
        deterministic_html_method = html_filename_method(taxyear, folder, path)
        if deterministic_html_method:
            forced_method = deterministic_html_method
            path_evidence = []
        elif standard_inc_method:
            forced_method = standard_inc_method
            path_evidence = []
        elif state_oltproc_method:
            forced_method = state_oltproc_method
            path_evidence = []
        elif taxyear.lower() == "partner":
            forced_method, path_evidence = partner_method_for_path(
                folder, relative_name, path, path_evidence
            )
        elif taxyear.lower() in {"base", "probase"}:
            forced_method, path_evidence = base_method_for_path(folder, path, path_evidence)
        elif taxyear.lower() == "cp":
            forced_method, path_evidence = cp_method_for_path(folder, path_evidence)
        elif taxyear.lower() == "mo":
            forced_method, path_evidence = mo_method_for_path(folder, path, path_evidence)
        elif taxyear.lower() == "main" and folder in MAIN_RECURSIVE_FLOW_FOLDERS:
            forced_method, path_evidence = main_folder_method_for_path(folder, path, relative_name, path_evidence)
        elif folder == "wfi":
            forced_method, path_evidence = wfi_method_for_path(taxyear, path)
        elif folder == "OLTPRO":
            forced_method, path_evidence = oltpro_method_for_path(
                taxyear,
                path,
                target_only=single_file,
            )
        elif folder == "Staffolt":
            forced_method, path_evidence = staffolt_method_for_path(
                taxyear,
                path,
                path_evidence,
                targeted_single_file=single_file,
            )
        elif folder == "efile":
            forced_method, path_evidence = efile_method_for_path(
                taxyear,
                path,
                reference_index=efile_references,
            )
        elif folder == "efilebank":
            forced_method, path_evidence = efilebank_method_for_path(taxyear, path)
        elif folder == "efilePartner":
            forced_method, path_evidence = efilepartner_method_for_path(taxyear, path)
        elif forced_folder_method:
            forced_method = forced_folder_method
        elif folder == "Original" and path.suffix.lower() == ".pdf":
            forced_method = (original_reference or {}).get("method", "ANALYSE")
        elif folder == "showreturn" and path.name.lower().startswith("batch_"):
            forced_method = "GET"
        elif folder == "jscripts" and path.suffix.lower() == ".js":
            forced_method = "GET"
        elif folder == "styles" and path.suffix.lower() == ".css":
            forced_method = "GET"
        elif folder == "images" and path.name.lower() == "index.php":
            forced_method = "GET"
        else:
            forced_method = (
                "GET"
                if folder != "csr_guide_pages" and path.suffix.lower() in STATIC_GET_EXTENSIONS
                else ""
            )
    apply_normal_folder_rule = (
        taxyear.lower() not in {"base", "probase", "partner", "cp", "mo"}
        and not (
            taxyear.lower() == "main"
            and folder in MAIN_RECURSIVE_FLOW_FOLDERS
        )
    )
    record = metadata_record(
        taxyear,
        folder,
        path,
        path_evidence,
        local_args.get(key, {"get": set(), "post": set()}),
        forced_method=forced_method,
        relative_name=relative_name,
        apply_folder_rule=apply_normal_folder_rule and not classification_is_final,
    )
    if (
        _is_standard_taxyear(taxyear)
        and folder == "Original"
        and path.suffix.lower() == ".pdf"
    ):
        record["fed_or_state"] = (
            "BANK"
            if original_reference and original_reference.get("bank") == "yes"
            else original_pdf_state(path.name)
        )
    if (
        _is_standard_taxyear(taxyear)
        and folder.lower() == "oltproc"
        and record["method"] == "ANALYSE"
        and not classification_is_final
    ):
        included_in_efile, efile_evidence = efile_include_found(taxyear, path)
        if included_in_efile:
            record = metadata_record(
                taxyear,
                folder,
                path,
                [*path_evidence, *efile_evidence],
                local_args.get(key, {"get": set(), "post": set()}),
                forced_method="Common",
                relative_name=relative_name,
                apply_folder_rule=apply_normal_folder_rule,
            )
        else:
            included_in_staffolt, staffolt_evidence = staffolt_include_found(
                taxyear, path
            )
            if included_in_staffolt:
                record = metadata_record(
                    taxyear,
                    folder,
                    path,
                    [*path_evidence, *staffolt_evidence],
                    local_args.get(key, {"get": set(), "post": set()}),
                    forced_method="Common",
                    relative_name=relative_name,
                    apply_folder_rule=apply_normal_folder_rule,
                )
    return record


def scan_metadata_file(
    taxyear: str,
    folder: str,
    file_name: str,
    skip_references: bool = False,
    reference_sources: Optional[Sequence[Dict]] = None,
) -> Dict:
    taxyear = str(taxyear)
    if not is_supported_folder(taxyear, folder):
        raise ValueError(f"Unsupported folder: {folder}")
    if not file_name:
        raise ValueError("File name is required")

    folder_path = source_folder_path(taxyear, folder)
    if not folder_path.exists():
        raise FileNotFoundError(f"Folder not found: {folder_path}")

    source_path = resolve_source_file_path(taxyear, folder, folder_path, file_name)

    relative_name = relative_file_name(folder_path, source_path)
    if taxyear.lower() == "partner":
        needs_references = partner_folder_needs_references(folder)
    elif taxyear.lower() in {"base", "probase"}:
        needs_references = base_folder_needs_references(folder)
    elif taxyear.lower() == "cp":
        needs_references = cp_folder_needs_references(folder)
    elif taxyear.lower() == "mo":
        needs_references = mo_folder_needs_references(folder)
    elif taxyear.lower() == "main" and folder in MAIN_RECURSIVE_FLOW_FOLDERS:
        needs_references = True
    else:
        needs_references = folder_needs_references(folder)
    deterministic_normal_method = (
        bool(html_filename_method(taxyear, folder, source_path))
        or (
            taxyear.lower() not in {"base", "probase", "partner", "cp", "mo", "main"}
            and (
                bool(standard_inc_filename_method(taxyear, folder, source_path))
                or (
                    folder == "oltproc"
                    and source_path.name.lower().startswith("sitesettings")
                )
                or bool(state_oltproc_filename_method(taxyear, folder, source_path))
            )
        )
    )
    override_skips_references = bool(
        forced_file_method(
            folder,
            relative_name,
            source_path.name,
            taxyear=taxyear,
        )
    )
    try:
        zero_byte_skips_references = (
            not override_skips_references
            and source_path.stat().st_size == 0
        )
    except OSError:
        # The source can disappear between resolution and scanning. Let the
        # normal record builder report that condition instead of failing here.
        zero_byte_skips_references = False
    if (
        not skip_references
        and needs_references
        and not deterministic_normal_method
        and not override_skips_references
        and not zero_byte_skips_references
    ):
        if reference_sources is not None:
            references, local_args = collect_code_move_references(
                taxyear,
                folder,
                relative_name,
                reference_sources,
            )
        elif taxyear.lower() == "partner":
            references, local_args = collect_partner_references(
                folder,
                folder_path,
                candidate_paths_for_folder(folder_path, folder),
            )
        elif taxyear.lower() == "main" and folder in MAIN_RECURSIVE_FLOW_FOLDERS:
            references, local_args = collect_main_folder_references(folder)
        elif folder == "Staffolt":
            # Staffolt has its own caller/source index and classification rules.
            # Do not run the generic tax-year reference scan for a one-file rebuild;
            # it duplicates the Staffolt lookup and makes single-file rebuilds slow.
            # We only need the target file's own request variables here.
            target_text = "\n".join(uncomment_code_lines(read_file_text(source_path).splitlines()))
            target_key = (folder, source_path.name)
            local_args = {
                target_key: {
                    "get": set(READ_ARG_RE.findall(target_text)),
                    "post": set(POST_ARG_RE.findall(target_text)),
                }
            }
            references = {}
        else:
            references, local_args = collect_references(
                taxyear,
                folder,
                target_file_name=source_path.name if folder == "oltproc" else "",
            )
    else:
        references, local_args = {}, {}

    forced_folder_method = FORCED_FOLDER_METHODS.get(folder, "")
    original_pdf_refs = (
        _collect_original_pdf_references(taxyear, reference_sources=reference_sources)
        if folder == "Original"
        else set()
    )
    return build_metadata_record_for_path(
        taxyear,
        folder,
        folder_path,
        source_path,
        references,
        local_args,
        forced_folder_method=forced_folder_method,
        original_pdf_refs=original_pdf_refs,
        single_file=True,
    )


def summarize(records: Sequence[Dict]) -> Dict:
    by_method = Counter(record["method"] for record in records)
    by_state = Counter(record["fed_or_state"] for record in records)
    flow_yes = sum(1 for record in records if record["called_from_flow"] == "yes")
    return {
        "total_files": len(records),
        "flow_files": flow_yes,
        "not_called_from_flow": len(records) - flow_yes,
        "by_method": dict(by_method),
        "by_state": dict(by_state.most_common()),
    }


def storage_dir(taxyear: str) -> Path:
    return QDRANT_ROOT / str(taxyear)


def latest_manifest_path(taxyear: str, folder: str) -> Path:
    return storage_dir(taxyear) / f"latest_{folder}.json"


def new_qdrant_path(taxyear: str, folder: str) -> Path:
    if str(taxyear).lower() == "partner" and folder.lower() == "partner":
        return storage_dir(taxyear)             
    return storage_dir(taxyear) / folder


def collection_name(taxyear: str, folder: str) -> str:
    return f"php_flow_analysis"


def write_latest_manifest(scan_result: Dict, qdrant: Dict) -> None:
    taxyear = scan_result["taxyear"]
    folder = scan_result["folder"]
    manifest = {
        "taxyear": taxyear,
        "folder": folder,
        "collection": qdrant.get("collection", collection_name(taxyear, folder)),
        "path": qdrant.get("path", ""),
        "created_at": datetime.now(timezone.utc).isoformat(),
        "summary": scan_result["summary"],
    }
    latest_manifest_path(taxyear, folder).write_text(json.dumps(manifest, indent=2, sort_keys=True), encoding="utf-8")


def read_latest_manifest(taxyear: str, folder: str) -> Optional[Dict]:
    path = latest_manifest_path(str(taxyear), folder)
    if path.exists():
        manifest = json.loads(path.read_text(encoding="utf-8"))
        folder_path = new_qdrant_path(str(taxyear), folder)
        if folder_path.exists():
            # The active DB has a stable folder name. Always prefer it even if
            # a legacy timestamped directory referenced by the manifest still
            # exists alongside it.
            manifest["path"] = str(folder_path)
        return manifest
    folder_path = new_qdrant_path(str(taxyear), folder)
    if folder_path.exists():
        return {
            "taxyear": str(taxyear),
            "folder": folder,
            "collection": collection_name(str(taxyear), folder),
            "path": str(folder_path),
            "created_at": "",
            "summary": {},
        }
    candidates = sorted(storage_dir(str(taxyear)).glob(f"qdrant_{folder}_*"), key=lambda item: item.name, reverse=True)
    if not candidates:
        # Backward compatibility for older DB folder names.
        candidates = sorted(storage_dir(str(taxyear)).glob(f"{folder}_vectordb_*"), key=lambda item: item.name, reverse=True)
    if not candidates:
        return None
    return {
        "taxyear": str(taxyear),
        "folder": folder,
        "collection": collection_name(str(taxyear), folder),
        "path": str(candidates[0]),
        "created_at": "",
        "summary": {},
    }


def qdrant_path_candidates(taxyear: str, folder: str, manifest: Optional[Dict]) -> List[Path]:
    candidates: List[Path] = [new_qdrant_path(str(taxyear), folder)]
    manifest_path = (manifest or {}).get("path", "")
    if manifest_path:
        candidates.append(Path(manifest_path))

    candidates.extend(sorted(storage_dir(str(taxyear)).glob(f"qdrant_{folder}_*"), key=lambda item: item.name, reverse=True))
    candidates.extend(sorted(storage_dir(str(taxyear)).glob(f"{folder}_vectordb_*"), key=lambda item: item.name, reverse=True))


    deduped: List[Path] = []
    seen = set()
    for path in candidates:
        path_str = str(path)
        if path_str not in seen:
            seen.add(path_str)
            deduped.append(path)
    return deduped


def collection_candidates(taxyear: str, folder: str, manifest: Optional[Dict]) -> List[str]:
    candidates = [
        (manifest or {}).get("collection", ""),
        collection_name(str(taxyear), folder),
        f"php_{taxyear}_{folder}",
    ]
    return [name for idx, name in enumerate(candidates) if name and name not in candidates[:idx]]


def point_id_for_file(file_name: str) -> int:
    return int(hashlib.md5(file_name.encode("utf-8")).hexdigest()[:15], 16)


def source_file_names(taxyear: str, folder: str) -> Set[str]:
    folder_path = source_folder_path(str(taxyear), folder)
    if not folder_path.exists():
        return set()
    return {
        relative_file_name(folder_path, path)
        for path in candidate_paths_for_folder(folder_path, folder)
    }


def metadata_file_names(records: Sequence[Dict], folder: str) -> Set[str]:
    names = set()
    for record in records:
        if record.get("folder") != folder:
            continue
        base_name = record.get("base_name")
        if base_name:
            names.add(base_name)
            continue
        file_name = record.get("file_name", "")
        if file_name:
            names.add(Path(file_name).name)
    return names


def load_folder_counts(taxyear: str, folders: Sequence[str] = FOLDERS) -> Dict:
    folder_counts = []
    aggregate_records = []
    aggregate_by_method = Counter()
    aggregate_by_state = Counter()
    total_files = 0
    flow_files = 0

    for folder in folders:
        manifest = read_latest_manifest(str(taxyear), folder)
        summary = (manifest or {}).get("summary") or summarize([])
        by_method = summary.get("by_method", {}) or {}
        by_state = summary.get("by_state", {}) or {}
        total = int(summary.get("total_files", 0) or 0)
        flow = int(summary.get("flow_files", 0) or 0)
        not_flow = int(summary.get("not_called_from_flow", 0) or 0)

        folder_counts.append({
            "folder": folder,
            "total_files": total,
            "flow_files": flow,
            "not_called_from_flow": not_flow,
            "by_method": by_method,
            "by_state": by_state,
            "qdrant": {
                "collection": (manifest or {}).get("collection", ""),
                "path": (manifest or {}).get("path", ""),
                "created_at": (manifest or {}).get("created_at", ""),
            },
        })

        total_files += total
        flow_files += flow
        aggregate_by_method.update(by_method)
        aggregate_by_state.update(by_state)

    aggregate = {
        "total_files": total_files,
        "flow_files": flow_files,
        "not_called_from_flow": total_files - flow_files,
        "by_method": dict(aggregate_by_method),
        "by_state": dict(aggregate_by_state.most_common()),
    }
    return {"taxyear": str(taxyear), "folders": folder_counts, "summary": aggregate}


def stable_vector(text: str, size: int = 64) -> List[float]:
    digest = hashlib.sha256(text.encode("utf-8")).digest()
    values = []
    while len(values) < size:
        for byte in digest:
            values.append((byte / 127.5) - 1.0)
            if len(values) == size:
                break
        digest = hashlib.sha256(digest).digest()
    norm = math.sqrt(sum(v * v for v in values)) or 1.0
    return [v / norm for v in values]


@serialized_qdrant_access
def upsert_qdrant(scan_result: Dict, progress: Optional[Callable[[str, int, int], None]] = None) -> Dict:
    try:
        from qdrant_client import QdrantClient
        from qdrant_client.models import Distance, PointStruct, VectorParams
    except Exception as exc:
        return {"enabled": False, "status": "skipped", "message": f"qdrant-client is not installed: {exc}"}

    taxyear = scan_result["taxyear"]
    folder = scan_result["folder"]
    qdrant_path = new_qdrant_path(taxyear, folder)
    qdrant_path.mkdir(parents=True, exist_ok=True)
    client = QdrantClient(path=str(qdrant_path))
    target_collection = collection_name(taxyear, folder)
    total = len(scan_result["records"])
    batch_size = 5000 if folder == "Original" else 1000
    try:
        # A full folder build replaces the stable folder DB.  Recreate the
        # collection so files removed from the source do not remain as stale
        # points across future rebuilds of the same path.
        if client.collection_exists(target_collection):
            client.delete_collection(target_collection)
        client.create_collection(target_collection, vectors_config=VectorParams(size=64, distance=Distance.COSINE))

        batch: List[PointStruct] = []
        for idx, record in enumerate(scan_result["records"], start=1):
            text = " ".join([
                record["file_name"],
                record["method"],
                record["fed_or_state"],
                " ".join(record.get("allowed_get_arguments", [])),
                " ".join(record.get("post_body_variables", [])),
            ])
            point_id = point_id_for_file(record["file_name"])
            payload = {**record, "folder": record.get("folder", folder)}
            point = PointStruct(id=point_id, vector=stable_vector(text), payload=payload)
            batch.append(point)
            if progress:
                progress(record.get("base_name", record["file_name"]), idx, total)
            if len(batch) >= batch_size:
                client.upsert(collection_name=target_collection, points=batch)
                batch = []
        if batch:
            client.upsert(collection_name=target_collection, points=batch)
    finally:
        close = getattr(client, "close", None)
        if callable(close):
            close()
    return {"enabled": True, "status": "ok", "collection": target_collection, "path": str(qdrant_path)}


@serialized_qdrant_access
def load_qdrant_store(taxyear: str, folder: str) -> Dict:
    manifest = read_latest_manifest(str(taxyear), folder)
    if not manifest:
        return {"taxyear": str(taxyear), "folder": folder, "records": [], "summary": summarize([]), "qdrant": None}

    try:
        from qdrant_client import QdrantClient
    except Exception as exc:
        raise RuntimeError(f"qdrant-client is required to read metadata from Qdrant: {exc}") from exc

    errors = []
    for qdrant_path in qdrant_path_candidates(str(taxyear), folder, manifest):
        if not qdrant_path.exists():
            continue
        client = QdrantClient(path=str(qdrant_path))
        try:
            available = {item.name for item in client.get_collections().collections}
            for target_collection in collection_candidates(str(taxyear), folder, manifest):
                if target_collection not in available:
                    continue
                records: List[Dict] = []
                file_prefix = f"/{taxyear}/{folder}/".lower()
                offset = None
                while True:
                    points, offset = client.scroll(
                        collection_name=target_collection,
                        limit=1000,
                        offset=offset,
                        with_payload=True,
                        with_vectors=False,
                    )
                    for point in points:
                        payload = point.payload
                        if not payload:
                            continue
                        file_name = str(payload.get("file_name", "")).lower()
                        if payload.get("folder") == folder or file_name.startswith(file_prefix):
                            records.append({**payload, "folder": folder})
                    if offset is None:
                        break
                qdrant_info = {**manifest, "path": str(qdrant_path), "collection": target_collection}
                return {"taxyear": str(taxyear), "folder": folder, "records": records, "summary": summarize(records), "qdrant": qdrant_info}
            errors.append(f"{qdrant_path}: collections={sorted(available)}")
        finally:
            close = getattr(client, "close", None)
            if callable(close):
                close()
    raise RuntimeError(f"No readable Qdrant collection found for {taxyear}/{folder}. Tried: {'; '.join(errors) or 'no paths'}")


@serialized_qdrant_access
def update_qdrant_metadata_method(taxyear: str, folder: str, file_name: str, method: str) -> Dict:
    method = "Common" if method.upper() == "COMMON" else method
    if method not in MANUAL_METHODS:
        raise ValueError(f"Unsupported metadata method: {method}")

    store = load_qdrant_store(str(taxyear), folder)
    matches = [
        record for record in store["records"]
        if record.get("base_name") == file_name or record.get("file_name") == file_name or Path(record.get("file_name", "")).name == file_name
    ]
    if not matches:
        raise ValueError(f"Metadata file not found: {file_name}")
    record = matches[0]

    manifest = read_latest_manifest(str(taxyear), folder)
    if not manifest:
        raise RuntimeError(f"No latest Qdrant manifest found for {taxyear}/{folder}")

    from qdrant_client import QdrantClient

    qdrant_path = Path((store.get("qdrant") or {}).get("path") or manifest.get("path", ""))
    target_collection = (store.get("qdrant") or {}).get("collection") or manifest.get("collection") or collection_name(str(taxyear), folder)
    payload = {
        "method": method,
        "methods": [method],
        "manual_method": "yes",
        "called_from_flow": "yes" if method in {"GET", "POST", "HEAD"} else "No",
        "updated_at": datetime.now(timezone.utc).isoformat(),
    }

    client = QdrantClient(path=str(qdrant_path))
    try:
        client.set_payload(
            collection_name=target_collection,
            payload=payload,
            points=[point_id_for_file(record["file_name"])],
        )
        updated_records: List[Dict] = []
        offset = None
        while True:
            points, offset = client.scroll(
                collection_name=target_collection,
                limit=1000,
                offset=offset,
                with_payload=True,
                with_vectors=False,
            )
            updated_records.extend(point.payload for point in points if point.payload and point.payload.get("folder") == folder)
            if offset is None:
                break
    finally:
        close = getattr(client, "close", None)
        if callable(close):
            close()

    manifest["summary"] = summarize(updated_records)
    manifest["updated_at"] = datetime.now(timezone.utc).isoformat()
    latest_manifest_path(str(taxyear), folder).write_text(json.dumps(manifest, indent=2, sort_keys=True), encoding="utf-8")

    updated_record = {**record, **payload}
    override = persist_forced_file_method_override(
        str(taxyear),
        folder,
        str(record.get("base_name") or Path(record["file_name"]).name),
        method,
    )
    return {
        "taxyear": str(taxyear),
        "folder": folder,
        "record": updated_record,
        "summary": manifest["summary"],
        "qdrant": {"path": str(qdrant_path), "collection": target_collection},
        "override": override,
    }


def _write_manifest_summary(taxyear: str, folder: str, manifest: Dict, records: Sequence[Dict]) -> Dict:
    manifest["summary"] = summarize(records)
    manifest["updated_at"] = datetime.now(timezone.utc).isoformat()
    latest_manifest_path(str(taxyear), folder).write_text(json.dumps(manifest, indent=2, sort_keys=True), encoding="utf-8")
    return manifest["summary"]


def _scroll_folder_records(client, target_collection: str, folder: str) -> List[Dict]:
    records: List[Dict] = []
    offset = None
    while True:
        points, offset = client.scroll(
            collection_name=target_collection,
            limit=1000,
            offset=offset,
            with_payload=True,
            with_vectors=False,
        )
        records.extend(point.payload for point in points if point.payload and point.payload.get("folder") == folder)
        if offset is None:
            break
    return records


def _replace_store_record(records: Sequence[Dict], payload: Dict) -> List[Dict]:
    """Replace one record in an already loaded stable folder store."""
    target_file = str(payload.get("file_name", "")).replace("\\", "/").lower()
    target_base = str(payload.get("base_name", "")).replace("\\", "/").lower()
    updated = [
        item
        for item in records
        if (
            str(item.get("file_name", "")).replace("\\", "/").lower()
            != target_file
            and (
                target_file
                or str(item.get("base_name", "")).replace("\\", "/").lower()
                != target_base
            )
        )
    ]
    updated.append(payload)
    return updated


def _metadata_list(value) -> List[str]:
    if value is None:
        return []
    if isinstance(value, list):
        return [str(item).strip() for item in value if str(item).strip()]
    return [item.strip() for item in re.split(r"[\n,]+", str(value)) if item.strip()]


def _metadata_evidence(value) -> List[Dict]:
    if value in (None, ""):
        return []
    if isinstance(value, list):
        return [item for item in value if isinstance(item, dict)]
    try:
        parsed = json.loads(str(value))
    except json.JSONDecodeError as exc:
        raise ValueError(f"Evidence must be valid JSON: {exc}") from exc
    if not isinstance(parsed, list) or not all(isinstance(item, dict) for item in parsed):
        raise ValueError("Evidence must be a JSON array of objects")
    return parsed


def apply_metadata_overrides(record: Dict, overrides: Optional[Dict]) -> Dict:
    if not overrides:
        return record

    updated = dict(record)
    method = str(overrides.get("method", "")).strip()
    if method:
        method = "Common" if method.upper() == "COMMON" else method
        if method not in MANUAL_METHODS:
            raise ValueError(f"Unsupported metadata method: {method}")
        updated["method"] = method
        updated["methods"] = [method]
        updated["manual_method"] = "yes"

    called_from_flow = str(overrides.get("called_from_flow", "")).strip()
    if updated.get("method") == "HEAD":
        updated["called_from_flow"] = "yes"
    elif called_from_flow:
        updated["called_from_flow"] = "yes" if called_from_flow.lower() in {"yes", "true", "1"} else "No"
    elif method:
        updated["called_from_flow"] = "yes" if method in {"GET", "POST", "INPUT"} else "No"

    fed_or_state = str(overrides.get("fed_or_state", "")).strip().upper()
    if fed_or_state:
        if fed_or_state not in {"FED", "BANK", *STATES}:
            raise ValueError(f"Unsupported fed/state value: {fed_or_state}")
        updated["fed_or_state"] = fed_or_state

    for key in ("allowed_get_arguments", "post_querystring_arguments", "post_body_variables", "called_by"):
        if key in overrides:
            updated[key] = _metadata_list(overrides.get(key))

    if "evidence" in overrides:
        updated["evidence"] = _metadata_evidence(overrides.get("evidence"))

    called_by = updated.get("called_by", [])
    updated["called_by_count"] = len(called_by) if isinstance(called_by, list) else 0
    updated["updated_at"] = datetime.now(timezone.utc).isoformat()
    return updated


@serialized_qdrant_access
def delete_qdrant_metadata(taxyear: str, folder: str, file_name: str = "") -> Dict:
    if not is_supported_folder(taxyear, folder):
        raise ValueError(f"Unsupported folder: {folder}")

    store = load_qdrant_store(str(taxyear), folder)
    records = store["records"]
    if file_name:
        delete_records = [
            record for record in records
            if record.get("base_name") == file_name or record.get("file_name") == file_name or Path(record.get("file_name", "")).name == file_name
        ]
        if not delete_records:
            raise ValueError(f"Metadata file not found: {file_name}")
    else:
        delete_records = list(records)

    manifest = read_latest_manifest(str(taxyear), folder)
    if not manifest:
        raise RuntimeError(f"No latest Qdrant manifest found for {taxyear}/{folder}")

    from qdrant_client import QdrantClient

    qdrant_path = Path((store.get("qdrant") or {}).get("path") or manifest.get("path", ""))
    target_collection = (store.get("qdrant") or {}).get("collection") or manifest.get("collection") or collection_name(str(taxyear), folder)
    point_ids = [point_id_for_file(record["file_name"]) for record in delete_records]

    client = QdrantClient(path=str(qdrant_path))
    try:
        if point_ids:
            client.delete(collection_name=target_collection, points_selector=point_ids)
        remaining_records = _scroll_folder_records(client, target_collection, folder)
    finally:
        close = getattr(client, "close", None)
        if callable(close):
            close()

    summary = _write_manifest_summary(str(taxyear), folder, manifest, remaining_records)
    return {
        "taxyear": str(taxyear),
        "folder": folder,
        "file_name": file_name,
        "deleted_count": len(point_ids),
        "summary": summary,
        "qdrant": {"path": str(qdrant_path), "collection": target_collection},
    }


@serialized_qdrant_access
def add_qdrant_metadata_file(
    taxyear: str,
    folder: str,
    file_name: str,
    metadata_overrides: Optional[Dict] = None,
    known_store: Optional[Dict] = None,
    skip_qdrant_scroll: bool = True,
    reference_sources: Optional[Sequence[Dict]] = None,
) -> Dict:
    if not is_supported_folder(taxyear, folder):
        raise ValueError(f"Unsupported folder: {folder}")
    if not file_name:
        raise ValueError("File name is required")

    folder_path = source_folder_path(str(taxyear), folder)
    source_path = resolve_source_file_path(str(taxyear), folder, folder_path, file_name)

    manifest = read_latest_manifest(str(taxyear), folder)
    if not manifest:
        raise RuntimeError(f"No latest Qdrant manifest found for {taxyear}/{folder}")
    store = known_store if known_store is not None else load_qdrant_store(str(taxyear), folder)

    resolved_file_name = relative_file_name(folder_path, source_path)
    force_dead = str((metadata_overrides or {}).get("method", "")).strip().upper() == "DEAD"
    record = apply_metadata_overrides(
        scan_metadata_file(
            str(taxyear),
            folder,
            resolved_file_name,
            skip_references=force_dead,
            reference_sources=reference_sources,
        ),
        metadata_overrides,
    )

    from qdrant_client import QdrantClient
    from qdrant_client.models import PointStruct

    qdrant_path = Path((store.get("qdrant") or {}).get("path") or manifest.get("path", ""))
    target_collection = (store.get("qdrant") or {}).get("collection") or manifest.get("collection") or collection_name(str(taxyear), folder)
    text = " ".join([
        record["file_name"],
        record["method"],
        record["fed_or_state"],
        " ".join(record.get("allowed_get_arguments", [])),
        " ".join(record.get("post_body_variables", [])),
    ])
    payload = {**record, "folder": folder}
    point = PointStruct(id=point_id_for_file(record["file_name"]), vector=stable_vector(text), payload=payload)

    batch_state = getattr(_QDRANT_BATCH_STATE, "value", None)
    client_key = (str(qdrant_path.resolve()), target_collection)
    owns_client = batch_state is None
    if owns_client:
        client = QdrantClient(path=str(qdrant_path))
    else:
        client = batch_state["clients"].get(client_key)
        if client is None:
            client = QdrantClient(path=str(qdrant_path))
            batch_state["clients"][client_key] = client
    try:
        client.upsert(collection_name=target_collection, points=[point])
        # The DB directory is stable (<taxyear>/<folder>), and ``store`` was
        # loaded immediately before this upsert. Update that snapshot locally
        # instead of scrolling the entire collection a second time.
        records = _replace_store_record(store.get("records", []), payload)
    finally:
        if owns_client:
            close = getattr(client, "close", None)
            if callable(close):
                close()

    if batch_state is None:
        summary = _write_manifest_summary(str(taxyear), folder, manifest, records)
    else:
        summary = summarize(records)
        batch_state["manifests"][(str(taxyear), folder)] = (manifest, list(records))
    return {
        "taxyear": str(taxyear),
        "folder": folder,
        "record": payload,
        "summary": summary,
        "qdrant": {"path": str(qdrant_path), "collection": target_collection},
    }


def rebuild_qdrant_metadata_files(taxyear: str, folder: str, file_name: str) -> Dict:
    """Rebuild one exact file, or all matches when given a duplicated basename."""
    if folder.lower() == "all":
        folder_results: Dict[str, Dict] = {}
        rebuilt_files: List[str] = []
        rebuilt_records: List[Dict] = []

        for source_folder in folders_for_taxyear(taxyear):
            try:
                result = rebuild_qdrant_metadata_files(
                    str(taxyear),
                    source_folder,
                    file_name,
                )
            except FileNotFoundError:
                continue
            folder_results[source_folder] = result
            rebuilt_files.extend(
                f"{source_folder}/{relative_name}"
                for relative_name in result.get("rebuilt_files", [])
            )
            rebuilt_records.extend(result.get("records", []))

        if not folder_results:
            raise FileNotFoundError(
                f"Source file not found in any {taxyear} folder: {file_name}"
            )

        aggregate = load_folder_counts(
            str(taxyear),
            folders_for_taxyear(taxyear),
        )["summary"]
        return {
            "taxyear": str(taxyear),
            "folder": "All",
            "record": rebuilt_records[-1] if rebuilt_records else {},
            "records": rebuilt_records,
            "rebuilt_count": len(rebuilt_files),
            "rebuilt_files": rebuilt_files,
            "summary": aggregate,
            "qdrant": {
                "by_folder": {
                    source_folder: result.get("qdrant", {})
                    for source_folder, result in folder_results.items()
                }
            },
            "by_folder": folder_results,
        }

    if not is_supported_folder(taxyear, folder):
        raise ValueError(f"Unsupported folder: {folder}")
    if not file_name:
        raise ValueError("File name is required")

    folder_path = source_folder_path(str(taxyear), folder)
    source_paths = resolve_source_file_paths(
        str(taxyear),
        folder,
        folder_path,
        file_name,
    )
    rebuilt_files = [
        relative_file_name(folder_path, source_path)
        for source_path in source_paths
    ]
    results = [
        add_qdrant_metadata_file(str(taxyear), folder, relative_name)
        for relative_name in rebuilt_files
    ]
    final_result = results[-1]
    return {
        **final_result,
        "record": final_result.get("record", {}),
        "records": [result.get("record", {}) for result in results],
        "rebuilt_count": len(results),
        "rebuilt_files": rebuilt_files,
    }


def compare_metadata_manifest_to_filesystem(taxyear: str, folder: str) -> Dict:
    source_names = source_file_names(str(taxyear), folder)
    manifest = read_latest_manifest(str(taxyear), folder) or {}
    summary = manifest.get("summary") or {}
    metadata_count = int(summary.get("total_files", 0) or 0)

    return {
        "taxyear": str(taxyear),
        "folder": folder,
        "filesystem_count": len(source_names),
        "metadata_count": metadata_count,
        "missing_count": max(len(source_names) - metadata_count, 0),
        "missing_files": [],
        "stale_count": max(metadata_count - len(source_names), 0),
        "stale_metadata_files": [],
        "qdrant": {
            "collection": manifest.get("collection", ""),
            "path": manifest.get("path", ""),
            "created_at": manifest.get("created_at", ""),
        } if manifest else None,
        "note": "Counts are from latest manifest to avoid opening local Qdrant during dashboard refresh.",
    }


def compare_metadata_to_filesystem(taxyear: str, folder: str) -> Dict:
    source_names = source_file_names(str(taxyear), folder)
    store = load_qdrant_store(str(taxyear), folder)
    meta_names = metadata_file_names(store["records"], folder)
    missing = sorted(source_names - meta_names)
    stale = sorted(meta_names - source_names)
    return {
        "taxyear": str(taxyear),
        "folder": folder,
        "filesystem_count": len(source_names),
        "metadata_count": len(meta_names),
        "missing_count": len(missing),
        "missing_files": missing,
        "stale_count": len(stale),
        "stale_metadata_files": stale,
        "qdrant": store.get("qdrant"),
    }

def compare_metadata_to_filesystem_safe(taxyear: str, folder: str) -> Dict:
    try:
        return compare_metadata_to_filesystem(str(taxyear), folder)
    except Exception as exc:
        source_names = source_file_names(str(taxyear), folder)
        manifest = read_latest_manifest(str(taxyear), folder) or {}
        summary = manifest.get("summary") or {}
        metadata_count = int(summary.get("total_files", 0) or 0)
        return {
            "taxyear": str(taxyear),
            "folder": folder,
            "filesystem_count": len(source_names),
            "metadata_count": metadata_count,
            "missing_count": 0,
            "missing_files": [],
            "stale_count": 0,
            "stale_metadata_files": [],
            "qdrant": {
                "collection": manifest.get("collection", ""),
                "path": manifest.get("path", ""),
                "created_at": manifest.get("created_at", ""),
            } if manifest else None,
            "error": str(exc),
        }


def compare_metadata_records_to_filesystem(taxyear: str, folder: str, records: Sequence[Dict], qdrant: Optional[Dict] = None) -> Dict:
    source_names = source_file_names(str(taxyear), folder)
    meta_names = metadata_file_names(records, folder)
    missing = sorted(source_names - meta_names)
    stale = sorted(meta_names - source_names)
    return {
        "taxyear": str(taxyear),
        "folder": folder,
        "filesystem_count": len(source_names),
        "metadata_count": len(meta_names),
        "missing_count": len(missing),
        "missing_files": missing,
        "stale_count": len(stale),
        "stale_metadata_files": stale,
        "qdrant": qdrant,
    }


def missing_files_report_path(taxyear: str) -> Path:
    return storage_dir(str(taxyear)) / "missing_files_report.json"


def load_missing_files_report(taxyear: str, folders: Sequence[str] = FOLDERS) -> Optional[Dict]:
    path = missing_files_report_path(str(taxyear))
    if not path.exists():
        return None
    report_mtime = path.stat().st_mtime
    scanner_mtime = Path(__file__).stat().st_mtime
    manifest_mtimes = [
        latest_manifest_path(str(taxyear), folder).stat().st_mtime
        for folder in folders
        if latest_manifest_path(str(taxyear), folder).exists()
    ]
    if report_mtime < max([scanner_mtime, *manifest_mtimes], default=scanner_mtime):
        return None
    report = json.loads(path.read_text(encoding="utf-8"))
    expected_folders = set(folders)
    reported_folders = {
        str(item.get("folder", ""))
        for item in report.get("folders", [])
        if isinstance(item, dict) and item.get("folder")
    }
    # A single-folder build updates only that folder in the cached report.
    # Do not use such a partial report for the full dashboard table.
    if not expected_folders.issubset(reported_folders):
        return None
    return report


def update_missing_files_report_for_folders(taxyear: str, folders: Sequence[str]) -> Dict:
    taxyear = str(taxyear)
    available_folders = folders_for_taxyear(taxyear)
    selected = [folder for folder in folders if folder in available_folders]
    path = missing_files_report_path(taxyear)

    if path.exists():
        try:
            report = json.loads(path.read_text(encoding="utf-8"))
        except Exception:
            report = {"taxyear": taxyear, "folders": [], "updated_at": ""}
    else:
        report = {"taxyear": taxyear, "folders": [], "updated_at": ""}

    existing_by_folder = {
        item.get("folder"): item
        for item in report.get("folders", [])
        if isinstance(item, dict) and item.get("folder")
    }

    for folder in selected:
        existing_by_folder[folder] = compare_metadata_manifest_to_filesystem(taxyear, folder)

    ordered_folders = []
    for folder in folders_for_taxyear(taxyear):
        if folder in existing_by_folder:
            ordered_folders.append(existing_by_folder[folder])

    # Preserve any unexpected folder entries at the end.
    for folder_name, item in existing_by_folder.items():
        if folder_name not in folders_for_taxyear(taxyear):
            ordered_folders.append(item)

    report = {
        "taxyear": taxyear,
        "folders": ordered_folders,
        "updated_at": datetime.now(timezone.utc).isoformat(),
    }

    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(report, indent=2, sort_keys=True), encoding="utf-8")
    return report
def build_missing_files_report(taxyear: str, folders: Sequence[str] = FOLDERS) -> Dict:
    report = {
        "taxyear": str(taxyear),
        "folders": [compare_metadata_manifest_to_filesystem(str(taxyear), folder) for folder in folders],
        "updated_at": datetime.now(timezone.utc).isoformat(),
    }
    path = missing_files_report_path(str(taxyear))
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(report, indent=2, sort_keys=True), encoding="utf-8")
    return report


def merged_qdrant_name() -> str:
    date_str = datetime.now(timezone.utc).strftime("%m%d%Y")
    return f"qdrant_vectordb_{date_str}"


def merged_qdrant_path(taxyear: str) -> Path:
    return storage_dir(str(taxyear)) / merged_qdrant_name()


@serialized_qdrant_access
def existing_merged_qdrant_folders(taxyear: str) -> Dict:
    taxyear = str(taxyear)
    destination = merged_qdrant_path(taxyear)
    target_collection = collection_name(taxyear, "")

    result = {
        "exists": destination.exists(),
        "destination": destination.name,
        "destination_path": str(destination),
        "collection": target_collection,
        "folders": [],
        "folder_counts": {},
        "points": 0,
    }

    if not destination.exists():
        return result

    try:
        from qdrant_client import QdrantClient
    except Exception as exc:
        result["error"] = f"qdrant-client is not installed: {exc}"
        return result

    client = QdrantClient(path=str(destination))
    try:
        available = {item.name for item in client.get_collections().collections}
        if target_collection not in available:
            result["error"] = f"Collection {target_collection} not found"
            return result

        offset = None
        folder_counts = Counter()
        total = 0
        while True:
            points, offset = client.scroll(
                collection_name=target_collection,
                limit=5000,
                offset=offset,
                with_payload=True,
                with_vectors=False,
            )
            for point in points:
                payload = point.payload or {}
                folder = str(payload.get("folder") or "").strip()
                if folder:
                    folder_counts[folder] += 1
                total += 1
            if offset is None:
                break

        result["folder_counts"] = dict(sorted(folder_counts.items()))
        result["folders"] = sorted(folder_counts)
        result["points"] = total
        return result
    finally:
        close = getattr(client, "close", None)
        if callable(close):
            close()
def list_mergeable_qdrant_dbs(taxyear: str) -> Dict:
    taxyear = str(taxyear)
    base = storage_dir(taxyear)
    destination_name = merged_qdrant_name()
    items = []
    available_by_lower = {folder.lower(): folder for folder in folders_for_taxyear(taxyear)}

    root_partner_db = taxyear.lower() == "partner" and (base / "collection").is_dir()

    if base.exists():
        for path in sorted(base.iterdir(), key=lambda item: item.name.lower()):
            if not path.is_dir():
                continue
            name = path.name
            folder = available_by_lower.get(name.lower(), "")
            if not folder and name.startswith("qdrant_") and not name.startswith("qdrant_vectordb_"):
                legacy_folder = name[len("qdrant_"):].rsplit("_", 1)[0]
                folder = available_by_lower.get(legacy_folder.lower(), "")
            if not folder:
                continue
            if root_partner_db and folder.lower() == "partner":
                continue
            items.append({
                "folder": folder,
                "name": name,
                "path": str(path),
            })

    if root_partner_db:
        items.insert(0, {"folder": "partner", "name": "partner", "path": str(base)})

    destination_status = existing_merged_qdrant_folders(taxyear)
    return {
        "taxyear": taxyear,
        "collection": collection_name(taxyear, ""),
        "destination": destination_name,
        "destination_path": str(base / destination_name),
        "destination_status": destination_status,
        "items": items,
    }


@serialized_qdrant_access
def merge_qdrant_dbs(taxyear: str, source_names: Sequence[str]) -> Dict:
    try:
        from qdrant_client import QdrantClient
        from qdrant_client.models import Distance, PointStruct, VectorParams
    except Exception as exc:
        return {"ok": False, "status": "error", "message": f"qdrant-client is not installed: {exc}"}

    taxyear = str(taxyear)
    source_names = [Path(str(name)).name for name in source_names if str(name).strip()]
    allowed = {item["name"]: item for item in list_mergeable_qdrant_dbs(taxyear)["items"]}
    selected = [allowed[name] for name in source_names if name in allowed]

    if not selected:
        raise ValueError("No valid qdrant folder DBs selected for merge.")

    destination = merged_qdrant_path(taxyear)
    destination_name = destination.name
    target_collection = collection_name(taxyear, "")

    destination_exists_before = destination.exists()

    destination.mkdir(parents=True, exist_ok=True)
    dest_client = QdrantClient(path=str(destination))

    merged_points = 0
    source_results = []
    vector_size = None
    created_collection = False

    try:
        available_dest = {item.name for item in dest_client.get_collections().collections}
        if target_collection in available_dest:
            created_collection = True
            existing_points, _ = dest_client.scroll(
                collection_name=target_collection,
                limit=1,
                with_payload=False,
                with_vectors=True,
            )
            if existing_points:
                existing_vector = existing_points[0].vector
                if isinstance(existing_vector, dict):
                    vector_size = len(next(iter(existing_vector.values()), []) or [])
                else:
                    vector_size = len(existing_vector or [])
        for source in selected:
            src_client = QdrantClient(path=str(Path(source["path"])))
            source_count = 0

            try:
                available = {item.name for item in src_client.get_collections().collections}
                if target_collection not in available:
                    source_results.append({**source, "status": "skipped", "message": f"Collection {target_collection} not found", "points": 0})
                    continue

                offset = None
                while True:
                    points, offset = src_client.scroll(
                        collection_name=target_collection,
                        limit=5000,
                        offset=offset,
                        with_payload=True,
                        with_vectors=True,
                    )

                    if not points:
                        break

                    upsert_points = []
                    for point in points:
                        vector = point.vector
                        if isinstance(vector, dict):
                            current_size = len(next(iter(vector.values()), []) or [])
                        else:
                            current_size = len(vector or [])

                        if vector_size is None:
                            vector_size = current_size
                            dest_client.create_collection(
                                collection_name=target_collection,
                                vectors_config=VectorParams(size=vector_size, distance=Distance.COSINE),
                            )
                            created_collection = True
                        elif current_size != vector_size:
                            raise ValueError(f"Vector size mismatch in {source['name']}: expected {vector_size}, got {current_size}")

                        payload = point.payload or {}
                        file_name = str(payload.get("file_name") or payload.get("base_name") or point.id)
                        folder = str(payload.get("folder") or source["folder"])
                        new_id = point_id_for_file(f"{folder}:{file_name}")

                        upsert_points.append(PointStruct(
                                id=new_id,
                                vector=point.vector,
                            payload={**payload, "folder": folder, "merged_from": source["name"]},
                        ))

                    if upsert_points:
                        dest_client.upsert(collection_name=target_collection, points=upsert_points)
                        source_count += len(upsert_points)
                        merged_points += len(upsert_points)

                    if offset is None:
                        break

                source_results.append({**source, "status": "ok", "points": source_count})
            finally:
                close = getattr(src_client, "close", None)
                if callable(close):
                    close()

        if not created_collection:
            raise ValueError("No vectors were found in the selected DBs.")

    except Exception:
        close = getattr(dest_client, "close", None)
        if callable(close):
            close()
        if not destination_exists_before and destination.exists():
            shutil.rmtree(destination)
        raise
    finally:
        close = getattr(dest_client, "close", None)
        if callable(close):
            close()

    return {
        "ok": True,
        "status": "ok",
        "taxyear": taxyear,
        "collection": target_collection,
        "destination": destination_name,
        "path": str(destination),
        "destination_existed": destination_exists_before,
        "destination_status": existing_merged_qdrant_folders(taxyear),
        "sources": source_results,
        "merged_points": merged_points,
    }
def _canonical_code_move_taxyear(name: str) -> str:
    value = str(name).strip()
    if re.fullmatch(r"\d{4}", value):
        return value
    return {
        "base": "base",
        "probase": "probase",
        "partner": "partner",
        "cp": "cp",
        "main": "main",
        "mo": "MO",
    }.get(value.lower(), "")


def discover_code_move_files(root: Optional[Path] = None) -> List[Dict]:
    """Map every staged code_move file to its site-asp target."""
    code_move_root = Path(root) if root is not None else code_move_root_path()
    if not code_move_root.exists():
        raise FileNotFoundError(f"Code Move directory not found: {code_move_root}")
    if not code_move_root.is_dir():
        raise NotADirectoryError(f"Code Move path is not a directory: {code_move_root}")

    entries: List[Dict] = []
    for staged_path in sorted(path for path in code_move_root.rglob("*") if path.is_file()):
        staged_name = staged_path.relative_to(code_move_root).as_posix()
        parts = list(Path(staged_name).parts)
        if parts and parts[0].lower() in {"site-asp", "site_asp"}:
            parts = parts[1:]

        entry = {"code_move_file": staged_name, "staged_path": str(staged_path)}
        if len(parts) < 2:
            entries.append({**entry, "error": "Expected <root>/<folder>/<file> or partner/<file>"})
            continue

        taxyear = _canonical_code_move_taxyear(parts[0])
        if not taxyear:
            entries.append({**entry, "error": f"Unsupported site-asp root: {parts[0]}"})
            continue

        available = folders_for_taxyear(taxyear)
        folder_by_lower = {item.lower(): item for item in available}
        if taxyear.lower() == "partner" and len(parts) == 2:
            folder = "partner"
            relative_name = parts[1]
        else:
            folder = folder_by_lower.get(parts[1].lower(), "")
            relative_name = Path(*parts[2:]).as_posix() if len(parts) > 2 else ""

        if not folder:
            entries.append({**entry, "taxyear": taxyear, "error": f"Unsupported folder for {taxyear}: {parts[1]}"})
            continue
        if not relative_name:
            entries.append({**entry, "taxyear": taxyear, "folder": folder, "error": "File name is missing"})
            continue

        entries.append({
            **entry,
            "taxyear": taxyear,
            "folder": folder,
            "file_name": relative_name,
            "target_file": rel_file(taxyear, folder, relative_name),
        })
    return entries


def clear_taxyear_scan_caches(taxyear: str) -> None:
    """Discard source indexes that can become stale after a live code move."""
    clear_generic_scan_cache(taxyear)
    clear_oltproc_cache(taxyear)
    # File-reference entries validate their own mtime and size. Preserve the
    # disk cache so a one-file Code Move does not trigger a full taxyear scan.
    clear_wfi_cache(taxyear)
    clear_staffolt_cache(taxyear)
    clear_efile_cache(taxyear)
    clear_efilebank_cache(taxyear)
    clear_efilepartner_cache(taxyear)
    _ORIGINAL_PDF_REFS_CACHE.pop(str(taxyear), None)


def rebuild_code_move_files(
    root: Optional[Path] = None,
    progress: Optional[Callable[[Dict, int, int], None]] = None,
) -> Dict:
    """Build new, zero-byte, and previously ANALYSE Code Move files."""
    entries = discover_code_move_files(root)
    with qdrant_write_batch():
        return _rebuild_code_move_entries(entries, root=root, progress=progress)


def _rebuild_code_move_entries(
    entries: Sequence[Dict],
    root: Optional[Path] = None,
    progress: Optional[Callable[[Dict, int, int], None]] = None,
) -> Dict:
    touched_taxyears = {
        entry["taxyear"] for entry in entries if entry.get("taxyear") and not entry.get("error")
    }
    for taxyear in touched_taxyears:
        clear_taxyear_scan_caches(taxyear)

    existing_by_group: Dict[Tuple[str, str], Dict[str, str]] = {}
    stores_by_group: Dict[Tuple[str, str], Dict] = {}
    results: List[Dict] = []
    total = len(entries)
    for index, entry in enumerate(entries, start=1):
        if progress:
            progress(entry, index, total)
        if entry.get("error"):
            results.append({**entry, "status": "failed"})
            continue

        taxyear = entry["taxyear"]
        folder = entry["folder"]
        file_name = entry["file_name"]
        group = (taxyear, folder)
        try:
            if group not in existing_by_group:
                store = load_qdrant_store(taxyear, folder)
                stores_by_group[group] = store
                existing_by_group[group] = {
                    str(record.get("base_name") or "").replace("\\", "/").lower():
                    str(record.get("method") or "").strip().upper()
                    for record in store.get("records", [])
                    if record.get("base_name")
                }
            file_key = file_name.replace("\\", "/").lower()
            existed = file_key in existing_by_group[group]
            existing_method = existing_by_group[group].get(file_key, "")
            staged_is_empty = Path(entry["staged_path"]).stat().st_size == 0
            rebuild_existing_analyse = existed and existing_method == "ANALYSE"
            if existed and not staged_is_empty and not rebuild_existing_analyse:
                results.append({
                    **entry,
                    "status": "skipped",
                    "details": "Already present in vector DB",
                })
                continue
            saved_method_override = forced_file_method(
                folder,
                file_name,
                Path(file_name).name,
                taxyear=taxyear,
            )
            result = add_qdrant_metadata_file(
                taxyear,
                folder,
                file_name,
                metadata_overrides=(
                    {"method": "DEAD"}
                    if staged_is_empty and not saved_method_override
                    else None
                ),
                known_store=stores_by_group[group],
                skip_qdrant_scroll=True,
                reference_sources=entries,
            )
            updated_record = result.get("record", {})
            existing_by_group[group][file_key] = str(
                updated_record.get("method") or ""
            ).strip().upper()
            existing_records = stores_by_group[group].setdefault("records", [])
            existing_records[:] = [
                item
                for item in existing_records
                if str(item.get("base_name") or "").replace("\\", "/").lower() != file_key
            ]
            existing_records.append(updated_record)
            stores_by_group[group]["summary"] = result.get("summary", {})
            results.append({
                **entry,
                "status": "rebuilt" if existed else "added",
                "method": (result.get("record") or {}).get("method", ""),
                "details": (
                    "Existing zero-byte file rebuilt"
                    if existed and staged_is_empty
                    else "Existing ANALYSE file rebuilt"
                    if rebuild_existing_analyse
                    else ""
                ),
            })
        except Exception as exc:
            results.append({**entry, "status": "failed", "error": str(exc)})

    counts = Counter(item["status"] for item in results)
    return {
        "code_move_root": str(Path(root) if root is not None else code_move_root_path()),
        "total": total,
        "rebuilt": counts.get("rebuilt", 0),
        "added": counts.get("added", 0),
        "skipped": counts.get("skipped", 0),
        "failed": counts.get("failed", 0),
        "results": results,
    }


def build_vector_store(taxyear: str, folder: str, progress: Optional[Callable[[str, int, int], None]] = None, qdrant_progress: Optional[Callable[[str, int, int], None]] = None) -> Dict:
    scan_result = scan_folder(str(taxyear), folder, progress=progress)
    qdrant = upsert_qdrant(scan_result, progress=qdrant_progress)
    if qdrant.get("status") == "ok":
        write_latest_manifest(scan_result, qdrant)
    scan_result["qdrant"] = qdrant
    return scan_result
