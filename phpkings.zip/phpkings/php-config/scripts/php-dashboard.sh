#!/bin/bash

PHP_ROOT="${PHP_HOME_DIR:-/home/ads0905001/phpkings}"
PHP_CONFIG="${PHP_CONFIG_DIR:-${PHP_ROOT}/php-config}"
ENV_FILE="${PHP_CONFIG}/.env"
LOG_DIR="${PHP_CONFIG}/logs"
LOG_FILE="${LOG_DIR}/php-dashboard.log"
PID_FILE="${LOG_DIR}/php-dashboard.pid"
DASHBOARD_DIR="${PHP_ROOT}/php-dashboard"
VENV_DIR="${PHP_VENV_DIR:-/home/ads0905001/env/php-dashboard-env}"
DASHBOARD_CMD="${VENV_DIR}/bin/python php_dashboard.py"

load_env_vars() {
    if [ -f "${ENV_FILE}" ]; then
        echo "Loading environment variables from ${ENV_FILE}"
        while IFS='=' read -r key value || [ -n "$key" ]; do
            if [ -z "$key" ] || [[ $key == \#* ]]; then
                continue
            fi
            key=$(echo "$key" | xargs)
            value=$(echo "$value" | xargs)
            export "$key=$value"
        done < "${ENV_FILE}"
    else
        echo "Warning: .env file not found at ${ENV_FILE}"
    fi
}

dashboard_pid() {
    if [ ! -f "${PID_FILE}" ]; then
        return 1
    fi

    pid=$(cat "${PID_FILE}")
    if [ -n "${pid}" ] && kill -0 "${pid}" 2>/dev/null; then
        echo "${pid}"
        return 0
    fi

    rm -f "${PID_FILE}"
    return 1
}

dashboard_url_host() {
    if [ "${PHP_DASHBOARD_HOST}" = "0.0.0.0" ]; then
        hostname -I | awk '{print $1}'
    else
        echo "${PHP_DASHBOARD_HOST:-127.0.0.1}"
    fi
}

start_dashboard() {
    load_env_vars
    mkdir -p "${LOG_DIR}"
    cd "${DASHBOARD_DIR}" || exit 1

    if dashboard_pid > /dev/null; then
        echo "PHP dashboard is already running"
        exit 1
    fi

    if [ ! -x "${VENV_DIR}/bin/python" ]; then
        echo "Error: Python venv not found at ${VENV_DIR}"
        exit 1
    fi

    nohup ${DASHBOARD_CMD} > "${LOG_FILE}" 2>&1 &
    echo "$!" > "${PID_FILE}"
    sleep 3

    if dashboard_pid > /dev/null; then
        echo "PHP dashboard started"
        echo "Log file: ${LOG_FILE}"
        echo "URL: http://$(dashboard_url_host):${PHP_DASHBOARD_PORT}/phphelper/"
    else
        rm -f "${PID_FILE}"
        echo "Error: PHP dashboard failed to start"
        echo "Log file: ${LOG_FILE}"
        exit 1
    fi
}

stop_dashboard() {
    pid=$(dashboard_pid)
    if [ -z "${pid}" ]; then
        echo "PHP dashboard is not running"
        exit 0
    fi
    kill -15 "${pid}"
    rm -f "${PID_FILE}"
}

status_dashboard() {
    load_env_vars
    if dashboard_pid > /dev/null; then
        echo "PHP dashboard is running"
    else
        echo "PHP dashboard is not running"
    fi
}

case "$1" in
    start)
        start_dashboard
        ;;
    stop)
        stop_dashboard
        ;;
    restart)
        stop_dashboard
        sleep 2
        start_dashboard
        ;;
    status)
        status_dashboard
        ;;
    *)
        echo "Usage: $0 {start|stop|restart|status}"
        exit 1
        ;;
esac
