<?



/********************************************************************************
                      MODIFICATION  CONTROL  LOG
---------------------------------------------------------------------------------
  Mod  Date         Programmer        Comment
  ------------------------------------------------------------------------------
  001  03/13/2003   s.pradapkumar,      Initial version
  002  04/13/2005   Ravi kumar	     According to ace issue #1602
  003  10/21/2013   Rajasekar S		Add to Simplified Limitation Election Indicator	  
********************************************************************************* */


     include_once("header.php");
     include_once("qt_func.php");

     $myPageId = 1740;	     
     $status = GetUniqueUserInfo($o9Ljw, $qt_user_id, $siteid, $pageid, $lasttime);
     
     $my_page="olt_f1116_foregintx_ct.php";

	$FileStatus = GetCurrentStatus($qt_user_id);
	if ($FileStatus) {
		include(PROTECTED_PATHQT."html/InvalidStatus.html");
		echo "</form>";
		db_close();
		exit;
	}
	if ($myPageId >  $pageid) {
$_SQL_DataArray[] = array( "key"=> "pageid", "val"=>(int)$myPageId, "table"=>"auth_access");     	     	
$out_sqlparm = db_sql_paramformat($_SQL_DataArray);

$query_clause="update auth_access set ".$out_sqlparm["_SQL_UpdateClause"]." WHERE ";
$query_clause.= "qt_user_id=(?) "; db_sql_BuildParamArray($qt_user_id, "auth_access::qt_user_id");
	     	$insert_result = db_sql_query(array($query_clause), $_SQL_ParamsArray);
	     	$pageid  = $myPageId;
	     	
	}
	
	include("../oltproc/olt_section_track_end.php");
	
	
$_SQL_DataArray[] = array( "key"=> "form_1116_flow_ind", "val"=>'1', "table"=>"olt_flow_events");	
$out_sqlparm = db_sql_paramformat($_SQL_DataArray);

$query_flow="update olt_flow_events set ".$out_sqlparm["_SQL_UpdateClause"]." WHERE ";
$query_flow.= "qt_user_id=(?) "; db_sql_BuildParamArray($qt_user_id, "olt_flow_events::qt_user_id");
	$result_flow  = db_sql_query(array($query_flow), $_SQL_ParamsArray);
	
	include_once("olt_pagehdr.php");
	
	$err_flag =0;
	//$f1116_simp_limit_elec_ind = (int)$f1116_simp_limit_elec_ind;
  $Allowedarrayvalues = array("0", "1");
  	if($frgn_tax_cred_ind == 1)
  	{
		if(($f1116_file_ind != "") && (!IsValidValue($f1116_file_ind, $Allowedarrayvalues)))
		{
			$err_flag = 1;
			$f1116_file_ind_err = 1;
		}
	}
	else
	{
		$f1116_file_ind = 0;
	}
	if(($frgn_tax_cred_ind != "") && (!IsValidValue($frgn_tax_cred_ind, $Allowedarrayvalues)))
		{
			$err_flag = 1;
			$frgn_tax_cred_ind_err = 1;
		}

	
	$ArrayOneZeroValue = array("0", "1");
	
	/*if(($f1116_simp_limit_elec_ind != "") && (!IsValidValue($f1116_simp_limit_elec_ind, $ArrayOneZeroValue)))
	{
		$err_flag = 1;
		$f1116_simp_limit_elec_ind_err = 1;
	}*/

	if($err_flag == 0)
	{
		if($more == "1" && $nv_mode == "1")
		{
		  	
			include("olt_efile_rej_veri_redirect.php");  echo "<form name=form1 action=\"olt_f1116_foregintx_ct.php \" method=post>";
		   	BuildDynamicFormHiddenData("more=1");
		   	include(PROTECTED_PATHQT."html/f1116_foregintx_ct.html");
		}
		else
		{	
			if($f1116_file_ind == 1)
			{
				$f1116_reporton_1099_ind = 1;
				$f1116_incfrom_share_ind = 1;
				$f1116_not_filed_4563_ind = 1;
				$f1116_for_tax_limit_ind = 1;
				$f1116_owe_notrefund_ind = 1;
				$f1116_recog_by_us_ind = 1;
			}
			else
			{
				$f1116_reporton_1099_ind = 0;
				$f1116_incfrom_share_ind = 0;
				$f1116_not_filed_4563_ind = 0;
				$f1116_for_tax_limit_ind = 0;
				$f1116_owe_notrefund_ind = 0;
				$f1116_recog_by_us_ind = 0;
			}
			
			//$f1116_simp_limit_elec_ind = (int)$f1116_simp_limit_elec_ind;	
			
			//002
			$check_query ="select qt_user_id from f1116_without_form where ";
			$check_query .= "qt_user_id=(?) "; db_sql_BuildParamArray($qt_user_id, "f1116_without_form::qt_user_id");
			$check_result = db_sql_query(array($check_query), $_SQL_ParamsArray);
			$check_noOfRows = db_num_rows(array($check_result));
			
			if($check_noOfRows == 0)
			{
      $_SQL_DataArray[] = array( "key"=> "qt_user_id", "val"=>$qt_user_id, "table"=>"f1116_without_form");
      $out_sqlparm = db_sql_paramformat($_SQL_DataArray);
      
      $query ="insert into f1116_without_form(".$out_sqlparm['_SQL_FieldClause'].") values (".$out_sqlparm['_SQL_ValueClause'].")";
      $insert_result = db_sql_query(array($query), $_SQL_ParamsArray);
		   	}
$_SQL_DataArray[] = array( "key"=> "f1116_reporton_1099_ind", "val"=>(int)$f1116_reporton_1099_ind, "table"=>"f1116_without_form");			 
$_SQL_DataArray[] = array( "key"=> "f1116_incfrom_share_ind", "val"=>(int)$f1116_incfrom_share_ind, "table"=>"f1116_without_form");			 
$_SQL_DataArray[] = array( "key"=> "f1116_not_filed_4563_ind", "val"=>(int)$f1116_not_filed_4563_ind, "table"=>"f1116_without_form");			 
$_SQL_DataArray[] = array( "key"=> "f1116_for_tax_limit_ind", "val"=>(int)$f1116_for_tax_limit_ind, "table"=>"f1116_without_form");			 
$_SQL_DataArray[] = array( "key"=> "f1116_owe_notrefund_ind", "val"=>(int)$f1116_owe_notrefund_ind, "table"=>"f1116_without_form");			 
$_SQL_DataArray[] = array( "key"=> "f1116_recog_by_us_ind", "val"=>(int)$f1116_recog_by_us_ind, "table"=>"f1116_without_form");			 
		         if(($f1116_reporton_1099_ind == 1) && ($f1116_incfrom_share_ind == 1) && ($f1116_not_filed_4563_ind == 1) && ($f1116_for_tax_limit_ind == 1) && ($f1116_owe_notrefund_ind == 1) && ($f1116_recog_by_us_ind == 1))			 
$_SQL_DataArray[] = array( "key"=> "f1116_simp_limit_elec_ind", "val"=>'0', "table"=>"f1116_without_form");			 
		         			 
						 
$out_sqlparm = db_sql_paramformat($_SQL_DataArray);

$query_clause="update f1116_without_form set ".$out_sqlparm["_SQL_UpdateClause"]." WHERE ";
$query_clause.= "qt_user_id=(?) "; db_sql_BuildParamArray($qt_user_id, "f1116_without_form::qt_user_id");
			$update_result= db_sql_query(array($query_clause), $_SQL_ParamsArray);
			
			
			db_free_result(array($update_result));
		        
		        $frgn_tax_cred_ind = (int)$frgn_tax_cred_ind;	
		        
		        
$_SQL_DataArray[] = array( "key"=> "frgn_tax_cred_ind", "val"=>(int)$frgn_tax_cred_ind, "table"=>"organiser_ind");		        
$out_sqlparm = db_sql_paramformat($_SQL_DataArray);

$query_clause="update organiser_ind set ".$out_sqlparm["_SQL_UpdateClause"]." WHERE ";
$query_clause.= "qt_user_id=(?) "; db_sql_BuildParamArray($qt_user_id, "organiser_ind::qt_user_id");
		     	$insert_result = db_sql_query(array($query_clause), $_SQL_ParamsArray);
		     	
		        if($frgn_tax_cred_ind == 0)
			{
          $SelectQuery ="delete from form_1116 where ";
          $SelectQuery .= "qt_user_id=(?) "; db_sql_BuildParamArray($qt_user_id, "form_1116::qt_user_id");
          $delete   	 = db_sql_query(array($SelectQuery), $_SQL_ParamsArray);
          
          $SelectQuery ="delete from form_1116_partI where ";
          $SelectQuery .= "qt_user_id=(?) "; db_sql_BuildParamArray($qt_user_id, "form_1116_partI::qt_user_id");
          $delete   	 = db_sql_query(array($SelectQuery), $_SQL_ParamsArray);
          
          $SelectQuery ="delete from form_1116_partII where ";
          $SelectQuery .= "qt_user_id=(?) "; db_sql_BuildParamArray($qt_user_id, "form_1116_partII::qt_user_id");
          $delete   	 = db_sql_query(array($SelectQuery), $_SQL_ParamsArray);
          
          $SelectQuery ="delete from form_1116_schb where ";
          $SelectQuery .= "qt_user_id=(?) "; db_sql_BuildParamArray($qt_user_id, "form_1116_schb::qt_user_id");
          $delete   	 = db_sql_query(array($SelectQuery), $_SQL_ParamsArray);
          
          $SelectQuery ="delete from f1116_without_form where ";
          $SelectQuery .= "qt_user_id=(?) "; db_sql_BuildParamArray($qt_user_id, "f1116_without_form::qt_user_id");
          $delete   	 = db_sql_query(array($SelectQuery), $_SQL_ParamsArray);
				
		        	/* NEXT HTML PAGE BEGIN */
		        	if($nv_mode=="1")
				{
					$SectionEnableIndex = "2";
					include("olt_org_adjust_call.php");
				}
				else
				include("olt_org_credit_call.php");	
				include_once("olt_pagehdr.php");
				          
				include("olt_efile_rej_veri_redirect.php");  echo "<form name=form1 action=\"$next_php.php \" method=post>";
				BuildDynamicFormHiddenData("step=w2done");
				include(PROTECTED_PATHQT."html/$next_html.html");
				
	        	}
			else if(($f1116_reporton_1099_ind == 1 && $f1116_incfrom_share_ind == 1 && $f1116_not_filed_4563_ind == 1 && $f1116_for_tax_limit_ind == 1 && $f1116_owe_notrefund_ind == 1 && $f1116_recog_by_us_ind == 1))  
			{
        $SelectQuery ="delete from form_1116 where ";
        $SelectQuery .= "qt_user_id=(?) "; db_sql_BuildParamArray($qt_user_id, "form_1116::qt_user_id");
        $delete   	 = db_sql_query(array($SelectQuery), $_SQL_ParamsArray);
        
        $SelectQuery ="delete from form_1116_partI where ";
        $SelectQuery .= "qt_user_id=(?) "; db_sql_BuildParamArray($qt_user_id, "form_1116_partI::qt_user_id");
        $delete   	 = db_sql_query(array($SelectQuery), $_SQL_ParamsArray);
        
        $SelectQuery ="delete from form_1116_partII where ";
        $SelectQuery .= "qt_user_id=(?) "; db_sql_BuildParamArray($qt_user_id, "form_1116_partII::qt_user_id");
        $delete   	 = db_sql_query(array($SelectQuery), $_SQL_ParamsArray);
        
        $SelectQuery ="delete from form_1116_schb where ";
        $SelectQuery .= "qt_user_id=(?) "; db_sql_BuildParamArray($qt_user_id, "form_1116_schb::qt_user_id");
        $delete   	 = db_sql_query(array($SelectQuery), $_SQL_ParamsArray);

		 		include("olt_efile_rej_veri_redirect.php");  
		 		echo "<form name=form1 action=\"olt_f1116_foregintx_ct_amt.php \" method=post>";
				include(PROTECTED_PATHQT."html/f1116_foregintx_ct_amt.html");
			}
			else
			{	 
        $_SQL_DataArray[] = array( "key"=> "f1116_foreign_tax_cdt", "val"=>'0', "table"=>"f1116_without_form");				
        $out_sqlparm = db_sql_paramformat($_SQL_DataArray);
        
        $query_clause="update f1116_without_form set ".$out_sqlparm["_SQL_UpdateClause"]." WHERE ";
        $query_clause.= "qt_user_id=(?) "; db_sql_BuildParamArray($qt_user_id, "f1116_without_form::qt_user_id");
        $update_result= db_sql_query(array($query_clause), $_SQL_ParamsArray);
        
        db_free_result(array($update_result));
				
				$form1116_resident_country = "";
				$query_res_cntry ="select form1116_resident_country from f1116_without_form where ";
				$query_res_cntry .= "qt_user_id=(?) "; db_sql_BuildParamArray($qt_user_id, "f1116_without_form::qt_user_id");
				$result_res_cntry = db_sql_query(array($query_res_cntry), $_SQL_ParamsArray);
				$noOfRows = db_num_rows(array($result_res_cntry));
				if ($noOfRows > 0) 
				{ 
					$res_data = db_fetchrow(array($result_res_cntry, DB_GETMODE_ASSOC));
					$form1116_resident_country = $res_data["form1116_resident_country"];    
				}
				db_free_result(array($result_res_cntry));
				
				if($form1116_resident_country == "")
				{
					include("olt_efile_rej_veri_redirect.php");  
					echo "<form name=form1 action=\"olt_f1116_fortax_resident_cntry.php \" method=post>";
					include(PROTECTED_PATHQT."html/f1116_fortax_resident_cntry.html");
				}
				else
				{
					include("olt_efile_rej_veri_redirect.php");  echo "<form name=form1 action=\"olt_f1116_foregintx_ct_ind.php \" method=post>";
					include(PROTECTED_PATHQT."html/f1116_foregintx_ct_ind.html");
				}
			}
		
		}
	}
	else
	{
	include("olt_efile_rej_veri_redirect.php");  echo "<form name=form1 action=\"olt_f1116_foregintx_ct.php \" method=post>";
	BuildDynamicFormHiddenData("verify=$correctverify");
	include(PROTECTED_PATHQT."html/f1116_foregintx_ct.html");
	}
include("olt_pageftr.php");	
/* HTML END */
?>