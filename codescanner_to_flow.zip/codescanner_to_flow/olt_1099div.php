<?

/* *******************************************************************
   *******************************************************************
        qt_1099divdone.php -> qt_1099div.php -> qt_1099divdone.php
	../html/1099divdone.html  ->  ../html/1099div.html

/********************************************************************************
                      MODIFICATION  CONTROL  LOG
---------------------------------------------------------------------------------
  Mod  Date         Programmer        Comment
  ------------------------------------------------------------------------------
  004  06/18/2003   Mohamed Azmal     Initial version
  005  10/21/2004   Akbar Ali	      2004 changes 	
  006  03/03/2005   Ruban Antony      Added a condition not to validate the state &
  				      zip code 	entries if foreign address is given
  007  03/03/2005   Ruban Antony      Zip code is not needed for foreign country
  008  06/06/2013   Jerry Thimothy J  Included city allocation operations
********************************************************************************* */

     include_once("header.php");
     include_once("qt_func.php");
     
     $my_page = "olt_1099div.php";

     $status = GetUniqueUserInfo($o9Ljw, $qt_user_id, $siteid, $pageid, $lasttime);

	$FileStatus = GetCurrentStatus($qt_user_id);
	if ($FileStatus) {
		include(PROTECTED_PATHQT."html/InvalidStatus.html");
		echo "</form>";
		db_close();
		exit;
	}

   	include("../oltproc/olt_section_track_end.php");
   	
   	/*$form1040_ind = "";
	$SelectQuery ="select form1040_ind from ind_label where ";
	$SelectQuery .= "qt_user_id=(?) "; db_sql_BuildParamArray($qt_user_id, "ind_label::qt_user_id");
$result   	 = db_sql_query(array($SelectQuery), $_SQL_ParamsArray);
	$noOfRows = db_num_rows(array($result));
	if ($noOfRows > 0) 
	{ 
		$res_data		= db_fetchrow(array($result, DB_GETMODE_ASSOC));
		$form1040_ind		= UDF_trim($res_data["form1040_ind"]); 		
	}
	db_free_result(array($result));*/
  
  
/*
Box1 = Gross Description
Box2 = Taxable Amount
Box2b = Taxable amount not determined
      = Total Distribution

Box3 = Capital Gain
Box4 = Federal income tax withheld
Box5 = Employeee contributions or insuarnce premiums
Box6 - Net unrealized appreciation in employers securities
Box7 =  Distribution code
Box8 = OtherPercentage
Box9a = Your percentage of total distribution
Box9b = Total employee contributions

Box10 = State Tax witheld
Box11 = State/Payers State No.
Box12 = State Distribution

Box13 = Local Tax withheld
Box14 = Name of Locality
Box15 = Local Distribution

*/
     include_once("header.php");
     include_once("qt_func.php");

     $my_page="olt_1099div.php";

	$err_flag=0;
	//if($OLTPRO_masterID != "")
	if($show_aloc_state_ind == 1)
	{
		$aloc_state     = UDF_trim($aloc_state);
		if($show_city_combo_ind == 1)
			$aloc_city	=	UDF_trim($aloc_city);
	}
	$payeraddress 	= fixtext($payeraddress);
	$payeraddress2 	= fixtext($payeraddress2);
	$payername	= fmtvalue($payername);
	//$payername 	= fixtext($payername);
	$payercity 	= fmtvalue($payercity);
	$payerstate 	= fmtvalue($payerstate);
	$payerzip	= fmtvalue($payerzip);
	$payerin 	= UDF_str_replace("-","",$payerin);
	$payerin 	= fmtvalue($payerin);
	$recipientin 	= fmtvalue($recipientin);
	$tot_cap_gain 	= fmtvalue($tot_cap_gain);
	$post_cap_gain 	= fmtvalue($post_cap_gain);
	$rate_gain 	= fmtvalue($rate_gain);
	$sec_897_ord_div 	= fmtvalue($sec_897_ord_div);
	$sec_897_cap_gain 	= fmtvalue($sec_897_cap_gain);
	$fed_inc_tax_with= fmtvalue($fed_inc_tax_with);
	$ord_div 	= fmtvalue($ord_div);
	$qual_div 	= fmtvalue($qual_div);
	$recipientname 	= fixtext($recipientname);
	$recipientaddress = fmtvalue($recipientaddress);
	$recipientaddress2 = fmtvalue($recipientaddress2);
	//if($recipientstate!=".")//**006
	{
	$recipientstate = fixtext($recipientstate);	
	}
	$unrecap_sec_1250= fmtvalue($unrecap_sec_1250);
	$sec_1202_gain	= fmtvalue($sec_1202_gain);
	$nontax_dist	= fmtvalue($nontax_dist);
	$inv_exp	= fmtvalue($inv_exp);
	$for_tax_paid	= fmtvalue($for_tax_paid);
	$f1116_block_autocalc_ind =(int) $f1116_block_autocalc_ind;
	
			
	$for_country	= fmtvalue($for_country);
	$acc_nbr	= fmtvalue($acc_nbr);
	$cash_liq	= fmtvalue($cash_liq);
	$noncash_liq	= fmtvalue($noncash_liq);
	$nominee_amt_div	= fmtvalue($nominee_amt_div);
	$nominee_qual_div_amt	= fmtvalue($nominee_qual_div_amt);
	$nominee_cap_gain_amt	= fmtvalue($nominee_cap_gain_amt);
	
	$exempt_inst_div	= fmtvalue($exempt_inst_div);
	$bond_inst_div		= fmtvalue($bond_inst_div);
	$nominee_state  	= fmtvalue($nominee_state);
	$nominee_identify       = fmtvalue($nominee_identify);
	$state_tax_withheld	= fmtvalue($state_tax_withheld);
	$section_199a_dividends = fmtvalue($section_199a_dividends);
	//$qual_5yr_gain = fmtvalue($qual_5yr_gain); //005
	//$recipientcity = fixtext($recipientcity);
	
	$payer_frgn_address=UDF_str_replace("#","" ,$payer_frgn_address); 
	$payer_frgn_address=UDF_str_replace(".","" ,$payer_frgn_address); 
	$payer_frgn_address=UDF_str_replace(",","" ,$payer_frgn_address); 
	$payer_frgn_address=UDF_str_replace("'"," " ,$payer_frgn_address);  
	$payer_frgn_address=UDF_str_replace("  "," " ,$payer_frgn_address); 
	$payer_frgn_address=UDF_str_replace("  "," " ,$payer_frgn_address);  
	$payer_frgn_address2=UDF_str_replace("#","" ,$payer_frgn_address2); 
	$payer_frgn_address2=UDF_str_replace(".","" ,$payer_frgn_address2); 
	$payer_frgn_address2=UDF_str_replace(",","" ,$payer_frgn_address2); 
	$payer_frgn_address2=UDF_str_replace("'"," " ,$payer_frgn_address2);  
	$payer_frgn_address2=UDF_str_replace("  "," " ,$payer_frgn_address2); 
	$payer_frgn_address2=UDF_str_replace("  "," " ,$payer_frgn_address2); 
	$payer_frgn_city		= fmtvalue($payer_frgn_city);
	$payer_frgn_city		= UDF_str_replace("."," " ,$payer_frgn_city); 
	$payer_frgn_city		= UDF_str_replace("  "," " ,$payer_frgn_city); 
	$payer_frgn_state		= fmtvalue($payer_frgn_state);
	$payer_frgn_state		= UDF_str_replace("  "," " ,$payer_frgn_state); 
	$payer_frgn_zip		= fmtvalue($payer_frgn_zip);
	$payer_frgn_add_ind = (int)UDF_trim($payer_frgn_add_ind);
	$FATCA_filing_req_ind = (int)UDF_trim($FATCA_filing_req_ind);
	
	$recip_frgn_address=UDF_str_replace("#","" ,$recip_frgn_address); 
	$recip_frgn_address=UDF_str_replace(".","" ,$recip_frgn_address); 
	$recip_frgn_address=UDF_str_replace(",","" ,$recip_frgn_address); 
	$recip_frgn_address=UDF_str_replace("  "," " ,$recip_frgn_address); 
	$recip_frgn_address=UDF_str_replace("  "," " ,$recip_frgn_address);   
	$recip_frgn_address2=UDF_str_replace("#","" ,$recip_frgn_address2); 
	$recip_frgn_address2=UDF_str_replace(".","" ,$recip_frgn_address2); 
	$recip_frgn_address2=UDF_str_replace(",","" ,$recip_frgn_address2); 
	$recip_frgn_address2=UDF_str_replace("  "," " ,$recip_frgn_address2); 
	$recip_frgn_address2=UDF_str_replace("  "," " ,$recip_frgn_address2);
	$recip_frgn_city		= fmtvalue($recip_frgn_city);
	$recip_frgn_city		= UDF_str_replace("."," " ,$recip_frgn_city); 
	$recip_frgn_city		= UDF_str_replace("  "," " ,$recip_frgn_city); 
	$rcpnt_frgn_state		= fmtvalue($rcpnt_frgn_state);
	$rcpnt_frgn_state		= UDF_str_replace("  "," " ,$rcpnt_frgn_state); 
	$recip_frgn_zip		= fmtvalue($recip_frgn_zip);
	$rcpnt_frgn_ctry_code	= fmtvalue($rcpnt_frgn_ctry_code);
	$recip_frgn_add_ind = (int)UDF_trim($recip_frgn_add_ind);
	
	$div_areacode 		= UDF_trim($div_areacode);
	$div_phone 		= UDF_trim($div_phone);
	//$dividend_report_ind = (int)UDF_trim($dividend_report_ind);
	$report_to_frm8958_ind	= (int)$report_to_frm8958_ind;
	$div1099_chld_ord_div_ind	= (int)$div1099_chld_ord_div_ind;
	$div1099_chld_qual_div_ind	= (int)$div1099_chld_qual_div_ind;
	
	$payeraddress 	= FormatAddress($payeraddress);
	$payeraddress2 	= FormatAddress($payeraddress2);
	$payercity 	= FormatCity($payercity);
	$payer_frgn_address=FormatAddress($payer_frgn_address); 
	$payer_frgn_address2=FormatAddress($payer_frgn_address2); 
	
	$recipientaddress = FormatAddress($recipientaddress); 
	$recipientaddress2 = FormatAddress($recipientaddress2); 
	$recipientcity = FormatCity($recipientcity);
	$recip_frgn_address = FormatAddress($recip_frgn_address); 
	$recip_frgn_address2 = FormatAddress($recip_frgn_address2);
	
	//$qualified_dividend_ind_Yes	=(int) $qualified_dividend_ind_Yes;
	//$qualified_dividend_ind_No	=(int) $qualified_dividend_ind_No;

	/*$query ="SELECT OLTPRO_masterID FROM oltpro_user_auth where ";
	$query .= "qt_user_id=(?) "; db_sql_BuildParamArray($qt_user_id, "oltpro_user_auth::qt_user_id");
	$result = db_sql_query(array($query), $_SQL_ParamsArray);
	if($res_data   = db_fetchrow(array($result, DB_GETMODE_ASSOC)))
	{
		$OLTPRO_masterID  = UDF_trim($res_data["OLTPRO_masterID"]);
	}
	db_free_result(array($result));*/
	if($chkNom !=1 )
	  $chkNom=0;
	  
	  $ArrayOneZeroValue = array("0", "1");
	  
	if(($chkNom != "") && (!IsValidValue($chkNom, $ArrayOneZeroValue)))
	{
		$err_flag = 1;
		$chkNom_err = 1;
	}
	
	if(($div1099_chld_ord_div_ind != "") && (!IsValidValue($div1099_chld_ord_div_ind, $ArrayOneZeroValue)))
	{
		$err_flag = 1;
		$div1099_chld_ord_div_ind_err = 1;
	}
	
	if(($div1099_chld_qual_div_ind != "") && (!IsValidValue($div1099_chld_qual_div_ind, $ArrayOneZeroValue)))
	{
		$err_flag = 1;
		$div1099_chld_qual_div_ind_err = 1;
	}
	
	if($F8958_Eligible_Questions == "true")
	{
		if(($report_to_frm8958_ind != "") && (!IsValidValue($report_to_frm8958_ind, $ArrayOneZeroValue)))
		{
			$err_flag = 1;
			$report_to_frm8958_ind_err = 1;
		}
	}
	
	if(($FATCA_filing_req_ind != "") && (!IsValidValue($FATCA_filing_req_ind, $ArrayOneZeroValue)))
	{
		$err_flag = 1;
		$FATCA_filing_req_ind_err = 1;
	}
	
	if(($f1116_block_autocalc_ind != "") && (!IsValidValue($f1116_block_autocalc_ind, $ArrayOneZeroValue)))
	{
		$err_flag = 1;
		$f1116_block_autocalc_ind_err = 1;
	}
	
	  

//if($foreingn_taxcdt_ind == "")
//	$foreingn_taxcdt_ind = 0;

//if (UDF_trim($OLTPRO_masterID) == '')
//{
	/*if(($payername != "" && !isAlphaNumericnumsp($payername))||($payername == "")) 
	{
	   $err_flag=1;
	   $pname_empty_err_flag=1;
	}*/
//}

	if($div_areacode!="" || $div_phone !="")
	{
		if (!(IsNumeric($div_areacode)) || (UDF_strlen($div_areacode) <> 3) || (!(IsValidAreaCode($div_areacode))))
		{
		 	$err_flag=1;
		 	$area_err_flag=1;
		}
		if (!(IsNumeric($div_phone)) || (UDF_strlen($div_phone) <> 7) || (!(IsValidPhoneNum($div_phone))))
		{
		 	$err_flag=1;
		 	$phone_err_flag=1;
		}
	}

	/*if(($dividend_report_ind == 0) && (($payerin == "") || (UDF_strlen($payerin) != 9) || (!IsValidEIN($payerin)) || ($payerin == "000000000")))
	{
	   $err_flag=1;
	   $fin_err_flag=1;
	}
	else */
	{
		/*if(($payerin != "") && ((UDF_strlen($payerin) != 9) || (!IsAlphaNumeric($payerin)) || ($payerin == "000000000"))) // || (!IsValidEIN($payerin))
		{
		   $err_flag=1;
		   $fin_err_flag=1;
		}*/
	}
	//if($filing_status == "joint") 
		$AllowedArrayValues = array("0", "1", "2");
	/*else
		$AllowedArrayValues = array("0");*/
	
	if(($whose_div != "") && (!IsValidValue($whose_div, $AllowedArrayValues)))
	{
		$err_flag = 1;
		$whose_div_err = 1;
	}
	$joint_ind=0;          
	if ($whose_div == 1)
	{
		$who ='S';
	}
	else if ($whose_div == 2)
	{
		$who='P';
		$joint_ind=1;
	}
	else
	{
		$who='P';
	}
	$query="select ssn from customer where ";
	$query.= "qt_user_id=(?) "; db_sql_BuildParamArray($qt_user_id, "customer::qt_user_id");
	$query.= "and relation=(?) "; db_sql_BuildParamArray($who, "customer::relation");
	$result_1040 = db_sql_query(array($query), $_SQL_ParamsArray);
	$noOfRows = db_num_rows(array($result_1040));
	if($noOfRows > 0)
	{
		$res_data=db_fetchrow(array($result_1040, DB_GETMODE_ASSOC));
		$recipientin        = $res_data["ssn"];
	}
	db_free_result(array($result_1040));
	if(($recipientin == ""))
	{	
		$err_flag = 1;
		$recipientin_err_flag = 1;
	}	
	$AllowedArrayValues = array("0", "1", "2");
	if(($dividend_report_ind != "") && (!IsValidValue($dividend_report_ind, $AllowedArrayValues)))
	{
		$err_flag = 1;
		$dividend_report_ind_err = 1;
	}

if($nv_mode=="1")
{
	if(($payer_1099DIV != "") || (UDF_trim($OLTPRO_masterID) != ''))
	{
		$cmn_frgn_addr_ind 	= "payer_frgn_add_ind";		
		$cmn_US_addr  		= "payeraddress";	${$cmn_US_addr."Skip"} = 1;
		$cmn_US_addr2  		= "payeraddress2";	${$cmn_US_addr2."Skip"} = 1;
		$cmn_US_city 		= "payercity";    	${$cmn_US_city."Skip"} = 1;    
		$cmn_US_state 		= "payerstate";      	${$cmn_US_state."Skip"} = 1; 
		$cmn_US_zip 		= "payerzip"; 		${$cmn_US_zip."Skip"} = 1;
		$cmn_US_zip_ext		= "";
	
		$cmn_frgn_addr          = "payer_frgn_address";		${$cmn_frgn_addr."Skip"} = 1;
		$cmn_frgn_addr2         = "payer_frgn_address2";	${$cmn_frgn_addr2."Skip"} = 1;
		$cmn_frgn_city 		= "payer_frgn_city";		${$cmn_frgn_city."Skip"} = 1;
		$cmn_frgn_state 	= "payer_frgn_state";		${$cmn_frgn_state."Skip"} = 1;
		$cmn_frgn_country_code  = "payer_frgn_country";		${$cmn_frgn_country_code."Skip"} = 1;
		$cmn_frgn_zip 		= "payer_frgn_zip";		${$cmn_frgn_zip."Skip"} = 1;
		
		/*if($dividend_report_ind == 1)
		{
			if($payer_frgn_add_ind == 0)
			{	
				if(($payeraddress == "") && ($payercity == "") && (($payerstate == "") || ($payerstate == ".")) && ($payerzip == ""))
				{
					$payeraddressSkip = 1;
					$payercitySkip 	= 1;
					$payerstateSkip = 1;
					$payerzipSkip = 1;
				}
			}
			else
			{
				if(($payer_frgn_address == "") && ($payer_frgn_city == "") && ($payer_frgn_state == "") && ($payer_frgn_zip == "") && ($payer_frgn_country == ""))
				{
					$payer_frgn_addressSkip = 1;
					$payer_frgn_citySkip 	= 1;
					$payer_frgn_stateSkip = 1;
					$payer_frgn_zipSkip = 1;
					$payer_frgn_countrySkip = 1;
				}
			}
		}*/
		
		
		
		include("../oltproc/commonAddressPnl.php");
	}
}
else
{
	if($payer_frgn_add_ind == 1)
	{
		if(($payer_frgn_address =="") || (UDF_strlen($payer_frgn_address) < 2))
		{
			$err_flag=1;
			$payer_frgn_address_err_flag=1;
		}
		if(($payer_frgn_city != "") &&( UDF_strlen($payer_frgn_city) < 3))
		{
			$err_flag=1;
			$payer_frgn_city_err_flag=1;
		}	
		if(UDF_strlen(UDF_trim($payer_frgn_country))==0)
		{
		      $err_flag = 1;
		      $payer_frgn_country_err_flag = 1;       
		}	 			
		if(!fmtNamesp1($payer_frgn_state))
		{
			$err_flag = 1;
			$payer_frgn_state_err_flag=1;       
		}
		if(!is_null($payer_frgn_zip) && !IsValidForeignPostalCode($payer_frgn_zip))
		{
			$err_flag = 1;
			$payer_frgn_zip_err_flag=1;
		}
	}
	else
	{

		$payeraddress = UDF_substr($payeraddress, 0, 70);
		
		if(!isAlphaNumericsp($payeraddress))
		{
		   $err_flag=1;
		   $paddr_err_flag=1;
		
		}
		
		//if($payerstate!=".")
		{
			if(($payeraddress!="" || $payercity!="") && ($payerstate != "") && (IsValidState($payerstate) == 0) )
			{
				  $err_flag=1;
				  $pstate_err_flag=1;   			  
			}
		}
		if ((($payerstate != "") && ($payerzip != "") && ($payercity != "")) && ($payeraddress == "") )
			 {  			   
				   $err_flag=1;
		  $paddr_err_flag=1;
		}
		
		
		if((!isAlphaNumericsp($payercity)) || ($payercity == ""))
		{
		   $err_flag=1;
		   $pcity_err_flag=1;
		}
	
		//if($payerstate!=".")//**006
		{
			if(!isNumeric($payerzip))
			{
			  
			  $err_flag=1;
			  $pzip_err_flag=1;
			  
			 }
			
			if((isNumeric($payerzip))&& ($payerstate == ""))
			{			  
				  $err_flag=1;
				  $pstate_err_flag=1;
			  	 	  
			}	
			
			if($payerzip == "")
			{	
			  	$err_flag=1;
			  	$pzip_err_flag=1;
			}
			
			if(UDF_strlen($payerzip) != 5)
			{
			  	$err_flag=1;
			  	$pzip_err_flag=1;
			} 
			$validStZip = IsValidZip($payerstate, $payerzip);
			  
			if ($validStZip == 0) 
			{ 
			  $err_flag=1;
			  $pzip_err_flag=1;
			}	
		}
	}
}
//if($OLTPRO_masterID != "")
if($show_aloc_state_ind == 1)
{
	if($aloc_state!=".")
	{
		
		if(($aloc_state == "") || (!fmtName($aloc_state)) || (UDF_strlen($aloc_state) != 2))
		{
		  $err_flag=1;
		  $aloc_state_err_flag=1;
		}
		
		if (IsValidState($aloc_state) == 0) 
		{
		  $err_flag=1;
		  $aloc_state_err_flag=1;
		} 
		
		
	}
	
	if(($show_city_combo_ind == 1)&&(UDF_in_array($aloc_state, $aloc_state_array))&&($aloc_city==""))
	{
		$err_flag=1;
		$aloc_city_err_flag=1;
	}
}
if($nv_mode=="1")
{ 
	$cmn_frgn_addr_ind 	= "recip_frgn_add_ind";		
	$cmn_US_addr  		= "recipientaddress";
	$cmn_US_addr2  		= "recipientaddress2";	
	$cmn_US_city 		= "recipientcity";        
	$cmn_US_state 		= "recipientstate";       
	$cmn_US_zip 		= "recipientzip"; 
	
	$cmn_frgn_addr          = "recip_frgn_address";	
	$cmn_frgn_addr2         = "recip_frgn_address2";	
	$cmn_frgn_city 		= "recip_frgn_city";
	$cmn_frgn_state 	= "rcpnt_frgn_state";
	$cmn_frgn_country_code  = "rcpnt_frgn_ctry_code";
	$cmn_frgn_zip 		= "recip_frgn_zip";
	include("../oltproc/commonAddressPnl.php");
}
else
{
if($recip_frgn_add_ind == 1)
{
	if(($recip_frgn_address =="") || (UDF_strlen($recip_frgn_address) < 2))
	{
		$err_flag=1;
		$recip_frgn_address_err_flag=1;
	}
	if(($recip_frgn_city != "") &&( UDF_strlen($recip_frgn_city) < 3))
	{
		$err_flag=1;
		$recip_frgn_city_err_flag=1;
	}	
	if(UDF_strlen(UDF_trim($rcpnt_frgn_ctry_code))==0)
	{
	      $err_flag = 1;
	      $rcpnt_frgn_ctry_code_err_flag = 1;       
	}	 			
	if(!fmtNamesp1($rcpnt_frgn_state))
	{
		$err_flag = 1;
		$rcpnt_frgn_state_err_flag=1;       
	}
	if(!is_null($recip_frgn_zip) && !IsValidForeignPostalCode($recip_frgn_zip))
	{
		$err_flag = 1;
		$recip_frgn_zip_err_flag=1;
	}
}
else
{	
	//if($recipientstate!=".") //**006
	{
		if(($recipientzip == "") || (!isNumeric($recipientzip)) || (UDF_strlen($recipientzip) != 5))
		{
		  $err_flag=1;
		  $rzip_err_flag=1;
		}
		$validStZip = IsValidZip($recipientstate, $recipientzip);
		if (($recipientstate != "") && ($validStZip == 0) )
		{ 
		  $err_flag=1;
		  $rzip_err_flag=1;
		}	
		if(($recipientstate == "") || (UDF_strlen($recipientstate) != 2) || (!fmtname($recipientstate)))
		{
		   $err_flag=1;
		   $rstate_err_flag=1;
		}
		if (($recipientstate != "") && (IsValidState($recipientstate) == 0) )
		{ 
		  $err_flag=1;
		  $rstate_err_flag=1;
		}
	}
	if(($recipientaddress == "") ||  (UDF_strlen($recipientaddress) > 70))
	{
	   $err_flag=1;
	   $raddr_err_flag=1;
	}
	
	if(($recipientcity == "") ||  (!isAlphaNumericnumsp($recipientcity)))
	{
	   $err_flag=1;
	   $rcity_err_flag=1;
	}
}
}
/*if(UDF_strlen($recipientcity) <= 3)
{
  $err_flag=1;
  $rcitylen_err_flag=1;
}*/
/*if(($payercity != "") && (UDF_strlen($payercity) <= 3))
{
  $err_flag=1;
  $pcitylen_err_flag=1;
}*/
if(($noncash_liq != "") && (!isNumeric($noncash_liq)))
{
   $err_flag=1;
   $noncash_err_flag=1;
}
if(($cash_liq != "") && (!isNumeric($cash_liq)))
{
   $err_flag=1;
   $cashdist_err_flag=1;
}
/*if(($acc_nbr != "") && (!(UDF_strlen($acc_nbr) >0) || (!IsAlphaNumeric($acc_nbr))))
{
   $err_flag=1;
   $acct_err_flag=1;
}*/
/*if(($for_country != "") && (!isAlphaNumericsp($for_country)))
{
   $err_flag=1;
   $forcount_err_flag=1;
}*/
if(($for_country == "") && ($f1116_block_autocalc_ind == 1) && ($for_tax_paid > 0))
{
	$err_flag = 1;
	$forcount_err_flag = 1;
}
else if(UDF_strlen(UDF_trim($for_country))!=0)
{
	$AllowedArrayComboValue = array('','UO','VA','RC','HT','96','95','86');
	
	$get_countryname_qry ="select country_name from general_country_code where ";
	$get_countryname_qry .= "country_cd=(?) "; db_sql_BuildParamArray($for_country, "general_country_code::country_cd");
	$countryname_result  = db_sql_query(array($get_countryname_qry), $_SQL_ParamsArray);
	$countryname_noOfRows = db_num_rows(array($countryname_result));
	if($countryname_noOfRows > 0)
	{}
	else if(($for_country != "") && (!IsValidValue($for_country, $AllowedArrayComboValue)))
	{
		$err_flag = 1;
		$forcount_err_flag = 1;
	}
	db_free_result(array($countryname_result));
}
if(($inv_exp != "") && (!isNumeric($inv_exp)))
{
   $err_flag=1;
   $invexp_err_flag=1;
}
if(($ord_div == "") || (!isNumeric($ord_div)))
{
   $err_flag=1;
   $ordiv_err_flag=1;
}
/*if($ord_div == 0)
{
   $err_flag=1;
   $ordiv_err_flag=1;
}*/
if(($qual_div != "") && (!isNumeric($qual_div)))
{
   $err_flag=1;
   $qual_div_err_flag=1;
}
if(($section_199a_dividends == "") || (!isNumeric($section_199a_dividends)))
{
   $err_flag=1;
   $section_199a_err_flag=1;
}
else if(($section_199a_dividends > $ord_div) && ($PassValidationInd != 1))
{
	$err_flag=1;
   	$section_199a_err_flag1=1;
   	$nv_dup_warn_msg .= "<br><label class='control control--checkbox' style='float:left' >Check here if your information is correct. <INPUT TYPE=checkbox value='1' name=PassValidationInd>&nbsp;<div class=\"control__indicator\"></div></label>";
}
$more_qual_val_err = 0;
if($qual_div > $ord_div)
{
   $err_flag = 1;
   //$qual_div_err_flag = 1;
   $more_qual_val_err = 1;
}

if(UDF_trim($chkNom) == 1)
{
	if(($nominee_amt_div == "") || (!isNumeric($nominee_amt_div)))
	{
		$err_flag=1;
		$nominee_amt_div_err_flag=1;
	}
	else if($nominee_amt_div > $ord_div)
	{
		$err_flag=1;
		$nominee_amt_div_err_flag1=1;
	}
	
	if(($nominee_qual_div_amt == "") || (!isNumeric($nominee_qual_div_amt)))
	{
		$err_flag=1;
		$qual_div_amt_err_flag=1;
	}
	else if($nominee_qual_div_amt > $qual_div)
	{
		$err_flag=1;
		$qual_div_amt_err_flag1=1;
	}

	if (($nominee_cap_gain_amt == "") || (!isNumeric($nominee_cap_gain_amt)))
	{
		$err_flag=1;
		$cap_gain_amt_err_flag=1;
	}
	else if($nominee_cap_gain_amt > $tot_cap_gain)
	{
		$err_flag=1;
		$cap_gain_amt_err_flag1=1;
	}
}

if(($for_tax_paid != "") && (!isNumeric($for_tax_paid)))
{
   $err_flag=1;
   $fortax_err_flag=1;
}
if(($nontax_dist != "") && (!isNumeric($nontax_dist)))
{
   $err_flag=1;
   $nontax_err_flag=1;
}
if(($sec_1202_gain != "") && (!isNumeric($sec_1202_gain)))
{
   $err_flag=1;
   $sect_err_flag=1;
}
if(($unrecap_sec_1250 != "") && (!isNumeric($unrecap_sec_1250)))
{
   $err_flag=1;
   $secgain_err_flag=1;
}
if(($rate_gain != "") && (!isNumeric($rate_gain)))
{
   $err_flag=1;
   $rategain_err_flag=1;
}
if(($sec_897_ord_div != "") && (!isNumeric($sec_897_ord_div)))
{
   $err_flag=1;
   $sec897_orddiv_err_flag=1;
}
if(($sec_897_cap_gain != "") && (!isNumeric($sec_897_cap_gain)))
{
   $err_flag=1;
   $sec897_capgain_err_flag=1;
}
if(($tot_cap_gain != "") && (!isNumeric($tot_cap_gain)))
{
   $err_flag=1;
   $totcapgain_err_flag=1;
}

//005 Begin
/*
if(($qual_5yr_gain != "") && (!isNumeric($qual_5yr_gain)))
{
   $err_flag=1;
   $qual5yrgain_err_flag=1;
}

if(($capital_gain_dist != "") && (!isNumeric($capital_gain_dist)))
{
   $err_flag=1;
   $capgaindist_err_flag=1;
}
*/
//005 End

if(($fed_inc_tax_with != "") && (!isNumeric($fed_inc_tax_with)))
{
   $err_flag=1;
   $fedtax_err_flag=1;
}

if(($exempt_inst_div != "") && (!isNumeric($exempt_inst_div)))
{
   $err_flag=1;
   $exempt_inst_div_err_flag=1;
}
if(($bond_inst_div != "") && (!isNumeric($bond_inst_div)))
{
   $err_flag=1;
   $bond_inst_div_err_flag=1;
}
if($nominee_state !=".")
{
	if(($nominee_state!="") && (IsValidState($nominee_state) == 0) )
	{ 
	  $err_flag=1;
	  $nominee_state_err_flag=1;
	}
}
//if(($nominee_identify != "") && ((!isNumeric($nominee_identify)) || (UDF_strlen($nominee_identify) != 9)))
if ((($nominee_identify != "") && (IsAlphaNumeric($nominee_identify) == 0)) || (UDF_strlen($nominee_identify) > 16))
{
   $err_flag=1;
   $nominee_identify_err_flag=1;
}
else if (($nominee_state == "MN") && ($state_tax_withheld > 0) && ((!fmtNum($nominee_identify)) || ($nominee_identify == "") || (UDF_strlen($nominee_identify) != 7)))
{
	$err_flag = 1;
	$nominee_identify_err_flag = 1;
}

if(($state_tax_withheld != "") && (!isNumeric($state_tax_withheld)))
{
   $err_flag=1;
   $state_tax_withheld_err_flag=1;
}

/*if($section_199a_dividends > 0) 
{
	if($qualified_dividend_ind_Yes =="0")	//$qualified_dividend_ind_No == "0" && 
	{
		$err_flag=1;
   		$qualified_dividend_ind_err_flag=1;
	}
}*/

if($F8958_Eligible_Questions == "true")//($filing_status == "separate") && ($f8958_not_inc_rows > 0)  && 
	$report_to_frm8958_ind = $report_to_frm8958_ind;
else
	$report_to_frm8958_ind = 0;

if(UDF_trim($OLTPRO_masterID) == '')
{
	$cmn_payer_combo 	= "payer_1099DIV";
	$cmn_payer_name1 	= "payername";
	if(UDF_trim($payerin) == "")
		${$cmn_payerin."Skip"} = 1;
	else
		$cmn_payerin 	= "payerin";		
	
	$cmn_account_nbr 	= "acc_nbr";
	$cmn_US_addr2  		= "payeraddress2";
	$cmn_frgn_addr2         = "payer_frgn_address2";
	$form_name		= "1099DIV";	
	include("../oltproc/olt_payer_common_val.php");
	
	if($err_flag!=1)	
	{	
		$olt_payer_name 	= fmtvalue($payername);
		$olt_payer_name2	="";
		$olt_payerin		= UDF_trim($payerin);
		$olt_payer_account_nbr	= UDF_trim($acc_nbr);
		$olt_payer_frgn_addrs_ind 	= (int)UDF_trim($payer_frgn_add_ind);
		if($payer_frgn_add_ind == 1)
		{
			$olt_payer_frgn_address	= FormatAddress($payer_frgn_address);
			$olt_payer_frgn_address2 	= FormatAddress($payer_frgn_address2);
			$olt_payer_frgn_city	= fmtvalue($payer_frgn_city);
			$olt_payer_frgn_state	= fmtvalue($payer_frgn_state);
			$olt_payer_frgn_country	= fmtvalue($payer_frgn_country);
			$olt_payer_frgn_zip		= fmtvalue($payer_frgn_zip);
		}
		else
		{	
			$olt_payer_us_address 	= FormatAddress($payeraddress);
			$olt_payer_us_address2 	= FormatAddress($payeraddress2);
			$olt_payer_us_city		= FormatCity($payercity);
			$olt_payer_us_state 	= fmtvalue($payerstate);
			$olt_payer_us_zip 		= fmtvalue($payerzip);
			$olt_payer_us_zip_ext   	= "";
		}
				
		if((UDF_trim($payerin) != "") && (UDF_strlen($payerin) == 9))
		{
			if($payer_1099DIV == "Add New")
			{		
					$action = "Add New";
				$called_frm_InputPage = 1;
				include("../oltproc/olt_get_payer_details.php");
			}	
			else
			{
				$action = "";		
				$olt_payer_details_id = $payer_1099DIV;
				$called_frm_InputPage = 1;
				include("../oltproc/olt_get_payer_details.php"); 
				
					/*$payername 		= $olt_payer_name;
				$payerin			= $olt_payerin;
				$acc_nbr			= $olt_payer_account_nbr;
				$payer_frgn_add_ind  	= $olt_payer_frgn_addrs_ind;
				if($payer_frgn_add_ind == 1)
				{
					$payer_frgn_address	= $olt_payer_frgn_address;
					$payer_frgn_address2	= $olt_payer_frgn_address2;
					$payer_frgn_city		= $olt_payer_frgn_city;
					$payer_frgn_state		= $olt_payer_frgn_state;
					$payer_frgn_country	= $olt_payer_frgn_country;
					$payer_frgn_zip		= $olt_payer_frgn_zip;
				}
				else
				{
					$payeraddress	 	= $olt_payer_us_address;
					$payeraddress2	 	= $olt_payer_us_address2;
					$payercity 		= $olt_payer_us_city;
					$payerstate 		= $olt_payer_us_state;
					$payerzip 		= $olt_payer_us_zip;
					}*/
			}
		}
	}
}
else
{
	if(($payername != "" && !isAlphaNumericnumsp($payername))||($payername == "")) 
	{
		$err_flag=1;
		$pname_empty_err_flag=1;
	}
	
	if(($payerin != "") && ((UDF_strlen($payerin) != 9) || (!IsAlphaNumeric($payerin)) || ($payerin == "000000000"))) // || (!IsValidEIN($payerin))
	{
		$err_flag=1;
		$fin_err_flag=1;
	}
	
	if(($acc_nbr != "") && (!(UDF_strlen($acc_nbr) >0) || (!IsAlphaNumeric($acc_nbr))))
	{
		$err_flag=1;
		$acct_err_flag=1;
	}
}

if($err_flag == 0)
{

	$joint_ind=0;          
	if ($whose_div == 1)
	{
		$who ='S';
	}
	else if ($whose_div == 2)
	{
		$who='P';
		$joint_ind=1;
	}
	else
	{
		$who='P';
	}
	
	if($f1116_block_autocalc_ind == 0)
		$f1116_block_autocalc_ind = 1;
	else
		$f1116_block_autocalc_ind = 0;
	//** Start 007 
	if($payerstate==".")
	{
		$payerzip="";
	}
	if($recipientstate==".")
	{
		$recipientzip="";
	}
	//** Start 007 
	$query="select ssn,last_name,first_name,middle_initial from customer where ";
	$query.= "qt_user_id=(?) "; db_sql_BuildParamArray($qt_user_id, "customer::qt_user_id");
	$query.= "and relation=(?) "; db_sql_BuildParamArray($who, "customer::relation");
	$result_1040 = db_sql_query(array($query), $_SQL_ParamsArray);

	$res_data=db_fetchrow(array($result_1040, DB_GETMODE_ASSOC));
	$recipientin        = $res_data["ssn"];
	$recipientname      = $res_data["first_name"]. " ".$res_data["middle_initial"]." ". $res_data["last_name"];
	
	db_free_result(array($result_1040));
	
	if(UDF_strlen($recipientname) > 50)
		$recipientname = UDF_trim(UDF_substr($recipientname,0,50));
	
	$ord_div 	= UDF_round((float)$ord_div);
	$tot_cap_gain 	= UDF_round((float)$tot_cap_gain);
	$qual_div 	= UDF_round((float)$qual_div);
	$rate_gain 	= UDF_round((float)$rate_gain);
	$unrecap_sec_1250 = UDF_round((float)$unrecap_sec_1250);
	$nontax_dist 	= UDF_round((float)$nontax_dist);
	$fed_inc_tax_with = UDF_round((float)$fed_inc_tax_with);
	$inv_exp 	= UDF_round((float)$inv_exp);
	$for_tax_paid 	= UDF_round((float)$for_tax_paid);
	$for_country 	= fixtext($for_country);
	$cash_liq 	= UDF_round((float)$cash_liq);
	$noncash_liq 	= UDF_round((float)$noncash_liq);
	$sec_1202_gain	= UDF_round((float)$sec_1202_gain);
	$nominee_amt_div=UDF_round((float)$nominee_amt_div);
	$nominee_qual_div_amt=UDF_round((float)$nominee_qual_div_amt);
	$nominee_cap_gain_amt=UDF_round((float)$nominee_cap_gain_amt);
	$section_199a_dividends=UDF_round((float)$section_199a_dividends);
	$recipientaddress= UDF_substr($recipientaddress,0,70);
	//$qual_5yr_gain = (float)$qual_5yr_gain; //005
	//$capital_gain_dist = (float)$capital_gain_dist; //005
	$sec_897_ord_div = UDF_round((float)$sec_897_ord_div);
	$sec_897_cap_gain = UDF_round((float)$sec_897_cap_gain);
	

	if ($newaction == "adddiv")
	{
		$_SQL_DataArray[] = array( "key"=> "qt_user_id", "val"=>$qt_user_id, "table"=>"div1099");
		$_SQL_DataArray[] = array( "key"=> "ssn", "val"=>$recipientin, "table"=>"div1099");
		$_SQL_DataArray[] = array( "key"=> "who", "val"=>$who, "table"=>"div1099");
		$_SQL_DataArray[] = array( "key"=> "joint_ind", "val"=>(int)$joint_ind, "table"=>"div1099");
		$out_sqlparm = db_sql_paramformat($_SQL_DataArray);

		$query ="insert into div1099(".$out_sqlparm['_SQL_FieldClause'].") values (".$out_sqlparm['_SQL_ValueClause'].")";
		$result = db_sql_query(array($query), $_SQL_ParamsArray);
		
		db_free_result(array($result));
		
		$query_clause ="select max(div1099_ID)'id' from div1099 where ";
		$query_clause .= "qt_user_id=(?) "; db_sql_BuildParamArray($qt_user_id, "div1099::qt_user_id");
		$result = db_sql_query(array($query_clause), $_SQL_ParamsArray);
		$noOfRowsdiv1099 = db_num_rows(array($result));
		if($noOfRowsdiv1099 > 0)
		{
			$res_data = db_fetchrow(array($result, DB_GETMODE_ASSOC));
			$id 	= UDF_trim($res_data["id"]);  
		}
		db_free_result(array($result));
		
		$newaction = "editdiv";
	}
    	if ($newaction == "editdiv") 
	{
		// 003 BEGIN
		
		$id = (int) $id;		
		//    $foreingn_taxcdt_ind = (int)$foreingn_taxcdt_ind;
		
		$for_country= UDF_substr($for_country,0,15);
		
		if(UDF_strlen($div_phone) > 7)
			$div_phone = UDF_trim(UDF_substr($div_phone,0,7));
			
		if(UDF_strlen($payername) > 75)
			$payername = UDF_trim(UDF_substr($payername,0,75));
		
		$_SQL_DataArray[] = array( "key"=> "ord_div", "val"=>(float)$ord_div, "table"=>"div1099");		
		$_SQL_DataArray[] = array( "key"=> "div1099_chld_ord_div_ind", "val"=>(int)$div1099_chld_ord_div_ind, "table"=>"div1099");
		$_SQL_DataArray[] = array( "key"=> "qual_div", "val"=>(float)$qual_div, "table"=>"div1099");		
		$_SQL_DataArray[] = array( "key"=> "div1099_chld_qual_div_ind", "val"=>(int)$div1099_chld_qual_div_ind, "table"=>"div1099");
		$_SQL_DataArray[] = array( "key"=> "ssn", "val"=>$recipientin, "table"=>"div1099");		
		//if($OLTPRO_masterID != "")	
		if($show_aloc_state_ind == 1)		
		{		
			$_SQL_DataArray[] = array( "key"=> "aloc_state", "val"=>$aloc_state, "table"=>"div1099");		
			if($show_city_combo_ind == 1)		
				$_SQL_DataArray[] = array( "key"=> "aloc_city", "val"=>$aloc_city, "table"=>"div1099");		
		}		
		$_SQL_DataArray[] = array( "key"=> "tot_cap_gain", "val"=>(float)$tot_cap_gain, "table"=>"div1099");		
		$_SQL_DataArray[] = array( "key"=> "payername", "val"=>$payername, "table"=>"div1099");		
		$_SQL_DataArray[] = array( "key"=> "payerin", "val"=>$payerin, "table"=>"div1099");
		//$_SQL_DataArray[] = array( "key"=> "dividend_report_ind", "val"=>(int)$dividend_report_ind, "table"=>"div1099");
		$_SQL_DataArray[] = array( "key"=> "section_199a_dividends", "val"=>(float)$section_199a_dividends, "table"=>"div1099");		
		if($payer_frgn_add_ind == 1)		
		{		
			$_SQL_DataArray[] = array( "key"=> "payer_frgn_add_ind", "val"=>'1', "table"=>"div1099");		
			$_SQL_DataArray[] = array( "key"=> "payer_frgn_address", "val"=>$payer_frgn_address, "table"=>"div1099");		
			$_SQL_DataArray[] = array( "key"=> "payer_frgn_address2", "val"=>$payer_frgn_address2, "table"=>"div1099");		
			$_SQL_DataArray[] = array( "key"=> "payer_frgn_city", "val"=>$payer_frgn_city, "table"=>"div1099");		
			$_SQL_DataArray[] = array( "key"=> "payer_frgn_state", "val"=>$payer_frgn_state, "table"=>"div1099");		
			$_SQL_DataArray[] = array( "key"=> "payer_frgn_country", "val"=>$payer_frgn_country, "table"=>"div1099");		
			$_SQL_DataArray[] = array( "key"=> "payer_frgn_zip", "val"=>$payer_frgn_zip, "table"=>"div1099");		
							
			$_SQL_DataArray[] = array( "key"=> "payeraddress", "val"=>'', "table"=>"div1099");		
			$_SQL_DataArray[] = array( "key"=> "payeraddress2", "val"=>'', "table"=>"div1099");		
			$_SQL_DataArray[] = array( "key"=> "payercity", "val"=>'', "table"=>"div1099");		
			$_SQL_DataArray[] = array( "key"=> "payerstate", "val"=>'', "table"=>"div1099");		
			$_SQL_DataArray[] = array( "key"=> "payerzip", "val"=>'', "table"=>"div1099");		
		}		
		else		
		{		
			$_SQL_DataArray[] = array( "key"=> "payer_frgn_add_ind", "val"=>'0', "table"=>"div1099");		
			$_SQL_DataArray[] = array( "key"=> "payer_frgn_address", "val"=>'', "table"=>"div1099");		
			$_SQL_DataArray[] = array( "key"=> "payer_frgn_address2", "val"=>'', "table"=>"div1099");		
			$_SQL_DataArray[] = array( "key"=> "payer_frgn_city", "val"=>'', "table"=>"div1099");		
			$_SQL_DataArray[] = array( "key"=> "payer_frgn_state", "val"=>'', "table"=>"div1099");		
			$_SQL_DataArray[] = array( "key"=> "payer_frgn_country", "val"=>'', "table"=>"div1099");		
			$_SQL_DataArray[] = array( "key"=> "payer_frgn_zip", "val"=>'', "table"=>"div1099");		
							
			$_SQL_DataArray[] = array( "key"=> "payeraddress", "val"=>$payeraddress, "table"=>"div1099");		
			$_SQL_DataArray[] = array( "key"=> "payeraddress2", "val"=>$payeraddress2, "table"=>"div1099");		
			$_SQL_DataArray[] = array( "key"=> "payercity", "val"=>$payercity, "table"=>"div1099");		
			$_SQL_DataArray[] = array( "key"=> "payerstate", "val"=>$payerstate, "table"=>"div1099");		
			$_SQL_DataArray[] = array( "key"=> "payerzip", "val"=>$payerzip, "table"=>"div1099");		
		}		
				
		$_SQL_DataArray[] = array( "key"=> "recipientin", "val"=>$recipientin, "table"=>"div1099");		
		$_SQL_DataArray[] = array( "key"=> "recipientname", "val"=>$recipientname, "table"=>"div1099");		
		if($recip_frgn_add_ind == 1)		
		{
			$rcpnt_frgn_state = UDF_trim(UDF_substr($rcpnt_frgn_state, 0, 17));	
				
			$_SQL_DataArray[] = array( "key"=> "recip_frgn_add_ind", "val"=>'1', "table"=>"div1099");		
			$_SQL_DataArray[] = array( "key"=> "recip_frgn_address", "val"=>$recip_frgn_address, "table"=>"div1099");		
			$_SQL_DataArray[] = array( "key"=> "recip_frgn_address2", "val"=>$recip_frgn_address2, "table"=>"div1099");		
			$_SQL_DataArray[] = array( "key"=> "recip_frgn_city", "val"=>$recip_frgn_city, "table"=>"div1099");		
			$_SQL_DataArray[] = array( "key"=> "rcpnt_frgn_state", "val"=>$rcpnt_frgn_state, "table"=>"div1099");		
			$_SQL_DataArray[] = array( "key"=> "rcpnt_frgn_ctry_code", "val"=>$rcpnt_frgn_ctry_code, "table"=>"div1099");		
			$_SQL_DataArray[] = array( "key"=> "recip_frgn_zip", "val"=>$recip_frgn_zip, "table"=>"div1099");		
							
			$_SQL_DataArray[] = array( "key"=> "recipientaddress", "val"=>'', "table"=>"div1099");		
			$_SQL_DataArray[] = array( "key"=> "recipientaddress2", "val"=>'', "table"=>"div1099");		
			$_SQL_DataArray[] = array( "key"=> "recipientcity", "val"=>'', "table"=>"div1099");		
			$_SQL_DataArray[] = array( "key"=> "recipientstate", "val"=>'', "table"=>"div1099");		
			$_SQL_DataArray[] = array( "key"=> "recipientzip", "val"=>'', "table"=>"div1099");		
		}		
		else		
		{		
			$_SQL_DataArray[] = array( "key"=> "recip_frgn_add_ind", "val"=>'0', "table"=>"div1099");		
			$_SQL_DataArray[] = array( "key"=> "recip_frgn_address", "val"=>'', "table"=>"div1099");		
			$_SQL_DataArray[] = array( "key"=> "recip_frgn_address2", "val"=>'', "table"=>"div1099");		
			$_SQL_DataArray[] = array( "key"=> "recip_frgn_city", "val"=>'', "table"=>"div1099");		
			$_SQL_DataArray[] = array( "key"=> "rcpnt_frgn_state", "val"=>'', "table"=>"div1099");		
			$_SQL_DataArray[] = array( "key"=> "rcpnt_frgn_ctry_code", "val"=>'', "table"=>"div1099");		
			$_SQL_DataArray[] = array( "key"=> "recip_frgn_zip", "val"=>'', "table"=>"div1099");		
							
			$_SQL_DataArray[] = array( "key"=> "recipientaddress", "val"=>$recipientaddress, "table"=>"div1099");		
			$_SQL_DataArray[] = array( "key"=> "recipientaddress2", "val"=>$recipientaddress2, "table"=>"div1099");		
			$_SQL_DataArray[] = array( "key"=> "recipientcity", "val"=>$recipientcity, "table"=>"div1099");		
			$_SQL_DataArray[] = array( "key"=> "recipientstate", "val"=>$recipientstate, "table"=>"div1099");		
			$_SQL_DataArray[] = array( "key"=> "recipientzip", "val"=>$recipientzip, "table"=>"div1099");		
		}		
		$_SQL_DataArray[] = array( "key"=> "FATCA_filing_req_ind", "val"=>(int)$FATCA_filing_req_ind, "table"=>"div1099");		
		$_SQL_DataArray[] = array( "key"=> "rate_gain", "val"=>(float)$rate_gain, "table"=>"div1099");		
		$_SQL_DataArray[] = array( "key"=> "unrecap_sec_1250", "val"=>(float)$unrecap_sec_1250, "table"=>"div1099");		
		$_SQL_DataArray[] = array( "key"=> "acc_nbr", "val"=>$acc_nbr, "table"=>"div1099");		
		$_SQL_DataArray[] = array( "key"=> "sec_1202_gain", "val"=>(float)$sec_1202_gain, "table"=>"div1099");		
		$_SQL_DataArray[] = array( "key"=> "sec_897_ord_div", "val"=>(float)$sec_897_ord_div, "table"=>"div1099");		
		$_SQL_DataArray[] = array( "key"=> "sec_897_cap_gain", "val"=>(float)$sec_897_cap_gain, "table"=>"div1099");		
						
		$_SQL_DataArray[] = array( "key"=> "nontax_dist", "val"=>(float)$nontax_dist, "table"=>"div1099");		
		$_SQL_DataArray[] = array( "key"=> "fed_inc_tax_with", "val"=>(float)$fed_inc_tax_with, "table"=>"div1099");		
		$_SQL_DataArray[] = array( "key"=> "inv_exp", "val"=>(float)$inv_exp, "table"=>"div1099");		
		$_SQL_DataArray[] = array( "key"=> "for_tax_paid", "val"=>(float)$for_tax_paid, "table"=>"div1099");		
		$_SQL_DataArray[] = array( "key"=> "f1116_block_autocalc_ind", "val"=>(int)$f1116_block_autocalc_ind, "table"=>"div1099");  
		//$_SQL_DataArray[] = array( "key"=> "foreingn_taxcdt_ind", "val"=>$foreingn_taxcdt_ind, "table"=>"div1099");		
		$_SQL_DataArray[] = array( "key"=> "for_country", "val"=>$for_country, "table"=>"div1099");		
		$_SQL_DataArray[] = array( "key"=> "cash_liq", "val"=>(float)$cash_liq, "table"=>"div1099");		
		$_SQL_DataArray[] = array( "key"=> "noncash_liq", "val"=>(float)$noncash_liq, "table"=>"div1099");		
		if($chkNom == 1)		
		{		
			$_SQL_DataArray[] = array( "key"=> "nominee_amt_div", "val"=>(float)$nominee_amt_div, "table"=>"div1099");		
			$_SQL_DataArray[] = array( "key"=> "nominee_qual_div_amt", "val"=>(float)$nominee_qual_div_amt, "table"=>"div1099");		
			$_SQL_DataArray[] = array( "key"=> "nominee_cap_gain_amt", "val"=>(float)$nominee_cap_gain_amt, "table"=>"div1099");		
		}		
		else		
		{		
			$_SQL_DataArray[] = array( "key"=> "nominee_amt_div", "val"=>'0', "table"=>"div1099");		
			$_SQL_DataArray[] = array( "key"=> "nominee_qual_div_amt", "val"=>'0', "table"=>"div1099");		
			$_SQL_DataArray[] = array( "key"=> "nominee_cap_gain_amt", "val"=>'0', "table"=>"div1099");		
		}		
		$_SQL_DataArray[] = array( "key"=> "who", "val"=>$who, "table"=>"div1099");		
		$_SQL_DataArray[] = array( "key"=> "chkNom", "val"=>$chkNom, "table"=>"div1099");		
		$_SQL_DataArray[] = array( "key"=> "joint_ind", "val"=>(int)$joint_ind, "table"=>"div1099"); //004 Mohamed Azmal added joint_ind
		//$_SQL_DataArray[] = array( "key"=> "qual_5yr_gain", "val"=>(float)$qual_5yr_gain, "table"=>"div1099"); //005
		//$_SQL_DataArray[] = array( "key"=> "capital_gain_dist", "val"=>(float)$capital_gain_dist, "table"=>"div1099"); //005		
						
		$_SQL_DataArray[] = array( "key"=> "prior_year_imported_ind", "val"=>0, "table"=>"div1099");		
		$_SQL_DataArray[] = array( "key"=> "imported_not_visited_ind", "val"=>0, "table"=>"div1099");		
						
		$_SQL_DataArray[] = array( "key"=> "complete_ind", "val"=>'1', "table"=>"div1099");		
						
		$_SQL_DataArray[] = array( "key"=> "exempt_inst_div", "val"=>(float)$exempt_inst_div, "table"=>"div1099");		
		$_SQL_DataArray[] = array( "key"=> "bond_inst_div", "val"=>(float)$bond_inst_div, "table"=>"div1099");		
		$_SQL_DataArray[] = array( "key"=> "nominee_state", "val"=>$nominee_state, "table"=>"div1099");		
		$_SQL_DataArray[] = array( "key"=> "nominee_identify", "val"=>$nominee_identify, "table"=>"div1099");
		$_SQL_DataArray[] = array( "key"=> "state_tax_withheld", "val"=>(float)$state_tax_withheld, "table"=>"div1099");		
		$_SQL_DataArray[] = array( "key"=> "div_areacode", "val"=>$div_areacode, "table"=>"div1099");		
		$_SQL_DataArray[] = array( "key"=> "div_phone", "val"=>$div_phone, "table"=>"div1099");		
						
		$_SQL_DataArray[] = array( "key"=> "report_to_frm8958_ind", "val"=>(int)$report_to_frm8958_ind, "table"=>"div1099");		
		if((UDF_trim($payerin) != "") && (UDF_strlen($payerin) == 9))
			$_SQL_DataArray[] = array( "key"=> "payer_details_id", "val"=>$olt_payer_details_id, "table"=>"div1099");
		else	
			$_SQL_DataArray[] = array( "key"=> "payer_details_id", "val"=>'0', "table"=>"div1099");
				
		if ($section_199a_dividends > 0)		
			$_SQL_DataArray[] = array( "key"=> "qualified_dividend_ind", "val"=>'1', "table"=>"div1099");
			//else if ($qualified_dividend_ind_No == 1)
			//$set_clause = $set_clause.", qualified_dividend_ind='2'";
		else		
			$_SQL_DataArray[] = array( "key"=> "qualified_dividend_ind", "val"=>'', "table"=>"div1099");
				
				
		$out_sqlparm = db_sql_paramformat($_SQL_DataArray);
		
		$query_clause="update div1099 set ".$out_sqlparm["_SQL_UpdateClause"]." WHERE ";
		$query_clause.= "qt_user_id=(?) "; db_sql_BuildParamArray($qt_user_id, "div1099::qt_user_id");
		$query_clause.= " and div1099_ID=(?) "; db_sql_BuildParamArray($id, "div1099::div1099_ID");
		$update_result = db_sql_query(array($query_clause), $_SQL_ParamsArray);
	
		
	   } 
	$pro_ein_info = array("ein"=>$payerin,"eName"=>$payername,"eAddress"=>$payeraddress.$payeraddress2, "eCity"=>$payercity, "eState"=>$payerstate, "eZipCode"=>$payerzip, "eZipExt"=>"");
	include("oltpro_update_ein_db.php");
	
	if($form1040_ind == "1040NR")	
	{		
		include_once("olt_pagehdr.php");
		include("olt_efile_rej_veri_redirect.php");
 		echo "<form name=form1 action=\"olt_1099divNec.php\" method=post>";
   		BuildDynamicFormHiddenData("step=1099divNecNV&id=$id");
   		include(PROTECTED_PATHQT."html/1099divNec.html");
   	}
   	else
   	{
   		include_once("olt_pagehdr.php");
		include("olt_efile_rej_veri_redirect.php");
 		echo "<form name=form1 action=\"olt_1099div_gov_oblig.php \" method=post>";
   		BuildDynamicFormHiddenData("id=$id");
   		include(PROTECTED_PATHQT."html/1099div_gov_oblig.html");
   		
   		/*include_once("olt_pagehdr.php");
		include("olt_efile_rej_veri_redirect.php");
 		echo "<form name=form1 action=\"olt_1099divdone.php\" method=post>";
   		
   		BuildDynamicFormHiddenData("step=1099divdone");
   		include(PROTECTED_PATHQT."html/1099divdone.html");*/
   	}
}        	
else
{ 		
	include_once("olt_pagehdr.php");
	include("olt_efile_rej_veri_redirect.php");
	echo "<form name=form1 action=\"olt_1099div.php\" method=post>";
	BuildDynamicFormHiddenData("id=$id&newaction=$newaction&step=w2done");
	include(PROTECTED_PATHQT."html/1099div.html");	
}        	

include("olt_pageftr.php");

?>