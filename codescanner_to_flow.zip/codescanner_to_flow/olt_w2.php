	<?
/********************************************************************************
                      MODIFICATION  CONTROL  LOG
---------------------------------------------------------------------------------
  Mod  Date         Programmer        Comment
  ------------------------------------------------------------------------------
  002  06/11/2003   Selvaraj          Included Function and Validation for 
                                      Payers Name - Federal Issue Task #123
  003  03/09/2004   Rajeshkumar J     Validation added for state2 box
  004  02/25/2005   Auvelin Raja      Removed Validation for combat pay
  005  03/08/2005   Anbalagan         Error validation conditions changed for state wages
  006  03/10/2005   Anbalagan         if condition added
  007  03/12/2005   Ruban Antony      Added a condition to avoid validation for 
  				      foreign state
  008  03/12/2005   Ruban Antony      Condition was added to verify the zipcode existence 
  				      for the resident country only.		
  009  06/16/2005   Selvaraj          Validation for State specific input entries
  010  01/12/2007   Saravana Kumar P  Calculation and Validation for Social Security 
                                       and Medicare Tax withheld   				          
********************************************************************************* */
   
	include_once("header.php");
	include_once("qt_func.php");


	$status = GetUniqueUserInfo($o9Ljw, $qt_user_id, $siteid, $pageid, $lasttime);
	$my_page="olt_w2.php";
	
	$FileStatus = GetCurrentStatus($qt_user_id);

	if ($FileStatus) {
		include(PROTECTED_PATHQT."html/InvalidStatus.html");
		echo "</form>";
		db_close();
		exit;
	}
	
	include("../oltproc/olt_section_track_end.php");
	
	if(!function_exists('IsValidAllocState'))
	{
		function IsValidAllocState($loc_state)
		{
			if(($loc_state == "OH") || ($loc_state == "MI") || ($loc_state == "KY") || ($loc_state == "NY") || ($loc_state == "PA") || ($loc_state == "MO"))
			 	return 1;
			 else
			 	return 0;
		}
	}

	if(!function_exists('isIRSVerifyCodeValid'))
	{
		function isIRSVerifyCodeValid($name)
		{
			$len =  UDF_strlen($name);
			for ($i=0; $i < $len; $i++) 
			{
				$ascii_cd = ord($name[$i]);
				if(!((($ascii_cd >= 48) && ($ascii_cd <= 57)) || (($ascii_cd >= 65) && ($ascii_cd <= 70))))  
				{ 
					return 0; 
				}
			}
			return 1;
		
		}
	}
	$amd_ind_w2	= $amd_ind;
	$OtherSiteAmdInd_w2 = $OtherSiteAmdInd;
	
	$form1040_ind_add = "";
	$SelectQuery   ="select residentof,address1,address2,apartment,city,state,zip,zip_ext,foreign_address_ind,foreign_state,foreign_country,foreign_country_code from ind_label where ";
	$SelectQuery   .= "qt_user_id=(?) "; db_sql_BuildParamArray($qt_user_id, "ind_label::qt_user_id");
	$f1040nr_result   	 = db_sql_query(array($SelectQuery), $_SQL_ParamsArray);
	$f1040nr_noOfRows = db_num_rows(array($f1040nr_result));
	if($f1040nr_noOfRows > 0)
	{
		$f1040nr_res_data	= db_fetchrow(array($f1040nr_result, DB_GETMODE_ASSOC));
		$form1040_ind_add	= $form1040_ind;
		$address1           	= UDF_trim($f1040nr_res_data["address1"]);
		$address2           	= UDF_trim($f1040nr_res_data["address2"]);
		$apartment          	= UDF_trim($f1040nr_res_data["apartment"]);
		$city               	= UDF_trim($f1040nr_res_data["city"]);
		$state              	= UDF_trim($f1040nr_res_data["state"]);
		$zip                	= UDF_trim($f1040nr_res_data["zip"]);
		$zip_ext            	= UDF_trim($f1040nr_res_data["zip_ext"]);
		$foreign_state      	= UDF_trim($f1040nr_res_data["foreign_state"]);
		$foreign_country    	= UDF_trim($f1040nr_res_data["foreign_country"]);
		$foreign_country_code	= UDF_trim($f1040nr_res_data["foreign_country_code"]);
		$foreign_address_ind	= UDF_trim($f1040nr_res_data["foreign_address_ind"]);
		$foreign_address_ind_tmp= $foreign_address_ind;
		$residentof_tmp		= UDF_trim($f1040nr_res_data["residentof"]);
	}
	db_free_result(array($f1040nr_result));
	
	
	$err_flag		= 0;
	$with_held_err		= 0;
	$ss_with_held_err 	= 0;
	$st1_with_held_err 	= 0;
	$st1_with_held_pass_err = 0;
	$st2_with_held_err 	= 0;
	$wage_comp_err		= 0;
	$state_comp_err 	= 0;
	$state_wage1_err = 0;
	$state_wage2_err = 0;
	$code12a_err=0;
	$stlocwag1_err = 0;
	$stlocwag2_err = 0;
	$stlocwag3_err = 0;
	$stlocwag4_err = 0;
	
	//$fw2_hash_cd1 	= UDF_trim($fw2_hash_cd1);
	//$fw2_hash_cd2 	= UDF_trim($fw2_hash_cd2);
	//$fw2_hash_cd3 	= UDF_trim($fw2_hash_cd3);
	//$fw2_hash_cd4 	= UDF_trim($fw2_hash_cd4);
	//$fw2_hash_cd 	= $fw2_hash_cd1;//.$fw2_hash_cd2.$fw2_hash_cd3.$fw2_hash_cd4;
	
	$report_to_frm8958_ind	= (int)$report_to_frm8958_ind;
	$control_num		=fmtvalue($control_num);
	//$ein1			=fmtvalue($ein1);
	//$ein2			=fmtvalue($ein2);
	$employer_id_num 	= fmtvalue($employer_id_num);
	$employer_id_num 	= UDF_str_replace("-","",$employer_id_num);
	//$employer_id_num			= $employer_id_num;
	$employer_id_num			=fmtvalue($employer_id_num);
	$employer_id_num			= fixtext($employer_id_num);
	$wages_tips		=fmtvalue($wages_tips);
	$fed_inc_tax_withheld	=fmtvalue($fed_inc_tax_withheld);
	$employer_name		=fmtvalue($employer_name);
	$employer_name2		=fmtvalue($employer_name2);
	$employer_city		=fmtvalue($employer_city);
	//$employer_name		=FormatAddress($employer_name);
	$employer_name2		=FormatAddress($employer_name2);
	$employer_address 	=FormatAddress($employer_address);
	$employer_address 	= UDF_str_replace("-","",$employer_address);
	$employer_address 	=UDF_trim($employer_address);
	$employer_city		=FormatCity($employer_city);
	if($employer_state !=".")//**007
	{
	$employer_state         =FormatAddress($employer_state);
	}
	$employer_zip		=fixtext($employer_zip);
	$employer_zip_ext	=fixtext($employer_zip_ext);
	$employer_foreign_address	= fmtvalue($employer_foreign_address);
	$employer_foreign_address	= UDF_str_replace("#","" ,$employer_foreign_address); 
	$employer_foreign_address	= UDF_str_replace(".","" ,$employer_foreign_address); 
	$employer_foreign_address	= UDF_str_replace(",","" ,$employer_foreign_address); 
	$employer_foreign_address	= UDF_str_replace("  "," " ,$employer_foreign_address); 
	$employer_foreign_address	= UDF_str_replace("  "," " ,$employer_foreign_address);
	$employer_foreign_city		= fmtvalue($employer_foreign_city);
	$employer_foreign_city		= UDF_str_replace("."," " ,$employer_foreign_city); 
	$employer_foreign_city		= UDF_str_replace("  "," " ,$employer_foreign_city); 
	$employer_foreign_state		= fmtvalue($employer_foreign_state);
	$employer_foreign_state		= UDF_str_replace("  "," " ,$employer_foreign_state); 
	$employer_foreign_country_code	= fixtext($employer_foreign_country_code);
	$employer_foreign_zip		= fmtvalue($employer_foreign_zip);
	$soc_sec_wages		=fmtvalue($soc_sec_wages);
	$soc_sec_tax_withheld	=fmtvalue($soc_sec_tax_withheld);
	$medicare_wages_tips	=fmtvalue($medicare_wages_tips);
	$medicare_tax_withheld	=fmtvalue($medicare_tax_withheld);
	$soc_sec_tips		=fmtvalue($soc_sec_tips);
	$allocated_tips		=fmtvalue($allocated_tips);
	$w2ssn			=fmtvalue($w2ssn);
	//$adv_eic_payment	=fmtvalue($adv_eic_payment); //1040 Instruction
	$dep_care_benefits	=fmtvalue($dep_care_benefits);
	$emp_first_name		=fmtvalue($emp_first_name);
	$emp_mid_initial	=fmtvalue($emp_mid_initial);
	$emp_last_name		=fmtvalue($emp_last_name);
	$nonqualified_plans	=fmtvalue($nonqualified_plans);
	/*$box12a_code		=fmtvalue($box12a_code);
	$box12a_amount		=fmtvalue($box12a_amount);
	$box12b_code		=fmtvalue($box12b_code);
	$box12b_amount		=fmtvalue($box12b_amount);
	$box12c_code		=fmtvalue($box12c_code);
	$box12c_amount		=fmtvalue($box12c_amount);
	$box12d_code		=fmtvalue($box12d_code);
	$box12d_amount		=fmtvalue($box12d_amount);
	$box12e_code		= fmtvalue($box12e_code);
	$box12e_amount		= fmtvalue($box12e_amount);
	$box12e_year		= fmtvalue($box12e_year);
	$box12f_code		= fmtvalue($box12f_code);
	$box12f_amount		= fmtvalue($box12f_amount);
	$box12f_year		= fmtvalue($box12f_year);
	$other1_amount		=fmtvalue($other1_amount);
	$other2_amount		=fmtvalue($other2_amount);
	$other3_amount		=fmtvalue($other3_amount);
	$other4_amount		=fmtvalue($other4_amount);
	$state1			=fmtvalue($state1);
	$st1_employer_id	=fixtext($st1_employer_id);
	$st1_wages_tips		=fmtvalue($st1_wages_tips);
	$st1_inc_tax		=fmtvalue($st1_inc_tax);
	$st1_local_wages	=fmtvalue($st1_local_wages);
	$st1_local_inc_tax	=fmtvalue($st1_local_inc_tax);
	$state2			=fmtvalue($state2);
	$st2_employer_id	=fixtext($st2_employer_id);
	$st2_wages_tips		=fmtvalue($st2_wages_tips);
	$st2_inc_tax		=fmtvalue($st2_inc_tax);
	$st2_local_wages	=fmtvalue($st2_local_wages);
	$st2_local_inc_tax	=fmtvalue($st2_local_inc_tax);

	$state3			=fmtvalue($state3);
	$st3_employer_id	=fixtext($st3_employer_id);
	$st3_wages_tips		=fmtvalue($st3_wages_tips);
	$st3_inc_tax		=fmtvalue($st3_inc_tax);
	$st3_local_wages	=fmtvalue($st3_local_wages);
	$st3_local_inc_tax	=fmtvalue($st3_local_inc_tax);

	$state4			=fmtvalue($state4);
	$st4_employer_id	=fixtext($st4_employer_id);
	$st4_wages_tips		=fmtvalue($st4_wages_tips);
	$st4_inc_tax		=fmtvalue($st4_inc_tax);
	$st4_local_wages	=fmtvalue($st4_local_wages);
	$st4_local_inc_tax	=fmtvalue($st4_local_inc_tax);*/
	
	if($soc_sec_wages == "")	 $soc_sec_wages		= 0; 
	if($soc_sec_tax_withheld == "")	 $soc_sec_tax_withheld	= 0; 
	if($medicare_wages_tips == "")	 $medicare_wages_tips	= 0; 
	if($medicare_tax_withheld == "") $medicare_tax_withheld	= 0; 
	
	//$st1_locality=FormatAddress($st1_locality);
	//$st2_locality=FormatAddress($st2_locality);
	$control_num=fmtvalue($control_num);
	$control_num=fixtext($control_num);
	//$fw2_hash_cd =fmtvalue($fw2_hash_cd);

	/*$other1_typeNew=fmtvalue($other1_typeNew);
	$other2_typeNew=fmtvalue($other2_typeNew);
	$other3_typeNew=fmtvalue($other3_typeNew);
	$other4_typeNew=fmtvalue($other4_typeNew);
	
	$other1_typeNew	=fixtext($other1_typeNew);
	$other2_typeNew	=fixtext($other2_typeNew);
	$other3_typeNew	=fixtext($other3_typeNew);
	$other4_typeNew	=fixtext($other4_typeNew);*/
	
	$emp_address 	= FormatAddress($emp_address);
	$emp_address 	= UDF_trim($emp_address);
	$emp_city 	= UDF_trim($emp_city);
	$emp_city	= fmtvalue($emp_city);
	$emp_city	= FormatCity($emp_city);
	$emp_state 	= UDF_trim($emp_state);
	$emp_zip 	= UDF_trim($emp_zip);
	$emp_zip_ext 	= UDF_trim($emp_zip_ext);
	$emp_for_address= fmtvalue($emp_for_address);
	$emp_for_address= FormatAddress($emp_for_address);
	$emp_for_address= UDF_str_replace("-","" ,$emp_for_address);
	$emp_for_address= UDF_str_replace("#","" ,$emp_for_address); 
	$emp_for_address= UDF_str_replace(".","" ,$emp_for_address); 
	$emp_for_address= UDF_str_replace(",","" ,$emp_for_address); 
	$emp_for_address= UDF_str_replace("  "," " ,$emp_for_address); 
	$emp_for_address= UDF_str_replace("  "," " ,$emp_for_address); 
	$emp_for_address2= fmtvalue($emp_for_address2);
	$emp_for_address2= FormatAddress($emp_for_address2);
	$emp_for_address2= UDF_str_replace("-","" ,$emp_for_address2); 
	$emp_for_address2= UDF_str_replace("#","" ,$emp_for_address2); 
	$emp_for_address2= UDF_str_replace(".","" ,$emp_for_address2); 
	$emp_for_address2= UDF_str_replace(",","" ,$emp_for_address2); 
	$emp_for_address2= UDF_str_replace("  "," " ,$emp_for_address2); 
	$emp_for_address2= UDF_str_replace("  "," " ,$emp_for_address2); 
	$emp_for_city 	= UDF_trim($emp_for_city);
	$emp_for_city	= fmtvalue($emp_for_city);
	$emp_for_city	= FormatCity($emp_for_city); 
	$emp_for_city	= UDF_str_replace("."," " ,$emp_for_city); 
	$emp_for_city	= UDF_str_replace("  "," " ,$emp_for_city); 
	$emp_for_state	= fmtvalue($emp_for_state);
	$emp_for_state	= UDF_str_replace("  "," " ,$emp_for_state); 
	$emp_foreign_country_cd= fixtext($emp_foreign_country_cd);
	$emp_for_zip	= fmtvalue($emp_for_zip);
	
	$emp_apt	= fmtvalue($emp_apt);
	$emp_apt_for	= fmtvalue($emp_apt_for);
	
	$w2Box14b_code1 = fmtvalue($w2Box14b_code1);
	$w2Box14b_code2 = fmtvalue($w2Box14b_code2);
	
	/*if(($other1_typeNew == "414" && $other1_type == "NOT ON LIST") && ($state1 == "NY" || $state2 == "NY" || $state3 == "NY" ||$state4 == "NY"))
	{
		$other1_type = "NY 414";
		$other1_typeNew = "";
	}
	else if(($other1_typeNew == "125" && $other1_type == "NOT ON LIST")&& ($state1 == "NY" || $state2 == "NY" || $state3 == "NY" ||$state4 == "NY"))
	{
		$other1_type = "NY 125";
		$other1_typeNew = "";
	}
	
	if(($other2_typeNew == "414" && $other2_type == "NOT ON LIST") && ($state1 == "NY" || $state2 == "NY" || $state3 == "NY" ||$state4 == "NY"))
	{
		$other2_type = "NY 414";
		$other2_typeNew = "";
	}
	else if(($other2_typeNew == "125" && $other2_type == "NOT ON LIST") && ($state1 == "NY" || $state2 == "NY" || $state3 == "NY" ||$state4 == "NY"))
	{
		$other2_type = "NY 125";
		$other2_typeNew = "";
	}
	
	if(($other3_typeNew == "414" && $other3_type == "NOT ON LIST") && ($state1 == "NY" || $state2 == "NY" || $state3 == "NY" ||$state4 == "NY"))
	{
		$other3_type = "NY 414";
		$other3_typeNew = "";
	}
	else if(($other3_typeNew == "125" && $other3_type == "NOT ON LIST") && ($state1 == "NY" || $state2 == "NY" || $state3 == "NY" ||$state4 == "NY"))
	{
		$other3_type = "NY 125";
		$other3_typeNew = "";
	}
	
	if(($other4_typeNew == "414" && $other4_type =="NOT ON LIST")  && ($state1 == "NY" || $state2 == "NY" || $state3 == "NY" ||$state4 == "NY"))
	{
		$other4_type = "NY 414";
		$other4_typeNew = "";
	}
	else if(($other4_typeNew == "125" && $other4_type =="NOT ON LIST") && ($state1 == "NY" || $state2 == "NY" || $state3 == "NY" ||$state4 == "NY"))
	{
		$other4_type = "NY 125";
		$other4_typeNew = "";
	}
	
	for($ictr=5; $ictr <= $TotCountOfRows; $ictr++) 
	{
		$stateVar 		= "state".$ictr;
		$stateVal 		= UDF_trim($$stateVar);
    $stateVal			=fmtvalue($stateVal);
		
		if(($other1_typeNew == "414" && $other1_type == "NOT ON LIST") && ($stateVal == "NY"))
		{
			$other1_type = "NY 414";
			$other1_typeNew = "";
		}
		else if(($other1_typeNew == "125" && $other1_type == "NOT ON LIST")&& ($stateVal == "NY"))
		{
			$other1_type = "NY 125";
			$other1_typeNew = "";
		}
		
		if(($other2_typeNew == "414" && $other2_type == "NOT ON LIST") && ($stateVal == "NY"))
		{
			$other2_type = "NY 414";
			$other2_typeNew = "";
		}
		else if(($other2_typeNew == "125" && $other2_type == "NOT ON LIST") && ($stateVal == "NY"))
		{
			$other2_type = "NY 125";
			$other2_typeNew = "";
		}
		
		if(($other3_typeNew == "414" && $other3_type == "NOT ON LIST") && ($stateVal == "NY"))
		{
			$other3_type = "NY 414";
			$other3_typeNew = "";
		}
		else if(($other3_typeNew == "125" && $other3_type == "NOT ON LIST") && ($stateVal == "NY"))
		{
			$other3_type = "NY 125";
			$other3_typeNew = "";
		}
		
		if(($other4_typeNew == "414" && $other4_type =="NOT ON LIST")  && ($stateVal == "NY"))
		{
			$other4_type = "NY 414";
			$other4_typeNew = "";
		}
		else if(($other4_typeNew == "125" && $other4_type =="NOT ON LIST") && ($stateVal == "NY"))
		{
			$other4_type = "NY 125";
			$other4_typeNew = "";
		}		
	}
	
	
	$other1_type_old = $other1_type;
	$other2_type_old = $other2_type;
	$other3_type_old = $other3_type;
	$other4_type_old = $other4_type;
	
	if(($other1_typeNew != "") && (($other1_type == "") || ($other1_type == "NOT ON LIST")))
	   $other1_type = $other1_typeNew;
	if(($other2_typeNew != "") && (($other2_type == "") || ($other2_type == "NOT ON LIST")))
	   $other2_type = $other2_typeNew;
	if(($other3_typeNew != "") && (($other3_type == "") || ($other3_type == "NOT ON LIST")))
	   $other3_type = $other3_typeNew;
	if(($other4_typeNew != "") && (($other4_type == "") || ($other4_type == "NOT ON LIST")))
	   $other4_type = $other4_typeNew;

	$other1_type=fmtvalue($other1_type);
	$other2_type=fmtvalue($other2_type);
	$other3_type=fmtvalue($other3_type);
	$other4_type=fmtvalue($other4_type);*/
	
	$TIN1	=fmtvalue($TIN1);
	$TIN2	=fmtvalue($TIN2);
	$TIN3	=fmtvalue($TIN3);
	$TIN 	= $TIN1.$TIN2.$TIN3;
	$TIN = fmtvalue($TIN);
	

	/*if(($whose_w2 != "0") && ($whose_w2 != "1"))
	{
		$TIVA_useraction = "ERROR OCCURED WHILE HANDLING WHOSE W2 POSTED VALUE :".$whose_w2;
		include("olt_track_invalid_action.php");
		//$whose_w2 = "0";
		
		$err_flag=1;
		$whose_w2_err_flag=1;
	}*/
	$whose_w2 = (int)$whose_w2;
	$AllowedArrayValuesWhose = array("0","1");
	if(($whose_w2 != "") && (!IsValidValue($whose_w2, $AllowedArrayValuesWhose)))
	{
		$err_flag = 1;
		$whose_w2_err_flag = 1;
	}
	if($whose_w2 == "0")
		$pri_or_spouse = "P";
	else if($whose_w2 == "1")
		$pri_or_spouse = "S";
 
        $query="select ssn,last_name,first_name,middle_initial,suffix,w7_itin_not_updated_ind from customer where ";
        $query.= "qt_user_id=(?) "; db_sql_BuildParamArray($qt_user_id, "customer::qt_user_id");
        $query.= "and relation=(?) "; db_sql_BuildParamArray($pri_or_spouse, "customer::relation");
	$result_1040 = db_sql_query(array($query), $_SQL_ParamsArray);
	$res_data	    = db_fetchrow(array($result_1040, DB_GETMODE_ASSOC));
	$w2ssn              = $res_data["ssn"];
	$mstrW2W7AppliedInd = $res_data["w7_itin_not_updated_ind"];
	$emp_last_name      = $res_data["last_name"];
	$emp_first_name     = $res_data["first_name"];
	$emp_mid_initial    = $res_data["middle_initial"];
	$suffix     	    = $res_data["suffix"]; 
	
	db_free_result(array($result_1040));
	
	if(UDF_strlen($emp_first_name) > 35)
		$emp_first_name = UDF_substr($emp_first_name,0,35);
	if(UDF_strlen($emp_last_name) > 35)
		$emp_last_name = UDF_substr($emp_last_name,0,35);
	
	$agent_for_employer_ind = (int)$agent_for_employer_ind;
	if ($non_standard_W2_ind != 1) $non_standard_W2_ind = 0;
	
	if($w2_military_ind != 1) $w2_military_ind = 0;
	if($w2_clergy_ind != 1) $w2_clergy_ind = 0;
	if($w2_church_emp_ind != 1) $w2_church_emp_ind = 0;
	if($w2_care_provider_ind != 1) $w2_care_provider_ind = 0;
	if($w2_scorp_2perc_share_ind != 1) $w2_scorp_2perc_share_ind = 0;
	if($w2c_ind != 1) $w2c_ind = 0;
	
	$AllowedArrayValuesOneZero = array("0", "1");
	
	if ($step1 == "editw2")
	{
		if(($id != "") && (!IsValidNumber($id)))
		{
		   $err_flag=1;
		}
	}
	$autocalc_ind = (int)$autocalc_ind;
	if(!IsValidValue($autocalc_ind, $AllowedArrayValuesOneZero))
	{
		$err_flag = 1;
		$autocalc_ind_err_flag = 1;
	}
	
	if(!IsValidValue($non_standard_W2_ind, $AllowedArrayValuesOneZero))
	{
		$err_flag = 1;
		$non_standard_W2_ind_err_flag = 1;
	}
	
	if(!IsValidValue($w2_military_ind, $AllowedArrayValuesOneZero))
	{
		$err_flag = 1;
		$w2_military_ind_err_flag = 1;
	}
	
	if(!IsValidValue($w2_clergy_ind, $AllowedArrayValuesOneZero))
	{
		$err_flag = 1;
		$w2_clergy_ind_err_flag = 1;
	}
	
	if(!IsValidValue($w2_church_emp_ind, $AllowedArrayValuesOneZero))
	{
		$err_flag = 1;
		$w2_church_emp_ind_err_flag = 1;
	}
	
	if(!IsValidValue($w2_care_provider_ind, $AllowedArrayValuesOneZero))
	{
		$err_flag = 1;
		$w2_care_provider_ind_err_flag = 1;
	}
	
	if(!IsValidValue($w2_scorp_2perc_share_ind, $AllowedArrayValuesOneZero))
	{
		$err_flag = 1;
		$w2_scorp_2perc_share_ind_err_flag = 1;
	}
	
	if(!IsValidValue($w2c_ind, $AllowedArrayValuesOneZero))
	{
		$err_flag = 1;
		$w2c_ind_err_flag = 1;
	}
	
	$employer_foreign_add_ind = (int)$employer_foreign_add_ind;
	if(!IsValidValue($employer_foreign_add_ind, $AllowedArrayValuesOneZero))
	{
		$err_flag = 1;
		$employer_foreign_add_ind_err_flag = 1;
	}
	
	$emp_for_add_ind = (int)$emp_for_add_ind;
	if(!IsValidValue($emp_for_add_ind, $AllowedArrayValuesOneZero))
	{
		$err_flag = 1;
		$emp_for_add_ind_err_flag = 1;
	}
	
	$statutory_emp = (int)$statutory_emp;
	$retirement_plan = (int)$retirement_plan;
	$third_party_sick_pay = (int)$third_party_sick_pay;
	if(!IsValidValue($statutory_emp, $AllowedArrayValuesOneZero))
	{
		$err_flag = 1;
		$statutory_emp_err_flag = 1;
	}
	
	if(!IsValidValue($retirement_plan, $AllowedArrayValuesOneZero))
	{
		$err_flag = 1;
		$retirement_plan_err_flag = 1;
	}
	
	if(!IsValidValue($third_party_sick_pay, $AllowedArrayValuesOneZero))
	{
		$err_flag = 1;
		$third_party_sick_pay_err_flag = 1;
	}
	
	if(!IsValidValue($agent_for_employer_ind, $AllowedArrayValuesOneZero))
	{
		$err_flag = 1;
		$agent_for_employer_ind_err_flag = 1;
	}
	
	
	if(($w2_church_emp_ind == 1) && ($w2_clergy_ind == 1))
	{
		$err_flag=1;
		$w2_minister_ind=1;
	}

		
	
	
	if(($ITIN_User_ind == 1) && ((IsValidITIN($w2ssn)) || ($mstrW2W7AppliedInd == "1")))
	{
		if ((UDF_strlen($TIN) != 9) || (!fmtNum($TIN)) || ((!IsValidSSN($TIN)) && (!IsValidITIN($TIN))))
		{
			$err_flag=1;
	  		$tin_err_flag=1;
		}
	}
	$query_cust ="select ssn,relation from customer where ";
	$query_cust .= "qt_user_id=(?) "; db_sql_BuildParamArray($qt_user_id, "customer::qt_user_id");
	$result_cust = db_sql_query(array($query_cust), $_SQL_ParamsArray);
	while($res_data = db_fetchrow(array($result_cust, DB_GETMODE_ASSOC)))
	{
		$cust_ssn		= $res_data["ssn"];
		$relation	= $res_data["relation"];
		
		//Employer EIN cannot be equal to primary or secondary tax payers SSN.
		if(($cust_ssn==$employer_id_num) && ($relation=="P"))
		{
			$err_flag	= 1;
			$ein_pri_err_flag = 1;
		}
		
		if(($cust_ssn==$employer_id_num) && ($relation=="S"))
		{
			$err_flag	= 1;
			$ein_sp_err_flag = 1;
		}
		
		if(($filing_status == "joint") && ($ITIN_User_ind == 1))
		{
			if($relation == "P")
				$w2Prssn = $cust_ssn;
			
			if($relation == "S")
				$w2Spssn = $cust_ssn;
			
			if (($whose_w2 == 1) && ($TIN == $w2Prssn) && ($TIN != ""))
			{
				$err_flag=1;
		  		$tinsp_err_flag=1;
			}
				
			if (($whose_w2 == 0) && ($TIN == $w2Spssn) && ($TIN != ""))
			{
				$err_flag=1;
		  		$tinpr_err_flag=1;
			}
		}
	}
	db_free_result(array($result_cust));
	
	$combatPayEntered = 0;
	/*if(
	       (UDF_trim($box12a_code) == "Q" && UDF_trim($box12a_amount) > 0) 
	    || (UDF_trim($box12b_code) == "Q" && UDF_trim($box12b_amount) > 0)
	    || (UDF_trim($box12c_code) == "Q" && UDF_trim($box12c_amount) > 0)
	    || (UDF_trim($box12d_code) == "Q" && UDF_trim($box12d_amount) > 0)
	    || (UDF_trim($box12e_code) == "Q" && UDF_trim($box12e_amount) > 0)
	    || (UDF_trim($box12f_code) == "Q" && UDF_trim($box12f_amount) > 0)

	    // FOR IN TEST 2

	  )
	{
	    $combatPayEntered = 1;
	}
	
    	if(($combatPayEntered == 1) && (UDF_trim($box12a_code) == "") && ((UDF_trim($box12b_code) == "Q" || UDF_trim($box12c_code) == "Q" || UDF_trim($box12d_code) == "Q" || UDF_trim($box12e_code) == "Q" || UDF_trim($box12f_code) == "Q" )))
	{
		$err_flag=1;
		$code12a_err=1;
	}
	*/

	
	/* if($wages_tips == 0)
	{
		$err_flag=1;
		$wages_err_flag=1;
	}*/
	if(($fed_inc_tax_withheld != "") && (!isNumeric($fed_inc_tax_withheld)))
	{
	  $err_flag=1;
	  $fed_err_flag=1;
	}
	/*if (($GLOBAL_FED_amended_rows == 0) && ($OtherSiteAmdInd_w2 !=1))
	{
		if(( $fed_inc_tax_withheld >  ($wages_tips/2)) && ($combatPayEntered == 0) && ($PassValidationInd != 1)) // 004
		{
		  $err_flag=1;
		  $fed_err_flag=2;
		}
	}*/
	
	
	$employer_city_chk  = FormatAddress($employer_city );
	$employer_city_chk  = fixtext($employer_city_chk );
	if($nv_mode=="1")
	{ 
		if(($employer_tin_w2 != "") || (UDF_trim($OLTPRO_masterID) != ''))
		{
			$cmn_addrTag		= "addr1";
			$cmn_frgn_addr_ind 	= "employer_foreign_add_ind";		
			$cmn_US_addr  		= "employer_address";
			$cmn_US_city 		= "employer_city";        
			$cmn_US_state 		= "employer_state";       
			$cmn_US_zip 		= "employer_zip"; 
			$cmn_US_zip_ext		= "employer_zip_ext";
	
			$cmn_frgn_addr          = "employer_foreign_address";	
			$cmn_frgn_city 		= "employer_foreign_city";
			$cmn_frgn_state 	= "employer_foreign_state";
			$cmn_frgn_country_code  = "employer_foreign_country_code";
			$cmn_frgn_zip 		= "employer_foreign_zip";
			include("../oltproc/commonAddressPnl.php");
		}
	}
	else
	{
		if($employer_foreign_add_ind == 1)
		{
			if(($employer_foreign_address =="") || (UDF_strlen($employer_foreign_address) < 2))
			{
				$err_flag=1;
				$emplr_frgn_add_err_flag=1;
			}
			if(($employer_foreign_city != "") &&( UDF_strlen($employer_foreign_city) < 3))
			{
				$err_flag=1;
				$emplr_frgn_city_err_flag=1;
			}	
			if(UDF_strlen(UDF_trim($employer_foreign_country_code))==0)
			{
				$err_flag = 1;
				$emplr_frgn_cutry_err_flag = 1;       
			}	 			
			if(!fmtNamesp1($employer_foreign_state))
			{
				$err_flag = 1;
				$emplr_frgn_state_err_flag=1;       
			}
			if(!is_null($employer_foreign_zip) && !IsValidForeignPostalCode($employer_foreign_zip))
			{
				$err_flag = 1;
				$emplr_frgn_zip_err_flag=1;
			}
		}
		else
		{	
			if(($employer_address=="") || (!IsAlphaNumericsp($employer_address)))
			{
				$err_flag=1;
				$eaddr_err_flag=1;
			}
		
			if(($employer_city=="") || (!IsAlphaNumericsp($employer_city)))
			{
				$err_flag=1;
				$ecity_err_flag=1;
			}
		
			if($employer_state == "")
			{
				$err_flag=1;
				$estate_err_flag=1;
			}
	
			if(($employer_zip == "") || (!isNumeric($employer_zip)))
			{
				$err_flag=1;
				$ezip_err_flag=1;
	
			}
	
			if((isNumeric($employer_zip))&& ($employer_state == ""))
			{
				$err_flag=1;
				$estate_err_flag=1;	
			}
	
			if(($employer_state != "") && ($employer_zip == ""))
			{
				$err_flag=1;
				$ezip_err_flag=1;
			}
	
			if(($employer_zip != "") && (UDF_strlen($employer_zip) != 5))
			{
				$err_flag=1;
				$ezip_err_flag=1;
			}
			$validStZip = IsValidZip($employer_state, $employer_zip);
	
			if (($employer_state != "") && ($validStZip == 0) )
			{
				$err_flag=1;
				$ezip_err_flag=1;
			}
			
      			$employer_zip_ext = UDF_trim($employer_zip_ext);
			$employer_zip_ext = fixnum($employer_zip_ext);
			
			if(($employer_zip_ext != "") && ((!isNumeric($employer_zip_ext)) || (UDF_strlen($employer_zip_ext) != 4)))
			{
			  	$err_flag=1;
			  	$ezipext_err_flag=1;
			}
		}
	}	
	//}		
	
	if((!isNumeric($soc_sec_wages)) && ($soc_sec_wages != ""))
	{
	  $err_flag=1;
	  $sswag_err_flag=1;
	}
	if((!isNumeric($soc_sec_tax_withheld)) && ($soc_sec_tax_withheld != ""))
	{
	  $err_flag=1;
	  $sstax_err_flag=1;
	}
	/*if( $soc_sec_tax_withheld >  ($soc_sec_wages/2)) 
	{
	  //$err_flag=1;
	  $sstax_err_flag=2;
	}*/
	
	$totBox3Box7 = (float)$soc_sec_wages + (float)$soc_sec_tips;
	if($totBox3Box7 > 184500)	// [TY2025 - 176100][TY2024 - 168600][TY2023 - 160200][TY2022 - 147000] [TY2021 - 142800]
		$totBox3Box7 = 184500;
	if(( UDF_round((float)$soc_sec_tax_withheld, 2) !=  UDF_round(((float)$totBox3Box7 * 0.062), 2)) && ($PassValidationInd != 1))  //**010
	{
		$AddOne = UDF_round(((float)$totBox3Box7 * 0.062), 2) + 1;
		$SubOne = UDF_round(((float)$totBox3Box7 * 0.062), 2) - 1;
		
		if(($AddOne < UDF_round((float)$soc_sec_tax_withheld, 2)))
		{
			$err_flag=1;
			$sstax_err_flag=2;
		}
		else if (($SubOne > UDF_round((float)$soc_sec_tax_withheld, 2)))
		{
	  $err_flag=1;
	  $sstax_err_flag=2;
	}
	}
	if((!isNumeric($medicare_wages_tips)) && ($medicare_wages_tips != ""))
	{
	  $err_flag=1;
	  $medwag_err_flag=1;
	}
	
	if((!isNumeric($medicare_tax_withheld)) && ($medicare_tax_withheld != ""))
	{
	  $err_flag=1;
	  $medtax_err_flag=1;
	}
	$dblTmpMTWValue = (float)$medicare_wages_tips * 0.0145;
	if($medicare_wages_tips > 200000)
	{
		$medicare_wages_tips_tmp = (float)$medicare_wages_tips - 200000;
		$medicare_tax_withheld_tmp = (float)$medicare_wages_tips_tmp * 0.009;
		$dblTmpMTWValue = (float)$dblTmpMTWValue + (float)$medicare_tax_withheld_tmp;
	}
	if((UDF_round((float)$medicare_tax_withheld, 2) !=  UDF_round((float)$dblTmpMTWValue, 2)) && ($PassValidationInd != 1)) //**010
	{
	  	$AddOne = ((float)$medicare_wages_tips * 0.0145) + 1;
		$SubOne = ((float)$medicare_wages_tips * 0.0145) - 1;
		
		if(($AddOne < UDF_round((float)$medicare_tax_withheld, 2)))
		{
			$err_flag=1;
	  		$medtax_err_flag=2;
		}
		else if (($SubOne > UDF_round((float)$medicare_tax_withheld, 2)))
		{
	  $err_flag=1;
	  $medtax_err_flag=2;
	}
	}
	if((!isNumeric($soc_sec_tips)) && ($soc_sec_tips != ""))
	{
	  $err_flag=1;
	  $sstips_err_flag=1;
	}
	if((!isNumeric($allocated_tips))&& ($allocated_tips != ""))
	{
	  $err_flag=1;
	  $alloc_err_flag=1;
	}
	//1040 Instruction
	/*if((!isNumeric($adv_eic_payment)) && ($adv_eic_payment != ""))
	{
	  $err_flag=1;
	  $eic_err_flag=1;
	}*/
	if((!isNumeric($dep_care_benefits)) && ($dep_care_benefits != ""))
	{
	  $err_flag=1;
	  $dep_err_flag=1;
	}
	
	if(($nonqualified_plans != "") && (!isNumeric($nonqualified_plans)))
	{
	  $err_flag=1;
	  $plan_err_flag=1;
	}
	
	/*if(($box12a_code =="") && ($box12a_amount > 0))
	{
	  $err_flag=1;
	  $codea_err_flag=1;
	}
	if(($box12a_amount !="") &&(!isNumeric($box12a_amount)))
	{
	  $err_flag=1;
	  $amta_err_flag=1;
	}
	if(($box12b_code =="") && ($box12b_amount > 0))
	{
	  $err_flag=1;
	  $codeb_err_flag=1;
	}
	if(($box12a_amount !="") && (!isNumeric($box12b_amount)))
	{
	  $err_flag=1;
	  $amtb_err_flag=1;
	}*/
	if($nv_mode=="1")
	{ 
		$cmn_addrTag		= "addr2";
		$cmn_frgn_addr_ind 	= "emp_for_add_ind";		
		$cmn_US_addr  		= "emp_address";
		$cmn_US_addr2  		= "emp_address2";
		$cmn_US_aptno  		= "emp_apt";
		$cmn_US_city 		= "emp_city";        
		$cmn_US_state 		= "emp_state";       
		$cmn_US_zip 		= "emp_zip"; 
		$cmn_US_zip_ext		= "emp_zip_ext";

		$cmn_frgn_addr          = "emp_for_address";	
		$cmn_frgn_addr2         = "emp_for_address2";	
		$cmn_forgn_aptno         = "emp_apt_for";	
		$cmn_frgn_city 		= "emp_for_city";
		$cmn_frgn_state 	= "emp_for_state";
		$cmn_frgn_country_code  = "emp_foreign_country_cd";
		$cmn_frgn_zip 		= "emp_for_zip";
		include("../oltproc/commonAddressPnl.php");
		
	
	}
	else
	{
		if($emp_for_add_ind == 1)
		{
			if(($emp_for_address =="") || (UDF_strlen($emp_for_address) < 2))
			{
				$err_flag=1;
				$emp_frgn_add_err_flag=1;
			}
			if(($emp_for_city != "") &&( UDF_strlen($emp_for_city) < 3))
			{
				$err_flag=1;
				$emp_frgn_city_err_flag=1;
			}	
			if(UDF_strlen(UDF_trim($emp_foreign_country_cd))==0)
			{
				$err_flag = 1;
				$emp_frgn_country_err_flag = 1;       
			}	 			
			if(!fmtNamesp1($emp_for_state))
			{
				$err_flag = 1;
				$emp_frgn_state_err_flag=1;       
			}
			if(!is_null($emp_for_zip) && !IsValidForeignPostalCode($emp_for_zip))
			{
				$err_flag = 1;
				$emp_frgn_zip_err_flag=1;
			}
		}
		else
		{	
			if(($emp_address=="") || (!IsAlphaNumericsp($emp_address)))
			{
				$err_flag=1;
				$addr_err_flag=1;
			}
		
			if(($emp_city=="") || (!IsAlphaNumericsp($emp_city)))
			{
				$err_flag=1;
				$city_err_flag=1;
			}
		
			if($emp_state == "")
			{
				$err_flag=1;
				$state_err_flag=1;
	
			}
	
			if(($emp_zip == "") || (!isNumeric($emp_zip)))
			{
				$err_flag=1;
				$zip_err_flag=1;
	
			}
	
			if((isNumeric($emp_zip))&& ($emp_state == ""))
			{
				$err_flag=1;
				$state_err_flag=1;	
			}
	
			if(($emp_state != "") && ($emp_zip == ""))
			{
				$err_flag=1;
				$zip_err_flag=1;
			}
	
			if(($emp_zip != "") && (UDF_strlen($emp_zip) != 5))
			{
				$err_flag=1;
				$zip_err_flag=1;
			}
			$validStZip = IsValidZip($emp_state, $emp_zip);
	
			if (($emp_state != "") && ($validStZip == 0) )
			{
				$err_flag=1;
				$zip_err_flag=1;
			}
			
			$emp_zip_ext = UDF_trim($emp_zip_ext);
			$emp_zip_ext = fixnum($emp_zip_ext);
			
			if(($emp_zip_ext != "") && ((!isNumeric($emp_zip_ext)) || (UDF_strlen($emp_zip_ext) != 4)))
			{
			  	$err_flag=1;
			  	$zipext_err_flag=1;
			}
		}
	}
	 //001
	/*if(($other1_type !="") &&(!isAlphaNumericsp($other1_type)))
	{
	  $err_flag=1;
	  $otcod1_err_flag=1;
	}
	if(($other2_type !="") && (!isAlphaNumericsp($other2_type)))
	{
	  $err_flag=1;
	  $otcod2_err_flag=1;
	}
	
	if(($other1_type !="") && $other1_amount==0)
	{
	  $err_flag=1;
	  $otcod1_err_flag=1;
	}
	
	if(($other1_typeNew !="") && ($other1_typeNew != $other1_type))
	{
	  $err_flag=1;
	  $otcodNew1_err_flag=1;
	}
	
	if(($other2_type !="") && $other2_amount==0)
	{
	  $err_flag=1;
	  $otcod2_err_flag=1;
	}
	
	if(($other2_typeNew !="") && ($other2_typeNew != $other2_type))
	{
	  $err_flag=1;
	  $otcodNew2_err_flag=1;
	}

	if(($other3_type !="") && $other3_amount==0)
	{
	  $err_flag=1;
	  $otcod3_err_flag=1;
	}
	
	if(($other3_typeNew !="") && ($other3_typeNew != $other3_type))
	{
	  $err_flag=1;
	  $otcodNew3_err_flag=1;
	}
	
	if(($other4_type !="") && $other4_amount==0)
	{
	  $err_flag=1;
	  $otcod4_err_flag=1;
	}
	
	if(($other4_typeNew !="") && ($other4_typeNew != $other4_type))
	{
	  $err_flag=1;
	  $otcodNew4_err_flag=1;
	}
	
	if(($box12a_year !="") && ((UDF_strlen(UDF_trim($box12a_year)) != 4) || (UDF_trim($box12a_year)== "0000") || (!isNumeric($box12a_year))))
	{
	  $err_flag = 1;
	  $box12a_year_flag = 1;
	}
	else if(($box12a_year =="") && ($box12a_amount > 0))
	{
		$err_flag = 1;
		$box12a_year_flag = 2;
	}
	
	if(($box12b_year !="") && ((UDF_strlen(UDF_trim($box12b_year)) != 4) || (UDF_trim($box12b_year)== "0000") || (!isNumeric($box12b_year))))
	{
	  $err_flag = 1;
	  $box12b_year_flag = 1;
	}
	else if(($box12b_year =="") && ($box12b_amount > 0))
	{
		$err_flag = 1;
		$box12b_year_flag = 2;
	}
		
	if(($box12c_year !="") && ((UDF_strlen(UDF_trim($box12c_year)) != 4) || (UDF_trim($box12c_year)== "0000") || (!isNumeric($box12c_year))))
	{
	  $err_flag = 1;
	  $box12c_year_flag = 1;
	}
	else if(($box12c_year =="") && ($box12c_amount > 0))
	{
		$err_flag = 1;
		$box12c_year_flag = 2;
	}
		
	if(($box12d_year !="") && ((UDF_strlen(UDF_trim($box12d_year)) != 4) || (UDF_trim($box12d_year)== "0000") || (!isNumeric($box12d_year))))
	{
	  $err_flag = 1;
	  $box12d_year_flag = 1;
	}
	else if(($box12d_year =="") && ($box12d_amount > 0))
	{
		$err_flag = 1;
		$box12d_year_flag = 2;
	}	
	
	//001
	if(($other1_amount > 0) && $other1_type=="")
	{
	  $err_flag=1;
	  $otcod1_err_flag=1;
	}
	
	if(($other2_amount > 0) && $other2_type=="")
	{
	  $err_flag=1;
	  $otcod2_err_flag=1;
	}

	if(($other3_amount > 0) && $other3_type=="")
	{
	  $err_flag=1;
	  $otcod3_err_flag=1;
	}
	if(($other4_amount > 0) && $other4_type=="")
	{
	  $err_flag=1;
	  $otcod4_err_flag=1;
	}
	
	
	if(($other1_amount !="") &&(!isNumeric($other1_amount)))
	{
	  $err_flag=1;
	  $otamt1_err_flag=1;
	}
	
	if(($other2_amount !="") && (!isNumeric($other2_amount)))
	{
	  $err_flag=1;
	  $otamt2_err_flag=1;
	}

	if(($other3_amount !="") && (!isNumeric($other3_amount)))
	{
	  $err_flag=1;
	  $otamt3_err_flag=1;
	}
	if(($other4_amount !="") && (!isNumeric($other4_amount)))
	{
	  $err_flag=1;
	  $otamt4_err_flag=1;
	}

	if(($box12c_code =="") && ($box12c_amount > 0))
	{
	  $err_flag=1;
	  $codec_err_flag=1;
	}
	if(($box12c_amount !="") && (!isNumeric($box12c_amount)))
	{
	  $err_flag=1;
	  $amtc_err_flag=1;
	}
	if(($box12d_code =="") && ($box12d_amount > 0))
	{
	  $err_flag=1;
	  $coded_err_flag=1;
	}
	
	if(($box12d_amount !="") && (!isNumeric($box12d_amount)))
	{
	  $err_flag=1;
	  $amtd_err_flag=1;
	}
	
	//Line 12e
	if(($box12e_code =="") && ($box12e_amount > 0))
	{
		$err_flag=1;
		$codee_err_flag=1;
	}
	
	if(($box12e_amount !="") && (!isNumeric($box12e_amount)))
	{
		$err_flag=1;
		$amte_err_flag=1;
	}
	
	if(($box12e_year !="") && ((UDF_strlen(UDF_trim($box12e_year)) != 4) || (UDF_trim($box12e_year)== "0000") || (!isNumeric($box12e_year))))
	{
		$err_flag = 1;
		$box12e_year_flag = 1;
	}
	else if(($box12e_year =="") && ($box12e_amount > 0))
	{
		$err_flag = 1;
		$box12e_year_flag = 2;
	}
	
	//
	//Line 12f
	if(($box12f_code =="") && ($box12f_amount > 0))
	{
		$err_flag=1;
		$codef_err_flag=1;
	}
	
	if(($box12f_amount !="") && (!isNumeric($box12f_amount)))
	{
		$err_flag=1;
		$amtf_err_flag=1;
	}
	
	if(($box12f_year !="") && ((UDF_strlen(UDF_trim($box12f_year)) != 4) || (UDF_trim($box12f_year)== "0000") || (!isNumeric($box12f_year))))
	{
		$err_flag = 1;
		$box12f_year_flag = 1;
	}
	else if(($box12f_year =="") && ($box12f_amount > 0))
	{
		$err_flag = 1;
		$box12f_year_flag = 2;
	}
	
	if(($state1 == "") && ((UDF_trim($st1_employer_id) !="") || (UDF_round($st1_wages_tips) > 0) || (UDF_round($st1_inc_tax) > 0)) )
	{
	  $err_flag=1;
	  $state1_err_flag=1;
	}
	
	if(($state2 == "") && ((UDF_trim($st2_employer_id) !="") || (UDF_round($st2_wages_tips) > 0) || (UDF_round($st2_inc_tax) > 0)) )
	{
		  $err_flag=1;
		  $state2_err_flag=1;
	}
	
	if(($state3 == "") && ((UDF_trim($st3_employer_id) !="") || (UDF_round($st3_wages_tips) > 0) || (UDF_round($st3_inc_tax) > 0)) )
	{
		  $err_flag = 1;
		  $state3_err_flag = 1;
	}
	
	if(($state4 == "") && ((UDF_trim($st4_employer_id) !="") || (UDF_round($st4_wages_tips) > 0) || (UDF_round($st4_inc_tax) > 0)) )
	{
		  $err_flag = 1;
		  $state4_err_flag = 1;
	}
	
	 if($state1 == "CA") 
	 {
	 	if((($st1_employer_id != "") && ($st1_wages_tips != "") && ($st1_wages_tips == $st1_employer_id)) || (($st1_employer_id == "") && ($st1_wages_tips > 0)))	
	 	{
	  		$err_flag=1;
	  		$eid1_ca_err_flag=1;
	  	}	  		  	
	 }	 	 	
	 
	 if($state2 == "CA") 
	 {
	 	if((($st2_employer_id != "") && ($st2_wages_tips != "") && ($st2_wages_tips == $st2_employer_id)) || (($st2_employer_id == "") && ($st2_wages_tips > 0)))	
	 	{
	  		$err_flag=1;
	  		$eid2_ca_err_flag=1;
	  	}	  		  	
	 }	 	
	 
	 if($state3 == "CA") 
	 {
	 	if((($st3_employer_id != "") && ($st3_wages_tips != "") && ($st3_wages_tips == $st3_employer_id)) || (($st3_employer_id == "") && ($st3_wages_tips > 0)))	
	 	{
	  		$err_flag=1;
	  		$eid3_ca_err_flag=1;
	  	}	  
	 }
	 
	 if($state4 == "CA") 
	 {
	 	if((($st4_employer_id != "") && ($st4_wages_tips != "") && ($st4_wages_tips == $st4_employer_id)) || (($st4_employer_id == "") && ($st4_wages_tips > 0)))	
	 	{
	  		$err_flag=1;
	  		$eid4_ca_err_flag=1;
	  	}	  		  	
	 }
	
	 if((($state1 == "MN") && (($st1_employer_id == "") || (UDF_strlen($st1_employer_id) != "7")) && (UDF_round($st1_inc_tax) > 0)) || (($state1 == "RI") && (($st1_employer_id == "") || (UDF_strlen($st1_employer_id) != "9"))) || (($state1 == "OH") && ($st1_employer_id == "")) || !isAlphaNumeric($st1_employer_id) || (UDF_strlen($st1_employer_id) > "16"))
	 {
	  $err_flag=1;
	  $eid_err_flag=1;
	 }
	
	if((($state2 == "MN") && (($st2_employer_id == "") || (UDF_strlen($st2_employer_id) != "7")) && (UDF_round($st2_inc_tax) > 0)) || (($state2 == "RI") && (($st2_employer_id == "") || (UDF_strlen($st2_employer_id) != "9"))) || (($state2 == "OH") && ($st2_employer_id == "")) || !isAlphaNumeric($st2_employer_id) || (UDF_strlen($st2_employer_id) > "16"))
	 {
	  $err_flag=1;
	  $eid2_err_flag=1;
	 }
	
	if((($state3 == "MN") && (($st3_employer_id == "") || (UDF_strlen($st3_employer_id) != "7")) && (UDF_round($st3_inc_tax) > 0)) || (($state3 == "RI") && (($st3_employer_id == "") || (UDF_strlen($st3_employer_id) != "9"))) || (($state3 == "OH") && ($st3_employer_id == "")) || !isAlphaNumeric($st3_employer_id) || (UDF_strlen($st3_employer_id) > "16"))
	 {
	  $err_flag=1;
	  $eid3_err_flag=1;
	 }
	
	if((($state4 == "MN") && (($st4_employer_id == "") || (UDF_strlen($st4_employer_id) != "7")) && (UDF_round($st4_inc_tax) > 0)) || (($state4 == "RI") && (($st4_employer_id == "") || (UDF_strlen($st4_employer_id) != "9"))) || (($state4 == "OH") && ($st4_employer_id == "")) || !isAlphaNumeric($st4_employer_id) || (UDF_strlen($st4_employer_id) > "16"))
	 {
	  $err_flag=1;
	  $eid4_err_flag=1;
	 }
	
	if((!isNumeric($st1_wages_tips)) && ($st1_wages_tips != ""))
	{
	  $err_flag=1;
	  $stwag_err_flag=1;
	}
	
	 if((!isNumeric($st2_wages_tips)) && ($st2_wages_tips != ""))
	{
	  $err_flag=1;
	  $stwag2_err_flag=1;
	}
	
	if((!isNumeric($st3_wages_tips)) && ($st3_wages_tips != ""))
	{
	  $err_flag=1;
	  $stwag3_err_flag=1;
	}
	
	 if((!isNumeric($st4_wages_tips)) && ($st4_wages_tips != ""))
	{
	  $err_flag=1;
	  $stwag4_err_flag=1;
	}
	
	if((!isNumeric($st1_inc_tax)) && ($st1_inc_tax != ""))
	{
	  $err_flag=1;
	  $sttax_err_flag=1;
	}
	
	if((!isNumeric($st2_inc_tax)) && ($st2_inc_tax != ""))
	{
	  $err_flag=1;
	  $sttax2_err_flag=1;
	}
	if((!isNumeric($st3_inc_tax)) && ($st3_inc_tax != ""))
	{
	  $err_flag=1;
	  $sttax3_err_flag=1;
	}
	
	if((!isNumeric($st4_inc_tax)) && ($st4_inc_tax != ""))
	{
	  $err_flag=1;
	  $sttax4_err_flag=1;
	}
	
	if((!isNumeric($st1_local_wages)) && ($st1_local_wages != ""))
	{
	  $err_flag=1;
	  $stlocwag_err_flag=1;
	}
	
	if((!isNumeric($st2_local_wages)) && ($st2_local_wages != ""))
	{
	  $err_flag=1;
	  $stlocwag2_err_flag=1;
	}
	
	if((!isNumeric($st3_local_wages)) && ($st3_local_wages != ""))
	{
	  $err_flag=1;
	  $stlocwag3_err_flag=1;
	}
	
	if((!isNumeric($st4_local_wages)) && ($st4_local_wages != ""))
	{
	  $err_flag=1;
	  $stlocwag4_err_flag=1;
	}
	
	if((!isNumeric($st1_local_inc_tax)) && ($st1_local_inc_tax !=""))
	{
	  $err_flag=1;
	  $stloctax_err_flag=1;
	}
	
	if((!isNumeric($st2_local_inc_tax)) && ($st2_local_inc_tax !=""))
	{
	  $err_flag=1;
	  $stloctax2_err_flag=1;
	}
	
	if((!isNumeric($st3_local_inc_tax)) && ($st3_local_inc_tax !=""))
	{
	  $err_flag=1;
	  $stloctax3_err_flag=1;
	}
	
	if((!isNumeric($st4_local_inc_tax)) && ($st4_local_inc_tax !=""))
	{
	  $err_flag=1;
	  $stloctax4_err_flag=1;
	}
	
	$st1_locality = UDF_trim($st1_locality);
	$st1_locality_txt = UDF_trim($st1_locality_txt);
	
	if(($st1_locality != "") && (!isAlphaNumericsp($st1_locality))) //|| (($st1_local_wages > 0 ) && ($st1_locality == ""))) // && ($PassValidationInd != 1))
	{
	  $err_flag=1;
	  $stloca_err_flag=1;
	}
	
	if(($st1_local_wages > 0 ) && ($st1_locality == "") && (IsValidAllocState($state1))  && ($PassValidationInd != 1)) 
	{
		$err_flag=1;
	  	$stloca_err_flag=1;
	  	$stlocwag1_err = 1;
	}
	
	if(($show_city_combo_ind == 1)&&(UDF_in_array($state1, $aloc_state_array)))
	{
		if(($st1_local_wages > 0 ) && ($st1_locality == "NOL") && (($st1_locality_txt == "") || (($st1_locality_txt != "") && (!isAlphaNumericsp($st1_locality_txt)))) && ($PassValidationInd != 1))
		{
			$err_flag=1;
			$stloca_err_flag=1;
		}
	}
	$st2_locality = UDF_trim($st2_locality);
	$st2_locality_txt = UDF_trim($st2_locality_txt);
	if(($st2_locality != "") && (!isAlphaNumericsp($st2_locality))) // || (($st2_local_wages > 0 ) && ($st2_locality == ""))) 
	{
	  $err_flag=1;
	  $stloca2_err_flag=1;
	}
	if(($st2_local_wages > 0 ) && ($st2_locality == "") && (IsValidAllocState($state2)) && ($PassValidationInd != 1))
	{
		$err_flag=1;
	  	$stloca2_err_flag=1;
	  	$stlocwag2_err = 1;
	}
	
	if(($show_city_combo_ind == 1)&&(UDF_in_array($state2, $aloc_state_array)))
	{
		if(($st2_local_wages > 0 ) && ($st2_locality == "NOL") && (($st2_locality_txt == "") || (($st2_locality_txt != "") && (!isAlphaNumericsp($st2_locality_txt)))) && ($PassValidationInd != 1))
		{
			$err_flag=1;
			$stloca2_err_flag=1;
		}
	}
	$st3_locality = UDF_trim($st3_locality);
	$st3_locality_txt = UDF_trim($st3_locality_txt);
	if(($st3_locality != "") && (!isAlphaNumericsp($st3_locality))) // || (($st3_local_wages > 0 ) && ($st3_locality == ""))) 
	{
	  $err_flag=1;
	  $stloca3_err_flag=1;
	}
	
	if(($st3_local_wages > 0 ) && ($st3_locality == "") && (IsValidAllocState($state3)) && ($PassValidationInd != 1))
	{
		$err_flag=1;
	  	$stloca3_err_flag=1;
	  	$stlocwag3_err = 1;
	}
	
	if(($show_city_combo_ind == 1)&&(UDF_in_array($state3, $aloc_state_array)))
	{
		if(($st3_local_wages > 0 ) && ($st3_locality == "NOL") && (($st3_locality_txt == "") || (($st3_locality_txt != "") && (!isAlphaNumericsp($st3_locality_txt)))) && ($PassValidationInd != 1))
		{
			$err_flag=1;
			$stloca3_err_flag=1;
		}
	}
	$st4_locality = UDF_trim($st4_locality);
	$st4_locality_txt = UDF_trim($st4_locality_txt);
	if(($st4_locality != "") && (!isAlphaNumericsp($st4_locality))) //|| (($st4_local_wages > 0 ) && ($st4_locality == ""))) 
	{
	  $err_flag=1;
	  $stloca4_err_flag=1;
	}
	
	if(($st4_local_wages > 0 ) && ($st4_locality == "") && (IsValidAllocState($state4)) && ($PassValidationInd != 1))
	{
		$err_flag=1;
	  	$stloca4_err_flag=1;
	  	$stlocwag4_err = 1;	
	}
	
	if(($show_city_combo_ind == 1)&&(UDF_in_array($state4, $aloc_state_array)))
	{
		if(($st4_local_wages > 0 ) && ($st4_locality == "NOL") && (($st4_locality_txt == "") || (($st4_locality_txt != "") && (!isAlphaNumericsp($st4_locality_txt)))) && ($PassValidationInd != 1))
		{
			$err_flag=1;
			$stloca4_err_flag=1;
		}
	}*/
	
	
        
        
        /*if(($st1_inc_tax > 0 && $st1_wages_tips == 0)  && ($PassValidationInd != 1))//006
        {
        	$err_flag =1 ;
        	$stwag_err_flag=1;
        	$state_wage1_err = 1;
        }
        // commented for MD test case 8 (MD05008)
        if(($st2_inc_tax > 0 && $st2_wages_tips == 0)  && ($PassValidationInd != 1))//006
        {
        	$err_flag =1 ;
        	$stwag_err_flag=1;
        	$state_wage2_err = 1;
        }
        
        if(UDF_trim($state1) == "IL" && $st1_wages_tips > 0)
        {
        	if($st1_inc_tax > $st1_wages_tips / 5)
	        {
	        	$err_flag =1 ;
	        	$st1_with_held_err = 1;
	        	$stwag_err_flag=1;
	        	$sttax_err_flag=1;
	        }
        }
        if(UDF_trim($state2) == "IL" && $st2_wages_tips > 0)
        {
        	if($st2_inc_tax > $st2_wages_tips / 5)
	        {
	        	$err_flag =1 ;
	        	$st2_with_held_err = 1;
	        	$stwag2_err_flag=1;
	        	$sttax2_err_flag=1;
	        }
        }
	if($st1_wages_tips > 0 && UDF_trim($state1) != "IL" && UDF_trim($state1) != "VA" && UDF_trim($state1) != "MN" && UDF_trim($state1) != "NY")
        {
	        if($st1_inc_tax > $st1_wages_tips / 2)
	        {
	        	$err_flag =1 ;
	        	$st1_with_held_err = 1;
	        	$stwag_err_flag=1;
	        	$sttax_err_flag=1;
	        }
	}
	
	if($st2_wages_tips > 0 && UDF_trim($state2) != "IL" && UDF_trim($state2) != "VA" && UDF_trim($state2) != "MN" && UDF_trim($state2) != "NY")
	{
	        if($st2_inc_tax > $st2_wages_tips / 2)
	        {
	        	$err_flag =1 ;
	        	$st2_with_held_err = 1;
	        	$stwag2_err_flag=1;
	        	$sttax2_err_flag=1;
	        }
	}
	
	if($st1_wages_tips > 0 && (UDF_trim($state1) == "MN" || UDF_trim($state1) == "NY") && ($PassValidationInd != 1))
        {
	        if($st1_inc_tax > $st1_wages_tips / 2)
	        {
	        	$err_flag =1 ;
	        	$st1_with_held_err = 1;
	        	$stwag_err_flag=1;
	        	$sttax_err_flag=1;
	        }
	}
	if($st2_wages_tips > 0 && (UDF_trim($state2) == "MN" || UDF_trim($state2) == "NY") && ($PassValidationInd != 1))
	{
	        if($st2_inc_tax > $st2_wages_tips / 2)
	        {
	        	$err_flag =1 ;
	        	$st2_with_held_err = 1;
	        	$stwag2_err_flag=1;
	        	$sttax2_err_flag=1;
	        }
	}

        if($st1_wages_tips > 0 && UDF_trim($state1) == "VA" && ($PassValidationInd != 1))
        {
	        if(UDF_round($st1_inc_tax) > UDF_round($st1_wages_tips / 4))
	        {
	        	$err_flag =1 ;
	        	$st1_with_held_err = 1;
	        	$stwag_err_flag=1;
	        	$sttax_err_flag=1;
	        }
	}
	if($st2_wages_tips > 0 && UDF_trim($state2) == "VA" && ($PassValidationInd != 1))
	{
	        if(UDF_round($st2_inc_tax) > UDF_round($st2_wages_tips / 4))
	        {
	        	$err_flag =1 ;
	        	$st2_with_held_err = 1;
	        	$stwag2_err_flag=1;
	        	$sttax2_err_flag=1;
	        }
	}
	
	if(($state1 == $state2) && ($PassValidationInd != 1)) //005
	{
	$state_wages = $st1_wages_tips + $st2_wages_tips;
		if (($amd_ind_w2 != 1) && ($OtherSiteAmdInd_w2 !=1))
		{
			if(($state_wages > ($wages_tips * 5 / 4)) && ($combatPayEntered == 0)) // 004
			{
				$err_flag =1 ;
				$wage_comp_err = 1;
				$wages_err_flag=1;
				$stwag_err_flag=1;
				$stwag2_err_flag=1;
			}
		}
	}
	else
	{/*
		if($state1 != "")
		{
			if(($st1_wages_tips > ($wages_tips * 5 / 4)) && ($combatPayEntered == 0))
			{
				$stwag_err_flag=1;
				$wages_err_flag=1;
				$err_flag =1 ;
				$wage_comp_err = 1;
			}
		}
		if($state2 != "")
		{
			if(($st2_wages_tips > ($wages_tips * 5 / 4)) && ($combatPayEntered == 0))
			{
				$stwag2_err_flag=1;
				$wages_err_flag=1;
				$err_flag =1 ;
				$wage_comp_err = 1;
			}
		}
	}
	if($st1_wages_tips > 0 && $st2_wages_tips > 0)
	{
		if($state1 == $state2 && $st1_inc_tax == $st2_inc_tax && $st1_wages_tips == $st2_wages_tips)
		{
			$err_flag =1 ;
			$stwag2_err_flag=1;
			$sttax_err_flag=1;
			$sttax2_err_flag=1;	
		        $stwag_err_flag=1;
		        $state1_err_flag=1;
		        $state2_err_flag=1;
		        $state_comp_err = 1;
		}
	}*/
	
	/*if(($fw2_hash_cd != "") && ((!(isIRSVerifyCodeValid($fw2_hash_cd))) || UDF_strlen($fw2_hash_cd) < 16))
	{		
		$err_flag=1;
		$fw2_hash_cd_err_flag=1;
	}*/
	//echo "<br><br><br><br><br>jhfjdhf $box12_code1";
	$Box12CodeIICnt=0;
	$icnt=0;
	$AllowedArrayValuesbox12Cd = array();	
	if($TotCountOfBox12Rows > 0)
	{
		$AllowedArrayValuesbox12Cd[$icnt++] = "A";
		$AllowedArrayValuesbox12Cd[$icnt++] = "B";
		$AllowedArrayValuesbox12Cd[$icnt++] = "C";
		$AllowedArrayValuesbox12Cd[$icnt++] = "D";
		$AllowedArrayValuesbox12Cd[$icnt++] = "E";
		$AllowedArrayValuesbox12Cd[$icnt++] = "F";
		$AllowedArrayValuesbox12Cd[$icnt++] = "G";
		$AllowedArrayValuesbox12Cd[$icnt++] = "H";
		$AllowedArrayValuesbox12Cd[$icnt++] = "J";
		$AllowedArrayValuesbox12Cd[$icnt++] = "K";
		$AllowedArrayValuesbox12Cd[$icnt++] = "L";
		$AllowedArrayValuesbox12Cd[$icnt++] = "M";
		$AllowedArrayValuesbox12Cd[$icnt++] = "N";
		$AllowedArrayValuesbox12Cd[$icnt++] = "P";
		$AllowedArrayValuesbox12Cd[$icnt++] = "Q";
		$AllowedArrayValuesbox12Cd[$icnt++] = "R";
		$AllowedArrayValuesbox12Cd[$icnt++] = "S";
		$AllowedArrayValuesbox12Cd[$icnt++] = "T";
		$AllowedArrayValuesbox12Cd[$icnt++] = "V";
		$AllowedArrayValuesbox12Cd[$icnt++] = "W";
		$AllowedArrayValuesbox12Cd[$icnt++] = "Y";
		$AllowedArrayValuesbox12Cd[$icnt++] = "Z";
		$AllowedArrayValuesbox12Cd[$icnt++] = "AA";
		$AllowedArrayValuesbox12Cd[$icnt++] = "BB";
		$AllowedArrayValuesbox12Cd[$icnt++] = "DD";
		$AllowedArrayValuesbox12Cd[$icnt++] = "EE";
		$AllowedArrayValuesbox12Cd[$icnt++] = "FF";
		$AllowedArrayValuesbox12Cd[$icnt++] = "GG";
		$AllowedArrayValuesbox12Cd[$icnt++] = "HH";
		$AllowedArrayValuesbox12Cd[$icnt++] = "II";
		$AllowedArrayValuesbox12Cd[$icnt++] = "TA";
		$AllowedArrayValuesbox12Cd[$icnt++] = "TP";
		$AllowedArrayValuesbox12Cd[$icnt++] = "TT";
	}
	for($ictr=1; $ictr <= $TotCountOfBox12Rows; $ictr++)
	{
		$box12_codeVar 		= "box12_code".$ictr;
		$box12_amountVar 	= "box12_amount".$ictr;
		$box12_yearVar 		= "box12_year".$ictr;
		
		$box12_codeVal 		= UDF_trim($$box12_codeVar);
		$box12_amountVal 	= UDF_trim($$box12_amountVar);
		$box12_yearVal 		= UDF_trim($$box12_yearVar);
		
		$box12_codeVal		=fmtvalue($box12_codeVal);
		$box12_amountVal	=fmtvalue($box12_amountVal);
		
		$box12_codeErr 		= "box12_code_err".$ictr;
		$box12_amountErr 	= "box12_amount_err".$ictr;
		$box12_yearErr 		= "box12_year_err".$ictr;
		
		$$box12_codeErr 	= 0;
		$$box12_amountErr 	= 0;
		$$box12_yearErr 	= 0;
		
		//echo "<br><br><br><br><br>if($box12_codeVar $box12_codeVal $box12_amountVal $box12_yearVal";
		//echo "<br><br><br><br><br>$TotCountOfBox12Rows $box12_code1";
		
		if(($box12_codeVal != "") && (!IsValidValue($box12_codeVal, $AllowedArrayValuesbox12Cd)))
		{
			$err_flag = 1;
			$box12_codeErr = 1;
		}
		
		if(($box12_codeVal =="") && ($box12_amountVal > 0))
		{
			$err_flag = 1;
			$$box12_codeErr = 1;
		}
		
		if(($box12_amountVal !="") &&(!isNumeric($box12_amountVal)))
		{
			$err_flag = 1;
			$$box12_amountErr = 1;
		}
		
		if(($box12_yearVal !="") && ((UDF_strlen(UDF_trim($box12_yearVal)) != 4) || (UDF_trim($box12_yearVal)== "0000") || (!isNumeric($box12_yearVal))))
		{
			$err_flag = 1;
			$$box12_yearErr = 1;
		}
		else if(($box12_yearVal =="") && ($box12_amountVal > 0))
		{
			$err_flag = 1;
			$$box12_yearErr = 2;
		}
		
		if(($box12_codeVal == "Q") && ($box12_amountVal > 0))
		{
			$combatPayEntered = 1;
		}
		if($box12_codeVal =="II")
		{
			$Box12CodeIICnt++;
		}
	}
	$query_info  ="select othersite_ori_efile_ind,othsite_ori_paperfile_ind from ind_return_info where ";
	$query_info  .= "qt_user_id=(?) "; db_sql_BuildParamArray($qt_user_id, "ind_return_info::qt_user_id");
$result_info   = db_sql_query(array($query_info), $_SQL_ParamsArray);
$noOfRows_info = db_num_rows(array($result_info));	
if($noOfRows_info > 0)
{	
	$res_data_info            = db_fetchrow(array($result_info, DB_GETMODE_ASSOC));
	$othersite_ori_efile_ind  = UDF_trim($res_data_info["othersite_ori_efile_ind"]); 
	$othsite_ori_paperfile_ind  = UDF_trim($res_data_info["othsite_ori_paperfile_ind"]); 
}
db_free_result(array($result_info)); 
  if (($OtherSiteAmdInd_w2 ==1) && ($othersite_ori_efile_ind == 0 && $othsite_ori_paperfile_ind == 0))//&& ($GLOBAL_FED_amended_rows == 0)
  {
  }
  else
  {
		if((UDF_round((float)$wages_tips) == 0 && $combatPayEntered == 0) && ($PassValidationInd != 1))
		{
		  $err_flag=1;
		  $wagesZero_err_flag=1;
		}
		
		if(($wages_tips == "") || (!isNumeric($wages_tips)))
		{
		  $err_flag=1;
		  $wages_err_flag=1;
		}
	}
	
	$fed_tax_ss_with = (float)$fed_inc_tax_withheld + (float)$soc_sec_tax_withheld;
	if (($OtherSiteAmdInd_w2 ==1) && ($othersite_ori_efile_ind == 0 && $othsite_ori_paperfile_ind == 0))
  {
  }
  else
	{
	        if(((float)$fed_inc_tax_withheld > (float)$wages_tips / 2) && ($combatPayEntered == 0) && ($PassValidationInd != 1)) // 004
	        {
	        	$err_flag =1 ;
	        	$with_held_err = 1;
	        	//$wages_err_flag=1;
	        	$fed_err_flag=2;
	        }
	        if(((float)$soc_sec_tax_withheld > ((float)$soc_sec_wages/2)) && ($PassValidationInd != 1))  // $wages_tips / 2) && ($combatPayEntered == 0)) // 004
	        {
	        	$err_flag =1 ;
	        	$ss_with_held_err = 1;
	        	$sstax_err_flag=3;
	        	$sswag_err_flag = 2;
	        	//$wages_err_flag=1;
	        }
        }
	
	$nv_dup_warn_msg = "";
	$ArrStateValCombinationWages = array();
	$ArrStateValCombinationIncome = array();
	$ArrStateValSameInfo = array();
	$ArrCntWages = 0;
	$ArrCntIncome = 0;
	$ArrCntSameInfo = 0;
	$fed_OH_state_err_flag = 0;
	$fed_IN_state_err_flag = 0;
	$fed_state_same_info_err_flag = 0;
	$NYStateRowCount =0;	
	$st_wages_tipsValTot=0;
	for($ictr=1; $ictr <= $TotCountOfRows; $ictr++)
	{
		$stateVar 		= "state".$ictr;
		$st_employer_idVar 	= "st".$ictr."_employer_id";
		$st_wages_tipsVar	= "st".$ictr."_wages_tips";
		$st_inc_taxVar 		= "st".$ictr."_inc_tax";
		$st_local_wagesVar 	= "st".$ictr."_local_wages";
		$st_local_inc_taxVar 	= "st".$ictr."_local_inc_tax";
		$st_localityVar 	= "st".$ictr."_locality";
		$st_locality_txtVar 	= "st".$ictr."_locality_txt";
		
		$stateVal 		= UDF_trim($$stateVar);
		$st_employer_idVal 	= UDF_trim($$st_employer_idVar);
		$st_wages_tipsVal	= UDF_trim($$st_wages_tipsVar);
		$st_inc_taxVal 		= UDF_trim($$st_inc_taxVar);
		$st_local_wagesVal 	= UDF_trim($$st_local_wagesVar);
		$st_local_inc_taxVal 	= UDF_trim($$st_local_inc_taxVar);
		$st_localityVal 	= UDF_trim($$st_localityVar);
		$st_locality_txtVal 	= UDF_trim($$st_locality_txtVar);
		
   		$st_wages_tipsVal 	= (float)$st_wages_tipsVal;
		$st_inc_taxVal 		= (float)$st_inc_taxVal;
		$st_local_wagesVal 	= (float)$st_local_wagesVal;
		$st_local_inc_taxVal 	= (float)$st_local_inc_taxVal;

		$st_employer_idVal	=fixtext($st_employer_idVal);
		$st_wages_tipsVal	=fmtvalue($st_wages_tipsVal);
		$st_inc_taxVal		=fmtvalue($st_inc_taxVal);
		$st_local_wagesVal	=fmtvalue($st_local_wagesVal);
		$st_local_inc_taxVal	=fmtvalue($st_local_inc_taxVal);
		
		$stateErr 		= "state_err".$ictr;
		$st_employer_idErr 	= "st_employer_id_err".$ictr;
		$st_employer_idCAErr 	= "st_employer_id_caerr".$ictr;
		$st_wages_tipsErr 	= "st_wages_tips_err".$ictr;
		$st_inc_taxVarErr 	= "st_inc_tax_err".$ictr;
		$st1_with_held_err	= "st_inc_tax_err".$ictr;
		$st_local_wagesErr 	= "st_local_wages_err".$ictr;
		$st_local_wagesErr1 	= "st_local_wages_err1".$ictr;
		$st_local_inc_taxErr 	= "st_local_inc_tax_err".$ictr;
		$st_localityErr 	= "st_locality_err".$ictr;
		$st_localityTxtErr 	= "st_locality_txt_err".$ictr;
		$st_localityCombErr 	= "st_locality_comb_err".$ictr;
		
		$$stateErr 		= 0;
		$$st_employer_idErr 	= 0;
		$$st_employer_idCAErr 	= 0;
		$$st_wages_tipsErr 	= 0;
		$$st_inc_taxVarErr 	= 0;
		$$st1_with_held_err	= 0;
		$$st_local_wagesErr 	= 0;
		$$st_local_wagesErr1 	= 0;
		$$st_local_inc_taxErr 	= 0;
		$$st_localityErr 	= 0;
		$$st_localityCombErr	= 0;
		$$st_localityTxtErr	= 0;	
		
		if(($stateVal != "") && (IsValidState($stateVal) == 0))
		{
			$err_flag = 1;
		  	$$stateErr = 1;
		}	
		
		if(($stateVal == "") && ((UDF_trim($st_employer_idVal) !="") || (UDF_round($st_wages_tipsVal) > 0) || (UDF_round($st_inc_taxVal) > 0)))
		{
			$err_flag = 1;
		  	$$stateErr = 1;
		}
		else if($stateVal == "NY")
		{
			$NYStateRowCount++;
		}
		
		if($stateVal == "ND") 
		{
			if($st_employer_idVal == "")
			{
				$err_flag = 1;
				$$st_employer_idCAErr = 1;
			}
		}
		if($stateVal == "CA") 
		{
			if((($st_employer_idVal != "") && ($st_wages_tipsVal != "") && ($st_wages_tipsVal == $st_employer_idVal)) || (($st_employer_idVal == "") && ($st_wages_tipsVal > 0)))
			{
				$err_flag = 1;
				$$st_employer_idCAErr = 1;
			}	  		  	
		}
		
		if((($stateVal == "MN") && (($st_employer_idVal == "") || (UDF_strlen($st_employer_idVal) != "7") || (!fmtNum($st_employer_idVal))) && (UDF_round($st_inc_taxVal) > 0)) || (($stateVal == "RI") && (($st_employer_idVal == "") || (UDF_strlen($st_employer_idVal) != "9"))) || (($stateVal == "OH") && ($st_employer_idVal == "") && ($st_wages_tipsVal > 0 || $st_inc_taxVal > 0)) || !isAlphaNumeric($st_employer_idVal) || (UDF_strlen($st_employer_idVal) > "16"))
		{
			$err_flag = 1;
			$$st_employer_idErr = 1;
		}
		
		if((!isNumeric($st_wages_tipsVal)) && ($st_wages_tipsVal != ""))
		{
			$err_flag = 1;
			$$st_wages_tipsErr = 1;
		}
    else
    {
    		$st_wages_tipsValTot    += $st_wages_tipsVal; 
    }
		
		if((!isNumeric($st_inc_taxVal)) && ($st_inc_taxVal != ""))
		{
			$err_flag = 1;
			$$st_inc_taxVarErr = 1;
		}
		
		if((!isNumeric($st_local_wagesVal)) && ($st_local_wagesVal != ""))
		{
			$err_flag = 1;
			$$st_local_wagesErr = 1;
		}
		
		if((!isNumeric($st_local_inc_taxVal)) && ($st_local_inc_taxVal !=""))
		{
			$err_flag = 1;
			$$st_local_inc_taxErr = 1;
		}
		
		$st_localityVal = UDF_trim($st_localityVal);
		$st_locality_txtVal = UDF_trim($st_locality_txtVal);
		if(($st_localityVal != "") && (!isAlphaNumericsp($st_localityVal)))
		{
			$err_flag = 1;
			$$st_localityErr = 1;
		}
		
		if(($st_local_wagesVal > 0 ) && ($st_localityVal == "") && (IsValidAllocState($stateVal))  && ($PassValidationInd != 1)) 
		{
			$err_flag = 1;
			if((UDF_in_array($stateVal, $aloc_state_array)) || ($stateVal == "NY"))
				$$st_localityCombErr = 1;
			else	
				$$st_localityErr = 1;
			
			if($stateVal != "NY")	
				$stlocwag1_err = 1;
		}
		
		if(($show_city_combo_ind == 1)&&(UDF_in_array($stateVal, $aloc_state_array)))
		{
			if(($st_local_wagesVal > 0 ) && ($st_localityVal == "NOL") && (($st_locality_txtVal == "") || (($st_locality_txtVal != "") && (!isAlphaNumericsp($st_locality_txtVal)))) && ($PassValidationInd != 1))
			{
				$err_flag = 1;
				$$st_localityTxtErr = 1;
			}
		}
		
		if(($st_inc_taxVal > 0 && $st_wages_tipsVal == 0)  && ($PassValidationInd != 1))
		{
			$err_flag = 1 ;
			$$st_wages_tipsErr = 1;
			$state_wage1_err = 1;
		}
		/*if($st_wages_tipsVal > 0 && UDF_trim($stateVal) != "MO" && UDF_trim($stateVal) != "IL" && UDF_trim($stateVal) != "VA" && UDF_trim($stateVal) != "MN" && UDF_trim($stateVal) != "NY" && UDF_trim($stateVal) != "SC" && UDF_trim($stateVal) != "NC" && UDF_trim($stateVal) != "WI" && UDF_trim($stateVal) != "CT" && UDF_trim($stateVal) != "KS")
		{
			if($st_inc_taxVal > $st_wages_tipsVal / 2)
			{
				$err_flag = 1 ;
				$$st1_with_held_err = 1;
				$$st_wages_tipsErr = 1;
				$$st_inc_taxVarErr = 1;
			}
		}*/
			
		if(($st_wages_tipsVal > 0) && ((UDF_trim($stateVal) != "") && (UDF_trim($stateVal) != "IL") && (UDF_trim($stateVal) != "VA")) && ($PassValidationInd != 1))	//(UDF_trim($stateVal) = "MN" || UDF_trim($stateVal) == "NY" || UDF_trim($stateVal) == "SC" || UDF_trim($stateVal) == "NC" || UDF_trim($stateVal) == "WI" || UDF_trim($stateVal) == "KS")
		{
			if($st_inc_taxVal > $st_wages_tipsVal / 2)
			{
				$err_flag = 1 ;
				$$st1_with_held_err = 1;
				$$st_wages_tipsErr = 1;
				$$st_inc_taxVarErr = 1;
			}
		}
		
		if($st_wages_tipsVal > 0 && UDF_trim($stateVal) == "VA" && ($PassValidationInd != 1))
		{
			if(UDF_round($st_inc_taxVal) > UDF_round($st_wages_tipsVal / 4))
			{
				$err_flag = 1 ;
				$$st1_with_held_err = 1;
				$$st_wages_tipsErr = 1;
				$$st_inc_taxVarErr = 1;
			}
		}
		
		if($st_wages_tipsVal > 0 && UDF_trim($stateVal) == "IL" && ($PassValidationInd != 1))
		{
			if(UDF_round($st_inc_taxVal) > UDF_round($st_wages_tipsVal / 5))
			{
				$err_flag = 1 ;
				$$st1_with_held_err = 1;
				$$st_wages_tipsErr = 1;
				$$st_inc_taxVarErr = 1;
			}
		}
		
 		if(($stateVal != "") && (($stateVal == "OH") || ($stateVal == "IN")))
		{
			$StrStateChkWagesvalue = $stateVal."#". $st_employer_idVal."#". UDF_round($st_wages_tipsVal);
			$StrStateChkIncomevalue = $stateVal."#". $st_employer_idVal."#". UDF_round($st_inc_taxVal);
			
			if(!UDF_in_array($StrStateChkWagesvalue,$ArrStateValCombinationWages))
			{
				if($st_wages_tipsVal != 0)
				{
					$ArrStateValCombinationWages[$ArrCntWages] = $StrStateChkWagesvalue;
					$ArrCntWages++;
				}
			}
			else if(UDF_in_array($StrStateChkWagesvalue,$ArrStateValCombinationWages))
			{				
				$err_flag = 1;
				if($stateVal == "OH")
					$fed_OH_state_err_flag = 1;
				else if($stateVal == "IN")
					$fed_IN_state_err_flag = 1;
			}
			
			if(!UDF_in_array($StrStateChkIncomevalue,$ArrStateValCombinationIncome))
			{
				if($st_inc_taxVal != 0)
				{
					$ArrStateValCombinationIncome[$ArrCntIncome] = $StrStateChkIncomevalue;
					$ArrCntIncome++;
				}
			}
			else if(UDF_in_array($StrStateChkIncomevalue,$ArrStateValCombinationIncome))
			{				
				$err_flag = 1;
				if($stateVal == "OH")
					$fed_OH_state_err_flag = 1;
				else if($stateVal == "IN")
					$fed_IN_state_err_flag = 1;
			}
		}		
		
		if (($stateVal == "IN") && (UDF_round($st_local_wagesVal) < (UDF_round($st_local_inc_taxVal))))  
		{
			$err_flag = 1;
			$$st_local_wagesErr1 = 1;
		}		
		
		if($stateVal != "")
		{
			$StrStateChksamevalue = $stateVal."#". $st_employer_idVal."#". $st_wages_tipsVal."#". $st_inc_taxVal."#". $st_local_wagesVal."#". $st_local_inc_taxVal."#". $st_localityVal."#". $st_locality_txtVal;			
			
			if(!UDF_in_array($StrStateChksamevalue,$ArrStateValSameInfo))
			{
				if(($st_wages_tipsVal != 0) || ($st_inc_taxVal != 0) || ($st_local_wagesVal != 0) || ($st_local_inc_taxVal != 0))
				{
					$ArrStateValSameInfo[$ArrCntSameInfo] = $StrStateChksamevalue;
					$ArrCntSameInfo++;
				}
			}
			else if(UDF_in_array($StrStateChksamevalue,$ArrStateValSameInfo))
			{				
				$err_flag = 1;
				$fed_state_same_info_err_flag = 1;
				
			}			
		}
		
		if($$st1_with_held_err == 1)
		{
			$per1 = 0;
			
			if(UDF_trim($stateVal) == "IL" && $$st1_with_held_err == 1) 
			{
				$per1 = 20;
				$st1_with_held_pass_err = 1;
			}
			else if(UDF_trim($stateVal) == "VA" && $$st1_with_held_err == 1) 
			{
				$per1 = 25;
				$st1_with_held_pass_err = 1;
			}
			/*else if((UDF_trim($stateVal) == "MN" || UDF_trim($stateVal) == "NY" || UDF_trim($stateVal) == "SC" || UDF_trim($stateVal) == "NC" || UDF_trim($stateVal) == "WI" || UDF_trim($stateVal) == "KS") && $$st1_with_held_err == 1) 
			{
				$per1 = 50;	
				$st1_with_held_pass_err = 1;	
			}*/
			else if($$st1_with_held_err == 1)
			{
				$per1 = 50;
				$st1_with_held_pass_err = 1;	
			}
			
			if($per1 > 0)
			{
				$dup_warn_msg .=" <tr><td width=\"3%\" valign=\"top\"><b></b></td>";
				$dup_warn_msg .=" <td width=\"97%\" class=\"OLTBodyText\">";    
				$dup_warn_msg .="Your '$stateVal' income tax withheld cannot be greater than $per1% of your '$stateVal' wages .";
				$nv_dup_warn_msg .= "<br>Your '$stateVal' income tax withheld cannot be greater than $per1% of your '$stateVal' wages .";
				$dup_warn_msg .=" </td></tr>";
			}			
		}
				
	}
	if(($st_wages_tipsValTot > $wages_tips) && ($PassValidationIndStWags != 1))
	{
		$err_flag = 1 ;		
		$state_wageTot_err = 1;
	}
	include("olt_w2_state_validate.php"); //009
	
	$icnt=0;
	$AllowedArrayValuesbox14Cd = array();
	if($TotCountOfBox14Rows > 0)
	{
		$query_b14 	="select w2_Box14Code from ref_w2Box14Code where ";
		$query_b14 	.= "w2_Box14Code!=(?) order by w2_Box14Code"; db_sql_BuildParamArray('Not on list', "ref_w2Box14Code::w2_Box14Code");
		$result_b14 	= db_sql_query(array($query_b14), $_SQL_ParamsArray);
		$noOfRows_b14 	= db_num_rows(array($result_b14));
		if ($noOfRows_b14 > 0)
		{
			while($res_data_b14 = db_fetchrow(array($result_b14, DB_GETMODE_ASSOC)))
			{
				
				$box14_code	= UDF_strtoupper(UDF_trim($res_data_b14["w2_Box14Code"]));
				$AllowedArrayValuesbox14Cd[$icnt] = $box14_code;
												
				$icnt++;
			}
			
			$AllowedArrayValuesbox14Cd[$icnt] = "NOT ON LIST";
		}
		db_free_result(array($result_b14));
	}
	
	for($ictr=1; $ictr <= $TotCountOfBox14Rows; $ictr++)
	{
		$other14_typeVar 	= "other14_type".$ictr;
		$other14_amountVar 	= "other14_amount".$ictr;
		$other14_typeNewVar 	= "other14_typeNew".$ictr;
		
		$other14_typeVal 	= UDF_trim($$other14_typeVar);
		$other14_amountVal 	= UDF_trim($$other14_amountVar);
		$other14_typeNewVal 	= UDF_trim($$other14_typeNewVar);
		
		$other14_typeVal	=fmtvalue($other14_typeVal);
		$other14_amountVal	=fmtvalue($other14_amountVal);
		$other14_typeNewVal	=fmtvalue($other14_typeNewVal);
		$other14_typeNewVal	=fixtext($other14_typeNewVal);
		
		$other14_typeErr 	= "other14_type_err".$ictr;
		$other14_amountErr 	= "other14_amount_err".$ictr;
		$other14_typeNewErr 	= "other14_typeNew_err".$ictr;
		
		$$other14_typeErr 	= 0;
		$$other14_amountErr 	= 0;
		$$other14_typeNewErr 	= 0;
		
		$other14_typeNewVal=UDF_str_replace("#","" ,$other14_typeNewVal); 
		$other14_typeNewVal=UDF_str_replace("(","" ,$other14_typeNewVal); 
		$other14_typeNewVal=UDF_str_replace(")","" ,$other14_typeNewVal); 
		$other14_typeNewVal=UDF_str_replace("/","" ,$other14_typeNewVal); 
		$other14_typeNewVal=UDF_str_replace(".","" ,$other14_typeNewVal); 
		$other14_typeNewVal=UDF_str_replace("-","" ,$other14_typeNewVal); 
		$other14_typeNewVal=UDF_str_replace(","," " ,$other14_typeNewVal); 
		
		if(($other14_typeVal != "") && (!IsValidValue($other14_typeVal, $AllowedArrayValuesbox14Cd)))
		{
			$err_flag = 1;
			$other14_typeErr = 1;
		}
				
		if($NYStateRowCount > 0)
		{
			if(($other14_typeNewVal == "414" && $other14_typeVal == "NOT ON LIST"))
			{
				$other14_typeVal = "NY 414";
				$other14_typeNewVal = "";
			}
			else if(($other14_typeNewVal == "125" && $other14_typeVal == "NOT ON LIST"))
			{
				$other14_typeVal = "NY 125";
				$other14_typeNewVal = "";
			}
		}
		
		$other14_type_oldVar = "other14_type_old".$ictr;
		$other14_type_oldVal = $other14_typeVal;
		if(($other14_typeNewVal != "") && (($other14_typeVal == "") || ($other14_typeVal == "NOT ON LIST")))
			   $other14_typeVal = $other14_typeNewVal;
			   
		if(($other14_typeVal !="") && $other14_amountVal==0)
		{
			$err_flag=1;
			$$other14_amountErr= 1;
		}
		
		if(($other14_typeNewVal != "") && ($other14_typeNewVal != $other14_typeVal))
		{
			$err_flag=1;
			$$other14_typeNewErr=1;
		}
		
		if(($other14_amountVal > 0) && $other14_typeVal=="")
		{
			$err_flag=1;
			$$other14_typeErr=1;
		}
		
		if(($other14_amountVal !="") && (!isNumeric($other14_amountVal)))
		{
			$err_flag=1;
			$$other14_amountErr=1;
		}

		if(($other14_typeVal == "") || ($other14_typeVal == "NOT ON LIST"))
		{
			if(($other14_amountVal > 0) && UDF_trim($other14_typeNewVal)=="")
			{
				$err_flag=1;
				$$other14_typeNewErr=1;
			}
		}
	} 
	
	$AllowedArrayValuesbox14bCd = array();
	$AllowedArrayValuesbox14bCd[0] = "000";
	$jcnt=1;
	$query_b14b 	="select w2Box14b_code from ref_w2Box14b_Code";
	$result_b14b 	= db_sql_query(array($query_b14b));
	$noOfRows_b14b 	= db_num_rows(array($result_b14b));
	if ($noOfRows_b14b > 0)
	{
		while($res_data_b14b = db_fetchrow(array($result_b14b, DB_GETMODE_ASSOC)))
		{
			$box14b_code	= UDF_strtoupper(UDF_trim($res_data_b14b["w2Box14b_code"]));
			$AllowedArrayValuesbox14bCd[$jcnt] = $box14b_code;
											
			$jcnt++;
		}
	}
	db_free_result(array($result_b14b));
	
	if(($w2Box14b_code1 != "") && (!IsValidValue($w2Box14b_code1, $AllowedArrayValuesbox14bCd)))
	{
		$err_flag = 1;
		$w2Box14b_code1_Err = 1;
	}
	
	if(($w2Box14b_code2 != "") && (!IsValidValue($w2Box14b_code2, $AllowedArrayValuesbox14bCd)))
	{
		$err_flag = 1;
		$w2Box14b_code2_Err = 1;
	}
	
	/*if(($non_standard_W2_ind == "1") && ($PassValidationIndNonStand != 1))
	{
		$err_flag = 1;
		$nonstand_w2_ind_err_flag = 1;

	}*/

//if(($filing_status == "separate") && ($f8958_not_inc_rows > 0)  && ($F8958_Eligible_Questions == "true"))
//	$report_to_frm8958_ind = $report_to_frm8958_ind;
//else
	$report_to_frm8958_ind = 0;

	if(UDF_trim($OLTPRO_masterID) == '')
	{	
		$form_name = "W2";
		$cmn_payer_combo 	= "employer_tin_w2";
		$cmn_payer_name1 	= "employer_name";
		$cmn_payer_name2 	= "employer_name2";
		if(($non_standard_W2_ind == 1) && (UDF_trim($employer_id_num) == ""))
			${$cmn_payerin."Skip"} = 1;
		else
			$cmn_payerin 	= "employer_id_num";	
		$cmn_account_nbr 	= "control_num";
		include("../oltproc/olt_payer_common_val.php");
		
		if($err_flag!=1)
		{	
				$olt_payer_name 	= fmtvalue($employer_name);
				$olt_payer_name2	= fmtvalue($employer_name2);
				$olt_payerin		= UDF_trim($employer_id_num);
				$olt_payer_account_nbr	= UDF_trim($control_num);
				$olt_payer_frgn_addrs_ind = (int)UDF_trim($employer_foreign_add_ind);
				if($employer_foreign_add_ind == 1)
				{
					$olt_payer_frgn_address	=FormatAddress($employer_foreign_address);
					$olt_payer_frgn_address2 = "";
					$olt_payer_frgn_city	= fmtvalue($employer_foreign_city);
					$olt_payer_frgn_state	= fmtvalue($employer_foreign_state);
					$olt_payer_frgn_country	= fmtvalue($employer_foreign_country_code);
					$olt_payer_frgn_zip	= fmtvalue($employer_foreign_zip);
				}
				else
				{	
					$olt_payer_us_address 	= FormatAddress($employer_address);
					$olt_payer_us_address2  = "";
					$olt_payer_us_city 	= FormatCity($employer_city);
					$olt_payer_us_state 	= fmtvalue($employer_state);
					$olt_payer_us_zip 	= fmtvalue($employer_zip);
					$olt_payer_us_zip_ext   = fmtvalue($employer_zip_ext);
				}
			
			if(($non_standard_W2_ind == 1) && ((UDF_trim($employer_id_num) == "") || (UDF_strlen($employer_id_num) != 9)))
			{
			}
			else
			{			
				if($employer_tin_w2 == "Add New")
				{
					$action = "Add New";										
				$called_frm_InputPage = 1;
				include("../oltproc/olt_get_payer_details.php");
			}
			else
			{
				$action = "";		
				$olt_payer_details_id = $employer_tin_w2;
				$called_frm_InputPage = 1;
				include("../oltproc/olt_get_payer_details.php"); 
				
					/*$employer_name 		= $olt_payer_name;
				$employer_name2		= $olt_payer_name2;
				$employer_id_num	= $olt_payerin;
				$control_num		= $olt_payer_account_nbr;
				$employer_foreign_add_ind 	= $olt_payer_frgn_addrs_ind;
				
				if($employer_foreign_add_ind == 1)
				{
					$employer_foreign_address	= $olt_payer_frgn_address; 		
					$employer_foreign_city		= $olt_payer_frgn_city;
					$employer_foreign_state		= $olt_payer_frgn_state;
					$employer_foreign_country_code	= $olt_payer_frgn_country;
					$employer_foreign_zip		= $olt_payer_frgn_zip;
				}
				else
				{
					$employer_address 		= $olt_payer_us_address;
					$employer_city 			= $olt_payer_us_city;
					$employer_state 		= $olt_payer_us_state;
					$employer_zip 			= $olt_payer_us_zip;
					$employer_zip_ext 		= $olt_payer_us_zip_ext;
					}*/
				}
			}
		}
	}
	else
	{
		if($control_num != "") 
		{
			if(!isAlphaNumeric($control_num))
		  	{
		   		$err_flag=1;
		   		$ctrl_err_flag=1;
		  	} 
		}
		
		if($non_standard_W2_ind == 1)
		{ 
			if(UDF_strlen($employer_id_num) > 0)
			{
				if ((UDF_strlen($employer_id_num) != 9)  || (!isNumeric($employer_id_num)) || ($employer_id_num == "000000000"))
				{
				  $err_flag=1;
				  $ein_err_flag=1;
				} 
				else if(!IsValidEIN($employer_id_num))
				{
				   $err_flag=1;
				   $ein2_err_flag=1;	
				}
			}
		}
		else
		{
			if((UDF_strlen($employer_id_num) != 9)  || (!isNumeric($employer_id_num)) || ($employer_id_num == "000000000"))	
			{
			  $err_flag=1;
			  $ein_err_flag=1;
			} 
			else if(!IsValidEIN($employer_id_num))
			{
			   $err_flag=1;
			   $ein2_err_flag=1;	
			}
		}
		
		if (($employer_name =="") || (UDF_strlen($employer_name) < 2) || (!isAlphaNumericnumsp($employer_name)))
		{
		  $err_flag=1;
		  $ename_err_flag=1;
		}
		if (($employer_name2 != "") && (!isAlphaNumericnumsp($employer_name2)))
		{
		  $err_flag=1;
		  $ename2_err_flag=1;
		}
	}
if(($Box12CodeIICnt > 0)&&($PassValidationIndIIVal != 1) && ($PassValidationIndIIIVal != 1))
{
	$err_flag=1;
	$Box12II_err_flag=1;
}

if($err_flag != 1)
{
	if(($medicare_wages_tips <= 184500) && ($soc_sec_tips > 0))	// && ($PassValidationIndIIIVal != 1)
	{
		//$err_flag=1;
		$sch1A_partII_entry_err_flag=1;
	}
}
			
if($err_flag!=1)
{     
	/*if(($show_city_combo_ind == 1)&&(UDF_in_array($state1, $aloc_state_array)))
	{
		if($st1_locality == "NOL")
		{
			$st1_locality = $st1_locality_txt;
		}
	}
	if(($show_city_combo_ind == 1)&&(UDF_in_array($state2, $aloc_state_array)))
	{	
		if($st2_locality == "NOL")
		{
			$st2_locality = $st2_locality_txt;
		}
	}
	if(($show_city_combo_ind == 1)&&(UDF_in_array($state3, $aloc_state_array)))
	{
		if($st3_locality == "NOL")
		{
			$st3_locality = $st3_locality_txt;
		}
	}
	if(($show_city_combo_ind == 1)&&(UDF_in_array($state4, $aloc_state_array)))
	{	
		if($st4_locality == "NOL")
		{
			$st4_locality = $st4_locality_txt;
		}
	}*/
	
	$invalid="";
	$employer_id_num 	= $employer_id_num;
	$soc_sec_tips		= (float)$soc_sec_tips;
	$allocated_tips		= (float)$allocated_tips;
	$wages_tips 		= (float)$wages_tips;
	$fed_inc_tax_withheld 	= (float)$fed_inc_tax_withheld;
	$soc_sec_wages 		= (float)$soc_sec_wages;
	$soc_sec_tax_withheld 	= (float)$soc_sec_tax_withheld;
	$medicare_wages_tips 	= (float)$medicare_wages_tips;
	$medicare_tax_withheld 	= (float)$medicare_tax_withheld;
	$soc_sec_tips 		= (float)$soc_sec_tips;
	$allocated_tips 	= (float)$allocated_tips;
	//$adv_eic_payment 	= (float)$adv_eic_payment; //1040 Instruction
	$dep_care_benefits 	= (float)$dep_care_benefits;
	$nonqualified_plans 	= (float)$nonqualified_plans;
	/*$box12a_amount 		= (float)$box12a_amount;
	$box12b_amount 		= (float)$box12b_amount;
	$box12c_amount 		= (float)$box12c_amount;
	$box12d_amount 		= (float)$box12d_amount;
	$box12e_amount 		= (float)$box12e_amount;
	$box12f_amount 		= (float)$box12f_amount;*/
	$other1_amount 		= (float)$other1_amount;
	$other2_amount 		= (float)$other2_amount;
	$other3_amount 		= (float)$other3_amount;
	$other4_amount 		= (float)$other4_amount;
	/*$st1_wages_tips 	= (float)$st1_wages_tips;
	$st1_inc_tax 		= (float)$st1_inc_tax;
	$st1_local_wages 	= (float)$st1_local_wages;
	$st1_local_inc_tax 	= (float)$st1_local_inc_tax;
	$st2_wages_tips 	= (float)$st2_wages_tips;
	$st2_inc_tax 		= (float)$st2_inc_tax;
	$st2_local_wages 	= (float)$st2_local_wages;
	$st2_local_inc_tax 	= (float)$st2_local_inc_tax;*/
	$employer_address 	= FormatAddress($employer_address);
	$emp_address 	        = FormatAddress($emp_address);
	$emp_address2 	        = FormatAddress($emp_address2);
	//$st2_local_inc_tax	= UDF_round($st2_local_inc_tax);
	/*$st1_local_wages	= UDF_round($st1_local_wages);
	$st1_wages_tips		= UDF_round($st1_wages_tips);
	$st2_wages_tips		= UDF_round($st2_wages_tips);*/
	$wages_tips		= UDF_round($wages_tips);
	$fed_inc_tax_withheld	= UDF_round($fed_inc_tax_withheld); 
	$other1_amount		= UDF_round($other1_amount); 
	$other2_amount		= UDF_round($other2_amount); 
	$other3_amount		= UDF_round($other3_amount); 
	$other4_amount		= UDF_round($other4_amount); 
	//$st1_local_inc_tax 	= UDF_round($st1_local_inc_tax);
	//$st2_local_inc_tax 	= UDF_round($st2_local_inc_tax);
	//$st1_inc_tax 		= UDF_round($st1_inc_tax);
	//$st2_inc_tax 		= UDF_round($st2_inc_tax);
	
	//$other1_type 		= UDF_strtoupper($other1_type);
	//$other2_type 		= UDF_strtoupper($other2_type);
	$autocalc_ind		= UDF_round($autocalc_ind);


	/*$st3_wages_tips 	= (float)$st3_wages_tips;
	$st3_inc_tax 		= (float)$st3_inc_tax;
	$st3_local_wages 	= (float)$st3_local_wages;
	$st3_local_inc_tax 	= (float)$st3_local_inc_tax;

	$st4_wages_tips 	= (float)$st4_wages_tips;
	$st4_inc_tax 		= (float)$st4_inc_tax;
	$st4_local_wages 	= (float)$st4_local_wages;
	$st4_local_inc_tax 	= (float)$st4_local_inc_tax;*/
	$emp_city		= UDF_substr($emp_city,0,50);
	
	if(($employer_state==".")&&($form1040_ind_add != "1040NR"))//**008
	{
	 	$employer_zip="";
	 	$employer_zip_ext="";
	}
	if($emp_state==".") //**008
	{		
		$emp_zip="";
		$emp_zip_ext="";
	}	
	if($whose_w2 == "0")
		$pri_or_spouse = "P";
	else if($whose_w2 == "1")
		$pri_or_spouse = "S";
  
        if($ITIN_User_ind == 1)
	{
		if((IsValidITIN($w2ssn)) || ($mstrW2W7AppliedInd == "1"))		
			$w2ssn = fmtvalue($TIN);
	}

	if(UDF_strlen($employer_name) > 60)
		$employer_name = UDF_substr(UDF_trim($employer_name), 0, 60);

	if(UDF_strlen($employer_name2) > 75)
		$employer_name2 = UDF_substr(UDF_trim($employer_name2), 0, 75);
	
	if(($form1040_ind_add == "1040NR" || $w2ssn == "400001047") && ($emp_state=="."))
	{
		if($address1 != "")
			$emp_address = UDF_trim($address1);
		if($address2 != "")
			$emp_address2 = UDF_trim($address2);	
		
		if($city != "")
			$emp_city = UDF_trim($city);
		$emp_foreign_state="";	
		if($foreign_state != "")
			$emp_foreign_state = UDF_trim($foreign_state);
			
		if($foreign_country_code != "")
			$emp_foreign_country_cd = UDF_trim($foreign_country_code);
		if($zip != "")
			$emp_zip = UDF_trim($zip);			
	}
	
	if(UDF_strlen($control_num) > 14)
	{
		$control_num = UDF_substr($control_num, 0, 14);
	}
	if(UDF_strlen($emp_apt_for) > 15)
	{
		$emp_apt_for = UDF_substr($emp_apt_for, 0, 15);
	}
	if(UDF_strlen($emp_apt) > 15)
	{
		$emp_apt = UDF_substr($emp_apt, 0, 15);
	}

if ($step1 == "addw2")
{
	$query_cust ="select ssn,relation from customer where ";
	$query_cust .= "qt_user_id=(?) "; db_sql_BuildParamArray($qt_user_id, "customer::qt_user_id");
	$result_cust = db_sql_query(array($query_cust), $_SQL_ParamsArray);	
	while($res_data=db_fetchrow(array($result_cust, DB_GETMODE_ASSOC)))
	{
		$relation	= $res_data["relation"];
	
		if ($whose_w2 == 0)
		{
			if($relation== "P")
				$ssn	= $res_data["ssn"];
		}
		else if (($whose_w2 == 1) && ($filing_status == "joint"))
		{
			if($relation== "S")
				$ssn	= $res_data["ssn"];
		}
	}
	db_free_result(array($result_cust));	
	

	$_SQL_DataArray[] = array( "key"=> "qt_user_id", "val"=>$qt_user_id, "table"=>"w2");
	$_SQL_DataArray[] = array( "key"=> "whose_w2", "val"=>$whose_w2, "table"=>"w2");
	$_SQL_DataArray[] = array( "key"=> "ssn", "val"=>$ssn, "table"=>"w2");
	$_SQL_DataArray[] = array( "key"=> "soc_sec_wages", "val"=>'0', "table"=>"w2");
	$out_sqlparm = db_sql_paramformat($_SQL_DataArray);

	$insert ="insert into w2 (".$out_sqlparm['_SQL_FieldClause'].") values (".$out_sqlparm['_SQL_ValueClause'].")";
	$result = db_sql_query(array($insert), $_SQL_ParamsArray);
     	db_free_result(array($result));
     	
     	$query_w2 ="select max(w2_ID)'id' from w2 where ";
     	$query_w2 .= "qt_user_id=(?) "; db_sql_BuildParamArray($qt_user_id, "w2::qt_user_id");
	$result_w2 = db_sql_query(array($query_w2), $_SQL_ParamsArray);
        
        $res_data = db_fetchrow(array($result_w2, DB_GETMODE_ASSOC));
        $id 	= UDF_trim($res_data["id"]);  
        db_free_result(array($result_w2));
	
	$action = "Wages salaries tips etc.. added";
	$which_form = "Form W-2";
	include("../oltproc/olt_record_action_all.php");
	
	$step1 = "editw2";
}

	if ($step1 == "editw2") 
	{		    
		$_SQL_DataArray[] = array( "key"=> "whose_w2", "val"=>$whose_w2, "table"=>"w2");		    
		$_SQL_DataArray[] = array( "key"=> "ssn", "val"=>$w2ssn, "table"=>"w2");		    
		$_SQL_DataArray[] = array( "key"=> "disability_amount", "val"=>(float)$disability_amount, "table"=>"w2");		    
		$_SQL_DataArray[] = array( "key"=> "control_num", "val"=>$control_num, "table"=>"w2");		    
		$_SQL_DataArray[] = array( "key"=> "employer_id_num", "val"=>$employer_id_num, "table"=>"w2");		    
		$_SQL_DataArray[] = array( "key"=> "report_to_frm8958_ind", "val"=>(int)$report_to_frm8958_ind, "table"=>"w2");		    
		$_SQL_DataArray[] = array( "key"=> "employer_name", "val"=>$employer_name, "table"=>"w2");		    
		$_SQL_DataArray[] = array( "key"=> "employer_name2", "val"=>$employer_name2, "table"=>"w2");		    
		$_SQL_DataArray[] = array( "key"=> "employer_foreign_add_ind", "val"=>(int)$employer_foreign_add_ind, "table"=>"w2");		    
		if($employer_foreign_add_ind=="1")
		{
			$_SQL_DataArray[] = array( "key"=> "employer_address", "val"=>'', "table"=>"w2");		    
			$_SQL_DataArray[] = array( "key"=> "employer_city", "val"=>'', "table"=>"w2");		    
			$_SQL_DataArray[] = array( "key"=> "employer_state", "val"=>'', "table"=>"w2");		    
			$_SQL_DataArray[] = array( "key"=> "employer_zip", "val"=>'', "table"=>"w2");		    
			$_SQL_DataArray[] = array( "key"=> "employer_zip_ext", "val"=>'', "table"=>"w2");		    
			$_SQL_DataArray[] = array( "key"=> "employer_foreign_address", "val"=>$employer_foreign_address, "table"=>"w2");		    
			$_SQL_DataArray[] = array( "key"=> "employer_foreign_city", "val"=>$employer_foreign_city, "table"=>"w2");		    
			$_SQL_DataArray[] = array( "key"=> "employer_foreign_state", "val"=>$employer_foreign_state, "table"=>"w2");		    
			$_SQL_DataArray[] = array( "key"=> "employer_foreign_country_code", "val"=>$employer_foreign_country_code, "table"=>"w2");		    
			$_SQL_DataArray[] = array( "key"=> "employer_foreign_zip", "val"=>$employer_foreign_zip, "table"=>"w2");		    
		}
		else
		{
			$_SQL_DataArray[] = array( "key"=> "employer_address", "val"=>$employer_address, "table"=>"w2");		    
			$_SQL_DataArray[] = array( "key"=> "employer_city", "val"=>$employer_city, "table"=>"w2");		    
			$_SQL_DataArray[] = array( "key"=> "employer_state", "val"=>$employer_state, "table"=>"w2");		    
			$_SQL_DataArray[] = array( "key"=> "employer_zip", "val"=>$employer_zip, "table"=>"w2");		    
			$_SQL_DataArray[] = array( "key"=> "employer_zip_ext", "val"=>$employer_zip_ext, "table"=>"w2");		    
			$_SQL_DataArray[] = array( "key"=> "employer_foreign_address", "val"=>'', "table"=>"w2");		    
			$_SQL_DataArray[] = array( "key"=> "employer_foreign_city", "val"=>'', "table"=>"w2");		    
			$_SQL_DataArray[] = array( "key"=> "employer_foreign_state", "val"=>'', "table"=>"w2");		    
			$_SQL_DataArray[] = array( "key"=> "employer_foreign_country_code", "val"=>'', "table"=>"w2");		    
			$_SQL_DataArray[] = array( "key"=> "employer_foreign_zip", "val"=>'', "table"=>"w2");		    
		}
		$_SQL_DataArray[] = array( "key"=> "emp_first_name", "val"=>$emp_first_name, "table"=>"w2");		    
		$_SQL_DataArray[] = array( "key"=> "emp_mid_initial", "val"=>$emp_mid_initial, "table"=>"w2");		    
		$_SQL_DataArray[] = array( "key"=> "emp_last_name", "val"=>$emp_last_name, "table"=>"w2");		    
		    
		/*if(($form1040_ind_add == "1040NR" || $w2ssn == "400001047") && ($emp_state=="."))
		{
		$_SQL_DataArray[] = array( "key"=> "emp_for_add_ind", "val"=>'1', "table"=>"w2");		    
		$_SQL_DataArray[] = array( "key"=> "emp_address", "val"=>$emp_address, "table"=>"w2");		    
		$_SQL_DataArray[] = array( "key"=> "emp_address2", "val"=>$emp_address2, "table"=>"w2");		    
		$_SQL_DataArray[] = array( "key"=> "emp_city", "val"=>$emp_city, "table"=>"w2");		    
		$_SQL_DataArray[] = array( "key"=> "emp_state", "val"=>$emp_foreign_state, "table"=>"w2");		    
		$_SQL_DataArray[] = array( "key"=> "emp_foreign_country_cd", "val"=>$emp_foreign_country_cd, "table"=>"w2");		    
		$_SQL_DataArray[] = array( "key"=> "emp_zip", "val"=>$emp_zip, "table"=>"w2");		    
		$_SQL_DataArray[] = array( "key"=> "emp_zip_ext", "val"=>'', "table"=>"w2");		    
		}
		else
		{*/
		$_SQL_DataArray[] = array( "key"=> "emp_for_add_ind", "val"=>(int)$emp_for_add_ind, "table"=>"w2");		    
		if($emp_for_add_ind=="1")
		{
			$emp_for_state = UDF_trim(UDF_substr($emp_for_state, 0, 17));
			
			$_SQL_DataArray[] = array( "key"=> "emp_address", "val"=>'', "table"=>"w2");		    
			$_SQL_DataArray[] = array( "key"=> "emp_address2", "val"=>'', "table"=>"w2");		    
			$_SQL_DataArray[] = array( "key"=> "emp_city", "val"=>'', "table"=>"w2");		    
			$_SQL_DataArray[] = array( "key"=> "emp_state", "val"=>'', "table"=>"w2");		    
			$_SQL_DataArray[] = array( "key"=> "emp_zip", "val"=>'', "table"=>"w2");		    
			$_SQL_DataArray[] = array( "key"=> "emp_zip_ext", "val"=>'', "table"=>"w2");		    
			$_SQL_DataArray[] = array( "key"=> "emp_for_address", "val"=>$emp_for_address, "table"=>"w2");		    
			$_SQL_DataArray[] = array( "key"=> "emp_for_address2", "val"=>$emp_for_address2, "table"=>"w2");		    
			$_SQL_DataArray[] = array( "key"=> "emp_for_city", "val"=>$emp_for_city, "table"=>"w2");		    
			$_SQL_DataArray[] = array( "key"=> "emp_for_state", "val"=>$emp_for_state, "table"=>"w2");		    
			$_SQL_DataArray[] = array( "key"=> "emp_foreign_country_cd", "val"=>$emp_foreign_country_cd, "table"=>"w2");		    
			$_SQL_DataArray[] = array( "key"=> "emp_for_zip", "val"=>$emp_for_zip, "table"=>"w2");		    
			$_SQL_DataArray[] = array( "key"=> "apt_no", "val"=>$emp_apt_for, "table"=>"w2");		    
		}
		else
		{
			$_SQL_DataArray[] = array( "key"=> "emp_address", "val"=>$emp_address, "table"=>"w2");		    
			$_SQL_DataArray[] = array( "key"=> "emp_address2", "val"=>$emp_address2, "table"=>"w2");		    
			$_SQL_DataArray[] = array( "key"=> "emp_city", "val"=>$emp_city, "table"=>"w2");		    
			$_SQL_DataArray[] = array( "key"=> "emp_state", "val"=>$emp_state, "table"=>"w2");		    
			$_SQL_DataArray[] = array( "key"=> "emp_zip", "val"=>$emp_zip, "table"=>"w2");		    
			$_SQL_DataArray[] = array( "key"=> "emp_zip_ext", "val"=>$emp_zip_ext, "table"=>"w2");		    
			$_SQL_DataArray[] = array( "key"=> "emp_for_address", "val"=>'', "table"=>"w2");		    
			$_SQL_DataArray[] = array( "key"=> "emp_for_address2", "val"=>'', "table"=>"w2");		    
			$_SQL_DataArray[] = array( "key"=> "emp_for_city", "val"=>'', "table"=>"w2");		    
			$_SQL_DataArray[] = array( "key"=> "emp_for_state", "val"=>'', "table"=>"w2");		    
			$_SQL_DataArray[] = array( "key"=> "emp_foreign_country_cd", "val"=>'', "table"=>"w2");		    
			$_SQL_DataArray[] = array( "key"=> "emp_for_zip", "val"=>'', "table"=>"w2");		    
			$_SQL_DataArray[] = array( "key"=> "apt_no", "val"=>$emp_apt, "table"=>"w2");		    
		}
		
		//}
		$_SQL_DataArray[] = array( "key"=> "wages_tips", "val"=>(float)$wages_tips, "table"=>"w2");		    
		$_SQL_DataArray[] = array( "key"=> "fed_inc_tax_withheld", "val"=>(float)$fed_inc_tax_withheld, "table"=>"w2");		    
		$_SQL_DataArray[] = array( "key"=> "soc_sec_wages", "val"=>(float)$soc_sec_wages, "table"=>"w2");		    
		$_SQL_DataArray[] = array( "key"=> "soc_sec_tax_withheld", "val"=>(float)$soc_sec_tax_withheld, "table"=>"w2");		    
		$_SQL_DataArray[] = array( "key"=> "medicare_wages_tips", "val"=>(float)$medicare_wages_tips, "table"=>"w2");		    
		$_SQL_DataArray[] = array( "key"=> "medicare_tax_withheld", "val"=>(float)$medicare_tax_withheld, "table"=>"w2");		    
		    
		$_SQL_DataArray[] = array( "key"=> "soc_sec_tips", "val"=>(float)$soc_sec_tips, "table"=>"w2");		    
		$_SQL_DataArray[] = array( "key"=> "allocated_tips", "val"=>(float)$allocated_tips, "table"=>"w2");		    
		//$_SQL_DataArray[] = array( "key"=> "adv_eic_payment", "val"=>(float)$adv_eic_payment, "table"=>"w2");
		$_SQL_DataArray[] = array( "key"=> "dep_care_benefits", "val"=>(float)$dep_care_benefits, "table"=>"w2");		    
		$_SQL_DataArray[] = array( "key"=> "nonqualified_plans", "val"=>(float)$nonqualified_plans, "table"=>"w2");
		/*$_SQL_DataArray[] = array( "key"=> "box12a_code", "val"=>$box12a_code, "table"=>"w2");		    
		$_SQL_DataArray[] = array( "key"=> "box12a_amount", "val"=>$box12a_amount, "table"=>"w2");		    
		$_SQL_DataArray[] = array( "key"=> "box12b_code", "val"=>$box12b_code, "table"=>"w2");		    
		$_SQL_DataArray[] = array( "key"=> "box12b_amount", "val"=>$box12b_amount, "table"=>"w2");		    
		$_SQL_DataArray[] = array( "key"=> "box12c_code", "val"=>$box12c_code, "table"=>"w2");		    
		$_SQL_DataArray[] = array( "key"=> "box12c_amount", "val"=>$box12c_amount, "table"=>"w2");		    
		$_SQL_DataArray[] = array( "key"=> "box12d_code", "val"=>$box12d_code, "table"=>"w2");		    
		$_SQL_DataArray[] = array( "key"=> "box12d_amount", "val"=>$box12d_amount, "table"=>"w2");		    
		$_SQL_DataArray[] = array( "key"=> "box12e_code", "val"=>$box12e_code, "table"=>"w2");		    
		$_SQL_DataArray[] = array( "key"=> "box12e_amount", "val"=>$box12e_amount, "table"=>"w2");		    
		$_SQL_DataArray[] = array( "key"=> "box12f_code", "val"=>$box12f_code, "table"=>"w2");		    
		$_SQL_DataArray[] = array( "key"=> "box12f_amount", "val"=>$box12f_amount, "table"=>"w2");*/
		$_SQL_DataArray[] = array( "key"=> "statutory_emp", "val"=>$statutory_emp, "table"=>"w2");		    
		$_SQL_DataArray[] = array( "key"=> "retirement_plan", "val"=>$retirement_plan, "table"=>"w2");		    
		$_SQL_DataArray[] = array( "key"=> "third_party_sick_pay", "val"=>$third_party_sick_pay, "table"=>"w2");		    
		/*$_SQL_DataArray[] = array( "key"=> "other1_type", "val"=>$other1_type, "table"=>"w2");		    
		$_SQL_DataArray[] = array( "key"=> "other1_amount", "val"=>$other1_amount, "table"=>"w2");		    
		$_SQL_DataArray[] = array( "key"=> "other2_type", "val"=>$other2_type, "table"=>"w2");		    
		$_SQL_DataArray[] = array( "key"=> "other2_amount", "val"=>$other2_amount, "table"=>"w2");		    
		$_SQL_DataArray[] = array( "key"=> "other3_type", "val"=>$other3_type, "table"=>"w2");		    
		$_SQL_DataArray[] = array( "key"=> "other3_amount", "val"=>$other3_amount, "table"=>"w2");		    
		$_SQL_DataArray[] = array( "key"=> "other4_type", "val"=>$other4_type, "table"=>"w2");		    
		$_SQL_DataArray[] = array( "key"=> "other4_amount", "val"=>$other4_amount, "table"=>"w2");		    
				    
		$_SQL_DataArray[] = array( "key"=> "box12a_year", "val"=>$box12a_year, "table"=>"w2");		    
		$_SQL_DataArray[] = array( "key"=> "box12b_year", "val"=>$box12b_year, "table"=>"w2");		    
		$_SQL_DataArray[] = array( "key"=> "box12c_year", "val"=>$box12c_year, "table"=>"w2");		    
		$_SQL_DataArray[] = array( "key"=> "box12d_year", "val"=>$box12d_year, "table"=>"w2");		    
		$_SQL_DataArray[] = array( "key"=> "box12e_year", "val"=>$box12e_year, "table"=>"w2");		    
		$_SQL_DataArray[] = array( "key"=> "box12f_year", "val"=>$box12f_year, "table"=>"w2");		    
			
		$_SQL_DataArray[] = array( "key"=> "state1", "val"=>$state1, "table"=>"w2");		    
		$_SQL_DataArray[] = array( "key"=> "st1_employer_id", "val"=>$st1_employer_id, "table"=>"w2");		    
		$_SQL_DataArray[] = array( "key"=> "st1_wages_tips", "val"=>$st1_wages_tips, "table"=>"w2");		    
		$_SQL_DataArray[] = array( "key"=> "st1_inc_tax", "val"=>$st1_inc_tax, "table"=>"w2");		    
		$_SQL_DataArray[] = array( "key"=> "st1_local_wages", "val"=>$st1_local_wages, "table"=>"w2");		    
		$_SQL_DataArray[] = array( "key"=> "st1_local_inc_tax", "val"=>$st1_local_inc_tax, "table"=>"w2");		    
		$_SQL_DataArray[] = array( "key"=> "st1_locality", "val"=>$st1_locality, "table"=>"w2");		    
			
		$_SQL_DataArray[] = array( "key"=> "state2", "val"=>$state2, "table"=>"w2");		    
		$_SQL_DataArray[] = array( "key"=> "st2_employer_id", "val"=>$st2_employer_id, "table"=>"w2");		    
		$_SQL_DataArray[] = array( "key"=> "st2_wages_tips", "val"=>$st2_wages_tips, "table"=>"w2");		    
		$_SQL_DataArray[] = array( "key"=> "st2_inc_tax", "val"=>$st2_inc_tax, "table"=>"w2");		    
		$_SQL_DataArray[] = array( "key"=> "st2_local_wages", "val"=>$st2_local_wages, "table"=>"w2");		    
		$_SQL_DataArray[] = array( "key"=> "st2_local_inc_tax", "val"=>$st2_local_inc_tax, "table"=>"w2");		    
		$_SQL_DataArray[] = array( "key"=> "st2_locality", "val"=>$st2_locality, "table"=>"w2");		    
		
		$_SQL_DataArray[] = array( "key"=> "state3", "val"=>$state3, "table"=>"w2");		    
		$_SQL_DataArray[] = array( "key"=> "st3_employer_id", "val"=>$st3_employer_id, "table"=>"w2");		    
		$_SQL_DataArray[] = array( "key"=> "st3_wages_tips", "val"=>$st3_wages_tips, "table"=>"w2");		    
		$_SQL_DataArray[] = array( "key"=> "st3_inc_tax", "val"=>$st3_inc_tax, "table"=>"w2");		    
		$_SQL_DataArray[] = array( "key"=> "st3_local_wages", "val"=>$st3_local_wages, "table"=>"w2");		    
		$_SQL_DataArray[] = array( "key"=> "st3_local_inc_tax", "val"=>$st3_local_inc_tax, "table"=>"w2");		    
		$_SQL_DataArray[] = array( "key"=> "st3_locality", "val"=>$st3_locality, "table"=>"w2");		    
		
		$_SQL_DataArray[] = array( "key"=> "state4", "val"=>$state4, "table"=>"w2");		    
		$_SQL_DataArray[] = array( "key"=> "st4_employer_id", "val"=>$st4_employer_id, "table"=>"w2");		    
		$_SQL_DataArray[] = array( "key"=> "st4_wages_tips", "val"=>$st4_wages_tips, "table"=>"w2");		    
		$_SQL_DataArray[] = array( "key"=> "st4_inc_tax", "val"=>$st4_inc_tax, "table"=>"w2");		    
		$_SQL_DataArray[] = array( "key"=> "st4_local_wages", "val"=>$st4_local_wages, "table"=>"w2");		    
		$_SQL_DataArray[] = array( "key"=> "st4_local_inc_tax", "val"=>$st4_local_inc_tax, "table"=>"w2");		    
		$_SQL_DataArray[] = array( "key"=> "st4_locality", "val"=>$st4_locality, "table"=>"w2");*/
		    
		$_SQL_DataArray[] = array( "key"=> "agent_for_employer_ind", "val"=>(int)$agent_for_employer_ind, "table"=>"w2");		    
		$_SQL_DataArray[] = array( "key"=> "non_standard_W2_ind", "val"=>(int)$non_standard_W2_ind, "table"=>"w2");		    
				    
		$_SQL_DataArray[] = array( "key"=> "w2_military_ind", "val"=>(int)$w2_military_ind, "table"=>"w2");		    
		$_SQL_DataArray[] = array( "key"=> "w2_clergy_ind", "val"=>(int)$w2_clergy_ind, "table"=>"w2");		    
		$_SQL_DataArray[] = array( "key"=> "w2_church_emp_ind", "val"=>(int)$w2_church_emp_ind, "table"=>"w2");		    
		$_SQL_DataArray[] = array( "key"=> "w2_care_provider_ind", "val"=>(int)$w2_care_provider_ind, "table"=>"w2");		    
		$_SQL_DataArray[] = array( "key"=> "w2_scorp_2perc_share_ind", "val"=>(int)$w2_scorp_2perc_share_ind, "table"=>"w2");		    
		$_SQL_DataArray[] = array( "key"=> "w2c_ind", "val"=>(int)$w2c_ind, "table"=>"w2");		    
		$_SQL_DataArray[] = array( "key"=> "autocalc_ind", "val"=>(int)$autocalc_ind, "table"=>"w2");		    
		    
		if($w2_scorp_2perc_share_ind == "0")	//&& $w2_clergy_ind == "0"
		{
			$_SQL_DataArray[] = array( "key"=> "W2self_health_ind", "val"=>'0', "table"=>"w2");		    
			$_SQL_DataArray[] = array( "key"=> "W2_ACA_1095A_markpl_ind", "val"=>'', "table"=>"w2");		    
			$_SQL_DataArray[] = array( "key"=> "W2tot_payments", "val"=>'0', "table"=>"w2");		    
			$_SQL_DataArray[] = array( "key"=> "W2p974_specified_premium", "val"=>'0', "table"=>"w2");
			$_SQL_DataArray[] = array( "key"=> "W2qual_long_care", "val"=>'0', "table"=>"w2");		    
			$_SQL_DataArray[] = array( "key"=> "W2qual_long_care_prsp", "val"=>'0', "table"=>"w2");		    
			$_SQL_DataArray[] = array( "key"=> "qual_long_care_dep_ind", "val"=>'0', "table"=>"w2");
			$_SQL_DataArray[] = array( "key"=> "W2p974_specified_month", "val"=>'0', "table"=>"w2");		    
			$_SQL_DataArray[] = array( "key"=> "W2p974_healthplan_month", "val"=>'0', "table"=>"w2");		    
			$_SQL_DataArray[] = array( "key"=> "W2p974_APTC_attr_specifid", "val"=>'0', "table"=>"w2");
			$_SQL_DataArray[] = array( "key"=> "W2_hlth_ins_complte_ind", "val"=>'0', "table"=>"w2");		    
		}
		
		$_SQL_DataArray[] = array( "key"=> "w2Box14b_code1", "val"=>$w2Box14b_code1, "table"=>"w2");
		$_SQL_DataArray[] = array( "key"=> "w2Box14b_code2", "val"=>$w2Box14b_code2, "table"=>"w2");
		    
		//$_SQL_DataArray[] = array( "key"=> "fw2_hash_cd", "val"=>$fw2_hash_cd, "table"=>"w2");		    
		
		/*if($other1_type_old != "NOT ON LIST")		    
			$_SQL_DataArray[] = array( "key"=> "other1_type_st_use", "val"=>$other1_type, "table"=>"w2");
		
		if($other2_type_old != "NOT ON LIST")		    
			$_SQL_DataArray[] = array( "key"=> "other2_type_st_use", "val"=>$other2_type, "table"=>"w2");
		    
		if($other3_type_old != "NOT ON LIST")		    
			$_SQL_DataArray[] = array( "key"=> "other3_type_st_use", "val"=>$other3_type, "table"=>"w2");
		
		if($other4_type_old != "NOT ON LIST")			    
			$_SQL_DataArray[] = array( "key"=> "other4_type_st_use", "val"=>$other4_type, "table"=>"w2");*/
		
		$_SQL_DataArray[] = array( "key"=> "prior_year_imported_ind", "val"=>'0', "table"=>"w2");
		$_SQL_DataArray[] = array( "key"=> "imported_not_visited_ind", "val"=>'0', "table"=>"w2");
		
		$_SQL_DataArray[] = array( "key"=> "complete_ind", "val"=>'1', "table"=>"w2");
		$_SQL_DataArray[] = array( "key"=> "form_visited_ind", "val"=>'0', "table"=>"w2");
		
		if(($non_standard_W2_ind == 1) && ((UDF_trim($employer_id_num) == "") || (UDF_strlen($employer_id_num) != 9)))
		{
			$_SQL_DataArray[] = array( "key"=> "payer_details_id", "val"=>'0', "table"=>"w2");
		}
		else
		{
			$_SQL_DataArray[] = array( "key"=> "payer_details_id", "val"=>$olt_payer_details_id, "table"=>"w2");
		}
		if($Box12CodeIICnt > 0)
		{
			$PassValidationIndII=(int)$PassValidationIndII;
			$_SQL_DataArray[] = array( "key"=> "w2_med_waivr_incl_ind", "val"=>$PassValidationIndII, "table"=>"w2");	
		}
		$out_sqlparm = db_sql_paramformat($_SQL_DataArray);
         	    
		$query_clause="update w2 set ".$out_sqlparm["_SQL_UpdateClause"]." where ";
		$query_clause.= "qt_user_id=(?) "; db_sql_BuildParamArray($qt_user_id, "w2::qt_user_id");
		$query_clause.= "and w2_ID=(?) "; db_sql_BuildParamArray($id, "w2::w2_ID");
		$result = db_sql_query(array($query_clause), $_SQL_ParamsArray);
		
		db_free_result(array($result));
		 
		if($w2_scorp_2perc_share_ind == "0")	//&& $w2_clergy_ind == "0"
		{
			$query_dep="DELETE from depend_health_insur where ";
			$query_dep .= "qt_user_id=(?) "; db_sql_BuildParamArray($qt_user_id, "depend_health_insur::qt_user_id");
			$query_dep .= "and w2_ID=(?) "; db_sql_BuildParamArray($id, "depend_health_insur::w2_ID");
			$result_dep=db_sql_query(array($query_dep), $_SQL_ParamsArray);
			db_free_result(array($result_dep));
		}
		$action = "Wages salaries tips etc.. edited";
		$which_form = "Form W-2";
		include("../oltproc/olt_record_action_all.php");
	}
	   	     
	$_SQL_DataArray[] = array( "key"=> "w2_ind", "val"=>'1', "table"=>"organiser_ind");		
	$out_sqlparm = db_sql_paramformat($_SQL_DataArray);
	
	$query_clause="update organiser_ind set ".$out_sqlparm["_SQL_UpdateClause"]." WHERE ";
	$query_clause.= "qt_user_id=(?) "; db_sql_BuildParamArray($qt_user_id, "organiser_ind::qt_user_id");
	$insert_result = db_sql_query(array($query_clause), $_SQL_ParamsArray);
	     
	     if($statutory_emp == 0)
	     {
	     	$query ="select schdC_id from scheduleC where ";
	     	$query .= "qt_user_id=(?) "; db_sql_BuildParamArray($qt_user_id, "scheduleC::qt_user_id");
	     	$query .= "and w2_schC_id=(?) "; db_sql_BuildParamArray($id, "scheduleC::w2_schC_id");
		$Delete_result = db_sql_query(array($query), $_SQL_ParamsArray);
		$noOfRows = db_num_rows(array($Delete_result));
		if($noOfRows > 0)
		{
			$res_data=db_fetchrow(array($Delete_result, DB_GETMODE_ASSOC));
			$schdC_id = UDF_trim($res_data["schdC_id"]);
			db_free_result(array($Delete_result));
			include("olt_delete_schC.php");
		}
	     }
	     
	     $pro_ein_info = array("ein"=>$employer_id_num,"eName"=>$employer_name,"eAddress"=>$employer_address, "eCity"=>$employer_city, "eState"=>$employer_state, "eZipCode"=>$employer_zip, "eZipExt"=>$employer_zip_ext);
	     include("oltpro_update_ein_db.php");
	     
	     /*if($sstax_err_flag == 2)
	     {
			$dup_warn_msg  ="<table border=\"0\" width=\"564\" style=\"border: 4px double #FF0000\" align=\"center\">";
			$dup_warn_msg .=" <tr><td colspan=2 align=center class=\"OLTBodyError\">WARNING</td></tr>";
			$dup_warn_msg .=" <tr>";
			$dup_warn_msg .="    <td width=\"3%\" valign=\"top\"><b></b></td>";
			$dup_warn_msg .="    <td width=\"97%\" class=\"OLTBodyText\">";
			$dup_warn_msg .="       The amount you in entered in Social Security Tax Withheld - box 4 is more than 50% of the social security wages in box 3. Please verify this information. <BR>Leave this warning message if the amount reported is correct."; 
			$dup_warn_msg .="    </td>";
			$dup_warn_msg .="  </tr>";
			$dup_warn_msg .="</table><br>";
	     }*/
	     
	     include("olt_w2_code_desc_box14.php");
	     
	//$query = "delete from w2_state_info where qt_user_id='$qt_user_id' and w2_ref_id=$id";
	//$Delete_result = db_sql_query(array($query));
	//db_free_result(array($Delete_result));
	
	$blnW2ConformOtherType = "false";
	$insert_cnt = 0;
	for($ictr=1; $ictr <= $TotCountOfRows; $ictr++) 
	{
		$w2_state_info_idVar 	= "w2_state_info_id".$ictr;
		$stateVar 		= "state".$ictr;
		$st_employer_idVar 	= "st".$ictr."_employer_id";
		$st_wages_tipsVar	= "st".$ictr."_wages_tips";
		$st_inc_taxVar 		= "st".$ictr."_inc_tax";
		$st_local_wagesVar 	= "st".$ictr."_local_wages";
		$st_local_inc_taxVar 	= "st".$ictr."_local_inc_tax";
		$st_localityVar 	= "st".$ictr."_locality";
		$st_locality_txtVar 	= "st".$ictr."_locality_txt";
		
		$w2_state_info_idVal	= UDF_trim($$w2_state_info_idVar);
		$w2_state_info_idVal	= fixnum($w2_state_info_idVal);		
		$stateVal 		= UDF_trim($$stateVar);
		$st_employer_idVal 	= UDF_trim($$st_employer_idVar);
		$st_employer_idVal	= fixtext($st_employer_idVal);
		$st_wages_tipsVal	= fmtvalue($$st_wages_tipsVar);				
		$st_inc_taxVal 		= fmtvalue($$st_inc_taxVar);
		$st_local_wagesVal 	= fmtvalue($$st_local_wagesVar);
		$st_local_inc_taxVal 	= fmtvalue($$st_local_inc_taxVar);
		
		$st_wages_tipsVal 	= (float)$st_wages_tipsVal;
		$st_inc_taxVal 		= (float)$st_inc_taxVal;
		$st_local_wagesVal 	= (float)$st_local_wagesVal;
		$st_local_inc_taxVal 	= (float)$st_local_inc_taxVal;
		
		$st_wages_tipsVal 	= UDF_round($st_wages_tipsVal);
		$st_inc_taxVal 		= UDF_round($st_inc_taxVal);
		$st_local_wagesVal 	= UDF_round($st_local_wagesVal);
		$st_local_inc_taxVal 	= UDF_round($st_local_inc_taxVal);
		
		$st_localityVal 	= UDF_trim($$st_localityVar);
		$st_locality_txtVal 	= UDF_trim($$st_locality_txtVar);
		
		if(($show_city_combo_ind == 1)&&(UDF_in_array($stateVal, $aloc_state_array)))
		{	
			if($st_localityVal == "NOL")
			{
				$st_localityVal = $st_locality_txtVal;
			}
		}
		
		if($stateVal != "")
		{		
			if(UDF_in_array($stateVal,$state_array))
				$blnW2ConformOtherType = "true";
			
			$w2_state_norows = 0;
			if($w2_state_info_idVal != "")
			{
				$query_w2_state  ="select qt_user_id from w2_state_info where ";
				$query_w2_state  .= "qt_user_id=(?) "; db_sql_BuildParamArray($qt_user_id, "w2_state_info::qt_user_id");
				$query_w2_state  .= "and w2_ref_id=(?) "; db_sql_BuildParamArray($id, "w2_state_info::w2_ref_id");
				$query_w2_state  .= "and w2_state_info_id=(?) "; db_sql_BuildParamArray($w2_state_info_idVal, "w2_state_info::w2_state_info_id");
				$result_w2_state = db_sql_query(array($query_w2_state), $_SQL_ParamsArray);
				$w2_state_norows = db_num_rows(array($result_w2_state));
				db_free_result(array($result_w2_state));
			}
			else
			{
				$query_w2_state  ="select qt_user_id,w2_state_info_id from w2_state_info where ";
				$query_w2_state  .= "qt_user_id=(?) "; db_sql_BuildParamArray($qt_user_id, "w2_state_info::qt_user_id");
				$query_w2_state  .= "and w2_ref_id=(?) "; db_sql_BuildParamArray($id, "w2_state_info::w2_ref_id");
				$query_w2_state  .= "and state=(?) "; db_sql_BuildParamArray($stateVal, "w2_state_info::state");
				$query_w2_state  .= "and state_employer_id=(?) "; db_sql_BuildParamArray($st_employer_idVal, "w2_state_info::state_employer_id");
				$query_w2_state  .= "and state_wages_tips=(?) "; db_sql_BuildParamArray($st_wages_tipsVal, "w2_state_info::state_wages_tips");
				$query_w2_state  .= "and state_inc_tax=(?) "; db_sql_BuildParamArray($st_inc_taxVal, "w2_state_info::state_inc_tax");
				$query_w2_state  .= "and state_local_wages=(?) "; db_sql_BuildParamArray($st_local_wagesVal, "w2_state_info::state_local_wages");
				$query_w2_state  .= "and state_local_inc_tax=(?) "; db_sql_BuildParamArray($st_local_inc_taxVal, "w2_state_info::state_local_inc_tax");
				$query_w2_state  .= "and state_locality=(?) "; db_sql_BuildParamArray($st_localityVal, "w2_state_info::state_locality");
				$result_w2_state = db_sql_query(array($query_w2_state), $_SQL_ParamsArray);
				$w2_state_norows = db_num_rows(array($result_w2_state));				
				if($w2_state_norows > 0)
				{
					$res_data = db_fetchrow(array($result_w2_state, DB_GETMODE_ASSOC));
					$w2_state_info_idVal = UDF_trim($res_data["w2_state_info_id"]);    	
				}
				db_free_result(array($result_w2_state));
			}
				
			if($w2_state_norows == 0)
			{	
				$_SQL_DataArray[] = array( "key"=> "qt_user_id", "val"=>$qt_user_id, "table"=>"w2_state_info");
				$_SQL_DataArray[] = array( "key"=> "w2_ref_id", "val"=>(int)$id, "table"=>"w2_state_info");
				$out_sqlparm = db_sql_paramformat($_SQL_DataArray);

				$insert ="insert into w2_state_info (".$out_sqlparm['_SQL_FieldClause'].") values (".$out_sqlparm['_SQL_ValueClause'].")";
				$result = db_sql_query(array($insert), $_SQL_ParamsArray);
			     	db_free_result(array($result));
				     	
			     	$query_clause ="select max(w2_state_info_id)'w2_ref_id' from w2_state_info where ";
			     	$query_clause .= "qt_user_id=(?) "; db_sql_BuildParamArray($qt_user_id, "w2_state_info::qt_user_id");
				$result = db_sql_query(array($query_clause), $_SQL_ParamsArray);
	
			        $res_data = db_fetchrow(array($result, DB_GETMODE_ASSOC));
			        $w2_state_info_idVal= UDF_trim($res_data["w2_ref_id"]);  
			        db_free_result(array($result));
			}
						
			$_SQL_DataArray[] = array( "key"=> "state", "val"=>$stateVal, "table"=>"w2_state_info");			
			$_SQL_DataArray[] = array( "key"=> "state_employer_id", "val"=>$st_employer_idVal, "table"=>"w2_state_info");			
			$_SQL_DataArray[] = array( "key"=> "state_wages_tips", "val"=>(float)$st_wages_tipsVal, "table"=>"w2_state_info");			
			$_SQL_DataArray[] = array( "key"=> "state_inc_tax", "val"=>(float)$st_inc_taxVal, "table"=>"w2_state_info");			
			$_SQL_DataArray[] = array( "key"=> "state_local_wages", "val"=>(float)$st_local_wagesVal, "table"=>"w2_state_info");			
			$_SQL_DataArray[] = array( "key"=> "state_local_inc_tax", "val"=>(float)$st_local_inc_taxVal, "table"=>"w2_state_info");			
			$_SQL_DataArray[] = array( "key"=> "state_locality", "val"=>$st_localityVal, "table"=>"w2_state_info");			
			$_SQL_DataArray[] = array( "key"=> "w2_state_whose_ind", "val"=>(int)$whose_w2, "table"=>"w2_state_info");			
			
			$out_sqlparm = db_sql_paramformat($_SQL_DataArray);
			
			$query_clause="update w2_state_info set ".$out_sqlparm["_SQL_UpdateClause"]." WHERE ";
			$query_clause.= "qt_user_id=(?) "; db_sql_BuildParamArray($qt_user_id, "w2_state_info::qt_user_id");
			$query_clause.= " and w2_state_info_id=(?) "; db_sql_BuildParamArray($w2_state_info_idVal, "w2_state_info::w2_state_info_id");
			$query_clause.= " and w2_ref_id=(?) "; db_sql_BuildParamArray($id, "w2_state_info::w2_ref_id");
			$result = db_sql_query(array($query_clause), $_SQL_ParamsArray);
			db_free_result(array($result));
		}
		else if($w2_state_info_idVal != "")
		{
			$query ="delete from w2_state_info where ";
			$query .= "qt_user_id=(?) "; db_sql_BuildParamArray($qt_user_id, "w2_state_info::qt_user_id");
			$query .= "and w2_ref_id=(?) "; db_sql_BuildParamArray($id, "w2_state_info::w2_ref_id");
			$query .= "and w2_state_info_id=(?) "; db_sql_BuildParamArray($w2_state_info_idVal, "w2_state_info::w2_state_info_id");
			$Delete_result = db_sql_query(array($query), $_SQL_ParamsArray);
			db_free_result(array($Delete_result));
		}
	}
	
	$insert_cnt = 0;
	for($ictr=1; $ictr <= $TotCountOfBox12Rows; $ictr++) 
	{
		$w2_line12_idVar 	= "w2_line12_id".$ictr;
		$w2_line12_idVal	= UDF_trim($$w2_line12_idVar);
		
		$box12_codeVar 		= "box12_code".$ictr;
		$box12_amountVar 	= "box12_amount".$ictr;
		$box12_yearVar 		= "box12_year".$ictr;
		
		$box12_codeVal 		= UDF_trim($$box12_codeVar);
		$box12_codeVal 		= fmtvalue($$box12_codeVar);
		$box12_amountVal 	= UDF_trim($$box12_amountVar);
		$box12_yearVal 		= UDF_trim($$box12_yearVar);
		
		if($box12_codeVal != "" && $box12_amountVal > 0  && $box12_yearVal != "")
		{
			
			$w2_box12_norows = 0;
			if($w2_line12_idVal != "")
			{
				$query_w2_box12  ="select qt_user_id from w2_line12 where ";
				$query_w2_box12  .= "qt_user_id=(?) "; db_sql_BuildParamArray($qt_user_id, "w2_line12::qt_user_id");
				$query_w2_box12  .= "and w2_ref_id=(?) "; db_sql_BuildParamArray($id, "w2_line12::w2_ref_id");
				$query_w2_box12  .= "and w2_line12_id=(?) "; db_sql_BuildParamArray($w2_line12_idVal, "w2_line12::w2_line12_id");
				$result_w2_box12 = db_sql_query(array($query_w2_box12), $_SQL_ParamsArray);
				$w2_box12_norows = db_num_rows(array($result_w2_box12));
				db_free_result(array($result_w2_box12));
			}	
			if($w2_box12_norows == 0)
			{	
				$_SQL_DataArray[] = array( "key"=> "qt_user_id", "val"=>$qt_user_id, "table"=>"w2_line12");
				$_SQL_DataArray[] = array( "key"=> "w2_ref_id", "val"=>(int)$id, "table"=>"w2_line12");
				$out_sqlparm = db_sql_paramformat($_SQL_DataArray);

				$insert ="insert into w2_line12 (".$out_sqlparm['_SQL_FieldClause'].") values (".$out_sqlparm['_SQL_ValueClause'].")";
				$result = db_sql_query(array($insert), $_SQL_ParamsArray);
			     	db_free_result(array($result));
				     	
			     	$query_clause ="select max(w2_line12_id)'w2_ref_id' from w2_line12 where ";
			     	$query_clause .= "qt_user_id=(?) "; db_sql_BuildParamArray($qt_user_id, "w2_line12::qt_user_id");
				$result = db_sql_query(array($query_clause), $_SQL_ParamsArray);
	
			        $res_data = db_fetchrow(array($result, DB_GETMODE_ASSOC));
			        $w2_line12_idVal= UDF_trim($res_data["w2_ref_id"]);  
			        db_free_result(array($result));
			}
							
			$_SQL_DataArray[] = array( "key"=> "box12_code", "val"=>$box12_codeVal, "table"=>"w2_line12");			
			$_SQL_DataArray[] = array( "key"=> "box12_amount", "val"=>(float)$box12_amountVal, "table"=>"w2_line12");			
			$_SQL_DataArray[] = array( "key"=> "box12_year", "val"=>$box12_yearVal, "table"=>"w2_line12");			
			$_SQL_DataArray[] = array( "key"=> "w2_line12_whose_ind", "val"=>(int)$whose_w2, "table"=>"w2_line12");			
						
			$out_sqlparm = db_sql_paramformat($_SQL_DataArray);
			
			$query_clause="update w2_line12 set ".$out_sqlparm["_SQL_UpdateClause"]." WHERE ";
			$query_clause.= "qt_user_id=(?) "; db_sql_BuildParamArray($qt_user_id, "w2_line12::qt_user_id");
			$query_clause.= " and w2_line12_id=(?) "; db_sql_BuildParamArray($w2_line12_idVal, "w2_line12::w2_line12_id");
			$query_clause.= " and w2_ref_id=(?) "; db_sql_BuildParamArray($id, "w2_line12::w2_ref_id");
			$result = db_sql_query(array($query_clause), $_SQL_ParamsArray);
			db_free_result(array($result));
		}
		else if($w2_line12_idVal != "")
		{
			$query ="delete from w2_line12 where ";
			$query .= "qt_user_id=(?) "; db_sql_BuildParamArray($qt_user_id, "w2_line12::qt_user_id");
			$query .= "and w2_ref_id=(?) "; db_sql_BuildParamArray($id, "w2_line12::w2_ref_id");
			$query .= "and w2_line12_id=(?) "; db_sql_BuildParamArray($w2_line12_idVal, "w2_line12::w2_line12_id");
			$Delete_result = db_sql_query(array($query), $_SQL_ParamsArray);
			db_free_result(array($Delete_result));
		}
	}
	
	$insert_cnt = 0;
	$oth14_type_old_tmp = "";
	$tot_NOL_line14 = 0;
	for($ictr=1; $ictr <= $TotCountOfBox14Rows; $ictr++) 
	{
		$w2_line14_idVar 	= "w2_line14_id".$ictr;
		$w2_line14_idVal	= UDF_trim($$w2_line14_idVar);
		
		$other14_typeVar 	= "other14_type".$ictr;
		$other14_amountVar 	= "other14_amount".$ictr;
		$other14_typeNewVar 	= "other14_typeNew".$ictr;
		
		$other14_typeVal 	= UDF_trim($$other14_typeVar);
		$other14_typeVal	= fmtvalue($other14_typeVal);
		$other14_amountVal 	= UDF_trim($$other14_amountVar);
		$other14_typeNewVal 	= UDF_trim($$other14_typeNewVar);
		$other14_typeNewVal	= fmtvalue($other14_typeNewVal);		
		
		$other14_amountVal	= fmtvalue($other14_amountVal);
		$other14_amountVal	= UDF_round((float)$other14_amountVal);
		
		$other14_typeNewVal=UDF_str_replace("#","" ,$other14_typeNewVal); 
		$other14_typeNewVal=UDF_str_replace("(","" ,$other14_typeNewVal); 
		$other14_typeNewVal=UDF_str_replace(")","" ,$other14_typeNewVal); 
		$other14_typeNewVal=UDF_str_replace("/","" ,$other14_typeNewVal); 
		$other14_typeNewVal=UDF_str_replace(".","" ,$other14_typeNewVal); 
		$other14_typeNewVal=UDF_str_replace("-","" ,$other14_typeNewVal); 
		$other14_typeNewVal=UDF_str_replace(","," " ,$other14_typeNewVal); 
		$other14_type_oldVar = "other14_type_old".$ictr;
		$other14_type_oldVal = $other14_typeVal;
		//echo "<br><br><br>other14_typeVal=$other14_typeVal other14_amountVal=$other14_amountVal other14_typeNewVal=$other14_typeNewVal";
		if(($other14_typeNewVal != "") && (($other14_typeVal == "") || ($other14_typeVal == "NOT ON LIST")))
			   $other14_typeVal = $other14_typeNewVal;
		if($other14_typeVal != "" && $other14_amountVal > 0)
		{
			
			$w2_box14_norows = 0;
			if($w2_line14_idVal != "")
			{
				$query_w2_box14  ="select qt_user_id from w2_line14 where ";
				$query_w2_box14  .= "qt_user_id=(?) "; db_sql_BuildParamArray($qt_user_id, "w2_line14::qt_user_id");
				$query_w2_box14  .= "and w2_ref_id=(?) "; db_sql_BuildParamArray($id, "w2_line14::w2_ref_id");
				$query_w2_box14  .= "and w2_line14_id=(?) "; db_sql_BuildParamArray($w2_line14_idVal, "w2_line14::w2_line14_id");
				$result_w2_box14 = db_sql_query(array($query_w2_box14), $_SQL_ParamsArray);
				$w2_box14_norows = db_num_rows(array($result_w2_box14));
				db_free_result(array($result_w2_box14));
			}	
			if($w2_box14_norows == 0)
			{	
				$_SQL_DataArray[] = array( "key"=> "qt_user_id", "val"=>$qt_user_id, "table"=>"w2_line14");
				$_SQL_DataArray[] = array( "key"=> "w2_ref_id", "val"=>(int)$id, "table"=>"w2_line14");
				$out_sqlparm = db_sql_paramformat($_SQL_DataArray);

				$insert ="insert into w2_line14 (".$out_sqlparm['_SQL_FieldClause'].") values (".$out_sqlparm['_SQL_ValueClause'].")";
				$result = db_sql_query(array($insert), $_SQL_ParamsArray);
			     	db_free_result(array($result));
				     	
			     	$query_clause ="select max(w2_line14_id)'w2_ref_id' from w2_line14 where ";
			     	$query_clause .= "qt_user_id=(?) "; db_sql_BuildParamArray($qt_user_id, "w2_line14::qt_user_id");
				$result = db_sql_query(array($query_clause), $_SQL_ParamsArray);
	
			        $res_data = db_fetchrow(array($result, DB_GETMODE_ASSOC));
			        $w2_line14_idVal= UDF_trim($res_data["w2_ref_id"]);  
			        db_free_result(array($result));
			}
				
			if($other14_type_oldVal == "NOT ON LIST")
			{
				$oth14_type_old_tmp .= $w2_line14_idVal."#";
				$tot_NOL_line14++;
			}
			if(UDF_strlen($other14_typeVal) > 30)
			{
				$other14_typeVal = UDF_substr($other14_typeVal, 0, 30);
			}
			$_SQL_DataArray[] = array( "key"=> "other14_type", "val"=>$other14_typeVal, "table"=>"w2_line14");			
			$_SQL_DataArray[] = array( "key"=> "other14_amount", "val"=>(float)$other14_amountVal, "table"=>"w2_line14");	
			if($other14_type_oldVal != "NOT ON LIST")
				$_SQL_DataArray[] = array( "key"=> "other14_type_st_use", "val"=>$other14_typeVal, "table"=>"w2_line14");
	    		//else
	    		//	$_SQL_DataArray[] = array( "key"=> "other14_type_st_use", "val"=>'', "table"=>"w2_line14");
	    		$_SQL_DataArray[] = array( "key"=> "w2_line14_whose_ind", "val"=>(int)$whose_w2, "table"=>"w2_line14");
	    		$out_sqlparm = db_sql_paramformat($_SQL_DataArray);
			
			$query_clause="update w2_line14 set ".$out_sqlparm["_SQL_UpdateClause"]." WHERE ";
			$query_clause.= "qt_user_id=(?) "; db_sql_BuildParamArray($qt_user_id, "w2_line14::qt_user_id");
			$query_clause.= " and w2_line14_id=(?) "; db_sql_BuildParamArray($w2_line14_idVal, "w2_line14::w2_line14_id");
			$query_clause.= " and w2_ref_id=(?) "; db_sql_BuildParamArray($id, "w2_line14::w2_ref_id");		    		    
			$result = db_sql_query(array($query_clause), $_SQL_ParamsArray);
			db_free_result(array($result));
		}
		else if($w2_line14_idVal != "")
		{
			$query ="delete from w2_line14 where ";
			$query .= "qt_user_id=(?) "; db_sql_BuildParamArray($qt_user_id, "w2_line14::qt_user_id");
			$query .= "and w2_ref_id=(?) "; db_sql_BuildParamArray($id, "w2_line14::w2_ref_id");
			$query .= "and w2_line14_id=(?) "; db_sql_BuildParamArray($w2_line14_idVal, "w2_line14::w2_line14_id");
			$Delete_result = db_sql_query(array($query), $_SQL_ParamsArray);
			db_free_result(array($Delete_result));
		}
	}
	
	/*$_SQL_DataArray[] = array( "key"=> "w2_line12_whose_ind", "val"=>(int)$whose_w2, "table"=>"w2_line12");
	$out_sqlparm = db_sql_paramformat($_SQL_DataArray);

	$Query ="update w2_line12 set ".$out_sqlparm["_SQL_UpdateClause"]." WHERE ";
	$Query .= "qt_user_id=(?) "; db_sql_BuildParamArray($qt_user_id, "w2_line12::qt_user_id");
	$Query .= " and w2_ref_id=(?) "; db_sql_BuildParamArray($id, "w2_line12::w2_ref_id");
	$update_ln12_who = db_sql_query(array($Query), $_SQL_ParamsArray);
	db_free_result(array($update_ln12_who));
	
	$_SQL_DataArray[] = array( "key"=> "w2_line14_whose_ind", "val"=>(int)$whose_w2, "table"=>"w2_line14");
	$out_sqlparm = db_sql_paramformat($_SQL_DataArray);

	$Query ="update w2_line14 set ".$out_sqlparm["_SQL_UpdateClause"]." WHERE ";
	$Query .= "qt_user_id=(?) "; db_sql_BuildParamArray($qt_user_id, "w2_line14::qt_user_id");
	$Query .= " and w2_ref_id=(?) "; db_sql_BuildParamArray($id, "w2_line14::w2_ref_id");
	$update_ln14_who = db_sql_query(array($Query), $_SQL_ParamsArray);
	db_free_result(array($update_ln14_who));*/
	
	//Populate corrected_data to OFX track table start
	
	$AI_Tag = "W2";
	$AICollectFullResponseCalledFromInput = 1;
	$attach_parent_id = $id;
	include("../oltproc/AI_FDE_collect_user_full_response.php");
	
	//Populate corrected_data to OFX track table end
	     
     	$action = "W2 Saved";
	include("recordaction.php");
	     
	$query_w2_state  ="select qt_user_id from w2_state_info where ";
	$query_w2_state  .= "qt_user_id=(?) "; db_sql_BuildParamArray($qt_user_id, "w2_state_info::qt_user_id");
	$query_w2_state  .= "and w2_ref_id=(?) "; db_sql_BuildParamArray($id, "w2_state_info::w2_ref_id");
	$result_w2_state = db_sql_query(array($query_w2_state), $_SQL_ParamsArray);
	$w2_state_norows = db_num_rows(array($result_w2_state));
	     
	     if($sch1A_partII_entry_err_flag == 1)
		{	
			$nv_dup_warn_msg_reminder = "1";
			$nv_dup_warn_msg .= "<label class='control control--checkbox' style='float:left' >You have entries in W2 line 7 for Tips. Please review Schedule 1-A Part II entries for $emp_first_name $emp_mid_initial $emp_last_name.</label>";	
		}
		
	     $skip_state_input_flow = array("AK", "AS", "FL", "NV", "SD", "TX", "VI", "WY");
	     if ((($foreign_address_ind_tmp == "0") && (!UDF_in_array($residentof_tmp,$skip_state_input_flow))) &&
	     	 ($w2_state_norows == 0) && ($TotCountOfRows < 5))	//($state1 == "" && $state2 == "" && $state3 == "" && $state4 == "")
	     {
	     	$RetriveWagesVal = 1;
	     	include_once("olt_pagehdr.php");	
 		include("olt_efile_rej_veri_redirect.php");  echo "<form name=form1 action=\"olt_w2_state.php \" method=post>";
   		BuildDynamicFormHiddenData("id=$id&RetriveWagesVal=$RetriveWagesVal&tot_NOL_line14=$tot_NOL_line14");
   		include(PROTECTED_PATHQT."html/w2_state.html");
	     }
	     else if(($blnW2ConformOtherType == "true") && ($tot_NOL_line14 > 0))	//$other1_type_old == "NOT ON LIST" ||$other2_type_old == "NOT ON LIST" || $other3_type_old == "NOT ON LIST" || $other4_type_old == "NOT ON LIST" || (UDF_in_array($state1,$state_array) || UDF_in_array($state2,$state_array) ||UDF_in_array($state3,$state_array) ||UDF_in_array($state4,$state_array) || 
	     {
	     	include_once("olt_pagehdr.php");	
 		include("olt_efile_rej_veri_redirect.php");  echo "<form name=form1 action=\"olt_w2_conform_othertype.php \" method=post>";
		
   		BuildDynamicFormHiddenData("id=$id&oth14_type_old_tmp=$oth14_type_old_tmp&tot_NOL_line14=$tot_NOL_line14");
   		include(PROTECTED_PATHQT."html/w2_conform_othertype.html");
	     }
	     else if(($statutory_emp == 1) && ($form1040_ind_add != "1040SS"))
	     {
	     	$step = "w2done";
	     	include_once("olt_pagehdr.php");	
 		include("olt_efile_rej_veri_redirect.php");  echo "<form name=form1 action=\"olt_Statutory_schC.php\" method=post>";
   		BuildDynamicFormHiddenData("step=$step&whose_w2=$whose_w2&id=$id");
   		include(PROTECTED_PATHQT."html/Statutory_schC.html");
	     }
	     else if($w2_scorp_2perc_share_ind == 1)	//|| $w2_clergy_ind == 1
	     {
	     	$attched_forms = "W2";
		$attched_id = UDF_trim($id);
		
		include_once("olt_pagehdr.php");
		include("olt_efile_rej_veri_redirect.php");  
		echo "<form name=form1 action=\"olt_self_emp_insur_health_common.php \" method=post>";
		BuildDynamicFormHiddenData("user_identifier=$user_identifier&step=$step&attched_id=$attched_id&attched_forms=$attched_forms&caldfrm=$caldfrm");
		include(PROTECTED_PATHQT."html/self_emp_insur_health_common.html");	     		
   	     }
   	     else
	     {
        	include_once("olt_pagehdr.php");	
 		include("olt_efile_rej_veri_redirect.php");  echo "<form name=form1 action=\"olt_w2done.php \" method=post>";
   		BuildDynamicFormHiddenData("step=w2done");
   		include(PROTECTED_PATHQT."html/w2done.html");
	      }
}
else
{     
	
	//**010 Start
	//$nv_dup_warn_msg="";
	include_once("olt_pagehdr.php");
	if($wagesZero_err_flag == 1 || $nonstand_w2_ind_err_flag == 1 || $with_held_err == 1 || $ss_with_held_err == 1 || $st1_with_held_pass_err == 1 || $NYStateWithHolding == 1 || $st2_with_held_err == 1 || $wage_comp_err == 1 || $state_comp_err == 1 || $state_wage1_err == 1 || $state_wage2_err == 1 || $sstax_err_flag == 2 || $medtax_err_flag == 2 || $code12a_err == 1 || $emp_address2_flag ==1 || $stlocwag1_err ==1 || $stlocwag2_err == 1 || $stlocwag3_err == 1 || $stlocwag4_err == 1 || $nystateinc_err == 1 || $Box12II_err_flag == 1)	// || $sch1A_partII_entry_err_flag == 1
	{
		$dup_warn_msg  ="<table border=\"0\" width=\"564\" style=\"border: 4px double #FF0000\" align=\"center\">";
		$dup_warn_msg .=" <tr><td colspan=2 align=center class=\"OLTBodyError\">WARNING</td></tr>";
		//$nv_dup_warn_msg = "";
		if($wagesZero_err_flag == 1)
		{
			$dup_warn_msg .=" <tr><td width=\"3%\" valign=\"top\"><b></b></td>";
			$dup_warn_msg .=" <td width=\"97%\" class=\"OLTBodyText\">";
			$dup_warn_msg .= "You have entered a W-2 with 0 wages in box 1. The IRS will not allow a W-2 to be sent with 0 in box 1.<BR>";
			$dup_warn_msg .= "If this is correct, you will have to print and mail the return to file it.<BR>";
			$dup_warn_msg .= "If the only item on your W-2 is third-party sick pay, then you can omit entering the W-2 and just retain it with your tax records.";
			$nv_dup_warn_msg .= "You have entered a W-2 with 0 wages in box 1. The IRS will not allow a W-2 to be sent with 0 in box 1.<BR>";
			$nv_dup_warn_msg .= "If this is correct, you will have to print and mail the return to file it.<BR>";
			$nv_dup_warn_msg .= "If the only item on your W-2 is third-party sick pay, then you can omit entering the W-2 and just retain it with your tax records.";
			$dup_warn_msg .=" </td></tr>";
		}
		if($with_held_err == 1)
		{
			$dup_warn_msg .=" <tr><td width=\"3%\" valign=\"top\"><b></b></td>";
			$dup_warn_msg .=" <td width=\"97%\" class=\"OLTBodyText\">";    
			$dup_warn_msg .= "Your Federal income tax withheld cannot be greater than 50% of your wages.";
			$nv_dup_warn_msg .= "Your Federal income tax withheld cannot be greater than 50% of your wages.";
			$dup_warn_msg .=" </td></tr>";
		}
		if($ss_with_held_err == 1)
		{
			$dup_warn_msg .=" <tr><td width=\"3%\" valign=\"top\"><b></b></td>";
			$dup_warn_msg .=" <td width=\"97%\" class=\"OLTBodyText\">";    
			$dup_warn_msg .="Your Social Security tax withheld cannot be greater than 50% of your social security wages.";
			$nv_dup_warn_msg .= "<br>Your Social Security tax withheld cannot be greater than 50% of your social security wages.";
			$dup_warn_msg .=" </td></tr>";
		}
		if(($stlocwag1_err == 1) || ($stlocwag2_err == 1) || ($stlocwag3_err == 1) || ($stlocwag4_err == 1))
		{
			$dup_warn_msg .=" <tr><td width=\"3%\" valign=\"top\"><b></b></td>";
			$dup_warn_msg .=" <td width=\"97%\" class=\"OLTBodyText\">";    
			$dup_warn_msg .="You have given locality wages but have not given locality name. Either enter your locality name or check the box below to confirm that your locality name is kept empty.";
			$nv_dup_warn_msg .= "<br>You have given locality wages but have not given locality name. Either enter your locality name or check the box below to confirm that your locality name is kept empty.";
			$dup_warn_msg .=" </td></tr>";
		}
		if($nystateinc_err == 1)
		{
			$dup_warn_msg .=" <tr><td width=\"3%\" valign=\"top\"><b></b></td>";
			$dup_warn_msg .=" <td width=\"97%\" class=\"OLTBodyText\">";    
			$dup_warn_msg .="Your State Income Tax Withheld - box 17 and Local Income Tax Withheld - box 19 cannot be greater your wages - box 1";
			$nv_dup_warn_msg .= "<br>Your State Income Tax Withheld - box 17 and Local Income Tax Withheld - box 19 cannot be greater your wages - box 1";
			$dup_warn_msg .=" </td></tr>";
		}
		/*if($st1_with_held_err == 1 || $st2_with_held_err == 1)
		{
			$per1 = 0;
			$per2 = 0;
			if(UDF_trim($state1) == "IL" && $st1_with_held_err == 1) 
				$per1 = 20;
			else if(UDF_trim($state1) == "VA" && $st1_with_held_err == 1) 
				$per1 = 25;
			else if((UDF_trim($state1) == "MN" || UDF_trim($state1) == "NY" || UDF_trim($state1) == "SC") && $st1_with_held_err == 1) 
				$per1 = 50;	
			else if($st1_with_held_err == 1)
				$per1 = 50;
			if(UDF_trim($state2) == "IL" && $st2_with_held_err == 1) 
				$per2 = 20;
			else if(UDF_trim($state2) == "VA" && $st2_with_held_err == 1) 
				$per2 = 25;
			else if((UDF_trim($state2) == "MN" || UDF_trim($state2) == "NY") && $st2_with_held_err == 1) 
				$per2 = 50;
			else if($st2_with_held_err == 1)
				$per2 = 50;	
 					
			if($per1 > 0)
			{
				$dup_warn_msg .=" <tr><td width=\"3%\" valign=\"top\"><b></b></td>";
				$dup_warn_msg .=" <td width=\"97%\" class=\"OLTBodyText\">";    
				$dup_warn_msg .="Your '$state1' income tax withheld cannot be greater than $per1% of your '$state1' wages .";
				$nv_dup_warn_msg .= "<br>Your '$state1' income tax withheld cannot be greater than $per1% of your '$state1' wages .";
				$dup_warn_msg .=" </td></tr>";
			}
			if($per2 > 0)
			{
				$dup_warn_msg .=" <tr><td width=\"3%\" valign=\"top\"><b></b></td>";
				$dup_warn_msg .=" <td width=\"97%\" class=\"OLTBodyText\">";    
				$dup_warn_msg .="Your '$state2' income tax withheld cannot be greater than $per2% of your '$state2' wages .";
				$nv_dup_warn_msg .= "<br>Your '$state2' income tax withheld cannot be greater than $per2% of your '$state2' wages .";
				$dup_warn_msg .=" </td></tr>";
			}
		}*/
		if($wage_comp_err == 1)
		{
			if($state1 == $state2)
			{
				$dup_warn_msg .=" <tr><td width=\"3%\" valign=\"top\"><b></b></td>";
				$dup_warn_msg .=" <td width=\"97%\" class=\"OLTBodyText\">";    
				$dup_warn_msg .="Your combined State Wages cannot be greater than 125% of your Federal wages .";
				$nv_dup_warn_msg .= "<br>Your combined State Wages cannot be greater than 125% of your Federal wages .";
				$dup_warn_msg .=" </td></tr>";
			}
			else
			{
				$dup_warn_msg .=" <tr><td width=\"3%\" valign=\"top\"><b></b></td>";
				$dup_warn_msg .=" <td width=\"97%\" class=\"OLTBodyText\">";    
				$dup_warn_msg .="Your State Wages cannot be greater than 125% of your Federal wages .";
				$nv_dup_warn_msg .= "<br>Your State Wages cannot be greater than 125% of your Federal wages .";
				$dup_warn_msg .=" </td></tr>";
			}
		}
		if($state_comp_err == 1)
		{
			$dup_warn_msg .=" <tr><td width=\"3%\" valign=\"top\"><b></b></td>";
			$dup_warn_msg .=" <td width=\"97%\" class=\"OLTBodyText\">";    
			$dup_warn_msg .=" Do not repeat the same state wages details.";
			$nv_dup_warn_msg .= "<br> Do not repeat the same state wages details.";
			$dup_warn_msg .=" </td></tr>";
			
		}
		if($state_wage1_err == 1 || $state_wage2_err == 1)
		{
			$dup_warn_msg .=" <tr><td width=\"3%\" valign=\"top\"><b></b></td>";
			$dup_warn_msg .=" <td width=\"97%\" class=\"OLTBodyText\">";    
			$dup_warn_msg .=" You must enter the State Income if you entered the state withheld.";
			$nv_dup_warn_msg .= "<br>You must enter the State Income if you entered the state withheld.";
			$dup_warn_msg .=" </td></tr>";
		}
 		if($sstax_err_flag == 2)
	     	{
			$dup_warn_msg .=" <tr><td width=\"3%\" valign=\"top\"><b></b></td>";
			$dup_warn_msg .=" <td width=\"97%\" class=\"OLTBodyText\">";    
			$dup_warn_msg .=" The amount you in entered in &quot;Social Security Tax Withheld - box 4&quot; is not equal to 6.2% of the total social security wages in box 3 and social security tips in Box 7. Please verify this information."; 
			$nv_dup_warn_msg .= "<br>The amount you in entered in &quot;Social Security Tax Withheld - box 4&quot; is not equal to 6.2% of the total social security wages in box 3 and social security tips in Box 7. Please verify this information.";
			$dup_warn_msg .=" </td></tr>";
     		}
	     	if($medtax_err_flag == 2)
     		{
			$dup_warn_msg .=" <tr><td width=\"3%\" valign=\"top\"><b></b></td>";
			$dup_warn_msg .=" <td width=\"97%\" class=\"OLTBodyText\">";    
			$dup_warn_msg .=" The amount you entered in &quot;Medicare Tax Withheld - box 6&quot; is not equal to 1.45% and 0.9% (if more than $200,000) of the medicare wages in box 5. Please verify this information."; 
			$nv_dup_warn_msg .= "<br>The amount you entered in &quot;Medicare Tax Withheld - box 6&quot; is not equal to 1.45% and 0.9% (if more than $200,000) of the medicare wages in box 5. Please verify this information.";
			$dup_warn_msg .=" </td></tr>";
		}
		if($wagesZero_err_flag == 1)
		{
			$dup_warn_msg .=" <tr><td width=\"3%\" valign=\"top\"><INPUT TYPE=\"CHECKBOX\"  value='1' name=PassValidationInd></td>";
			$dup_warn_msg .=" <td width=\"97%\" class=\"OLTBodyError\">";    
			$dup_warn_msg .= "Check here if this entry is correct and you will plan to print and mail your return.";
			$nv_dup_warn_msg .= "<br><label class='control control--checkbox' style='float:left' >Check here if this entry is correct and you will plan to print and mail your return.<INPUT TYPE=checkbox value='1' name=PassValidationInd>&nbsp;<div class=\"control__indicator\"></div></label>";
			//$nv_dup_warn_msg .= "<br>".$output;
			$dup_warn_msg .=" </td></tr>";
		}
		else if(($sstax_err_flag == 2) || ($with_held_err == 1) || ($medtax_err_flag == 2) || ($state_wage1_err == 1) || ($state_wage2_err == 1) || ($st1_with_held_pass_err == 1) || ($NYStateWithHolding == 1) || ($st1_with_held_err == 1 && UDF_trim($state1) == "VA") || ($st1_with_held_err == 1 && UDF_trim($state1) == "SC") || ($st2_with_held_err == 1 && UDF_trim($state2) == "VA") || ($stlocwag1_err ==1) || ($stlocwag2_err == 1) || ($stlocwag3_err == 1) || ($stlocwag4_err == 1) || ($ss_with_held_err == 1) || (($st1_with_held_err == 1 && (UDF_trim($state1) == "MN" || UDF_trim($state1) == "NY")) || ($st2_with_held_err == 1 && (UDF_trim($state2) == "MN" || UDF_trim($state2) == "NY"))) || (($wage_comp_err == 1) && ($state1 == "NJ" || $state2 == "NJ" || $state3 == "NJ" || $state4 == "NJ")) || ($nystateinc_err == 1))
		{
			$dup_warn_msg .=" <tr><td width=\"3%\" valign=\"top\"><INPUT TYPE=\"CHECKBOX\"  value='1' name=PassValidationInd></td>";
			$dup_warn_msg .=" <td width=\"97%\" class=\"OLTBodyError\">";    
			$dup_warn_msg .= "Check here if your information is correct.";
			$nv_dup_warn_msg .= "<br><label class='control control--checkbox' style='float:left' >Check here if your information is correct.<INPUT TYPE=checkbox value='1' name=PassValidationInd>&nbsp;<div class=\"control__indicator\"></div></label><br>";
			//$nv_dup_warn_msg .= "<br>".$output;
			$dup_warn_msg .=" </td></tr>";
		}
		
		if($code12a_err == 1)
		{
			$dup_warn_msg .=" <tr><td width=\"3%\" valign=\"top\"></td>";
			$dup_warn_msg .=" <td width=\"97%\" class=\"OLTBodyError\">";    
			$dup_warn_msg .= "IRS will reject your return if you enter any information Box 12b,12c,12d,12e or 12f without any information in Box 12a ";
			$nv_dup_warn_msg .= "<br>IRS will reject your return if you enter any information Box 12b,12c,12d,12e or 12f without any information in Box 12a ";
			$dup_warn_msg .=" </td></tr>";
		}
		if ($emp_address2_flag == 1)
		{
			$dup_warn_msg .=" <tr><td width=\"3%\" valign=\"top\"></td>";
			$dup_warn_msg .=" <td width=\"97%\" class=\"OLTBodyError\">";    
			$dup_warn_msg .= "When Employee Address Continuation (Employee Address Line 2) is significant, then a period (.) must be present in Employee State.";
			$nv_dup_warn_msg .= "<br>When Employee Address Continuation (Employee Address Line 2) is significant, then a period (.) must be present in Employee State.";
			$dup_warn_msg .=" </td></tr>";
		}
		
		/*if($nonstand_w2_ind_err_flag == 1)
		{
			$nv_dup_warn_msg .= "<p style='float:left'>Are you sure you need to check the non-standard box?  Doing so will result in the requirement to paper file the return.</p>";
			$nv_dup_warn_msg .= "<BR><label class='control control--checkbox' style='float:left' >Yes, I intended to check non-standard.<INPUT TYPE=\"CHECKBOX\"  value='1' name=PassValidationIndNonStand>&nbsp;<div class=\"control__indicator\"></div></label>";	
		}*/
		if($Box12II_err_flag == 1 && $with_held_err == 0)// && $st1_with_held_pass_err== 0 && $wagesZero_err_flag == 0 && $with_held_err == 0 && $ss_with_held_err == 0 && $stlocwag1_err == 0 && $stlocwag2_err == 0 && $stlocwag3_err == 0 && $stlocwag4_err == 0 && $nystateinc_err == 0 && $wage_comp_err == 0 && $state_comp_err == 0 && $state_wage1_err == 0 && $state_wage2_err == 0 && $sstax_err_flag == 0 && $medtax_err_flag == 0 && $wagesZero_err_flag == 0 && $sstax_err_flag == 0 && $with_held_err == 0 && $medtax_err_flag == 0 && $state_wage1_err == 0 && $state_wage2_err == 0 && $st1_with_held_pass_err == 0 && $NYStateWithHolding == 0 && $st1_with_held_err == 0 && $st2_with_held_err == 0 && $stlocwag1_err ==0 && $stlocwag2_err == 0 && $stlocwag3_err == 0 && $stlocwag4_err == 0 && $code12a_err == 0 && $emp_address2_flag == 0 && $state_wageTot_err == 0)
		{
			$nv_dup_warn_msg_review = "1";
			$nv_dup_warn_msg_heading = "Please Review";
			$med_waivr_incl_chkd="";
			if($w2_med_waivr_incl_ind == 1)
				$med_waivr_incl_chkd = "checked";
			$dup_warn_msg .=" <tr><td width=\"3%\" valign=\"top\"><INPUT TYPE=\"CHECKBOX\"  value='1' name=PassValidationInd></td>";
			$dup_warn_msg .=" <td width=\"97%\" class=\"OLTBodyError\">";    
			$dup_warn_msg .= "This W2 contains values in Box 12 code II, Medicare Waiver Payments. Check here to include these values in EIC/ACTC earned income calculations";
		  	$nv_dup_warn_msg .= "<br><label class='control control--checkbox' style='float:left' >This W2 contains values in Box 12 code II, Medicare Waiver Payments. Check here to include these values in EIC/ACTC earned income calculations<INPUT TYPE=\"CHECKBOX\"  value='1' name=PassValidationIndII $med_waivr_incl_chkd >&nbsp;<div class=\"control__indicator\"></div></label>";
		  	$nv_dup_warn_msg .= "<INPUT TYPE=\"hidden\"  value='1' name=PassValidationIndIIVal>";
			$dup_warn_msg .=" </td></tr>";
		}
		
		/*if($sch1A_partII_entry_err_flag == 1)
		{			
			$nv_dup_warn_msg_review = "1";
			$nv_dup_warn_msg_heading = "Please Review";
			$dup_warn_msg .=" <tr><td width=\"3%\" valign=\"top\"><INPUT TYPE=\"CHECKBOX\"  value='1' name=PassValidationInd></td>";
			$dup_warn_msg .=" <td width=\"97%\" class=\"OLTBodyError\">";    
			$dup_warn_msg .= "You have entries in W2 line 7 for Tips. Please review Schedule 1-A Part II entries for $emp_first_name $emp_mid_initial $emp_last_name.";
		  	$nv_dup_warn_msg .= "<label class='control control--checkbox' style='float:left' >You have entries in W2 line 7 for Tips. Please review Schedule 1-A Part II entries for $emp_first_name $emp_mid_initial $emp_last_name.</label>";	
		  	$nv_dup_warn_msg .= "<INPUT TYPE=\"hidden\"  value='1' name=PassValidationIndIIIVal>";
			$dup_warn_msg .=" </td></tr>";
		}*/
		$dup_warn_msg .=" </td></tr>";	
		$dup_warn_msg .="</table><br>";
	}
	if(($w2_clergy_ind == 1) && ($w2_church_emp_ind == 1))
	{
		$dup_warn_msg  ="<table border=\"0\" width=\"564\" style=\"border: 4px double #FF0000\" align=\"center\">";
		$dup_warn_msg .=" <tr><td colspan=2 align=center class=\"OLTBodyError\">WARNING</td></tr>";
		$dup_warn_msg .=" <tr><td width=\"3%\" valign=\"top\"></td>";
		$dup_warn_msg .=" <td width=\"97%\" class=\"OLTBodyError\">";    
		$dup_warn_msg .= "You cannot check both Minister wages and Church employee income (worked not as a minister). Check anyone that is applicable to you.";
		$dup_warn_msg .=" </td></tr>";
		$dup_warn_msg .=" </td></tr>";	
		$dup_warn_msg .="</table><br>";
		//if($nv_mode == "1")
			$nv_dup_warn_msg .= "You cannot check both Minister wages and Church employee income (worked not as a minister). Check anyone that is applicable to you.";
	}
	if($state_wageTot_err == 1)
	{
		$dup_warn_msg .=" <tr><td width=\"3%\" valign=\"top\"><INPUT TYPE=\"CHECKBOX\"  value='1' name=PassValidationIndStWags></td>";
		$dup_warn_msg .=" <td width=\"97%\" class=\"OLTBodyError\">";    
		$dup_warn_msg .= "<BR>Your total State wages income is greater than box 1 Wages amount.Check here if your information is correct.";
		if($nv_dup_warn_msg != "")
			$nv_dup_warn_msg .="<BR><BR>";
		$nv_dup_warn_msg .= "<BR>Your total State wages income is greater than box 1 Wages amount.<label class='control control--checkbox' style='float:left' >Check here if your information is correct.<INPUT TYPE=checkbox value='1' name=PassValidationIndStWags>&nbsp;<div class=\"control__indicator\"></div></label>";
		//$nv_dup_warn_msg .= "<br>".$output;
		$dup_warn_msg .=" </td></tr>";
	}	
     	//**010 End
	include("olt_efile_rej_veri_redirect.php");  echo "<form name=form1 action=\"olt_w2.php \" method=post>";
	
	echo "<input type=hidden name=PassValidationInd value=$PassValidationInd>"; 
	echo "<input type=hidden name=PassValidationIndNonStand value=$PassValidationIndNonStand>"; 
	echo "<input type=hidden name=PassValidationIndStWags value=$PassValidationIndStWags>"; 
	if($nv_mode == "1" && $nv_dup_warn_msg != "")
	{
		//echo "<br>";
		//OLTGenWarning("WARNING", $nv_dup_warn_msg, "", "");
	}
	else 
		echo $dup_warn_msg;

	BuildDynamicFormHiddenData("step=w2done&TotCountOfRows=$TotCountOfRows&TotCountOfBox12Rows=$TotCountOfBox12Rows&tot_NOL_line14=$tot_NOL_line14&id=$id&step1=$step1");
	include(PROTECTED_PATHQT."html/w2.html");

}


include("olt_pageftr.php");

?>