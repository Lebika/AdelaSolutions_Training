<?
/********************************************************************************
                      MODIFICATION  CONTROL  LOG
---------------------------------------------------------------------------------
  Mod  Date         Programmer        Comment
  ------------------------------------------------------------------------------
  001  04/13/2004   Akbar Ali        Initial Version
  002  03/15/2004   Akbar Ali        Added for form type indicator  
  003  05/05/2005   S.Balakrishnan   ACE issues fixed #1808
  004  07/08/2005   S.Auvelin Raja   Floated variables to prevent site error.
  005  06/10/2013   Jerry Thimothy J Included city allocation operations
********************************************************************************* */

	include_once("header.php");
	include_once("qt_func.php");
	
	$status = GetUniqueUserInfo($o9Ljw, $qt_user_id, $siteid, $pageid, $lasttime);	
	
	$my_page="olt_misc1099.php";
	
	include("../oltproc/olt_section_track_end.php");
 

	$err_flag=0;


	if(UDF_strtoupper($choice)=="P")//FOR PRIMARY
	{
	 $recipient_name=$full_name;
	 $misc_ssn_inp=$ssn;
	}elseif(UDF_strtoupper($choice)=="S")  //FOR SPOUSE
	{
	 $recipient_name=$sp_full_name;
	 $misc_ssn_inp=$sp_ssn;
	}else //FOR JOINT
	{
	 $recipient_name="JOINT";
	 $misc_ssn_inp=$ssn;
	}

	$misc_form_type		= fmtvalue($misc_form_type);
	if($misc_recipientid_ein_ind == 1)
	{
		$misc_ein = UDF_str_replace("-","",$misc_ein);
		$misc_ssn= fmtvalue($misc_ein);
	}
	else
	{
		//$misc_ssn_inp = UDF_str_replace("-","",$misc_ssn_inp);
		$misc_ssn= fmtvalue($misc_ssn_inp);
	}
	
	if(($payerin_1099MISC != "") || (UDF_trim($OLTPRO_masterID) != ''))
	{
		if($misc_payerid_ssn_ind == 1)
		{
			$payer_in_ssn 		= UDF_str_replace("-","",$payer_in_ssn);
			$payer_in		= fmtvalue($payer_in_ssn);
		}
		else
		{
			$payer_in_ein 		= UDF_str_replace("-","",$payer_in_ein);
			$payer_in		= fmtvalue($payer_in_ein);	
		}
	}
	$payer_name		= fmtvalue($payer_name);
	$payer_address		= fmtvalue($payer_address);
	$payer_city		= fmtvalue($payer_city);
	if($payer_state != ".")
	{
		$payer_state		= fmtvalue($payer_state);
	}
	$payer_zip		= fmtvalue($payer_zip);
	$zip_ext		= fmtvalue($zip_ext);
	$acc_nbr		= fmtvalue($acc_nbr);
	$rent			= fmtvalue($rent);
	$royalties		= fmtvalue($royalties);
	$other_inc		= fmtvalue($other_inc);
	$fed_inc_withheld	= fmtvalue($fed_inc_withheld);
	$fish_boat		= fmtvalue($fish_boat);
	$med_health_payment	= fmtvalue($med_health_payment);
	$unemp_compen		= fmtvalue($unemp_compen);
	$unemp_compen		= 0;
	$sub_payment		= fmtvalue($sub_payment);
	$direct_sale_ind	= fmtvalue($direct_sale_ind);
	$second_tin_ind		= fmtvalue($second_tin_ind);
	$misc_payerid_ssn_ind	= fmtvalue($misc_payerid_ssn_ind);
	$misc_recipientid_ein_ind= fmtvalue($misc_recipientid_ein_ind);
	$crop_insur		= fmtvalue($crop_insur);
	$acc_nbr		= fmtvalue($acc_nbr);
	//$ess_gold_payment	= fmtvalue($ess_gold_payment);
	$nonqual_def_comp	= fmtvalue($nonqual_def_comp);
	$gross_paid		= fmtvalue($gross_paid);
	$gross_paid_tot		= fmtvalue($gross_paid_tot);
	$st_tax_withheld1	= fmtvalue($st_tax_withheld1);
	$payers_st_no1		= fmtvalue($payers_st_no1);
	$st_inc1		= fmtvalue($st_inc1);
	$st_tax_withheld2	= fmtvalue($st_tax_withheld2);
	$payers_st_no2		= fmtvalue($payers_st_no2);
	$st_inc2		= fmtvalue($st_inc2);
	$payers_st1		= fmtvalue($payers_st1);
	$payers_st2		= fmtvalue($payers_st2);
	$payer_frgn_address	= fmtvalue($payer_frgn_address);
	$payer_frgn_address=UDF_str_replace("#","" ,$payer_frgn_address); 
	$payer_frgn_address=UDF_str_replace(".","" ,$payer_frgn_address); 
	$payer_frgn_address=UDF_str_replace(",","" ,$payer_frgn_address); 
	$payer_frgn_address=UDF_str_replace("  "," " ,$payer_frgn_address); 
	$payer_frgn_address=UDF_str_replace("  "," " ,$payer_frgn_address);   
	$payer_frgn_city		= fmtvalue($payer_frgn_city);
	$payer_frgn_city		= UDF_str_replace("."," " ,$payer_frgn_city); 
	$payer_frgn_city		= UDF_str_replace("  "," " ,$payer_frgn_city); 
	$payer_frgn_state		= fmtvalue($payer_frgn_state);
	$payer_frgn_state		= UDF_str_replace("  "," " ,$payer_frgn_state); 
	$payer_frgn_zip		= fmtvalue($payer_frgn_zip);
	$misc1099_payer_frgn_add_ind = (int)UDF_trim($misc1099_payer_frgn_add_ind);
	$FATCA_filing_req_ind = (int)UDF_trim($FATCA_filing_req_ind);
	$for_country = fixtext($for_country);
	$for_tax_paid = fmtvalue($for_tax_paid);
	$misc_areacode 		= UDF_trim($misc_areacode);
	$misc_phone 		= UDF_trim($misc_phone);
	$misc99_409A_deferrals	= fmtvalue($misc99_409A_deferrals);
	$misc99_409A_income	= fmtvalue($misc99_409A_income);
	$fish_pur_resale	= fmtvalue($fish_pur_resale);
	$direct_sale_ind	= (int)$direct_sale_ind;
	$second_tin_ind		= (int)$second_tin_ind;
	
	//$gross_paid = 0;
	$misc99_409A_income = 0;
	//if($OLTPRO_masterID != "")
	if($show_aloc_state_ind == 1)
	{
		$aloc_state             = UDF_trim($aloc_state);
		if($show_city_combo_ind == 1)
			$aloc_city	=	UDF_trim($aloc_city);
	}
	
	$ArrayOneZeroValue = array("0", "1");
	if(($FATCA_filing_req_ind != "") && (!IsValidValue($FATCA_filing_req_ind, $ArrayOneZeroValue)))
	{
		$err_flag = 1;
		$FATCA_filing_req_ind_err = 1;
	}
	if(($second_tin_ind != "") && (!IsValidValue($second_tin_ind, $ArrayOneZeroValue)))
	{
		$err_flag = 1;
		$second_tin_ind_err = 1;
	}
	if(($direct_sale_ind != "") && (!IsValidValue($direct_sale_ind, $ArrayOneZeroValue)))
	{
		$err_flag = 1;
		$direct_sale_ind_err = 1;
	}

	
	if($misc_areacode!="" || $misc_phone !="")
	{
		if (!(IsNumeric($misc_areacode)) || (UDF_strlen($misc_areacode) <> 3) || (!(IsValidAreaCode($misc_areacode))))
		{
			 $err_flag=1;
			 $area_err_flag=1;
		}
		if (!(IsNumeric($misc_phone)) || (UDF_strlen($misc_phone) <> 7) || (!(IsValidPhoneNum($misc_phone))))
		{
			 $err_flag=1;
			 $phone_err_flag=1;
		}
	}
	if($nv_mode=="1")
	{ 
		if(($payerin_1099MISC != "") || (UDF_trim($OLTPRO_masterID) != ''))
		{
			$cmn_frgn_addr_ind 	= "misc1099_payer_frgn_add_ind";		
			$cmn_US_addr  		= "payer_address";	//${$cmn_US_addr."Skip"} = 1;
			$cmn_US_city 		= "payer_city";  	//${$cmn_US_city."Skip"} = 1;       
			$cmn_US_state 		= "payer_state";     	//${$cmn_US_state."Skip"} = 1;  
			$cmn_US_zip 		= "payer_zip"; 		//${$cmn_US_zip."Skip"} = 1;
			$cmn_US_zip_ext		= "zip_ext";
	
			$cmn_frgn_addr          = "payer_frgn_address";	//${$cmn_frgn_addr."Skip"} = 1;
			$cmn_frgn_city 		= "payer_frgn_city";	//${$cmn_frgn_city."Skip"} = 1;
			$cmn_frgn_state 	= "payer_frgn_state";	//${$cmn_frgn_state."Skip"} = 1;
			$cmn_frgn_country_code  = "payer_frgn_country";	//${$cmn_frgn_country_code."Skip"} = 1;
			$cmn_frgn_zip 		= "payer_frgn_zip";	${$cmn_frgn_zip."Skip"} = 1;
			include("../oltproc/commonAddressPnl.php");
		}
	}
	else
	{
	if($misc1099_payer_frgn_add_ind == 1)
	{
		if(($payer_frgn_address =="") || (UDF_strlen($payer_frgn_address) < 2))
		{
			$err_flag=1;
			$payer_frgn_address_err_flag=1;
		}
		if(($payer_frgn_city != "") &&( UDF_strlen($payer_frgn_city) < 3))
		{
			$err_flag=1;
			$payer_frgn_city_err_flag=1;
		}	
		if(UDF_strlen(UDF_trim($payer_frgn_country))==0)
		{
		      $err_flag = 1;
		      $payer_frgn_country_err_flag = 1;       
		}	 			
		if(!fmtNamesp1($payer_frgn_state))
		{
			$err_flag = 1;
			$payer_frgn_state_err_flag=1;       
		}
		if(!is_null($payer_frgn_zip) && !IsValidForeignPostalCode($payer_frgn_zip))
		{
			$err_flag = 1;
			$payer_frgn_zip_err_flag=1;
		}
	}
	else
	{	
		if(($payer_address=="") || (!IsAlphaNumericsp($payer_address)))
		{
			$err_flag=1;
			$add_err_flag=1;
		}
		
		if(($payer_city=="") || (!IsAlphaNumericsp($payer_city)))
		{
			$err_flag=1;
			$city_err_flag=1;
		}
		
		//if($payer_state!=".")
		{
		if($payer_state == "")
		{
		   $err_flag=1;
		   $state_err_flag=1;
		
		}
	
		if(($payer_zip == "") || (!isNumeric($payer_zip)))
		{
		  $err_flag=1;
		  $zip_err_flag=1;
		  
		}
		
		if((isNumeric($payer_zip))&& ($payer_state == ""))
		{
			$err_flag=1;
			$state_err_flag=1;	
		}
		
		if(($payer_state != "") && ($payer_zip == ""))
		{
		  $err_flag=1;
		  $zip_err_flag=1;
		}
		
		if(($payer_zip != "") && (UDF_strlen($payer_zip) != 5))
		{
			$err_flag=1;
			$zip_err_flag=1;
		}
		$validStZip = IsValidZip($payer_state, $payer_zip);
		
		if (($payer_state != "") && ($validStZip == 0) )
		{
		  $err_flag=1;
		  $zip_err_flag=1;
		}
		
		}
        }
	}
if(($rent!="")&&(!isNumeric($rent)))
{
$err_flag=1; 
$rent_err_flag=1;
}

/*if(($for_country != "") && (!fmtnamesp($for_country)))
{
   $err_flag=1;
   $forcount_err_flag=1;
}*/


if(($payerin_1099MISC != "") || (UDF_trim($OLTPRO_masterID) != ''))
{
	$ArrayOneZeroValue = array("0", "1");
	if(($misc_payerid_ssn_ind != "") && (!IsValidValue($misc_payerid_ssn_ind, $ArrayOneZeroValue)))
	{
		$misc_payerid_ssn_ind_err = 1;
		$err_flag = 1;
	}

	if($misc_payerid_ssn_ind == 0)//EIN
	{
		if(!fmtNum($payer_in)||(UDF_strlen($payer_in)!=9))
		{
			$err_flag=1; 
			$payer_in_ein_num_err_flag=1;
		}
	
	}
	else
	{
		if(!fmtNum($payer_in)||(UDF_strlen($payer_in)!=9))
	{
		$err_flag=1; 
			$payer_in_ssn_num_err_flag=1;
		}
	}
	/*
	if($payerin_1099MISC == "Add New")
	{
		if(($payer_in_ein_num_err_flag != 1) && ($payer_in_ssn_num_err_flag != 1))
		{
			/*$query_payer ="select qt_user_id from olt_payer_details where ";
			$query_payer .= "qt_user_id=(?) "; db_sql_BuildParamArray($qt_user_id, "olt_payer_details::qt_user_id");
			$query_payer .= "and olt_payerin=(?) "; db_sql_BuildParamArray($payer_in, "olt_payer_details::olt_payerin");
			$query_payer .= "and olt_payer_name=(?) "; db_sql_BuildParamArray($payer_name, "olt_payer_details::olt_payer_name");				
			$result_payer = db_sql_query(array($query_payer), $_SQL_ParamsArray);
			$noOfRows_payer = db_num_rows(array($result_payer));
			if ($noOfRows_payer > 0 )
			{	
				$err_flag=1;
				if($misc_payerid_ssn_ind == 0)
					$payer_in_ein_num_err_flag1=1;		
				else 	
					$payer_in_ssn_num_err_flag1=1;		
			}
			db_free_result(array($result_payer));
			
			if(($payer_in_ein_num_err_flag1 != 1) && ($payer_in_ssn_num_err_flag1 !=1))*/
			/*{
				//Employer EIN cannot be equal to primary or secondary tax payers SSN.
				$query_primary ="select relation from customer where ";
				$query_primary .= "qt_user_id=(?) "; db_sql_BuildParamArray($qt_user_id, "customer::qt_user_id");
				$query_primary .= "and ssn=(?) "; db_sql_BuildParamArray($payer_in, "customer::ssn");
				$result_primary= db_sql_query(array($query_primary), $_SQL_ParamsArray);
				$noOfRows_pri  = db_num_rows(array($result_primary));
				
				if($noOfRows_pri > 0)
				{
					while($res_data=db_fetchrow(array($result_primary, DB_GETMODE_ASSOC)))
					{	
						$relation        = UDF_trim($res_data["relation"]);
						if($relation == 'P')
						{
							$err_flag	= 1;
							if($misc_payerid_ssn_ind == 0)
								$payer_in_ein_num_pri_err_flag=1;		
							else 	
								$payer_in_ein_num_sp_err_flag=1;						
						}
						else if($relation == 'S')
						{
							$err_flag	= 1;
							if($misc_payerid_ssn_ind == 0)
								$payer_in_ssn_num_pri_err_flag=1;		
							else 	
								$payer_in_ssn_num_sp_err_flag=1;
						}
					}
				}
				db_free_result(array($result_primary));
			}
		}
	}*/	
}

	//if($OLTPRO_masterID != "")
	if($show_aloc_state_ind == 1)
	{
		if($aloc_state!=".")
		{
			
			if(($aloc_state == "") || (!fmtName($aloc_state)) || (UDF_strlen($aloc_state) != 2))
			{
			  $err_flag=1;
			  $aloc_state_err_flag=1;
			}
			
			if (IsValidState($aloc_state) == 0) 
			{
			  $err_flag=1;
			  $aloc_state_err_flag=1;
			} 
			
			
		}
		
		if(($show_city_combo_ind == 1)&&(UDF_in_array($aloc_state, $aloc_state_array))&&($aloc_city==""))
		{
			$err_flag=1;
			$aloc_city_err_flag=1;
		}
	}
	

if(($royalties!="")&&(!isNumeric($royalties)))
{
$err_flag=1; 
$royal_err_flag=1;
}


if(($other_inc!="")&&(!isNumeric($other_inc)))
{
$err_flag=1; 
$other_err_flag=1;
}

if(($fed_inc_withheld!="")&&(!isNumeric($fed_inc_withheld)))
{
$err_flag=1; 
$fed_err_flag=1;
}


if(($fish_boat!="")&&(!isNumeric($fish_boat)))
{
$err_flag=1; 
$fish_err_flag=1;
}

if(($med_health_payment!="")&&(!isNumeric($med_health_payment)))
{
$err_flag=1; 
$med_err_flag=1;
}

/*if(($unemp_compen!="")&&(!isNumeric($unemp_compen)))
{
$err_flag=1; 
$unemp_err_flag=1;
}*/

if(($sub_payment!="")&&(!isNumeric($sub_payment)))
{
$err_flag=1; 
$sub_err_flag=1;
}

if(($crop_insur!="")&&(!isNumeric($crop_insur)))
{
	$err_flag=1; 
	$crop_err_flag=1;

}



/*
if(($ess_gold_payment!="")&&(!isNumeric($ess_gold_payment)))
{
$err_flag=1; 
$ess_err_flag=1;
}
*/

if(($nonqual_def_comp!="")&&(!isNumeric($nonqual_def_comp)))
{
	$err_flag=1; 
	$nonqual_def_comp_err_flag=1;
}

if(($gross_paid!="")&&(!isNumeric($gross_paid)))
{
$err_flag=1; 
$gross_err_flag=1;
}


if(($gross_paid_tot!="")&&(!isNumeric($gross_paid_tot)))
{
$err_flag=1; 
$gross_paid_tot_err_flag=1;
}
if((UDF_round((float)$gross_paid_tot) > 0)&&(UDF_round((float)$gross_paid) == 0) && ($PassValidationInd != 1))
{
	$err_flag=1; 
	$gross_paid_val_err_flag=1;
}
if(($st_tax_withheld1!="")&&(!isNumeric($st_tax_withheld1)))
{
	$err_flag=1; 
	$withheld1_err_flag=1;
}elseif(($st_tax_withheld1>0)&&($payers_st1==""))
{
	$err_flag=1; 
	$payers_st1_err=1;
}

/*if(($for_tax_paid != "") && (!isNumeric($for_tax_paid)))
{
   $err_flag=1;
   $for_tax_paid_err_flag=1;
}*/


if($payers_st1!="")
{
	if(!isAlphaNumeric($payers_st_no1))
	{
		$err_flag=1; 
		$no1_err_flag=1;
	}
	else if (($payers_st1 == "MN") && ($st_tax_withheld1 > 0) && ((!fmtNum($payers_st_no1)) || ($payers_st_no1 == "") || (UDF_strlen($payers_st_no1) != 7)))
	{
		$err_flag = 1;
		$no1_err_flag = 1;
	}
	
	if (IsValidState($payers_st1) == 0)
	{
		$err_flag=1;
		$payers_st1_err=1;
	}
}

if($payers_st2!="")
{
	if(!isAlphaNumeric($payers_st_no2))
	{
		$err_flag = 1;
		$no2_err_flag = 1;
	}
	else if (($payers_st2 == "MN") && ($st_tax_withheld2 > 0) && ((!fmtNum($payers_st_no2)) || ($payers_st_no2 == "") || (UDF_strlen($payers_st_no2) != 7)))
	{
		$err_flag = 1;
		$no2_err_flag = 1;
	}
	
	if (IsValidState($payers_st2) == 0)
	{
		$err_flag=1;
		$payers_st2_err=1;
	}
}

if(($st_inc1!="")&&(!isNumeric($st_inc1)))
{

	$err_flag=1; 
	$inc1_err_flag=1;

}elseif(($st_inc1>0) &&($payers_st1==""))
{
	$err_flag=1; 
	$payers_st1_err=1;
}

if(($st_tax_withheld2!="")&&(!isNumeric($st_tax_withheld2)))
{
	$err_flag=1; 
	$withheld2_err_flag=1;
	
}elseif(($st_tax_withheld2>0)&&($payers_st2==""))
{
	$err_flag=1; 
	$payers_st2_err=1;
}

if(($st_inc2!="")&&(!isNumeric($st_inc2)))
{
	$err_flag=1; 
	$inc2_err_flag=1;

}elseif(($st_inc2>0) &&($payers_st2==""))
{
	$err_flag=1; 
	$payers_st2_err=1;
}

if(($misc99_409A_deferrals!="")&&(!isNumeric($misc99_409A_deferrals)))
{
	$err_flag=1; 
	$deferrals_err_flag=1;	
}

/*if(($misc99_409A_income!="")&&(!isNumeric($misc99_409A_income)))
{
	$err_flag=1; 
	$income_err_flag=1;	
}*/

if(($fish_pur_resale!="")&&(!isNumeric($fish_pur_resale)))
{
	$err_flag=1; 
	$fish_pur_resale_err_flag=1;	
}
$ArrayOneZeroValue = array("0", "1");
if(($misc_recipientid_ein_ind != "") && (!IsValidValue($misc_recipientid_ein_ind, $ArrayOneZeroValue)))
{
	$misc_recipientid_ein_ind_err = 1;
	$err_flag = 1;
}
$ArrayPSValue = array("P", "S");
if((UDF_strtoupper($choice) != "") && (!IsValidValue(UDF_strtoupper($choice), $ArrayPSValue)))
{
	$choice_err = 1;
	$err_flag = 1;
}
if($misc_recipientid_ein_ind == 1)//EIN
{
	if((UDF_strlen($misc_ssn) != 9) || (!isNumeric($misc_ssn)) || ($misc_ssn == "000000000"))	
	{
	  $err_flag=1;
	  $misc_ein_num_err_flag=1;
	} 
}
/*else
{
	if((UDF_strlen($misc_ssn) != 9) || (!isNumeric($misc_ssn)) || ($misc_ssn == "000000000") || ((!IsValidSSN($misc_ssn)) && (!IsValidITIN($misc_ssn))))	
	{
	  $err_flag=1;
	  $misc_ssn_inp_num_err_flag=1;
	} 

}*/

if (($payers_st1 == "OH" || $payers_st1 == "NY" || $payers_st1 == "IL") && (UDF_round($st_tax_withheld1) > (UDF_round($st_inc1))) && ($PassValidationIndStDist != 1))  //$payers_st1 == "IN" || 
{  
 	$err_flag=1;
	$inc1_IN_err_flag=1;
}
if (($payers_st2 == "OH" || $payers_st2 == "NY" || $payers_st2 == "IL") && (UDF_round($st_tax_withheld2) > (UDF_round($st_inc2))) && ($PassValidationIndStDist != 1))  //$payers_st2 == "IN" || 
{  
 	$err_flag=1;
	$inc2_IN_err_flag=1;
}

	if(UDF_trim($OLTPRO_masterID) == '')
	{	
		$form_name = "1099MISC";
		$cmn_payer_combo 	= "payerin_1099MISC";
		$cmn_payer_name1 	= "payer_name";
		$cmn_payer_name2 	= "";
		$cmn_account_nbr 	= "acc_nbr";
		include("../oltproc/olt_payer_common_val.php");
		
		if($err_flag!=1)
		{	
				$olt_payer_name 	= fmtvalue($payer_name);				
				$olt_payerin		= UDF_trim($payer_in);
				$olt_payer_account_nbr	= UDF_trim($acc_nbr);
				$olt_payer_frgn_addrs_ind = (int)UDF_trim($misc1099_payer_frgn_add_ind);
				if($misc1099_payer_frgn_add_ind == 1)
				{
					$olt_payer_frgn_address	=FormatAddress($payer_frgn_address);
					$olt_payer_frgn_address2 = "";
					$olt_payer_frgn_city	= fmtvalue($payer_frgn_city);
					$olt_payer_frgn_state	= fmtvalue($payer_frgn_state);
					$olt_payer_frgn_country	= fmtvalue($payer_frgn_country);
					$olt_payer_frgn_zip	= fmtvalue($payer_frgn_zip);
				}
				else
				{	
					$olt_payer_us_address 	= FormatAddress($payer_address);					
					$olt_payer_us_address2 	= "";
					$olt_payer_us_city 	= FormatCity($payer_city);
					$olt_payer_us_state 	= fmtvalue($payer_state);
					$olt_payer_us_zip 	= fmtvalue($payer_zip);
					$olt_payer_us_zip_ext   = fmtvalue($zip_ext);
				}
			
			if($payerin_1099MISC == "Add New")
			{	
				$action = "Add New";
				$called_frm_InputPage = 1;
				include("../oltproc/olt_get_payer_details.php");
			}
			else
			{
				$action = "";		
				$olt_payer_details_id = $payerin_1099MISC;
				$called_frm_InputPage = 1;
				include("../oltproc/olt_get_payer_details.php"); 
				
				/*$payer_name 			= $olt_payer_name;							
				$payer_in			= $olt_payerin;
				$acc_nbr			= $olt_payer_account_nbr;
				$misc1099_payer_frgn_add_ind 	= $olt_payer_frgn_addrs_ind;
				
				if($misc1099_payer_frgn_add_ind == 1)
				{
					$payer_frgn_address		= $olt_payer_frgn_address; 							
					$payer_frgn_city		= $olt_payer_frgn_city;
					$payer_frgn_state		= $olt_payer_frgn_state;
					$payer_frgn_country		= $olt_payer_frgn_country;
					$payer_frgn_zip			= $olt_payer_frgn_zip;
				}
				else
				{
					$payer_address	 		= $olt_payer_us_address;					
					$payer_city 			= $olt_payer_us_city;
					$payer_state 			= $olt_payer_us_state;
					$payer_zip 			= $olt_payer_us_zip;
					$zip_ext 			= $olt_payer_us_zip_ext;
				}*/
			}
		}	
	}
	else
	{	
		$payer_name = UDF_str_replace('&',' ',$payer_name);//003	
	
		if(($payer_name=="") || (!isAlphaNumericnumsp($payer_name)))
		{
			$err_flag=1;
			$name_empty_err_flag=1;
		}
		
		if(!isAlphaNumeric($acc_nbr) && ($acc_nbr!=""))
		{
			$err_flag=1; 
			$acc_err_flag=1;
		}	
	}

if($err_flag!=1)
{

	$id = (int) $id; 
	
	//  ------ 004  BEGIN ------
	
	$rent			= (float) $rent;          
	$royalties 		= (float) $royalties;             
	$other_inc 		= (float) $other_inc;             
	$fed_inc_withheld 	= (float) $fed_inc_withheld;	
	$fish_boat 		= (float) $fish_boat;             
	$med_health_payment 	= (float) $med_health_payment;	
	$unemp_compen 		= (float) $unemp_compen;          
	$st_inc2 		= (float) $st_inc2;                 
	$sub_payment 		= (float) $sub_payment;           
	$crop_insur 		= (float) $crop_insur;            
	$gross_paid 		= (float) $gross_paid;            
	$gross_paid_tot 	= (float) $gross_paid_tot;	
	//$ess_gold_payment 	= (float) $ess_gold_payment;
	$nonqual_def_comp 	= (float) $nonqual_def_comp;	
	$st_tax_withheld1 	= (float) $st_tax_withheld1;	
	$st_tax_withheld2 	= (float) $st_tax_withheld2;	
	$st_inc1 		= (float) $st_inc1;   
	$misc99_409A_deferrals 	= (float) $misc99_409A_deferrals;	
	$misc99_409A_income 	= (float) $misc99_409A_income;	
	$fish_pur_resale 	= (float) $fish_pur_resale;
	
	$for_tax_paid = 0;
	$for_country = "";              

	//  ------ 004  END ------
	
	if($payer_state==".")//**008
	{
	 	$payer_zip="";
	 	$zip_ext="";
	}

	if($newaction=="addmisc1099")
	{
		
		if($choice=="j")  
		{
			$misc_ssn_inp=$ssn;
		}
		elseif($choice=="s")  
		{
			$misc_ssn_inp=$sp_ssn;
		}
		else  
		{
			$misc_ssn_inp=$ssn;
		}
			
		if($misc_recipientid_ein_ind == 1)
		{
		}
		else
		{
			$misc_ssn=$misc_ssn_inp;
		}
			

$_SQL_DataArray[] = array( "key"=> "qt_user_id", "val"=>$qt_user_id, "table"=>"misc1099");
$_SQL_DataArray[] = array( "key"=> "ssn", "val"=> $misc_ssn, "table"=>"misc1099");
$_SQL_DataArray[] = array( "key"=> "payer_in", "val"=> $payer_in, "table"=>"misc1099");
$out_sqlparm = db_sql_paramformat($_SQL_DataArray);

		$insert ="insert into misc1099(".$out_sqlparm['_SQL_FieldClause'].") values (".$out_sqlparm['_SQL_ValueClause'].")";
		$result = db_sql_query(array($insert), $_SQL_ParamsArray);
	
		$query ="select max(misc1099_id) AS id from misc1099 where ";
		$query .= "qt_user_id=(?) "; db_sql_BuildParamArray($qt_user_id, "misc1099::qt_user_id");
		$result = db_sql_query(array($query), $_SQL_ParamsArray);
		
		$res_data	 = db_fetchrow(array($result, DB_GETMODE_ASSOC));
		$id	 	 = UDF_trim($res_data["id"]);
		db_free_result(array($result));
		
		$newaction = "editmisc1099";
	}
	if($newaction=="editmisc1099")
	{
  
		if($direct_sale_ind=="") $direct_sale_ind=0;
		
		if($second_tin_ind=="")  $second_tin_ind=0; 	
		
		if(UDF_strtoupper($choice)=="J")  
		{
			$recipient_name=$full_name ." " . $sp_full_name;
			$whose_misc="J";
			$misc_ssn_inp=$ssn;
		}
		elseif(UDF_strtoupper($choice)=="S")  
		{
			$recipient_name=$sp_full_name;
			$whose_misc="S";
			$misc_ssn_inp=$sp_ssn;
		}
		else  
		{
			$recipient_name=$full_name;
			$whose_misc="P";
			$misc_ssn_inp=$ssn;
		}	
		
		if($misc_recipientid_ein_ind == 1)
		{
		}
		else
		{
			$misc_ssn=$misc_ssn_inp;
		}
		if(UDF_strlen($recipient_name) > 50)
			$recipient_name = UDF_trim(UDF_substr($recipient_name,0,50));
		$whose_misc = UDF_strtoupper($whose_misc);
		
		$_SQL_DataArray[] = array( "key"=> "whose_misc", "val"=>$whose_misc, "table"=>"misc1099");		
		if($misc_recipientid_ein_ind == 1)		
			$_SQL_DataArray[] = array( "key"=> "ssn", "val"=>$misc_ssn, "table"=>"misc1099");		
		else		
			$_SQL_DataArray[] = array( "key"=> "ssn", "val"=>$misc_ssn_inp, "table"=>"misc1099");		
		$_SQL_DataArray[] = array( "key"=> "payer_in", "val"=>$payer_in, "table"=>"misc1099");		
		$_SQL_DataArray[] = array( "key"=> "payer_name", "val"=>$payer_name , "table"=>"misc1099");		
		$_SQL_DataArray[] = array( "key"=> "royalties", "val"=>(float)$royalties, "table"=>"misc1099");		
		$_SQL_DataArray[] = array( "key"=> "acc_nbr", "val"=>$acc_nbr, "table"=>"misc1099");		
		$_SQL_DataArray[] = array( "key"=> "rent", "val"=>(float)$rent, "table"=>"misc1099");		
		if($misc1099_payer_frgn_add_ind == 1)		
    		{		
			$_SQL_DataArray[] = array( "key"=> "misc1099_payer_frgn_add_ind", "val"=>'1', "table"=>"misc1099");		
			$_SQL_DataArray[] = array( "key"=> "payer_frgn_address", "val"=>$payer_frgn_address, "table"=>"misc1099");		
			$_SQL_DataArray[] = array( "key"=> "payer_frgn_city", "val"=>$payer_frgn_city, "table"=>"misc1099");		
			$_SQL_DataArray[] = array( "key"=> "payer_frgn_state", "val"=>$payer_frgn_state, "table"=>"misc1099");		
			$_SQL_DataArray[] = array( "key"=> "payer_frgn_country", "val"=>$payer_frgn_country, "table"=>"misc1099");		
			$_SQL_DataArray[] = array( "key"=> "payer_frgn_zip", "val"=>$payer_frgn_zip, "table"=>"misc1099");		
				    			
			$_SQL_DataArray[] = array( "key"=> "payer_address", "val"=>'', "table"=>"misc1099");		
			$_SQL_DataArray[] = array( "key"=> "payer_city", "val"=>'', "table"=>"misc1099");		
			$_SQL_DataArray[] = array( "key"=> "payer_state", "val"=>'', "table"=>"misc1099");		
			$_SQL_DataArray[] = array( "key"=> "payer_zip", "val"=>'', "table"=>"misc1099");		
			$_SQL_DataArray[] = array( "key"=> "zip_ext", "val"=>'', "table"=>"misc1099");		
    		}		
    		else		
    		{		
		         $zip_ext = UDF_substr($zip_ext,0,4);	
				$_SQL_DataArray[] = array( "key"=> "misc1099_payer_frgn_add_ind", "val"=>'0', "table"=>"misc1099");		
				$_SQL_DataArray[] = array( "key"=> "payer_frgn_address", "val"=>'', "table"=>"misc1099");		
				$_SQL_DataArray[] = array( "key"=> "payer_frgn_city", "val"=>'', "table"=>"misc1099");		
				$_SQL_DataArray[] = array( "key"=> "payer_frgn_state", "val"=>'', "table"=>"misc1099");		
				$_SQL_DataArray[] = array( "key"=> "payer_frgn_country", "val"=>'', "table"=>"misc1099");		
				$_SQL_DataArray[] = array( "key"=> "payer_frgn_zip", "val"=>'', "table"=>"misc1099");		
				    				
				$_SQL_DataArray[] = array( "key"=> "payer_address", "val"=>$payer_address, "table"=>"misc1099");		
				$_SQL_DataArray[] = array( "key"=> "payer_city", "val"=>$payer_city, "table"=>"misc1099");		
				$_SQL_DataArray[] = array( "key"=> "payer_state", "val"=>$payer_state, "table"=>"misc1099");		
				$_SQL_DataArray[] = array( "key"=> "payer_zip", "val"=>$payer_zip, "table"=>"misc1099");		
				$_SQL_DataArray[] = array( "key"=> "zip_ext", "val"=>$zip_ext, "table"=>"misc1099");		
		}		
				$_SQL_DataArray[] = array( "key"=> "other_inc", "val"=>(float)$other_inc, "table"=>"misc1099");		
				$_SQL_DataArray[] = array( "key"=> "fed_inc_withheld", "val"=>(float)$fed_inc_withheld, "table"=>"misc1099");		
				$_SQL_DataArray[] = array( "key"=> "fish_boat", "val"=>(float)$fish_boat, "table"=>"misc1099");		
				$_SQL_DataArray[] = array( "key"=> "med_health_payment", "val"=>(float)$med_health_payment, "table"=>"misc1099");		
				$_SQL_DataArray[] = array( "key"=> "unemp_compen", "val"=>(float)$unemp_compen, "table"=>"misc1099");		
				$_SQL_DataArray[] = array( "key"=> "sub_payment", "val"=>(float)$sub_payment, "table"=>"misc1099");		
				$_SQL_DataArray[] = array( "key"=> "direct_sale_ind", "val"=>(int)$direct_sale_ind, "table"=>"misc1099");		
				$_SQL_DataArray[] = array( "key"=> "second_TIN_ind", "val"=>(int)$second_tin_ind, "table"=>"misc1099");		
				$_SQL_DataArray[] = array( "key"=> "misc_recipientid_ein_ind", "val"=>(int)$misc_recipientid_ein_ind, "table"=>"misc1099");		
				if(($payerin_1099MISC != "") || (UDF_trim($OLTPRO_masterID) != ''))		
		$_SQL_DataArray[] = array( "key"=> "misc_payerid_ssn_ind", "val"=>(int)$misc_payerid_ssn_ind, "table"=>"misc1099");		
				//else			
		//$_SQL_DataArray[] = array( "key"=> "misc_payerid_ssn_ind", "val"=>'0', "table"=>"misc1099");		
		$_SQL_DataArray[] = array( "key"=> "crop_insur", "val"=>(float)$crop_insur, "table"=>"misc1099");		
						
				if($show_aloc_state_ind == 1)		
				{		
		$_SQL_DataArray[] = array( "key"=> "aloc_state", "val"=>$aloc_state, "table"=>"misc1099");		
					if($show_city_combo_ind == 1)		
		$_SQL_DataArray[] = array( "key"=> "aloc_city", "val"=>$aloc_city, "table"=>"misc1099");		
				}		
		//$_SQL_DataArray[] = array( "key"=> "ess_gold_payment", "val"=>(float)$ess_gold_payment, "table"=>"misc1099");		
		$_SQL_DataArray[] = array( "key"=> "nonqual_def_comp", "val"=>(float)$nonqual_def_comp, "table"=>"misc1099");		
		$_SQL_DataArray[] = array( "key"=> "gross_paid", "val"=>(float)$gross_paid, "table"=>"misc1099");		
		$_SQL_DataArray[] = array( "key"=> "st_tax_withheld1", "val"=>(float)$st_tax_withheld1, "table"=>"misc1099");		
		$_SQL_DataArray[] = array( "key"=> "payer_st_no1", "val"=>$payers_st_no1, "table"=>"misc1099");		
		$_SQL_DataArray[] = array( "key"=> "st_inc1", "val"=>(float)$st_inc1, "table"=>"misc1099");		
		$_SQL_DataArray[] = array( "key"=> "st_tax_withheld2", "val"=>(float)$st_tax_withheld2, "table"=>"misc1099");		
		$_SQL_DataArray[] = array( "key"=> "payer_st_no2", "val"=>$payers_st_no2, "table"=>"misc1099");		
		$_SQL_DataArray[] = array( "key"=> "st_inc2", "val"=>(float)$st_inc2, "table"=>"misc1099");		
		$_SQL_DataArray[] = array( "key"=> "payer_st1", "val"=>$payers_st1, "table"=>"misc1099");		
		$_SQL_DataArray[] = array( "key"=> "payer_st2", "val"=>$payers_st2, "table"=>"misc1099");		
		$_SQL_DataArray[] = array( "key"=> "recipient_name", "val"=>$recipient_name, "table"=>"misc1099");		
		$_SQL_DataArray[] = array( "key"=> "gross_paid_tot", "val"=>(float)$gross_paid_tot, "table"=>"misc1099");		
		$_SQL_DataArray[] = array( "key"=> "for_country", "val"=>$for_country, "table"=>"misc1099");		
		$_SQL_DataArray[] = array( "key"=> "for_tax_paid", "val"=>(float)$for_tax_paid, "table"=>"misc1099");		
		$_SQL_DataArray[] = array( "key"=> "misc_areacode", "val"=>$misc_areacode, "table"=>"misc1099");		
		$_SQL_DataArray[] = array( "key"=> "misc_phone", "val"=>$misc_phone, "table"=>"misc1099");		
		$_SQL_DataArray[] = array( "key"=> "prior_year_imported_ind", "val"=>0, "table"=>"misc1099");		
		$_SQL_DataArray[] = array( "key"=> "imported_not_visited_ind", "val"=>'0', "table"=>"misc1099");		
		$_SQL_DataArray[] = array( "key"=> "FATCA_filing_req_ind", "val"=>(int)$FATCA_filing_req_ind, "table"=>"misc1099");		
		$_SQL_DataArray[] = array( "key"=> "misc99_409A_deferrals", "val"=>(float)$misc99_409A_deferrals, "table"=>"misc1099");		
		$_SQL_DataArray[] = array( "key"=> "misc99_409A_income", "val"=>(float)$misc99_409A_income, "table"=>"misc1099");		
		$_SQL_DataArray[] = array( "key"=> "fish_pur_resale", "val"=>(float)$fish_pur_resale, "table"=>"misc1099");		
		$_SQL_DataArray[] = array( "key"=> "payer_details_id", "val"=>$olt_payer_details_id, "table"=>"misc1099");
						
		$out_sqlparm = db_sql_paramformat($_SQL_DataArray);

		$query_clause="update misc1099 set ".$out_sqlparm["_SQL_UpdateClause"]." WHERE ";
		$query_clause.= "qt_user_id=(?) "; db_sql_BuildParamArray($qt_user_id, "misc1099::qt_user_id");
    		$query_clause.= " and misc1099_id=(?) "; db_sql_BuildParamArray($id, "misc1099::misc1099_id");
		$result = db_sql_query(array($query_clause), $_SQL_ParamsArray);

		
 	
	}
	
	
$_SQL_DataArray[] = array( "key"=> "misc1099_ind", "val"=>1, "table"=>"organiser_ind");	
$out_sqlparm = db_sql_paramformat($_SQL_DataArray);

$query_clause="update organiser_ind set ".$out_sqlparm["_SQL_UpdateClause"]." WHERE ";
$query_clause.= "qt_user_id=(?) "; db_sql_BuildParamArray($qt_user_id, "organiser_ind::qt_user_id");
	$insert_result = db_sql_query(array($query_clause), $_SQL_ParamsArray);
	
	if($misc_recipientid_ein_ind == 0)
	{
		$pro_ein_info = array("ein"=>$payer_in,"eName"=>$payer_name,"eAddress"=>$payer_address, "eCity"=>$payer_city, "eState"=>$payer_state, "eZipCode"=>$payer_zip, "eZipExt"=>$zip_ext);
		include("oltpro_update_ein_db.php");  
	}
	
	if($form1099misc_schcflow == 1 && $form1099misc_schcEditflow != 1)
    	{
    		
    		$schdC_misc_id_tmp="";
    		$query ="select schdC_misc_id from scheduleC where ";
    		$query .= "qt_user_id=(?) "; db_sql_BuildParamArray($qt_user_id, "scheduleC::qt_user_id");
    		$query .= "and schdC_id=(?) "; db_sql_BuildParamArray($schdC_id_frmc, "scheduleC::schdC_id");
		$result = db_sql_query(array($query), $_SQL_ParamsArray);
		$noOfRows = db_num_rows(array($result));		
		if ($noOfRows > 0) 
		{ 
			if($res_data	= db_fetchrow(array($result, DB_GETMODE_ASSOC)))
			{				
				$schdC_misc_id 	= UDF_trim($res_data["schdC_misc_id"]);
				if($schdC_misc_id == "")
					$schdC_misc_id_tmp = $id."#";
				else if($schdC_misc_id != "")
				{
					if(UDF_strstr($schdC_misc_id,$id) == true)
					{
					}
					else
					{
						$schdC_misc_id_tmp = $schdC_misc_id;
						$schdC_misc_id_tmp .= $id."#";
					}
					
				}
				
$_SQL_DataArray[] = array( "key"=> "schdC_misc_id", "val"=>$schdC_misc_id_tmp, "table"=>"scheduleC");				
$out_sqlparm = db_sql_paramformat($_SQL_DataArray);

$query_clause="update scheduleC set ".$out_sqlparm["_SQL_UpdateClause"]." WHERE ";
$query_clause.= "qt_user_id=(?) "; db_sql_BuildParamArray($qt_user_id, "scheduleC::qt_user_id");
$query_clause.= " and schdC_id=(?) "; db_sql_BuildParamArray($schdC_id_frmc, "scheduleC::schdC_id");
				$insert_result= db_sql_query(array($query_clause), $_SQL_ParamsArray);
				
				db_free_result(array($insert_result));	
			}
		}
    	}
    	if($form1099misc_schEflow == 1 && $form1099misc_scheEditflow != 1)
    	{
    		
    		$sche_misc_id_tmp="";
    		$query ="select sche_misc_id from sche_form_partI where ";
    		$query .= "qt_user_id=(?) "; db_sql_BuildParamArray($qt_user_id, "sche_form_partI::qt_user_id");
    		$query .= "and sche_partI_id=(?) "; db_sql_BuildParamArray($sche_partI_id_frme, "sche_form_partI::sche_partI_id");
		$result = db_sql_query(array($query), $_SQL_ParamsArray);
		$noOfRows = db_num_rows(array($result));		
		if ($noOfRows > 0) 
		{ 
			if($res_data	= db_fetchrow(array($result, DB_GETMODE_ASSOC)))
			{				
				$sche_misc_id 	= UDF_trim($res_data["sche_misc_id"]);
				if($sche_misc_id == "")
					$sche_misc_id_tmp = $id.",";
				else if($sche_misc_id != "")
				{
					if(UDF_strstr($sche_misc_id,$id) == true)
					{
					}
					else
					{
						$sche_misc_id_tmp = $sche_misc_id;
						$sche_misc_id_tmp .= $id.",";
					}
					
				}
				
$_SQL_DataArray[] = array( "key"=> "sche_misc_id", "val"=>$sche_misc_id_tmp, "table"=>"sche_form_partI");				
								
$out_sqlparm = db_sql_paramformat($_SQL_DataArray);

$query_clause="update sche_form_partI set ".$out_sqlparm["_SQL_UpdateClause"]." WHERE ";
$query_clause.= "qt_user_id=(?) "; db_sql_BuildParamArray($qt_user_id, "sche_form_partI::qt_user_id");
$query_clause.= " and sche_partI_id=(?) "; db_sql_BuildParamArray($sche_partI_id_frme, "sche_form_partI::sche_partI_id");
				$insert_result= db_sql_query(array($query_clause), $_SQL_ParamsArray);
				
				db_free_result(array($insert_result));	
			}
		}
    	}
    	if($form1099misc_schFflow == 1 && $form1099misc_schFEditflow != 1)
	{
    		
    		$schdF_misc_id_tmp="";
    		$query ="select schdF_misc_id from scheduleF where ";
    		$query .= "qt_user_id=(?) "; db_sql_BuildParamArray($qt_user_id, "scheduleF::qt_user_id");
    		$query .= "and scheduleF_id=(?) "; db_sql_BuildParamArray($scheduleF_id_frmF, "scheduleF::scheduleF_id");
		$result = db_sql_query(array($query), $_SQL_ParamsArray);
		$noOfRows = db_num_rows(array($result));		
		if ($noOfRows > 0) 
		{ 
			if($res_data	= db_fetchrow(array($result, DB_GETMODE_ASSOC)))
			{				
				$schdF_misc_id 	= UDF_trim($res_data["schdF_misc_id"]);
				if($schdF_misc_id == "")
					$schdF_misc_id_tmp = $id."#";
				else if($schdF_misc_id != "")
				{
					if(UDF_strstr($schdF_misc_id,$id) == true)
					{
					}
					else
					{
						$schdF_misc_id_tmp = $schdF_misc_id;
						$schdF_misc_id_tmp .= $id."#";
					}
					
				}
				
$_SQL_DataArray[] = array( "key"=> "schdF_misc_id", "val"=>$schdF_misc_id_tmp, "table"=>"scheduleF");				
$out_sqlparm = db_sql_paramformat($_SQL_DataArray);

$query_clause="update scheduleF set ".$out_sqlparm["_SQL_UpdateClause"]." WHERE ";
$query_clause.= "qt_user_id=(?) "; db_sql_BuildParamArray($qt_user_id, "scheduleF::qt_user_id");
$query_clause.= " and scheduleF_id=(?) "; db_sql_BuildParamArray($scheduleF_id_frmF, "scheduleF::scheduleF_id");
				$insert_result= db_sql_query(array($query_clause), $_SQL_ParamsArray);
				
				db_free_result(array($insert_result));	
			}
		}
    	}
    	if($form1099misc_schcflow == 1)
	{
		if($rent > 0) $Box1_2_ind = "C";
		
		if($royalties > 0) $Box2_ind = "C";
			
		if($other_inc > 0) $Box3_ind = "C";
			
		if($fish_boat > 0) $Box5_ind = "C";
		
		if($med_health_payment > 0) $Box6_ind = "C";
		
		if($unemp_compen > 0) $Box7_ind = "C";
		
		if($gross_paid > 0) $Box14_ind = "C";
		
		$Box10_ind = "";
		
		$_SQL_DataArray[] = array( "key"=> "Box1_2_ind", "val"=>$Box1_2_ind, "table"=>"misc1099");			
		$_SQL_DataArray[] = array( "key"=> "Box2_ind", "val"=>$Box2_ind, "table"=>"misc1099");
		$_SQL_DataArray[] = array( "key"=> "Box3_ind", "val"=>$Box3_ind, "table"=>"misc1099");			
		$_SQL_DataArray[] = array( "key"=> "Box5_ind", "val"=>$Box5_ind, "table"=>"misc1099");			
		$_SQL_DataArray[] = array( "key"=> "Box6_ind", "val"=>$Box6_ind, "table"=>"misc1099");			
		$_SQL_DataArray[] = array( "key"=> "Box7_ind", "val"=>$Box7_ind, "table"=>"misc1099");			
		$_SQL_DataArray[] = array( "key"=> "Box10_ind", "val"=>$Box10_ind, "table"=>"misc1099");			
		$_SQL_DataArray[] = array( "key"=> "Box14_ind", "val"=>$Box14_ind, "table"=>"misc1099");			
								
		$_SQL_DataArray[] = array( "key"=> "SchF_type12_ind", "val"=>'', "table"=>"misc1099");			
		$_SQL_DataArray[] = array( "key"=> "SchF_type3_ind", "val"=>'', "table"=>"misc1099");			
		$_SQL_DataArray[] = array( "key"=> "SchF_type7_ind", "val"=>'', "table"=>"misc1099");			
		$_SQL_DataArray[] = array( "key"=> "SchF_type14_ind", "val"=>'', "table"=>"misc1099");			
		$_SQL_DataArray[] = array( "key"=> "misc1099_med_waiver_paymt", "val"=>'0', "table"=>"misc1099");			
		$_SQL_DataArray[] = array( "key"=> "misc1099_med_incl_eic_ind", "val"=>'0', "table"=>"misc1099");			
		$_SQL_DataArray[] = array( "key"=> "misc_med_waiver_paymt_bx7", "val"=>'0', "table"=>"misc1099");			
		$_SQL_DataArray[] = array( "key"=> "misc_med_incl_eic_bx7_ind", "val"=>'0', "table"=>"misc1099");			
		$out_sqlparm = db_sql_paramformat($_SQL_DataArray);
		
		$query_clause = "update misc1099 set ".$out_sqlparm["_SQL_UpdateClause"]." WHERE ";
		$query_clause.= "qt_user_id=(?) "; db_sql_BuildParamArray($qt_user_id, "misc1099::qt_user_id");
		$query_clause.= " and misc1099_id=(?) "; db_sql_BuildParamArray($id, "misc1099::misc1099_id");
		$result = db_sql_query(array($query_clause), $_SQL_ParamsArray);
		db_free_result(array($result));
		
		if($rent > 0 || $royalties > 0 || $unemp_compen > 0 || $med_health_payment > 0 || $other_inc > 0 || $gross_paid > 0)
		{
			include_once("olt_pagehdr.php");
			include("olt_efile_rej_veri_redirect.php");  
		 	echo "<form name=form1 action=\"olt_misc1099_formtype.php \" method=post>";
			BuildDynamicFormHiddenData("id=$id&schdC_id_frmc=$schdC_id_frmc&form1099misc_schcflow=$form1099misc_schcflow");
			include(PROTECTED_PATHQT."html/misc1099_formtype.html");
		}
		else
		{
			include_once("olt_pagehdr.php");
			include("olt_efile_rej_veri_redirect.php");  
	 		echo "<form name=form1 action=\"olt_schdC_income.php \" method=post>";
			BuildDynamicFormHiddenData("id=$id&schdC_id_frmc=$schdC_id_frmc");
			include(PROTECTED_PATHQT."html/schdC_income.html");
		}
	}
	else if($form1099misc_schEflow == 1)
	{
		include_once("olt_pagehdr.php");
		include("olt_efile_rej_veri_redirect.php");  
	 	echo "<form name=form1 action=\"olt_schdE_income_expense.php \" method=post>";
		BuildDynamicFormHiddenData("id=$id&sche_partI_id_frme=$sche_partI_id_frme");
		include(PROTECTED_PATHQT."html/schdE_income_expense.html");
	}
	else if($form1099misc_schFflow == 1)
	{
		if($rent > 0 || $royalties > 0 || $unemp_compen > 0 || $med_health_payment > 0 || $other_inc > 0 || $gross_paid > 0 || $crop_insur > 0)
		{
		include_once("olt_pagehdr.php");
		include("olt_efile_rej_veri_redirect.php");  
	 	echo "<form name=form1 action=\"olt_misc1099_formtype.php \" method=post>";
		BuildDynamicFormHiddenData("id=$id&scheduleF_id_frmF=$scheduleF_id_frmF&form1099misc_schFflow=$form1099misc_schFflow");
		include(PROTECTED_PATHQT."html/misc1099_formtype.html");
	}
	else
	{
			include_once("olt_pagehdr.php");
			include("olt_efile_rej_veri_redirect.php");  
		 	echo "<form name=form1 action=\"olt_schF_material_income.php \" method=post>";
			BuildDynamicFormHiddenData("scheduleF_id_frmF=$scheduleF_id_frmF&form1099misc_schFflow=$form1099misc_schFflow");
			include(PROTECTED_PATHQT."html/schF_material_income.html");
		}
	}
	else
	{
	
		if(($direct_sale_ind != 1 && ($rent > 0 || $royalties > 0 || $unemp_compen > 0 || $med_health_payment > 0 || $other_inc > 0 || $gross_paid > 0) ) || ($crop_insur > 0))
		{

			$query ="select SchF_type12_ind,SchF_type3_ind,SchF_type7_ind,SchF_type14_ind,Box10_ind,Box1_2_ind,Box7_ind,Box3_ind,Box6_ind,Box3_ind,Box14_ind,f1099misc_gamb_win_ind,f1099misc_gamb_loss,f1099_tips_cust_regu_ind,f1099_quali_tips_amt,f1099_qual_overtime_ind,f1099_qual_overtime_amt";
			$query .= ",misc1099_med_waiver_paymt,misc1099_med_incl_eic_ind,misc_med_incl_eic_bx7_ind,misc_med_waiver_paymt_bx7,misc_Box7_SCH_rep_ind,box3_ca_mctr_ind,Box2_ind,SchF_type2_ind from misc1099 where ";
			$query .= "qt_user_id=(?) "; db_sql_BuildParamArray($qt_user_id, "misc1099::qt_user_id");
			$query .= "and misc1099_id=(?) "; db_sql_BuildParamArray($id, "misc1099::misc1099_id");
			$result = db_sql_query(array($query), $_SQL_ParamsArray);
			
			
			
			$res_data	 = db_fetchrow(array($result, DB_GETMODE_ASSOC));
			$Box10_ind	 = UDF_trim($res_data["Box10_ind"]);
			$Box1_2_ind	 = UDF_trim($res_data["Box1_2_ind"]);
			$Box7_ind	 = UDF_trim($res_data["Box7_ind"]);
			$Box3_ind	 = UDF_trim($res_data["Box3_ind"]);
			$Box6_ind	 = UDF_trim($res_data["Box6_ind"]);
			$Box14_ind	 = UDF_trim($res_data["Box14_ind"]);
			$f1099misc_gamb_win_ind = UDF_trim($res_data["f1099misc_gamb_win_ind"]);
			$f1099misc_gamb_loss = UDF_trim($res_data["f1099misc_gamb_loss"]);
			$misc1099_med_waiver_paymt = UDF_round((float)UDF_trim($res_data["misc1099_med_waiver_paymt"]));
			$misc1099_med_incl_eic_ind = UDF_trim($res_data["misc1099_med_incl_eic_ind"]);
			$misc_med_waiver_paymt_bx7 = UDF_round((float)UDF_trim($res_data["misc_med_waiver_paymt_bx7"]));
			$misc_med_incl_eic_bx7_ind = UDF_trim($res_data["misc_med_incl_eic_bx7_ind"]);
			
			$SchF_type12_ind = UDF_trim($res_data["SchF_type12_ind"]);
			$SchF_type3_ind = UDF_trim($res_data["SchF_type3_ind"]);
			$SchF_type7_ind = UDF_trim($res_data["SchF_type7_ind"]);
			$SchF_type14_ind = UDF_trim($res_data["SchF_type14_ind"]);
			$misc_Box7_SCH_rep_ind = UDF_trim($res_data["misc_Box7_SCH_rep_ind"]);
			$box3_ca_mctr_ind = UDF_trim($res_data["box3_ca_mctr_ind"]);
			$Box2_ind	 = UDF_trim($res_data["Box2_ind"]);
			$SchF_type2_ind	 = UDF_trim($res_data["SchF_type2_ind"]);
			$f1099_tips_cust_regu_ind	= UDF_trim($res_data["f1099_tips_cust_regu_ind"]);
			$f1099_quali_tips_amt    	= UDF_trim($res_data["f1099_quali_tips_amt"]);
			$f1099_qual_overtime_ind 	= UDF_trim($res_data["f1099_qual_overtime_ind"]);
			$f1099_qual_overtime_amt    	= UDF_trim($res_data["f1099_qual_overtime_amt"]);
			
			db_free_result(array($result));
				
			include_once("olt_pagehdr.php");
			
			include("olt_efile_rej_veri_redirect.php");  echo "<form name=form1 action=\"olt_misc1099_formtype.php\" method=post>";
			BuildDynamicFormHiddenData("id=$id&fish_boat=$fish_boat");
			include(PROTECTED_PATHQT."html/misc1099_formtype.html");

		}else
		{
			if($direct_sale_ind ==1 && ($rent > 0)) $Box1_2_ind = "C";
			if($direct_sale_ind ==1 && ($royalties > 0)) $Box2_ind = "C";
			
			if($direct_sale_ind ==1 && $other_inc > 0) $Box3_ind = "C";
			
			if($direct_sale_ind ==1 && $fish_boat > 0) $Box5_ind = "C";
			
			if($direct_sale_ind ==1 && $med_health_payment > 0) $Box6_ind = "C";
			
			if($direct_sale_ind ==1 && $unemp_compen > 0) $Box7_ind = "C";
			
			if($direct_sale_ind ==1 && $gross_paid > 0) $Box14_ind = "C";
			
			$Box10_ind = "";

			
					
$_SQL_DataArray[] = array( "key"=> "Box1_2_ind", "val"=>$Box1_2_ind, "table"=>"misc1099");			
$_SQL_DataArray[] = array( "key"=> "Box2_ind", "val"=>$Box2_ind, "table"=>"misc1099");
$_SQL_DataArray[] = array( "key"=> "Box3_ind", "val"=>$Box3_ind, "table"=>"misc1099");			
$_SQL_DataArray[] = array( "key"=> "Box5_ind", "val"=>$Box5_ind, "table"=>"misc1099");			
$_SQL_DataArray[] = array( "key"=> "Box6_ind", "val"=>$Box6_ind, "table"=>"misc1099");			
$_SQL_DataArray[] = array( "key"=> "Box7_ind", "val"=>$Box7_ind, "table"=>"misc1099");			
$_SQL_DataArray[] = array( "key"=> "Box10_ind", "val"=>$Box10_ind, "table"=>"misc1099");			
$_SQL_DataArray[] = array( "key"=> "Box14_ind", "val"=>$Box14_ind, "table"=>"misc1099");			
						
$_SQL_DataArray[] = array( "key"=> "SchF_type12_ind", "val"=>'', "table"=>"misc1099");			
$_SQL_DataArray[] = array( "key"=> "SchF_type3_ind", "val"=>'', "table"=>"misc1099");			
$_SQL_DataArray[] = array( "key"=> "SchF_type7_ind", "val"=>'', "table"=>"misc1099");			
$_SQL_DataArray[] = array( "key"=> "SchF_type14_ind", "val"=>'', "table"=>"misc1099");			
$_SQL_DataArray[] = array( "key"=> "misc1099_med_waiver_paymt", "val"=>'0', "table"=>"misc1099");			
$_SQL_DataArray[] = array( "key"=> "misc1099_med_incl_eic_ind", "val"=>'0', "table"=>"misc1099");			
$_SQL_DataArray[] = array( "key"=> "misc_med_waiver_paymt_bx7", "val"=>'0', "table"=>"misc1099");			
$_SQL_DataArray[] = array( "key"=> "misc_med_incl_eic_bx7_ind", "val"=>'0', "table"=>"misc1099");			
$out_sqlparm = db_sql_paramformat($_SQL_DataArray);

$query_clause="update misc1099 set ".$out_sqlparm["_SQL_UpdateClause"]." WHERE ";
$query_clause.= "qt_user_id=(?) "; db_sql_BuildParamArray($qt_user_id, "misc1099::qt_user_id");
$query_clause.= " and misc1099_id=(?) "; db_sql_BuildParamArray($id, "misc1099::misc1099_id");

			$result = db_sql_query(array($query_clause), $_SQL_ParamsArray);
		
			
		
			db_free_result(array($result));
			
			if(($fish_boat > 0) || ($Box1_2_ind == "C") || ($Box2_ind == "C") || ($Box3_ind == "C") || ($Box6_ind == "C") || ($Box7_ind == "C") || ($Box14_ind == "C"))
			{
				include_once("olt_pagehdr.php");	
				include("olt_efile_rej_veri_redirect.php");  
				echo "<form name=form1 action=\"olt_misc1099_selection.php \" method=post>";
				BuildDynamicFormHiddenData("id=$id");
				include(PROTECTED_PATHQT."html/misc1099_selection.html");
			}
			else
			{				
				include_once("olt_pagehdr.php");
				include("olt_efile_rej_veri_redirect.php");  
				echo "<form name=form1 action=\"olt_misc1099done.php \" method=post>";
				include(PROTECTED_PATHQT."html/misc1099done.html");
			}
 
		}	


}}else
{
		include_once("olt_pagehdr.php");
		$nv_dup_warn_msg="";
		if($gross_paid_val_err_flag == 1)
		{
			$nv_dup_warn_msg = "<label class='control control--checkbox' style='float:left' >Check here to confirm that the taxable amount of the gross proceeds paid to attorney (box 10) is 0. Otherwise, please correct the taxable proceeds.<INPUT TYPE=\"CHECKBOX\"  value='1' name=PassValidationInd>&nbsp;<div class=\"control__indicator\"></div></label>";
		}
		else if($inc1_IN_err_flag == 1 || $inc2_IN_err_flag == 1)
		{
			$nv_dup_warn_msg .= "<label class='control control--checkbox' style='float:left' >Check here if your information is correct.<INPUT TYPE=\"CHECKBOX\"  value='1' name=PassValidationIndStDist>&nbsp;<div class=\"control__indicator\"></div></label>";
		}
 		include("olt_efile_rej_veri_redirect.php");  echo "<form name=form1 action=\"olt_misc1099.php\" method=post>";
 		echo "<input type=hidden name=PassValidationIndStDist value=$PassValidationIndStDist>"; 
 		echo "<input type=hidden name=PassValidationInd value=$PassValidationInd>";
   		BuildDynamicFormHiddenData("newaction=$newaction&step=$step&id=$id&form1099misc_schcflow=$form1099misc_schcflow&form1099misc_schFflow=$form1099misc_schFflow&form1099misc_schEflow=$form1099misc_schEflow");
      		if($form1099misc_schcflow == 1)
   		{	   		
	   		BuildDynamicFormHiddenData("form1099misc_schcEditflow=$form1099misc_schcEditflow&form1099misc_schcDelflow=$form1099misc_schcDelflow&schdC_id_frmc=$schdC_id_frmc&attach_form_misc=$attach_form_misc");
		}
    		if($form1099misc_schEflow == 1)
   		{	   		
	   		BuildDynamicFormHiddenData("form1099misc_scheEditflow=$form1099misc_scheEditflow&form1099misc_scheDelflow=$form1099misc_scheDelflow&sche_partI_id_frme=$sche_partI_id_frme&attach_form_misc=$attach_form_misc&schdE_type_property_misc=$schdE_type_property_misc");
		}
		if($form1099misc_schFflow == 1)
   		{	   		
	   		BuildDynamicFormHiddenData("form1099misc_schFEditflow=$form1099misc_schFEditflow&form1099misc_schFDelflow=$form1099misc_schFDelflow&scheduleF_id_frmF=$scheduleF_id_frmF&attach_form_misc=$attach_form_misc");
		}
   		include(PROTECTED_PATHQT."html/misc1099.html");
}

include("olt_pageftr.php");

?>