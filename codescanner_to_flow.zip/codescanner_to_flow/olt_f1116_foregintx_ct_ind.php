<?



/********************************************************************************
                      MODIFICATION  CONTROL  LOG
---------------------------------------------------------------------------------
  Mod  Date         Programmer        Comment
  ------------------------------------------------------------------------------
    001  04/13/2005   Ravi kumar         Initial version, According to ace issue #1602 
********************************************************************************* */


     include_once("header.php");
     include_once("qt_func.php");

     $myPageId = 1740;	     
     $status = GetUniqueUserInfo($o9Ljw, $qt_user_id, $siteid, $pageid, $lasttime);
     
     $my_page="olt_f1116_foregintx_ct.php";

	$FileStatus = GetCurrentStatus($qt_user_id);
	if ($FileStatus) {
		include(PROTECTED_PATHQT."html/InvalidStatus.html");
		echo "</form>";
		db_close();
		exit;
	}
	if ($myPageId >  $pageid) {
		// 003 BEGIN
$_SQL_DataArray[] = array( "key"=> "pageid", "val"=>(int)$myPageId, "table"=>"auth_access");     	     	
$out_sqlparm = db_sql_paramformat($_SQL_DataArray);

$query_clause="update auth_access set ".$out_sqlparm["_SQL_UpdateClause"]." WHERE ";
$query_clause.= "qt_user_id=(?) "; db_sql_BuildParamArray($qt_user_id, "auth_access::qt_user_id");
	     	$insert_result = db_sql_query(array($query_clause), $_SQL_ParamsArray);
	     	$pageid  = $myPageId;
	     	//003 END	
	}
	
	include("../oltproc/olt_section_track_end.php");

$_SQL_DataArray[] = array( "key"=> "form_1116_flow_ind", "val"=>'1', "table"=>"olt_flow_events");
$out_sqlparm = db_sql_paramformat($_SQL_DataArray);

$query_flow="update olt_flow_events set ".$out_sqlparm["_SQL_UpdateClause"]." WHERE ";
$query_flow.= "qt_user_id=(?) "; db_sql_BuildParamArray($qt_user_id, "olt_flow_events::qt_user_id");
$result_flow  = db_sql_query(array($query_flow), $_SQL_ParamsArray);

$err_flag = 0;
$Allowedarrayvalues = array("0", "1");
if(($more != "") && (!IsValidValue($more, $Allowedarrayvalues)))
{
	$err_flag = 1;
	$more_err = 1;
}
$f1116_simp_limit_elec_ind = (int) $f1116_simp_limit_elec_ind;
if(($f1116_simp_limit_elec_ind != "") && (!IsValidValue($f1116_simp_limit_elec_ind, $Allowedarrayvalues)))
{
	$err_flag = 1;
	$f1116_simp_limit_elec_ind_err = 1;
}


if($err_flag != 1)
{
$_SQL_DataArray[] = array( "key"=> "f1116_simp_limit_elec_ind", "val"=>(int)$f1116_simp_limit_elec_ind, "table"=>"f1116_without_form");
$out_sqlparm = db_sql_paramformat($_SQL_DataArray);

$query_clause="update f1116_without_form set ".$out_sqlparm["_SQL_UpdateClause"]." WHERE ";
$query_clause.= "qt_user_id=(?) "; db_sql_BuildParamArray($qt_user_id, "f1116_without_form::qt_user_id");
$update_result= db_sql_query(array($query_clause), $_SQL_ParamsArray);
db_free_result(array($update_result));

$OLTFED_MULTIENTRYPAGE_VISITEDIND=1;
if($step=="delete")
    {
    	
    	
		
		include_once("olt_pagehdr.php");
				
     		include("olt_efile_rej_veri_redirect.php");  echo "<form name=form1 action=\"olt_f1116_foregintx_ct_delete.php \" method=post>";
   		BuildDynamicFormHiddenData("verify=$correctverify");
   		include(PROTECTED_PATHQT."html/f1116_foregintx_ct_delete.html");
        	
        	$more=3;
        	
}
      if($step=="edit")
    {
    	        $step=$step;
        	$sche_partI_id=$sche_partI_id;
		
		include_once("olt_pagehdr.php");

 		include("olt_efile_rej_veri_redirect.php");  echo "<form name=form1 action=\"olt_f1116_froeig_tyinc.php \" method=post>";
   		BuildDynamicFormHiddenData("step=$step");
   		include(PROTECTED_PATHQT."html/f1116_froeig_tyinc.html");
        	
        	$more=23;
        	
        	
        }	 	
 	if ($more == 1  || $more == 2 )
 	{
     		$more = $more;

$_SQL_DataArray[] = array( "key"=> "qt_user_id", "val"=>$qt_user_id, "table"=>"form_1116");
$out_sqlparm = db_sql_paramformat($_SQL_DataArray);

 		$table_clause ="insert into form_1116(".$out_sqlparm['_SQL_FieldClause'].") values (".$out_sqlparm['_SQL_ValueClause'].")";
		$result = db_sql_query(array($table_clause), $_SQL_ParamsArray);
      		
 		$qc ="select max(f1116_id)f1116_id  from form_1116 where ";
 		$qc .= "qt_user_id=(?) "; db_sql_BuildParamArray($qt_user_id, "form_1116::qt_user_id");
		$result = db_sql_query(array($qc), $_SQL_ParamsArray);
		$noOfRows = db_num_rows(array($result));
		if ($noOfRows > 0) { 
			$res_data=db_fetchrow(array($result, DB_GETMODE_ASSOC));
			$f1116_id = $res_data["f1116_id"];
		}
		
    include("olt_get_income_ind.php");

 		$f1116_curt_id = (int) $f1116_id;
 		include("olt_cal_int_div_fortax.php");
 		$f1116_id = (int) $f1116_curt_id;
 		$my_page="olt_f1116_foregintx_ct.php";
 		include_once("olt_pagehdr.php");
 		
 		include("olt_efile_rej_veri_redirect.php");  echo "<form name=form1 action=\"olt_f1116_froeig_tyinc.php \" method=post>";
   		BuildDynamicFormHiddenData("verify=$correctverify&f1116_id=$f1116_id");
   		include(PROTECTED_PATHQT."html/f1116_froeig_tyinc.html");
        	
        }
        
        if ($more == 0 )
 	{
 		$OLTFED_MULTIENTRYPAGE_VISITEDIND=0;
 		include("olt_update_diag_visited.php");
 		$qc ="select *  from form_1116 where ";
 		$qc .= "qt_user_id=(?) "; db_sql_BuildParamArray($qt_user_id, "form_1116::qt_user_id");
		$result_1116 = db_sql_query(array($qc), $_SQL_ParamsArray);
		$noOfRows_1116 = db_num_rows(array($result_1116));
     		if($noOfRows_1116 > 0)
     		{
	     		$more = $more;
	 		
	 		$chkform1040_ind = UDF_trim($form1040_ind);
	 		
	 		if($chkform1040_ind == "1040SS")
			{
				include_once("olt_cal_f1040ss.php");	
			}
			else
			{
				if($do_not_calculate_here == 0)
				{
					include_once("olt_calculations.php");
				}	
			}
			
	 		include_once("olt_pagehdr.php");
	 		
	 		include("olt_efile_rej_veri_redirect.php");  echo "<form name=form1 action=\"olt_f1116_redct_credit.php \" method=post>";
	   		BuildDynamicFormHiddenData("verify=$correctverify");
	   		include(PROTECTED_PATHQT."html/f1116_redct_credit.html");
	        	
	        }else
	        {
	        	/* NEXT HTML PAGE BEGIN */
	        	if($nv_mode=="1")
			{
				$SectionEnableIndex = "2";
				include("olt_org_adjust_call.php");
			}
			else
			include("olt_org_credit_call.php");	
			include_once("olt_pagehdr.php");
			          
			include("olt_efile_rej_veri_redirect.php");  echo "<form name=form1 action=\"$next_php.php \" method=post>";
			BuildDynamicFormHiddenData("step=w2done");
			include(PROTECTED_PATHQT."html/$next_html.html");
			
        	}
        }
}
else
{
	include_once("olt_pagehdr.php");
	include("olt_efile_rej_veri_redirect.php");  
	echo "<form name=form1 action=\"olt_f1116_foregintx_ct_ind.php \" method=post>";
	include(PROTECTED_PATHQT."html/f1116_foregintx_ct_ind.html");
}       
include("olt_pageftr.php");	
/* HTML END */
?>