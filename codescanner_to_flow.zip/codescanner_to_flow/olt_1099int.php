<?
/*********************************************************************************************
				Modification Control Log
----------------------------------------------------------------------------------------------
Mod	Date	    Programmer		Description
----------------------------------------------------------------------------------------------
001	03/03/2005  Ruban Antony	Added condition to validated the state abbreviation
					only for resident country.
002	03/03/2005  Ruban Antony	To empty the zip code if foreign address is given.					
003	08/28/2012  Rajasekar S		Included the State,State Identification Number,State tax withheld.
004    	06/10/2013  Jerry Thimothy J  	Included city allocation operations
*********************************************************************************************/
	include_once("header.php");
	include_once("qt_func.php");
	
	$my_page="olt_1099int.php";
	
	$status = GetUniqueUserInfo($o9Ljw, $qt_user_id, $siteid, $pageid, $lasttime);
	
	$FileStatus = GetCurrentStatus($qt_user_id);
	if ($FileStatus) {
		include(PROTECTED_PATHQT."html/InvalidStatus.html");
		echo "</form>";
		db_close();
		exit;
	}
	
	/*$form1040_ind = "";
	$SelectQuery ="select form1040_ind from ind_label where ";
	$SelectQuery .= "qt_user_id=(?) "; db_sql_BuildParamArray($qt_user_id, "ind_label::qt_user_id");
	$result   	 = db_sql_query(array($SelectQuery), $_SQL_ParamsArray);
	$noOfRows = db_num_rows(array($result));
	if ($noOfRows > 0) 
	{ 
		$res_data		= db_fetchrow(array($result, DB_GETMODE_ASSOC));
		$form1040_ind		= UDF_trim($res_data["form1040_ind"]); 		
	}
	db_free_result(array($result));*/
	
	include("../oltproc/olt_section_track_end.php");
     /* NEXT HTML PAGE BEGIN */
    
$err_flag	 = 0;
//if($OLTPRO_masterID != "")
if($show_aloc_state_ind == 1)
{
	$aloc_state= UDF_trim($aloc_state);
	if($show_city_combo_ind == 1)
		$aloc_city	=	UDF_trim($aloc_city);
}
/*
$box3_8_mismatch = 0;
if(($part == "TOT_EX") && ($tax_exempt_1099int != $int_inc))
{
	$err_flag=1;
	$box3_8_mismatch = 1;
	$tax_exempt_1099int_err_flag=1;
}
*/

$payername 	= fixtext($payername);
$payeraddress 	= fixtext($payeraddress);
$payercity 	= fixtext($payercity);
if($payerstate!=".")//**001
{
	$payerstate 	= fixtext($payerstate);		
}
$payerzip	= fmtvalue($payerzip);
$payerin 	= UDF_str_replace("-","",$payerin);
$payerin 	= fmtvalue($payerin);
$PayerRTN 	= fmtvalue($PayerRTN);
$recipientin 	= fmtvalue($recipientin);
$int_inc	= fmtvalue((float)$int_inc);
$early_with	= fmtvalue((float)$early_with);
$int_on_USSav	= fmtvalue((float)$int_on_USSav);
$int_on_USSav_pryr	= fmtvalue((float)$int_on_USSav_pryr);
$fed_inc_tax	= fmtvalue((float)($fed_inc_tax));
$invest_exp 	= fmtvalue((float)$invest_exp);
$recipientname 	= fmtvalue($recipientname);
$recipientaddress = fixtext($recipientaddress);
$recipientaddress = UDF_substr($recipientaddress,0,70);
$recipientcity 	= fmtvalue($recipientcity);
$recipientstate = fmtvalue($recipientstate);	
$recipientzip 	= fmtvalue($recipientzip);

$for_tax_paid	= fmtvalue((float)$for_tax_paid);
$tax_exempt_1099int = fmtvalue($tax_exempt_1099int);
$spec_bond_int	= fmtvalue((float)($spec_bond_int));
$for_country	= fmtvalue($for_country);
$tax_exempt_CUSIP_no = fmtvalue($tax_exempt_CUSIP_no);
$nominee_amt	= fmtvalue(UDF_round((float)($nominee_amt)));
$nominee_desc = Formatdescription($nominee_desc); 
$accrued_amt	= fmtvalue(UDF_round((float)($accrued_amt)));
//$abp_adj	= fmtvalue(UDF_round($abp_adj)); //abp_adj - Added New TY2010
$taxexemt_acrued_bond_amt = fmtvalue(((float)($taxexemt_acrued_bond_amt)));
$adj_box1_accint_earnamt = fmtvalue(((float)($adj_box1_accint_earnamt)));
$adj_box3_accint_earnamt = fmtvalue(((float)($adj_box3_accint_earnamt)));
$f1116int_block_autocalc_ind =(int) $f1116int_block_autocalc_ind;


//add-2012 
$nominee_state  	= fmtvalue($nominee_state);
$nominee_identify   = fmtvalue($nominee_identify);
$state_tax_withheld	= fmtvalue($state_tax_withheld);

 $payer_frgn_address 	= fixtext($payer_frgn_address);
 $payer_frgn_city 	= fixtext($payer_frgn_city);
 $payer_frgn_state 	= fixtext($payer_frgn_state);	
 $payer_frgn_address=UDF_str_replace("#","" ,$payer_frgn_address); 
 $payer_frgn_address=UDF_str_replace(".","" ,$payer_frgn_address); 
 $payer_frgn_address=UDF_str_replace(",","" ,$payer_frgn_address); 
 $payer_frgn_address=UDF_str_replace("  "," " ,$payer_frgn_address); 
 $payer_frgn_address=UDF_str_replace("  "," " ,$payer_frgn_address);   
 $payer_frgn_city		= fmtvalue($payer_frgn_city);
 $payer_frgn_city		= UDF_str_replace("."," " ,$payer_frgn_city); 
 $payer_frgn_city		= UDF_str_replace("  "," " ,$payer_frgn_city); 
 $payer_frgn_state		= fmtvalue($payer_frgn_state);
 $payer_frgn_state		= UDF_str_replace("  "," " ,$payer_frgn_state); 
 $payer_frgn_zip		= fmtvalue($payer_frgn_zip);
$payer_frgn_add_ind = (int)UDF_trim($payer_frgn_add_ind);
 $FATCA_filing_req_ind = (int)UDF_trim($FATCA_filing_req_ind);
 $account_num	= fmtvalue($account_num);
 $recip_frgn_address 	= fixtext($recip_frgn_address);
 $recip_frgn_city 	= fixtext($recip_frgn_city);
 $rcpnt_frgn_state 	= fixtext($rcpnt_frgn_state);	
 $recip_frgn_address=UDF_str_replace("#","" ,$recip_frgn_address); 
 $recip_frgn_address=UDF_str_replace(".","" ,$recip_frgn_address); 
 $recip_frgn_address=UDF_str_replace(",","" ,$recip_frgn_address); 
 $recip_frgn_address=UDF_str_replace("  "," " ,$recip_frgn_address); 
 $recip_frgn_address=UDF_str_replace("  "," " ,$recip_frgn_address);   
 $recip_frgn_city		= fmtvalue($recip_frgn_city);
 $recip_frgn_city		= UDF_str_replace("."," " ,$recip_frgn_city); 
 $recip_frgn_city		= UDF_str_replace("  "," " ,$recip_frgn_city); 
 $rcpnt_frgn_state		= fmtvalue($rcpnt_frgn_state);
 $rcpnt_frgn_state		= UDF_str_replace("  "," " ,$rcpnt_frgn_state); 
 $recip_frgn_zip		= fmtvalue($recip_frgn_zip);
 $rcpnt_frgn_ctry_code	= fmtvalue($rcpnt_frgn_ctry_code);
$rcpnt_frgn_addr_ind = (int)UDF_trim($rcpnt_frgn_addr_ind);
//$interest_report_ind = (int)UDF_trim($interest_report_ind);

$int_areacode 		= UDF_trim($int_areacode);
$int_phone 		= UDF_trim($int_phone);
$derived_ord_course_ind	= (int)$derived_ord_course_ind;
$report_to_frm8958_ind	= (int)$report_to_frm8958_ind;
$dont_amortize_bond_ind = (int)$dont_amortize_bond_ind;

$int99_market_discount	= fmtvalue((float)$int99_market_discount);
$int99_bond_premium	= fmtvalue((float)($int99_bond_premium));
$int99_bond_pre_taxempt	= fmtvalue((float)($int99_bond_pre_taxempt));
$int99_bond_prem_treasury = fmtvalue((float)($int99_bond_prem_treasury));

if($early_with == "")			$early_with   		  = "0";
if($int_on_USSav == "") 		$int_on_USSav 		  = "0";
if($invest_exp == "")  			$invest_exp   		  = "0";
if($for_tax_paid == "")  		$for_tax_paid 		  = "0";
if($tax_exempt_1099int == "") 		$tax_exempt_1099int 	  = "0";

if($nominee_amt != 0)
 $part = "NOM";
else
 $part = "INT";	
 
$accrued_amt = 0;
	
/*$query ="SELECT OLTPRO_masterID FROM oltpro_user_auth where ";
$query .= "qt_user_id=(?) "; db_sql_BuildParamArray($qt_user_id, "oltpro_user_auth::qt_user_id");
$result = db_sql_query(array($query), $_SQL_ParamsArray);
if($res_data   = db_fetchrow(array($result, DB_GETMODE_ASSOC)))
{
	$OLTPRO_masterID  = UDF_trim($res_data["OLTPRO_masterID"]);
}
db_free_result(array($result));*/


/*$query ="SELECT int1099sf_id FROM int1099sf where ";
$query .= "qt_user_id=(?) "; db_sql_BuildParamArray($qt_user_id, "int1099sf::qt_user_id");
$result = db_sql_query(array($query), $_SQL_ParamsArray);
$f1099sf_noOfRows = db_num_rows(array($result));*/
	
$ArrayOneZeroValue = array("0", "1");
	
	if($F8958_Eligible_Questions == "true")
	{
		if(($report_to_frm8958_ind != "") && (!IsValidValue($report_to_frm8958_ind, $ArrayOneZeroValue)))
		{
			$err_flag = 1;
			$report_to_frm8958_ind_err = 1;
		}
	}
	
	if(($derived_ord_course_ind != "") && (!IsValidValue($derived_ord_course_ind, $ArrayOneZeroValue)))
	{
		$err_flag = 1;
		$derived_ord_course_ind_err = 1;
	}
	
	if(($FATCA_filing_req_ind != "") && (!IsValidValue($FATCA_filing_req_ind, $ArrayOneZeroValue)))
	{
		$err_flag = 1;
		$FATCA_filing_req_ind_err = 1;
	}
	
	if(($f1116int_block_autocalc_ind != "") && (!IsValidValue($f1116int_block_autocalc_ind, $ArrayOneZeroValue)))
	{
		$err_flag = 1;
		$f1116int_block_autocalc_ind_err = 1;
	}
	
	if(($dont_amortize_bond_ind != "") && (!IsValidValue($dont_amortize_bond_ind, $ArrayOneZeroValue)))
	{
		$err_flag = 1;
		$dont_amortize_bond_ind_err = 1;
	}

	if($int_areacode!="" || $int_phone !="")
	{
		if (!(IsNumeric($int_areacode)) || (UDF_strlen($int_areacode) <> 3))
		{
		 	$err_flag=1;
		 	$area_err_flag=1;
		}
		else if(!(IsValidAreaCode($int_areacode)) && ($PassValidationInd != 1))
		{
			$err_flag=1;
		 	$area_warning_flag = 1;
		}
		if (!(IsNumeric($int_phone)) || (UDF_strlen($int_phone) <> 7))
		{
		 	$err_flag=1;
		 	$phone_err_flag=1;
		}
		else if(!(IsValidPhoneNum($int_phone)) && ($PassValidationInd != 1))
		{
			$err_flag=1;
		 	$phone_warning_flag = 1;
		}
	}
	
	/*if(($interest_report_ind == 0) && (($payerin == "") || (UDF_strlen($payerin) != 9) || (!IsValidEIN($payerin)) || ($payerin == "000000000")))
	{
	   $err_flag=1;
	   $pfin_err_flag=1;
	}
	else*/ 
	

	//if((UDF_trim($part) == "SFIN") && ($payerin == ""))
        /*if(($f1099sf_noOfRows > 0) && ($payerin == ""))
	{
	   $err_flag=1;
	   $pfin_err_flag=1;
	}*/
	//if((UDF_trim($part) == "SFIN") && ($payername == ""))
	/*if(($f1099sf_noOfRows > 0) && ($payername == ""))
	{
	   $err_flag=1;
	   $pname_err_flag=1;
	}*/
	
//if($OLTPRO_masterID != "")
if($show_aloc_state_ind == 1)
{	
	if($aloc_state!=".")
	{
		
		if(($aloc_state == "") || (!fmtName($aloc_state)) || (UDF_strlen($aloc_state) != 2))
		{
		  $err_flag=1;
		  $aloc_state_err_flag=1;
		}
		
		if (IsValidState($aloc_state) == 0) 
		{
		  $err_flag=1;
		  $aloc_state_err_flag=1;
		} 
		
		
	}	
	
	if(($show_city_combo_ind == 1)&&(UDF_in_array($aloc_state, $aloc_state_array))&&($aloc_city==""))
	{
		$err_flag=1;
		$aloc_city_err_flag=1;
	}
}
	//if(UDF_trim($part) == "SFIN" && (($payeraddress == "") || (!isAlphaNumericnumsp($payeraddress))))
	
	/*if($f1099sf_noOfRows > 0 && (($payeraddress == "") || (!isAlphaNumericnumsp($payeraddress))))
	{
	   $err_flag=1;
	   $paddr_err_flag=1;
	}*/
	
	if($nv_mode=="1")
	{ 
		if(($payerin_1099int != "") || (UDF_trim($OLTPRO_masterID) != ''))
		{
			$cmn_frgn_addr_ind 	= "payer_frgn_add_ind";		
			$cmn_US_addr  		= "payeraddress";		${$cmn_US_addr."Skip"} = 1;
			$cmn_US_addr2  		= "";
			$cmn_US_aptno	  	= "";
			$cmn_US_city 		= "payercity";			${$cmn_US_city."Skip"} = 1;        
			$cmn_US_state 		= "payerstate";			${$cmn_US_state."Skip"} = 1;       
			$cmn_US_zip 		= "payerzip";			${$cmn_US_zip."Skip"} = 1; 
			$cmn_US_zip_ext		= "";
		
			$cmn_frgn_addr          = "payer_frgn_address";		${$cmn_frgn_addr."Skip"} = 1;
			$cmn_frgn_addr2         = "";	
			$cmn_forgn_aptno        = "";
			$cmn_frgn_city 		= "payer_frgn_city";		${$cmn_frgn_city."Skip"} = 1;
			$cmn_frgn_state 	= "payer_frgn_state";		${$cmn_frgn_state."Skip"} = 1;
			$cmn_frgn_country_code  = "payer_frgn_country";		${$cmn_frgn_country_code."Skip"} = 1;
			$cmn_frgn_zip 		= "payer_frgn_zip";
			
			/*if($interest_report_ind == 1)
			{
				if($payer_frgn_add_ind == 0)
				{	
					if(($payeraddress == "") && ($payercity == "") && (($payerstate == "") || ($payerstate == ".")) && ($payerzip == ""))
					{
						$payeraddressSkip = 1;
						$payercitySkip 	= 1;
						$payerstateSkip = 1;
						$payerzipSkip = 1;
					}
				}
				else
				{
					if(($payer_frgn_address == "") && ($payer_frgn_city == "") && ($payer_frgn_state == "") && ($payer_frgn_zip == "") && ($payer_frgn_country == ""))
					{
						$payer_frgn_addressSkip = 1;
						$payer_frgn_citySkip 	= 1;
						$payer_frgn_stateSkip = 1;
						$payer_frgn_zipSkip = 1;
						$payer_frgn_countrySkip = 1;
					}
				}
			}*/
			
			include("../oltproc/commonAddressPnl.php");
		}
	}
	else
	{
		if($payer_frgn_add_ind == 1)
		{
			if(($payer_frgn_address =="") || (UDF_strlen($payer_frgn_address) < 2))
			{
				$err_flag=1;
				$payer_frgn_address_err_flag=1;
			}
			if(($payer_frgn_city != "") &&( UDF_strlen($payer_frgn_city) < 3))
			{
				$err_flag=1;
				$payer_frgn_city_err_flag=1;
			}	
			if(UDF_strlen(UDF_trim($payer_frgn_country))==0)
			{
			      $err_flag = 1;
			      $payer_frgn_country_err_flag = 1;       
			}	 			
			if(!fmtNamesp1($payer_frgn_state))
			{
				$err_flag = 1;
				$payer_frgn_state_err_flag=1;       
			}
			if(!is_null($payer_frgn_zip) && !IsValidForeignPostalCode($payer_frgn_zip))
			{
				$err_flag = 1;
				$payer_frgn_zip_err_flag=1;
			}
		}
		else
		{
			if(($payeraddress != "") &&  (!isAlphaNumericnumsp($payeraddress)))
			{
				$err_flag=1;
				$paddr_err_flag=1;
			}	
			if ((($payerstate != "") && ($payerzip != "") && ($payercity != "")) && ($payeraddress == "") )
			{ 
				$err_flag=1;
				$paddr_err_flag=1;
			}
			if($payeraddress =="")
			{
				$err_flag=1;
				$paddr_err_flag=1;
			}
			if(UDF_strlen($payercity) < 3)
			{
				$err_flag=1;
				$pcitylen_err_flag=1;
			}
			//if($payerstate!=".")
			{
				if (IsValidState($payerstate) == 0) 
				{
					$err_flag=1;
					$pstate_err_flag=1;   			  
				}
				$SelectQuery ="select center from centers where ";
				$SelectQuery .= "state=(?) "; db_sql_BuildParamArray($payerstate, "centers::state");
				$pick   	 = db_sql_query(array($SelectQuery), $_SQL_ParamsArray);
				if (db_num_rows(array($pick)) == 0) 
				{  			   
					$err_flag=1;
					$pstate_err_flag=1; 				   
				}
				if(($payerstate == "") || (!fmtName($payerstate)) || (UDF_strlen($payerstate) != 2))
				{			  
					$err_flag=1;
					$pstate_err_flag=1;
				
				}	
				$payerzip = UDF_trim($payerzip);
				if(($payerzip == "") || (!isNumeric($payerzip)) || (UDF_strlen($payerzip) != 5))
				{	
					$err_flag=1;
					$pzip_err_flag=1;
				}
				$pvalidStZip1 = IsValidZip($payerstate, $payerzip);
				if ($pvalidStZip1 == 0) 
				{
					$err_flag=1;
					$pzip_err_flag=1;
				
				}	
			}
		}
	}
	
	
	/*if(UDF_trim($part) == "NOM" && (($nominee_amt == "") || ($nominee_amt == 0)||(!isNumeric($nominee_amt))))
	{
	   $err_flag=1;
	   $nominee_amt_err_flag=1;
	} 
	else */
	if(UDF_trim($part) == "NOM" && (($nominee_amt != "") || ($nominee_amt != 0)||(isNumeric($nominee_amt))))
	{	  
		$int_on_USSav_pryr_amt = (float) $int_on_USSav_pryr;
		$int_inc_amt = (float) $int_inc;
		$int_on_USSav_amt = (float) $int_on_USSav;
		$TempAmt =($int_inc_amt + $int_on_USSav_amt)- $int_on_USSav_pryr_amt;
	   
		if($TempAmt < $nominee_amt)
		{
		   $err_flag=1;
		   $nominee_amt_err_over=1;
		}
	} 
	
	/*if(UDF_trim($part) == "ACC" && (($accrued_amt == "") || ($accrued_amt == 0)|| (!isNumeric($accrued_amt))))
	{
	   $err_flag=1;
	   $accrued_amt_err_flag=1;
	} 
	
	else if(UDF_trim($part) == "ACC" && (($accrued_amt != "") || ($accrued_amt != 0)|| (isNumeric($accrued_amt))))
	{
		$int_on_USSav_pryr_amt = (float) $int_on_USSav_pryr;
		$int_inc_amt = (float) $int_inc;
		$int_on_USSav_amt = (float) $int_on_USSav;
		$TempAmt =($int_inc_amt + $int_on_USSav_amt)- $int_on_USSav_pryr_amt;
	  
		/*if($TempAmt < $accrued_amt)
		{
		   $err_flag=1;
		   $accrued_amt_err_over=1;
	} 
	
		}*/
	
	//if(UDF_trim($part) == "SFIN" && (($payercity == "") || (!isAlphaNumericnumsp($payercity))))
	/*if(($f1099sf_noOfRows > 0) && ($payercity == "") || (!isAlphaNumericnumsp($payercity)))
	{
	   $err_flag=1;
	   $pcity_err_flag=1;
	}*/
	
if(($PayerRTN != "") &&  (!isNumeric($PayerRTN)))
{
   $err_flag=1;
   $prtn_err_flag=1;
}

if(($PayerRTN != "") && (UDF_strlen($PayerRTN) != 9))
{
   $err_flag=1;
   $prtn_err_flag=1;
}

	if($nv_mode=="1")
	{ 
		$cmn_frgn_addr_ind 	= "rcpnt_frgn_addr_ind";		
		$cmn_US_addr  		= "recipientaddress";
		$cmn_US_addr2  		= "";
		$cmn_US_aptno	  	= "";
		$cmn_US_city 		= "recipientcity";        
		$cmn_US_state 		= "recipientstate";       
		$cmn_US_zip 		= "recipientzip"; 
		$cmn_US_zip_ext		= "";
	
		$cmn_frgn_addr          = "recip_frgn_address";	
		$cmn_frgn_addr2         = "";	
		$cmn_forgn_aptno        = "";
		$cmn_frgn_city 		= "recip_frgn_city";
		$cmn_frgn_state 	= "rcpnt_frgn_state";
		$cmn_frgn_country_code  = "rcpnt_frgn_ctry_code";
		$cmn_frgn_zip 		= "recip_frgn_zip";
		include("../oltproc/commonAddressPnl.php");
	}
	else
	{
		if($rcpnt_frgn_addr_ind == 1)
		{
			if(($recip_frgn_address =="") || (UDF_strlen($recip_frgn_address) < 2))
			{
				$err_flag=1;
				$recip_frgn_address_err_flag=1;
			}
			if(($recip_frgn_city != "") &&( UDF_strlen($recip_frgn_city) < 3))
			{
				$err_flag=1;
				$recip_frgn_city_err_flag=1;
			}	
			if(UDF_strlen(UDF_trim($rcpnt_frgn_ctry_code))==0)
			{
			      $err_flag = 1;
			      $rcpnt_frgn_ctry_code_err_flag = 1;       
			}	 			
			if(!fmtNamesp1($rcpnt_frgn_state))
			{
				$err_flag = 1;
				$rcpnt_frgn_state_err_flag=1;       
			}
			if(!is_null($recip_frgn_zip) && !IsValidForeignPostalCode($recip_frgn_zip))
			{
				$err_flag = 1;
				$recip_frgn_zip_err_flag=1;
			}
		}
		else
		{
			//if($recipientstate!=".")	//**001
			{
				if(($recipientzip == "") || (!isNumeric($recipientzip)) || (UDF_strlen($recipientzip) != 5))
				{
				  $err_flag=1;
				  $rzip_err_flag=1;
				}
				$validStZip = IsValidZip($recipientstate, $recipientzip);
				if (($recipientstate != "") && ($validStZip == 0) )
				{ 
				  $err_flag=1;
				  $rzip_err_flag=1;
				}
			}
			if(($recipientaddress == "") ||  (UDF_strlen($recipientaddress) > 45))
			{
			   $err_flag=1;
			   $raddr_err_flag=1;
			}
			if($recipientstate!=".")	//**001
			{
				if(($recipientstate == "") || (UDF_strlen($recipientstate) != 2) || (!fmtname($recipientstate)))
				{
				   $err_flag=1;
				   $rstate_err_flag=1;
				}
				if (($recipientstate != "") && (IsValidState($recipientstate) == 0) )
				{ 
				  $err_flag=1;
				  $rstate_err_flag=1;
				}
			}
			if(($recipientcity == "") ||  (!fmtnamesp($recipientcity)))
			{
			   $err_flag=1;
			   $rcity_err_flag=1;
			}
		}
	}

if(($int99_market_discount != "") && (!isNumeric($int99_market_discount)))
{
   $err_flag=1;
   $int99_market_discount_err_flag=1;
}

if(($int99_bond_premium != "") && (!isNumeric($int99_bond_premium)))
{
   $err_flag=1;
   $int99_bond_premium_err_flag=1;
}

if(($int99_bond_pre_taxempt != "") && (!isNumeric($int99_bond_pre_taxempt)))
{
   $err_flag=1;
   $int99_bond_pre_taxempt_err_flag=1;
}

if(($int99_bond_prem_treasury != "") && (!isNumeric($int99_bond_prem_treasury)))
{
   $err_flag=1;
   $int99_bond_prem_treasury_err_flag=1;
}
/*if(($payercity != "") && (UDF_strlen($payercity) <= 3))
{
  $err_flag=1;
  $pcitylen_err_flag=1;
}*/
/*if(($for_country != "") && (!fmtnamesp($for_country)))
{
   $err_flag=1;
   $forcount_err_flag=1;
}*/
if(($for_country == "") && ($f1116int_block_autocalc_ind == 1) && ($for_tax_paid > 0))
{
	$err_flag = 1;
	$forcount_err_flag = 1;
}
else if(UDF_strlen(UDF_trim($for_country))!=0)
{
	$AllowedArrayComboValue = array('','UO','VA','RC','HT','96','95','86');
	
	$get_countryname_qry ="select country_name from general_country_code where ";
	$get_countryname_qry .= "country_cd=(?) "; db_sql_BuildParamArray($for_country, "general_country_code::country_cd");
	$countryname_result  = db_sql_query(array($get_countryname_qry), $_SQL_ParamsArray);
	$countryname_noOfRows = db_num_rows(array($countryname_result));
	if($countryname_noOfRows > 0)
	{}
	else if(($for_country != "") && (!IsValidValue($for_country, $AllowedArrayComboValue)))
	{
		$err_flag = 1;
		$forcount_err_flag = 1;
	}
	db_free_result(array($countryname_result));
}
if(($int_inc == "") || (!isNumeric($int_inc)))
{
   $err_flag=1;
   $intinc_err_flag=1;
}
/*if($int_inc == 0)
{
   $err_flag=1;
   $intinc_err_flag=1;
}*/
if(($invest_exp != "") && (!isNumeric($invest_exp)))
{
   $err_flag=1;
   $invexp_err_flag=1;
}
if(($early_with != "") && (!isNumeric($early_with)))
{
   $err_flag=1;
   $pen_err_flag=1;
}
if(($int_on_USSav != "") && (!isNumeric($int_on_USSav)))
{
   $err_flag=1;
   $intonUSS_err_flag=1;
}
if(($for_tax_paid != "") && (!isNumeric($for_tax_paid)))
{
   $err_flag=1;
   $fortax_err_flag=1;
}
if(($tax_exempt_1099int != "") && (!isNumeric($tax_exempt_1099int)))
{
   $err_flag=1;
   $tax_exempt_1099int_err_flag=1;
}
if(($spec_bond_int != "") && (!isNumeric($spec_bond_int)))
{
   $err_flag=1;
   $specbond_err_flag=1;
}
$box8_9_mismatch = 0;
if($spec_bond_int > $tax_exempt_1099int)
{
   $err_flag=1;
   $box8_9_mismatch = 1;
   $tax_exempt_1099int_err_flag=1;
   $specbond_err_flag=1;
}
if(($fed_inc_tax != "") && (!isNumeric($fed_inc_tax)))
{
   $err_flag=1;
   $fed_err_flag=1;
}
if(($int_on_USSav_pryr != "") && (!isNumeric($int_on_USSav_pryr)))
{
   $err_flag=1;
   $int_on_USSav_pryr_err_flag=1;
}
else if(($int_on_USSav_pryr != "") && (isNumeric($int_on_USSav_pryr)))
{
	$int_on_USSavTmp = (float) $int_on_USSav;
	if($int_on_USSavTmp < $int_on_USSav_pryr)
	{
	   $err_flag=1;
	   $int_on_USSav_pryr_over_err=1;
	}
}
//abp_adj - Added New TY2010
/*if(($abp_adj != "") && (!isNumeric($abp_adj))) 
{
	$err_flag = 1;
	$abp_adj_err_flag = 1;

}*/

if(($taxexemt_acrued_bond_amt != "") && (!isNumeric($taxexemt_acrued_bond_amt))) 
{
	$err_flag = 1;
	$taxexemt_acrued_bond_amt_err_flag = 1;

}

if(($adj_box1_accint_earnamt != "") && (!isNumeric($adj_box1_accint_earnamt))) 
{
	$err_flag = 1;
	$adj_box1_accint_earnamt_err_flag = 1;

}

if(($adj_box3_accint_earnamt != "") && (!isNumeric($adj_box3_accint_earnamt))) 
{
	$err_flag = 1;
	$adj_box3_accint_earnamt_err_flag = 1;

}

//add-2012
if($nominee_state !=".")
{
	if(($nominee_state!="") && (IsValidState($nominee_state) == 0) )
	{ 
	  $err_flag=1;
	  $nominee_state_err_flag=1;
	}
}
/*if(($nominee_identify != "") && ((!isNumeric($nominee_identify)) || (UDF_strlen($nominee_identify) != 9)))
{
   $err_flag=1;
   $nominee_identify_err_flag=1;
}*/

if (($nominee_state == "MN") && ($state_tax_withheld > 0) && ((!fmtNum($nominee_identify)) || ($nominee_identify == "") || (UDF_strlen($nominee_identify) != 7)))
{
	$err_flag = 1;
	$nominee_identify_err_flag = 1;
}

if(($state_tax_withheld != "") && (!isNumeric($state_tax_withheld)))
{
   $err_flag=1;
   $state_tax_withheld_err_flag=1;
}

/*
$box3_8_mismatch_gr = 0;
if($tax_exempt_1099int > $int_inc)
{
   $err_flag=1;
   $box3_8_mismatch_gr = 1;
   $int_inc_err_flag=1;
   $tax_exempt_1099int_err_flag=1;
}*/

if((UDF_trim($part) == "ACC") && ($accrued_amt != 0))
{
}
else if(($int_inc == 0) && ($tax_exempt_1099int == 0) && ($int_on_USSav == 0) && ($early_with == 0) && ($for_tax_paid == 0) && ($invest_exp == 0) && ($int99_market_discount == 0))
{
   $err_flag=1;
   $intinc_err_flag1=1;
   $tax_exempt_1099int_err_flag1=1;
   $intonUSS_err_flag1=1;
   $pen_err_flag1=1;
   $fortax_err_flag1=1;
   $invexp_err_flag1=1;
   $int99_market_discount_err_flag1 = 1;
}

if($F8958_Eligible_Questions == "true")//($filing_status == "separate") && ($f8958_not_inc_rows > 0)  && 
	$report_to_frm8958_ind = $report_to_frm8958_ind;
else
	$report_to_frm8958_ind = 0;

//if($filing_status == "joint") 
	$AllowedArrayValues = array("0", "1", "2");
/*else
	$AllowedArrayValues = array("0");*/

if(($whose_int != "") && (!IsValidValue($whose_int, $AllowedArrayValues)))
{
	$err_flag = 1;
	$whose_int_err = 1;
}

$AllowedArrayValues = array("INT", "ACC", "NOM");

if(($part != "") && (!IsValidValue($part, $AllowedArrayValues)))
{
	$err_flag = 1;
	$part_err = 1;
}


if(UDF_trim($OLTPRO_masterID) == '')
{
	$cmn_payer_combo 	= "payerin_1099int";
	$cmn_payer_name1 	= "payername";
	if(UDF_trim($payerin) == "")
		${$cmn_payerin."Skip"} = 1;
	else
		$cmn_payerin 	= "payerin";
	$cmn_account_nbr 	= "account_num";
  $form_name		= "1099INT";
	include("../oltproc/olt_payer_common_val.php");
	
	if($err_flag!=1)
	{	
				$olt_payer_name 	= fmtvalue($payername);
				$olt_payer_name2	="";
				$olt_payerin		= UDF_trim($payerin);
				$olt_payer_account_nbr	= UDF_trim($account_num);
				$olt_payer_frgn_addrs_ind = (int)UDF_trim($payer_frgn_add_ind);
				if($payer_frgn_add_ind == 1)
				{
					$olt_payer_frgn_address	=FormatAddress($payer_frgn_address);
					$olt_payer_frgn_address2 = "";
					$olt_payer_frgn_city	= fmtvalue($payer_frgn_city);
					$olt_payer_frgn_state	= fmtvalue($payer_frgn_state);
					$olt_payer_frgn_country	= fmtvalue($payer_frgn_country);
					$olt_payer_frgn_zip	= fmtvalue($payer_frgn_zip);
				}
				else
				{	
					$olt_payer_us_address 	= FormatAddress($payeraddress);
					$olt_payer_us_address2  = "";
					$olt_payer_us_city 	= FormatCity($payercity);
					$olt_payer_us_state 	= fmtvalue($payerstate);
					$olt_payer_us_zip 	= fmtvalue($payerzip);
					$olt_payer_us_zip_ext   = "";
				}
				
		if((UDF_trim($payerin) != "") && (UDF_strlen($payerin) == 9))
		{		
			if($payerin_1099int == "Add New")
			{	
				$action = "Add New";
				$called_frm_InputPage = 1;
				include("../oltproc/olt_get_payer_details.php");
			}	
		else
		{
			$action = "";		
				$olt_payer_details_id = $payerin_1099int;
			$called_frm_InputPage = 1;
			include("../oltproc/olt_get_payer_details.php"); 
			
				/*$payername 		= $olt_payer_name;
			$payerin		= $olt_payerin;
			$account_num		= $olt_payer_account_nbr;
			$payer_frgn_add_ind 	= $olt_payer_frgn_addrs_ind;
			
			if($payer_frgn_add_ind == 1)
			{
				$payer_frgn_address	= $olt_payer_frgn_address; 		
				$payer_frgn_city	= $olt_payer_frgn_city;
				$payer_frgn_state	= $olt_payer_frgn_state;
				$payer_frgn_country	= $olt_payer_frgn_country;
				$payer_frgn_zip		= $olt_payer_frgn_zip;
			}
			else
			{
				$payeraddress 		= $olt_payer_us_address;
				$payercity 		= $olt_payer_us_city;
				$payerstate 		= $olt_payer_us_state;
				$payerzip 		= $olt_payer_us_zip;
				}*/
			}
		}
	}	
}
else
{
	if(($payername == "") ||  (!isAlphaNumericnumsp($payername)))
	{
	   $err_flag=1;
	   $pname_err_flag=1;
	}
		
	if(($payerin != "") && ((UDF_strlen($payerin) != 9) || (!IsValidEIN($payerin)) || ($payerin == "000000000")))
	{
	   $err_flag=1;
	   $pfin_err_flag=1;
	}
	
	if(($payerin != "") && (!isNumeric($payerin)))
	{
	   $err_flag=1;
	   $pfin_err_flag=1;
	}
			
	if(($account_num != "") && (!(UDF_strlen($account_num) >0) || (!IsAlphaNumeric($account_num))))
	{
	   $err_flag=1;
	   $acct_err_flag=1;
	}
}
	
if($err_flag ==0)
{ 	
         $int_inc 	= (float) $int_inc;
         $early_with 	= (float) $early_with;
         $int_on_USSav 	= (float) $int_on_USSav;
         $int_on_USSav_pryr = (float) $int_on_USSav_pryr;
         $fed_inc_tax 	= (float) $fed_inc_tax;
         $invest_exp 	= (float) $invest_exp;
         $for_tax_paid 	= (float) $for_tax_paid;
         $int_on_USSav 	= (float) $int_on_USSav;
         $tax_exempt_1099int 	= (float) $tax_exempt_1099int;
         $spec_bond_int 	= (float) $spec_bond_int;
         $nominee_amt=UDF_round((float)$nominee_amt);
         $nominee_desc = Formatdescription($nominee_desc); 
         $accrued_amt=UDF_round((float)$accrued_amt);
       	 //$abp_adj = (float)UDF_round($abp_adj); //abp_adj - Added New TY2010
       	 $taxexemt_acrued_bond_amt = (float)($taxexemt_acrued_bond_amt);
       	 $adj_box1_accint_earnamt = (float)($adj_box1_accint_earnamt);
       	 $adj_box3_accint_earnamt = (float)($adj_box3_accint_earnamt);
         //**Start 002
         $for_country = UDF_substr($for_country,0,100);
         if($payerstate==".")
         {
         	$payerzip ="";
         }
         if($recipientstate==".")
         {
         	$recipientzip="";
         }
         //** end 002

	    $joint_ind=0;         
	    if ($whose_int == 1)
	    {
	      $who ='S';
	    }
	    else if ($whose_int == 2)
	    {
	      $who='P';
	      $joint_ind=1;
	    }
	    else
	    {
	      $who='P';
	    }

	if($f1116int_block_autocalc_ind == 0)
		$f1116int_block_autocalc_ind = 1;
	else
		$f1116int_block_autocalc_ind = 0;

	$query="select ssn,last_name,first_name,middle_initial from customer where ";
	$query.= "qt_user_id=(?) "; db_sql_BuildParamArray($qt_user_id, "customer::qt_user_id");
	$query.= "and relation=(?) "; db_sql_BuildParamArray($who, "customer::relation");
	$result_1040 = db_sql_query(array($query), $_SQL_ParamsArray);
	
	$res_data=db_fetchrow(array($result_1040, DB_GETMODE_ASSOC));
	$recipientin              = $res_data["ssn"];
	$recipientSSN              = $res_data["ssn"];
	$recipientname      = $res_data["first_name"]. " ".$res_data["middle_initial"]." ". $res_data["last_name"];
	db_free_result(array($result_1040));
	$recipientname = UDF_substr($recipientname,0,50);
	
/*
    $int_inc = UDF_round($int_inc);

    $payerin = fixnum($payerin);
    $recipientin = fixnum($recipientin);
    $recipientname = FormatNameLine1($recipientname);
    $recipientaddress = FormatAddress($recipientaddress);
    $recipientcity = FormatCity($recipientcity);
    $recipientstate = fixalpha($recipientstate);
    $payername = FormatEmpName($payername);
    $payeraddress = FormatAddress($payeraddress);
    $payercity = FormatCity($payercity);
    $payerstate = fixalpha($payerstate);
  


    if ($int_inc  == "") {
        $int_inc  = 0;
	
    }

    if (UDF_strlen($payername) < 3) {
        $invalid="Please enter a number payor name.";
	
    }
    if ($invalid <> "") {
		// return(0);
    }
*/

$abp_adj =0;
if($dont_amortize_bond_ind == 0)
{
	$abp_adj += $int99_bond_premium;
}


$rcpnt_frgn_state = UDF_substr($rcpnt_frgn_state,0,17);
$nominee_identify = UDF_substr($nominee_identify,0,16);
    	
if($newaction == "addint")
{
	$query="select ssn from customer where ";
	$query .= "qt_user_id=(?) "; db_sql_BuildParamArray($qt_user_id, "customer::qt_user_id");
	$query .= "and relation=(?) "; db_sql_BuildParamArray('P', "customer::relation");
	$result_1040 = db_sql_query(array($query), $_SQL_ParamsArray);
	$noOfRowsCust = db_num_rows(array($result_1040));
	if ($noOfRowsCust > 0)
	{
		$res_data=db_fetchrow(array($result_1040, DB_GETMODE_ASSOC));
		$ssn        = $res_data["ssn"];
	}
	db_free_result(array($result_1040));

	$_SQL_DataArray[] = array( "key"=> "qt_user_id", "val"=>$qt_user_id, "table"=>"int1099");
	$_SQL_DataArray[] = array( "key"=> "part", "val"=>'INT', "table"=>"int1099");
	$_SQL_DataArray[] = array( "key"=> "ssn", "val"=>$ssn, "table"=>"int1099");
	$out_sqlparm = db_sql_paramformat($_SQL_DataArray);

	$query ="insert into int1099 (".$out_sqlparm['_SQL_FieldClause'].") values (".$out_sqlparm['_SQL_ValueClause'].")";
	$result = db_sql_query(array($query), $_SQL_ParamsArray);		
	db_free_result(array($result));
	
	$query_clause ="select max(int1099_ID)'id' from int1099 where ";
	$query_clause .= "qt_user_id=(?) "; db_sql_BuildParamArray($qt_user_id, "int1099::qt_user_id");
	$result = db_sql_query(array($query_clause), $_SQL_ParamsArray);
	$noOfRows = db_num_rows(array($result));
	
	if ($noOfRows > 0)
	{
		$res_data = db_fetchrow(array($result, DB_GETMODE_ASSOC));
		$id 	= UDF_trim($res_data["id"]);
	}
	db_free_result(array($result));
	
	$newaction = "editint";
}	
if ($newaction == "editint")  {
	// 003 BEGIN      
	$_SQL_DataArray[] = array( "key"=> "int_inc", "val"=>(float)$int_inc, "table"=>"int1099");         
	$_SQL_DataArray[] = array( "key"=> "payername", "val"=>$payername, "table"=>"int1099"); 
//if($OLTPRO_masterID != "")        
	if($show_aloc_state_ind == 1)         
	{         
		$_SQL_DataArray[] = array( "key"=> "aloc_state", "val"=>$aloc_state, "table"=>"int1099");         
		if($show_city_combo_ind == 1)         
			$_SQL_DataArray[] = array( "key"=> "aloc_city", "val"=>$aloc_city, "table"=>"int1099");         
	}         
	$_SQL_DataArray[] = array( "key"=> "payer_rtn", "val"=>$PayerRTN, "table"=>"int1099");         
	$_SQL_DataArray[] = array( "key"=> "payerin", "val"=>$payerin, "table"=>"int1099");
	//$_SQL_DataArray[] = array( "key"=> "interest_report_ind", "val"=>(int)$interest_report_ind, "table"=>"int1099");
	if($payer_frgn_add_ind == 1)         
	{         
		$_SQL_DataArray[] = array( "key"=> "payer_frgn_add_ind", "val"=>'1', "table"=>"int1099");         
		$_SQL_DataArray[] = array( "key"=> "payer_frgn_address", "val"=>$payer_frgn_address, "table"=>"int1099");         
		$_SQL_DataArray[] = array( "key"=> "payer_frgn_city", "val"=>$payer_frgn_city, "table"=>"int1099");         
		$_SQL_DataArray[] = array( "key"=> "payer_frgn_state", "val"=>$payer_frgn_state, "table"=>"int1099");         
		$_SQL_DataArray[] = array( "key"=> "payer_frgn_country", "val"=>$payer_frgn_country, "table"=>"int1099");         
		$_SQL_DataArray[] = array( "key"=> "payer_frgn_zip", "val"=>$payer_frgn_zip, "table"=>"int1099");         
		 
		$_SQL_DataArray[] = array( "key"=> "payeraddress", "val"=>'', "table"=>"int1099");         
		$_SQL_DataArray[] = array( "key"=> "payercity", "val"=>'', "table"=>"int1099");         
		$_SQL_DataArray[] = array( "key"=> "payerstate", "val"=>'', "table"=>"int1099");         
		$_SQL_DataArray[] = array( "key"=> "payerzip", "val"=>'', "table"=>"int1099");         
	}         
	else         
	{         
		$_SQL_DataArray[] = array( "key"=> "payer_frgn_add_ind", "val"=>'0', "table"=>"int1099");         
		$_SQL_DataArray[] = array( "key"=> "payer_frgn_address", "val"=>'', "table"=>"int1099");         
		$_SQL_DataArray[] = array( "key"=> "payer_frgn_city", "val"=>'', "table"=>"int1099");         
		$_SQL_DataArray[] = array( "key"=> "payer_frgn_state", "val"=>'', "table"=>"int1099");         
		$_SQL_DataArray[] = array( "key"=> "payer_frgn_country", "val"=>'', "table"=>"int1099");         
		$_SQL_DataArray[] = array( "key"=> "payer_frgn_zip", "val"=>'', "table"=>"int1099");         
		     
		$_SQL_DataArray[] = array( "key"=> "payeraddress", "val"=>$payeraddress, "table"=>"int1099");         
		$_SQL_DataArray[] = array( "key"=> "payercity", "val"=>$payercity, "table"=>"int1099");         
		$_SQL_DataArray[] = array( "key"=> "payerstate", "val"=>$payerstate, "table"=>"int1099");         
		$_SQL_DataArray[] = array( "key"=> "payerzip", "val"=>$payerzip, "table"=>"int1099");         
	}         
	$_SQL_DataArray[] = array( "key"=> "recipientin", "val"=>$recipientin, "table"=>"int1099");         
	$_SQL_DataArray[] = array( "key"=> "ssn", "val"=>$recipientSSN, "table"=>"int1099");         
	$_SQL_DataArray[] = array( "key"=> "recipientname", "val"=>$recipientname, "table"=>"int1099");         
	if($rcpnt_frgn_addr_ind == 1)         
	{         
		$_SQL_DataArray[] = array( "key"=> "rcpnt_frgn_addr_ind", "val"=>'1', "table"=>"int1099");         
		$_SQL_DataArray[] = array( "key"=> "recip_frgn_address", "val"=>$recip_frgn_address, "table"=>"int1099");         
		$_SQL_DataArray[] = array( "key"=> "recip_frgn_city", "val"=>$recip_frgn_city, "table"=>"int1099");         
		$_SQL_DataArray[] = array( "key"=> "rcpnt_frgn_state", "val"=>$rcpnt_frgn_state, "table"=>"int1099");         
		$_SQL_DataArray[] = array( "key"=> "rcpnt_frgn_ctry_code", "val"=>$rcpnt_frgn_ctry_code, "table"=>"int1099");         
		$_SQL_DataArray[] = array( "key"=> "recip_frgn_zip", "val"=>$recip_frgn_zip, "table"=>"int1099");         
		 
		$_SQL_DataArray[] = array( "key"=> "recipientaddress", "val"=>'', "table"=>"int1099");         
		$_SQL_DataArray[] = array( "key"=> "recipientcity", "val"=>'', "table"=>"int1099");         
		$_SQL_DataArray[] = array( "key"=> "recipientstate", "val"=>'', "table"=>"int1099");         
		$_SQL_DataArray[] = array( "key"=> "recipientzip", "val"=>'', "table"=>"int1099");         
	}         
	else         
	{         
		$_SQL_DataArray[] = array( "key"=> "rcpnt_frgn_addr_ind", "val"=>'0', "table"=>"int1099");         
		$_SQL_DataArray[] = array( "key"=> "recip_frgn_address", "val"=>'', "table"=>"int1099");         
		$_SQL_DataArray[] = array( "key"=> "recip_frgn_city", "val"=>'', "table"=>"int1099");         
		$_SQL_DataArray[] = array( "key"=> "rcpnt_frgn_state", "val"=>'', "table"=>"int1099");         
		$_SQL_DataArray[] = array( "key"=> "rcpnt_frgn_ctry_code", "val"=>'', "table"=>"int1099");         
		$_SQL_DataArray[] = array( "key"=> "recip_frgn_zip", "val"=>'', "table"=>"int1099");         
		 
		$_SQL_DataArray[] = array( "key"=> "recipientaddress", "val"=>$recipientaddress, "table"=>"int1099");         
		$_SQL_DataArray[] = array( "key"=> "recipientcity", "val"=>$recipientcity, "table"=>"int1099");         
		$_SQL_DataArray[] = array( "key"=> "recipientstate", "val"=>$recipientstate, "table"=>"int1099");         
		$_SQL_DataArray[] = array( "key"=> "recipientzip", "val"=>$recipientzip, "table"=>"int1099");         
	}         
	$_SQL_DataArray[] = array( "key"=> "FATCA_filing_req_ind", "val"=>(int)$FATCA_filing_req_ind, "table"=>"int1099");         
	$_SQL_DataArray[] = array( "key"=> "account_num", "val"=>$account_num, "table"=>"int1099");         
	$_SQL_DataArray[] = array( "key"=> "early_with", "val"=>(float)$early_with, "table"=>"int1099");         
	$_SQL_DataArray[] = array( "key"=> "int_on_USSav", "val"=>(float)$int_on_USSav, "table"=>"int1099");         
	$_SQL_DataArray[] = array( "key"=> "fed_inc_tax", "val"=>(float)$fed_inc_tax, "table"=>"int1099");         
	$_SQL_DataArray[] = array( "key"=> "invest_exp", "val"=>(float)$invest_exp, "table"=>"int1099");         
	$_SQL_DataArray[] = array( "key"=> "for_tax_paid", "val"=>(float)$for_tax_paid, "table"=>"int1099");         
	$_SQL_DataArray[] = array( "key"=> "tax_exempt_1099int", "val"=>(float)$tax_exempt_1099int, "table"=>"int1099");         
	$_SQL_DataArray[] = array( "key"=> "spec_bond_int", "val"=>(float)$spec_bond_int, "table"=>"int1099");         
	$_SQL_DataArray[] = array( "key"=> "for_country", "val"=>$for_country, "table"=>"int1099");         
	$_SQL_DataArray[] = array( "key"=> "int_on_USSav_pryr", "val"=>(float)$int_on_USSav_pryr, "table"=>"int1099");         
	$_SQL_DataArray[] = array( "key"=> "tax_exempt_CUSIP_no", "val"=>$tax_exempt_CUSIP_no, "table"=>"int1099");         
	  
	if(UDF_trim($part) == "NOM")         
	{         
		$_SQL_DataArray[] = array( "key"=> "nominee_amt", "val"=>(float)$nominee_amt, "table"=>"int1099");         
		$_SQL_DataArray[] = array( "key"=> "nominee_desc", "val"=>$nominee_desc, "table"=>"int1099");         
	}         
	else         
	{         
		$_SQL_DataArray[] = array( "key"=> "nominee_amt", "val"=>'0', "table"=>"int1099");         
		$_SQL_DataArray[] = array( "key"=> "nominee_desc", "val"=>'', "table"=>"int1099");         
	}         
	/*if(UDF_trim($part) == "ACC")         
	{         
		$_SQL_DataArray[] = array( "key"=> "accrued_amt", "val"=>(float)$accrued_amt, "table"=>"int1099");         
	}         
	else*/         
	{         
		$_SQL_DataArray[] = array( "key"=> "accrued_amt", "val"=>'0', "table"=>"int1099");         
	}         
	  
	$_SQL_DataArray[] = array( "key"=> "abp_adj", "val"=>(float)$abp_adj, "table"=>"int1099");         //abp_adj - Added New 
	$_SQL_DataArray[] = array( "key"=> "dont_amortize_bond_ind", "val"=>(int)$dont_amortize_bond_ind, "table"=>"int1099");         
	$_SQL_DataArray[] = array( "key"=> "taxexemt_acrued_bond_amt", "val"=>(float)$taxexemt_acrued_bond_amt, "table"=>"int1099");         
	$_SQL_DataArray[] = array( "key"=> "adj_box1_accint_earnamt", "val"=>(float)$adj_box1_accint_earnamt, "table"=>"int1099");         
	$_SQL_DataArray[] = array( "key"=> "adj_box3_accint_earnamt", "val"=>(float)$adj_box3_accint_earnamt, "table"=>"int1099");         
	
	$part = UDF_trim($part);                  
	$_SQL_DataArray[] = array( "key"=> "part", "val"=>$part, "table"=>"int1099");         
	     
	$_SQL_DataArray[] = array( "key"=> "who", "val"=>$who, "table"=>"int1099");         
	$_SQL_DataArray[] = array( "key"=> "joint_ind", "val"=>(int)$joint_ind, "table"=>"int1099");         
	  
	$_SQL_DataArray[] = array( "key"=> "prior_year_imported_ind", "val"=>'0', "table"=>"int1099");         
	$_SQL_DataArray[] = array( "key"=> "imported_not_visited_ind", "val"=>'0', "table"=>"int1099");         
	  
	$_SQL_DataArray[] = array( "key"=> "nominee_state", "val"=>$nominee_state, "table"=>"int1099");
	$_SQL_DataArray[] = array( "key"=> "nominee_identify", "val"=>$nominee_identify, "table"=>"int1099");
	$_SQL_DataArray[] = array( "key"=> "state_tax_withheld", "val"=>(float)$state_tax_withheld, "table"=>"int1099");         
	$_SQL_DataArray[] = array( "key"=> "int_areacode", "val"=>$int_areacode, "table"=>"int1099");         
	$_SQL_DataArray[] = array( "key"=> "int_phone", "val"=>$int_phone, "table"=>"int1099");         
	$_SQL_DataArray[] = array( "key"=> "int99_market_discount", "val"=>(float)$int99_market_discount, "table"=>"int1099");         
	$_SQL_DataArray[] = array( "key"=> "int99_bond_premium", "val"=>(float)$int99_bond_premium, "table"=>"int1099");         
	$_SQL_DataArray[] = array( "key"=> "derived_ord_course_ind", "val"=>(int)$derived_ord_course_ind, "table"=>"int1099");         
	$_SQL_DataArray[] = array( "key"=> "report_to_frm8958_ind", "val"=>(int)$report_to_frm8958_ind, "table"=>"int1099");         
	$_SQL_DataArray[] = array( "key"=> "int99_bond_pre_taxempt", "val"=>(float)$int99_bond_pre_taxempt, "table"=>"int1099");         
	$_SQL_DataArray[] = array( "key"=> "int99_bond_prem_treasury", "val"=>(float)$int99_bond_prem_treasury, "table"=>"int1099");         
	$_SQL_DataArray[] = array( "key"=> "f1116int_block_autocalc_ind", "val"=>(int)$f1116int_block_autocalc_ind, "table"=>"int1099");         
	
	$_SQL_DataArray[] = array( "key"=> "complete_ind", "val"=>'1', "table"=>"int1099");         
	if((UDF_trim($payerin) != "") && (UDF_strlen($payerin) == 9))
		$_SQL_DataArray[] = array( "key"=> "payer_details_id", "val"=>$olt_payer_details_id, "table"=>"int1099");
	else	
	  	$_SQL_DataArray[] = array( "key"=> "payer_details_id", "val"=>'0', "table"=>"int1099");
	  	
	$out_sqlparm = db_sql_paramformat($_SQL_DataArray);
	
	$query_clause="update int1099 set ".$out_sqlparm["_SQL_UpdateClause"]." WHERE ";
	$query_clause.= "qt_user_id=(?) "; db_sql_BuildParamArray($qt_user_id, "int1099::qt_user_id");
	$query_clause.= " and int1099_ID=(?) "; db_sql_BuildParamArray($id, "int1099::int1099_ID");
	$update_result = db_sql_query(array($query_clause), $_SQL_ParamsArray);
	
}
	
	$_SQL_DataArray[] = array( "key"=> "int1099_ind", "val"=>'1', "table"=>"organiser_ind");   	
	$out_sqlparm = db_sql_paramformat($_SQL_DataArray);
	
	$query_clause="update organiser_ind set ".$out_sqlparm["_SQL_UpdateClause"]." WHERE ";
	$query_clause.= "qt_user_id=(?) "; db_sql_BuildParamArray($qt_user_id, "organiser_ind::qt_user_id");
	$insert_result = db_sql_query(array($query_clause), $_SQL_ParamsArray);
    
    	$pro_ein_info = array("ein"=>$payerin,"eName"=>$payername,"eAddress"=>$payeraddress, "eCity"=>$payercity, "eState"=>$payerstate, "eZipCode"=>$payerzip, "eZipExt"=>"");
	include("oltpro_update_ein_db.php");
	
	if($tax_exempt_1099int > 0)
	{
		include_once("olt_pagehdr.php");
	 	include("olt_efile_rej_veri_redirect.php");  echo "<form name=form1 action=\"olt_1099int_stexempt.php\" method=post>";
		BuildDynamicFormHiddenData("tax_exempt_1099int=$tax_exempt_1099int&step=1099intnecNV&id=$id");
		include(PROTECTED_PATHQT."html/1099int_stexempt.html");	
	}
	else
	{
		$query 	      ="select qt_user_id from f1099int_state_exempt where ";
		$query 	      .= "qt_user_id=(?) "; db_sql_BuildParamArray($qt_user_id, "f1099int_state_exempt::qt_user_id");
		$query 	      .= "and int1099_ID=(?) "; db_sql_BuildParamArray($id, "f1099int_state_exempt::int1099_ID");
		$state_res  = db_sql_query(array($query), $_SQL_ParamsArray);
		$state_rows = db_num_rows(array($state_res));
		if($state_rows > 0)
		{
			$query 	      ="delete from f1099int_state_exempt where ";
			$query 	      .= "qt_user_id=(?) "; db_sql_BuildParamArray($qt_user_id, "f1099int_state_exempt::qt_user_id");
			$query 	      .= "and int1099_ID=(?) "; db_sql_BuildParamArray($id, "f1099int_state_exempt::int1099_ID");
			$state_res  = db_sql_query(array($query), $_SQL_ParamsArray);
		}
		
		if($form1040_ind == "1040NR")
		{
			include_once("olt_pagehdr.php");
		 	include("olt_efile_rej_veri_redirect.php");  echo "<form name=form1 action=\"olt_1099intnec.php\" method=post>";
			BuildDynamicFormHiddenData("step=1099intnecNV&id=$id");
			include(PROTECTED_PATHQT."html/1099intnec.html");		
		}
		else
		{		
			include_once("olt_pagehdr.php");
		 	include("olt_efile_rej_veri_redirect.php");  echo "<form name=form1 action=\"olt_1099intdone.php\" method=post>";
			
			BuildDynamicFormHiddenData("step=1099intdone");
			include(PROTECTED_PATHQT."html/1099intdone.html");
		}
	}
	
/* HTML END */	
}        	
else
{       
	include_once("olt_pagehdr.php");
 		
 	$warning_msg ="";	
 	if(($box3_8_mismatch == 1) || ($box8_9_mismatch == 1) || ($box3_8_mismatch_gr == 1))
	{
		if($nv_mode != "1")
		{
		$warning_msg  ="<table border=\"0\" width=\"564\" style=\"border: 4px double #FF0000\" align=\"center\">";
		$warning_msg .=" <tr><td colspan=2 align=center class=\"OLTBodyError\">WARNING</td></tr>";
		}
		if($box3_8_mismatch == 1)
		{
			if($nv_mode == "1")
			{
				$nv_mode_warning_msg = "You have selected 100% Tax Exempt Interest. Your Interest Income (box 1) must equal to Tax-exempt interest (box 8).";
			}
			else
			{
			$warning_msg .=" <tr><td width=\"3%\" valign=\"top\"><b></b></td>";
			$warning_msg .=" <td width=\"97%\" class=\"OLTBodyText\">";    
			$warning_msg .= "You have selected 100% Tax Exempt Interest. Your Interest Income (box 1) must equal to Tax-exempt interest (box 8).";
			$warning_msg .=" </td></tr>";
			}
		}
		if($box3_8_mismatch_gr == 1)
		{
			if($nv_mode == "1")
			{
				$nv_mode_warning_msg = "Taxable amount interest (Box 1) must be less than or equal to Tax-Exempt Interest in Box 8.";
			}
			else
			{
			$warning_msg .=" <tr><td width=\"3%\" valign=\"top\"><b></b></td>";
			$warning_msg .=" <td width=\"97%\" class=\"OLTBodyText\">";    
			$warning_msg .= "Taxable amount interest (Box 1) must be less than or equal to Tax-Exempt Interest in Box 8.";
			$warning_msg .=" </td></tr>";
			}
		}
		if($box8_9_mismatch == 1)
		{
			if($nv_mode == "1")
			{
				$nv_mode_warning_msg = "Specified Private activity Bond Interest (Box 9) always must be less than or equal to Tax-Exempt Interest in Box 8.";
			}
			else
			{
			$warning_msg .=" <tr><td width=\"3%\" valign=\"top\"><b></b></td>";
			$warning_msg .=" <td width=\"97%\" class=\"OLTBodyText\">";    
			$warning_msg .= "Specified Private activity Bond Interest (Box 9) always must be less than or equal to Tax-Exempt Interest in Box 8.";
			$warning_msg .=" </td></tr>";
			}
		}
		
		$warning_msg .=" </td></tr>";	
		$warning_msg .="</table><br>";
	} 	
	$nv_dup_warn_msg="";
	if(($area_warning_flag == 1) || ($phone_warning_flag == 1)) 
	{
		$nv_dup_warn_msg = "<label class='control control--checkbox' style='float:left' >Check here to confirm your phone number you have entered is correct.<INPUT TYPE=\"CHECKBOX\"  value='1' name=PassValidationInd>&nbsp;<div class=\"control__indicator\"></div></label>";
	}
	
	include("olt_efile_rej_veri_redirect.php");  echo "<form name=form1 action=\"olt_1099int.php\" method=post>";
	BuildDynamicFormHiddenData("id=$id&newaction=$newaction&step=w2done");
	include(PROTECTED_PATHQT."html/1099int.html");   	

   	

/* HTML END */
	
}  
	include("olt_pageftr.php");
	
?>