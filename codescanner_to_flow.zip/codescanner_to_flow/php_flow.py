#!/usr/bin/env python3
"""
php_flow.py - Generate page-navigation flowcharts from PHP (+ HTML) files.

For a PHP page it produces a flowchart that shows
  * the page (php + the html template it shows)
  * every decision (if / elseif / else / switch / loops) with TRUE / FALSE branches
  * the MEANING of each condition, taken from the page's own HTML
    (field labels, button captions, option texts, placeholders ...)
  * DB operations (INSERT / UPDATE / DELETE / SELECT + table)
  * variable "indicator" assignments, include()/redirect to other pages
  * links / form actions found in the HTML (where the user can go next)
and writes  PNG + SVG + DOT + Mermaid + condition glossary (CSV) + a Word document.

Usage
-----
    python php_flow.py olt_f1116_foregintx_ct.php
    python php_flow.py  /path/to/folder  --entry olt_f1116_foregintx_ct.php --depth 1
    python php_flow.py  /path/to/folder                # all "root" pages of the folder

Requirements:  Python 3.8+, Graphviz ('dot' on PATH), pip install beautifulsoup4 python-docx
"""
from __future__ import annotations

import argparse
import csv
import json
import os
import re
import shutil
import subprocess
import sys
import textwrap
from collections import OrderedDict, defaultdict
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional, Tuple

try:
    from bs4 import BeautifulSoup, Comment
except ImportError:  # pragma: no cover
    sys.exit("Missing dependency:  pip install beautifulsoup4")

PHP_EXT = (".php", ".php3", ".php4", ".php5", ".phtml", ".inc")
HTML_EXT = (".html", ".htm", ".tpl", ".phtml", ".xhtml")

# --------------------------------------------------------------------------
# 1. PHP tokenizer
# --------------------------------------------------------------------------


@dataclass
class Tok:
    kind: str   # html var id str num op
    text: str
    line: int


MULTI_OPS = [
    "<<<", "===", "!==", "<=>", "**=", "...", "<<=", ">>=", "??=", "==", "!=", "<>", "<=", ">=",
    "&&", "||", "++", "--", "+=", "-=", "*=", "/=", ".=", "%=", "&=", "|=", "^=", "->", "=>",
    "::", "<<", ">>", "??", "?->", "**",
]


def tokenize(src: str):
    """Return (tokens, comments{line: text}).  Inline HTML becomes 'html' tokens,
    '?>' becomes an ';' op, '<?=' becomes the id 'echo'."""
    toks: List[Tok] = []
    comments: Dict[int, str] = {}
    i, n, line = 0, len(src), 1

    def add_comment(l, txt):
        txt = re.sub(r"^[\s/*#]+|[\s/*]+$", "", txt.strip())
        if txt:
            comments[l] = (comments.get(l, "") + " " + txt).strip()

    while i < n:
        # ---------- inline html ----------
        m = re.compile(r"<\?(php\b|=)?", re.I).search(src, i)
        # skip <?xml
        while m and src[m.end():m.end() + 3].lower() == "xml" and not m.group(1):
            m = re.compile(r"<\?(php\b|=)?", re.I).search(src, m.end())
        end_html = m.start() if m else n
        if end_html > i:
            chunk = src[i:end_html]
            toks.append(Tok("html", chunk, line))
            line += chunk.count("\n")
        if not m:
            break
        i = m.end()
        if m.group(1) == "=":
            toks.append(Tok("id", "echo", line))
        # ---------- php mode ----------
        while i < n:
            c = src[i]
            if c == "\n":
                line += 1; i += 1; continue
            if c in " \t\r":
                i += 1; continue
            if src.startswith("?>", i):
                toks.append(Tok("op", ";", line))
                i += 2
                if src.startswith("\r\n", i):
                    i += 2; line += 1
                elif src.startswith("\n", i):
                    i += 1; line += 1
                break
            if src.startswith("//", i) or (c == "#" and not src.startswith("#[", i)):
                j = i
                while j < n and src[j] != "\n" and not src.startswith("?>", j):
                    j += 1
                add_comment(line, src[i:j]); i = j; continue
            if src.startswith("/*", i):
                j = src.find("*/", i + 2)
                j = n if j < 0 else j + 2
                add_comment(line, src[i:j]); line += src[i:j].count("\n"); i = j; continue
            if src.startswith("<<<", i):
                mh = re.compile(r"<<<\s*(['\"]?)(\w+)\1\r?\n").match(src, i)
                if mh:
                    tag = mh.group(2)
                    me = re.compile(r"^\s*" + re.escape(tag) + r"\b", re.M).search(src, mh.end())
                    j = me.end() if me else n
                    body = src[mh.end(): me.start()] if me else src[mh.end():]
                    toks.append(Tok("str", body, line))
                    line += src[i:j].count("\n"); i = j; continue
            if c in "'\"`":
                j = i + 1
                while j < n and src[j] != c:
                    j += 2 if src[j] == "\\" else 1
                body = src[i + 1:j]
                toks.append(Tok("str", body, line))
                line += body.count("\n"); i = j + 1; continue
            if c == "$":
                mv = re.compile(r"\$\$?([A-Za-z_]\w*)").match(src, i)
                if mv:
                    toks.append(Tok("var", mv.group(1), line)); i = mv.end(); continue
            mi = re.compile(r"[A-Za-z_\\][\w\\]*").match(src, i)
            if mi:
                toks.append(Tok("id", mi.group(0).lstrip("\\"), line)); i = mi.end(); continue
            mn = re.compile(r"0x[0-9a-fA-F]+|\d+(\.\d+)?").match(src, i)
            if mn:
                toks.append(Tok("num", mn.group(0), line)); i = mn.end(); continue
            for op in MULTI_OPS:
                if src.startswith(op, i):
                    toks.append(Tok("op", op, line)); i += len(op); break
            else:
                toks.append(Tok("op", c, line)); i += 1
    return toks, comments


# --------------------------------------------------------------------------
# 2. PHP parser -> light AST
# --------------------------------------------------------------------------


@dataclass
class Stmt:
    kind: str                     # simple html if loop switch block
    toks: List[Tok] = field(default_factory=list)   # simple: tokens; if/loop/switch: header tokens
    line: int = 0
    body: List["Stmt"] = field(default_factory=list)
    orelse: List["Stmt"] = field(default_factory=list)
    cases: List[Tuple[List[List[Tok]], List["Stmt"], bool]] = field(default_factory=list)
    text: str = ""                # html text
    comment: str = ""
    loop_kind: str = ""


class Parser:
    MODS = {"public", "private", "protected", "static", "abstract", "final", "var"}

    def __init__(self, toks, comments):
        self.t = toks
        self.p = 0
        self.comments = comments
        self.functions: Dict[str, List[Stmt]] = {}

    # helpers
    def peek(self, k=0) -> Optional[Tok]:
        return self.t[self.p + k] if self.p + k < len(self.t) else None

    def is_id(self, *names, k=0):
        t = self.peek(k)
        return t is not None and t.kind == "id" and t.text.lower() in names

    def is_op(self, ch, k=0):
        t = self.peek(k)
        return t is not None and t.kind == "op" and t.text == ch

    def comment_for(self, line):
        return self.comments.get(line) or self.comments.get(line - 1) or ""

    def paren_group(self) -> List[Tok]:
        """at '(' -> returns tokens inside, p after ')'"""
        assert self.is_op("(")
        depth, out = 0, []
        while self.peek():
            t = self.t[self.p]; self.p += 1
            if t.kind == "op" and t.text == "(":
                depth += 1
                if depth == 1:
                    continue
            elif t.kind == "op" and t.text == ")":
                depth -= 1
                if depth == 0:
                    break
            out.append(t)
        return out

    # statements
    def parse_all(self) -> List[Stmt]:
        out = []
        while self.peek():
            s = self.statement()
            if s:
                out.append(s)
        return out

    def block_until(self, *enders) -> List[Stmt]:
        out = []
        while self.peek() and not self.is_id(*enders):
            if self.is_op("}"):
                break
            s = self.statement()
            if s:
                out.append(s)
        return out

    def body(self, alt_enders=()) -> List[Stmt]:
        """body of if/while/for: {..} | : ... endX; | single statement"""
        if self.is_op("{"):
            self.p += 1
            out = self.block_until()
            if self.is_op("}"):
                self.p += 1
            return out
        if self.is_op(":"):
            self.p += 1
            return self.block_until(*alt_enders)
        s = self.statement()
        return [s] if s else []

    def skip_semicolon(self):
        if self.is_op(";"):
            self.p += 1

    def statement(self) -> Optional[Stmt]:
        t = self.peek()
        if t is None:
            return None
        if t.kind == "html":
            self.p += 1
            return Stmt("html", text=t.text, line=t.line)
        if t.kind == "op":
            if t.text == ";":
                self.p += 1; return None
            if t.text == "{":
                self.p += 1
                inner = self.block_until()
                if self.is_op("}"):
                    self.p += 1
                return Stmt("block", body=inner, line=t.line)
            if t.text == "}":
                self.p += 1; return None
        if t.kind == "id":
            w = t.text.lower()
            while w in self.MODS and self.peek(1) and self.peek(1).kind == "id":
                self.p += 1; t = self.peek(); w = t.text.lower()
            if w == "if":
                return self.parse_if()
            if w in ("while", "for", "foreach"):
                self.p += 1
                hdr = self.paren_group()
                b = self.body(("endwhile", "endfor", "endforeach"))
                if self.is_id("endwhile", "endfor", "endforeach"):
                    self.p += 1; self.skip_semicolon()
                return Stmt("loop", toks=hdr, body=b, line=t.line, loop_kind=w,
                            comment=self.comment_for(t.line))
            if w == "do":
                self.p += 1
                b = self.body()
                hdr = []
                if self.is_id("while"):
                    self.p += 1; hdr = self.paren_group(); self.skip_semicolon()
                return Stmt("loop", toks=hdr, body=b, line=t.line, loop_kind="do-while",
                            comment=self.comment_for(t.line))
            if w == "switch":
                return self.parse_switch()
            if w == "try":
                self.p += 1
                b = self.body()
                while self.is_id("catch", "finally"):
                    self.p += 1
                    if self.is_op("("):
                        self.paren_group()
                    self.body()
                return Stmt("block", body=b, line=t.line)
            if w == "function" and self.peek(1) and (
                    self.peek(1).kind == "id" or (self.is_op("&", k=1) and self.peek(2) and self.peek(2).kind == "id")):
                self.p += 1
                if self.is_op("&"):
                    self.p += 1
                name = self.peek().text; self.p += 1
                if self.is_op("("):
                    self.paren_group()
                if self.is_op(":"):          # return type
                    while self.peek() and not self.is_op("{") and not self.is_op(";"):
                        self.p += 1
                if self.is_op("{"):
                    self.p += 1
                    b = self.block_until()
                    if self.is_op("}"):
                        self.p += 1
                    self.functions[name.lower()] = b
                else:
                    self.skip_semicolon()
                return None
            if w in ("class", "interface", "trait"):
                while self.peek() and not self.is_op("{"):
                    self.p += 1
                if self.is_op("{"):
                    self.p += 1
                    self.block_until()    # methods get registered as functions
                    if self.is_op("}"):
                        self.p += 1
                return None
        # simple statement
        start = self.p
        depth = 0
        while self.peek():
            x = self.peek()
            if x.kind == "op":
                if x.text in "([{":
                    depth += 1
                elif x.text in ")]}":
                    if depth == 0:
                        break
                    depth -= 1
                elif x.text == ";" and depth == 0:
                    break
            if x.kind == "html" and depth == 0:
                break
            self.p += 1
        toks = self.t[start:self.p]
        self.skip_semicolon()
        if not toks:
            return None
        return Stmt("simple", toks=toks, line=toks[0].line, comment=self.comment_for(toks[0].line))

    def parse_if(self) -> Stmt:
        t = self.peek(); self.p += 1
        cond = self.paren_group()
        stm = Stmt("if", toks=cond, line=t.line, comment=self.comment_for(t.line))
        alt = self.is_op(":")
        stm.body = self.body(("elseif", "else", "endif"))
        if self.is_id("elseif") or (self.is_id("else") and self.is_id("if", k=1)):
            if self.is_id("else"):
                self.p += 1
            nested = self.parse_if()    # parse_if consumes 'elseif' as 'if'
            stm.orelse = [nested]
            return stm
        if self.is_id("else"):
            self.p += 1
            stm.orelse = self.body(("endif",))
        if alt and self.is_id("endif"):
            self.p += 1; self.skip_semicolon()
        return stm

    def parse_switch(self) -> Stmt:
        t = self.peek(); self.p += 1
        subj = self.paren_group()
        stm = Stmt("switch", toks=subj, line=t.line, comment=self.comment_for(t.line))
        alt = self.is_op(":")
        if self.is_op("{") or alt:
            self.p += 1
        labels: List[List[Tok]] = []
        while self.peek():
            if self.is_op("}") or self.is_id("endswitch"):
                self.p += 1
                if alt:
                    self.skip_semicolon()
                break
            if self.is_id("case") or self.is_id("default"):
                is_def = self.is_id("default")
                self.p += 1
                lab: List[Tok] = []
                while self.peek() and not (self.is_op(":") or self.is_op(";")):
                    lab.append(self.peek()); self.p += 1
                self.p += 1
                labels.append(["default"] if is_def else lab)  # type: ignore
                # body
                body: List[Stmt] = []
                while self.peek() and not (self.is_id("case") or self.is_id("default")
                                           or self.is_op("}") or self.is_id("endswitch")):
                    s = self.statement()
                    if s:
                        body.append(s)
                if body or True:
                    stm.cases.append((labels, body, any(isinstance(x, str) for x in labels[-1:])))
                    if body:
                        labels = []
                continue
            self.p += 1
        return stm


# --------------------------------------------------------------------------
# 3. HTML index : label / meaning lookup
# --------------------------------------------------------------------------


def clean(s: Optional[str], limit=90) -> str:
    if not s:
        return ""
    s = re.sub(r"<[^>]+>", " ", s)
    s = re.sub(r"&nbsp;|\xa0", " ", s)
    s = re.sub(r"\s+", " ", s).strip(" \t\r\n:*-–—|")
    return s if len(s) <= limit else s[: limit - 1].rstrip() + "…"


def humanize(name: str) -> str:
    n = re.sub(r"[_\-\.]+", " ", name).strip()
    n = re.sub(r"(?<=[a-z])(?=[A-Z])", " ", n)
    return n


@dataclass
class FieldInfo:
    name: str
    tag: str = ""
    typ: str = ""
    label: str = ""
    label_src: str = ""
    file: str = ""
    values: Dict[str, str] = field(default_factory=dict)
    actionable: bool = False        # button / link (user clicks it)
    rank: int = 0


BLOCK_TAGS = {"p", "div", "tr", "td", "th", "table", "br", "li", "ul", "ol", "form", "h1", "h2",
              "h3", "h4", "h5", "h6", "fieldset", "body", "html", "tbody", "thead", "dd", "dt"}


class HtmlIndex:
    def __init__(self):
        self.fields: Dict[str, List[FieldInfo]] = defaultdict(list)
        self.navs: Dict[str, List[dict]] = defaultdict(list)   # file -> nav targets
        self.raw: Dict[str, str] = {}
        self.titles: Dict[str, str] = {}

    # ---- indexing ----
    def add_source(self, fname: str, html: str):
        self.raw[fname] = self.raw.get(fname, "") + "\n" + html
        # neutralise php/template tags so the parser is not confused
        h = re.sub(r"<\?(?:php|=)?(.*?)(\?>|$)", lambda m: " {{" + m.group(1).strip()[:60] + "}} ",
                   html, flags=re.S)
        soup = BeautifulSoup(h, "html.parser")
        if soup.title and soup.title.string:
            self.titles.setdefault(fname, clean(soup.title.string))
        elif soup.find(["h1", "h2"]):
            self.titles.setdefault(fname, clean(soup.find(["h1", "h2"]).get_text(" ")))
        for el in soup.find_all(True):
            if el.name in ("script", "style", "meta", "link", "html", "head", "body", "title"):
                continue
            self._index_element(el, soup, fname)
        self._index_nav(soup, fname)
        self._index_placeholders(h, fname)

    def _add(self, key, fi: FieldInfo):
        key = re.sub(r"\[\]$", "", key)
        for existing in self.fields[key]:
            if existing.file == fi.file and existing.tag == fi.tag and existing.typ == fi.typ \
                    and existing.label == fi.label:
                existing.values.update(fi.values)
                return
        self.fields[key].append(fi)

    def _index_element(self, el, soup, fname):
        names = {el.get("name"), el.get("id")} - {None, ""}
        if not names:
            return
        tag, typ = el.name, (el.get("type") or "").lower()
        label, src, rank = self._label(el, soup)
        fi = FieldInfo(name="", tag=tag, typ=typ, label=label, label_src=src, file=fname, rank=rank)
        if tag == "input" and typ in ("submit", "button", "image", "reset") or tag == "button":
            fi.actionable = True
            cap = clean(el.get("value") if tag == "input" else el.get_text(" ")) or clean(el.get("alt"))
            if not cap and tag == "button":
                cap = clean(el.get("value"))
            val = el.get("value") or cap
            fi.values[str(val)] = cap or str(val)
            fi.label = cap or fi.label
            fi.label_src = "button caption"
            fi.rank = 9
        elif tag == "select":
            for o in el.find_all("option"):
                fi.values[str(o.get("value", clean(o.get_text())))] = clean(o.get_text(" "))
        elif tag == "input" and typ in ("radio", "checkbox"):
            v = el.get("value", "on")
            t = self._text_after(el, soup)
            if t:
                fi.values[str(v)] = t
        elif tag == "input" and typ == "hidden":
            fi.values[str(el.get("value", ""))] = ""
        for nm in names:
            c = FieldInfo(**{**fi.__dict__, "name": nm, "values": dict(fi.values)})
            self._add(nm, c)

    def _text_after(self, el, soup) -> str:
        if el.get("id"):
            lab = soup.find("label", attrs={"for": el.get("id")})
            if lab:
                return clean(lab.get_text(" "))
        pl = el.find_parent("label")
        if pl:
            return clean(pl.get_text(" "))
        out = []
        for sib in el.next_siblings:
            if getattr(sib, "name", None) in ("br", "input", "p", "div", "tr", "td"):
                break
            t = sib if isinstance(sib, str) else sib.get_text(" ")
            if isinstance(sib, Comment):
                continue
            if t.strip():
                out.append(t)
                break
        return clean(" ".join(out))

    def _label(self, el, soup) -> Tuple[str, str, int]:
        tag = el.name
        if el.get("id"):
            lab = soup.find("label", attrs={"for": el.get("id")})
            if lab and clean(lab.get_text(" ")):
                return clean(lab.get_text(" ")), "<label for>", 10
        for attr in ("aria-label", "title", "placeholder", "alt"):
            if el.get(attr) and clean(el.get(attr)):
                return clean(el.get(attr)), f"{attr} attribute", 8
        if tag in ("input", "select", "textarea"):
            typ = (el.get("type") or "").lower()
            pl = el.find_parent("label")
            if pl and typ not in ("radio", "checkbox"):
                t = clean(pl.get_text(" "))
                if t:
                    return t, "enclosing <label>", 9
            fs = el.find_parent("fieldset")
            if fs and fs.find("legend") and typ in ("radio", "checkbox"):
                return clean(fs.find("legend").get_text(" ")), "<legend>", 9
            # text before the control in same cell / table row
            t = self._text_before(el)
            if t:
                return t, "text before field", 7
            cell = el.find_parent(["td", "th"])
            if cell:
                prev = cell.find_previous_sibling(["td", "th"])
                if prev and clean(prev.get_text(" ")):
                    return clean(prev.get_text(" ")), "previous table cell", 7
                row = cell.find_parent("tr")
                if row:
                    prow = row.find_previous_sibling("tr")
                    if prow and clean(prow.get_text(" ")) and len(prow.find_all("td")) <= 2:
                        return clean(prow.get_text(" ")), "previous table row", 5
            t = self._comment_before(el)
            if t:
                return t, "html comment", 4
            return "", "", 0
        # generic element (div/span/td/p/a ...): own text
        txt = clean(el.get_text(" "))
        if txt and not re.fullmatch(r"\{\{.*\}\}", txt):
            return txt, f"<{tag}> text", 6
        t = self._comment_before(el)
        if t:
            return t, "html comment", 4
        return "", "", 0

    def _text_before(self, el) -> str:
        parts = []
        for sib in el.previous_siblings:
            if isinstance(sib, Comment):
                continue
            if getattr(sib, "name", None) in BLOCK_TAGS:
                break
            if getattr(sib, "name", None) in ("input", "select", "textarea"):
                break
            t = sib if isinstance(sib, str) else sib.get_text(" ")
            if t.strip():
                parts.insert(0, t)
                if len(" ".join(parts)) > 3:
                    break
        return clean(" ".join(parts))

    def _comment_before(self, el) -> str:
        for sib in el.previous_siblings:
            if isinstance(sib, Comment):
                return clean(str(sib))
            if getattr(sib, "name", None) or (isinstance(sib, str) and sib.strip()):
                break
        return ""

    def _index_nav(self, soup, fname):
        def tgt(u):
            if not u:
                return None
            u = u.strip()
            if u.startswith(("#", "javascript:", "mailto:", "http://", "https://")) or u == "":
                return None
            base = re.split(r"[?#]", u)[0]
            base = os.path.basename(base)
            if re.search(r"(PHP_SELF|\{\{)", u) and not base.lower().endswith(PHP_EXT + HTML_EXT):
                return None
            return base if base.lower().endswith(PHP_EXT + HTML_EXT) else None

        for f in soup.find_all("form"):
            t = tgt(f.get("action"))
            btns = []
            for b in f.find_all(["input", "button"]):
                ty = (b.get("type") or ("submit" if b.name == "button" else "")).lower()
                if ty in ("submit", "image", "button"):
                    cap = clean(b.get("value") if b.name == "input" else b.get_text(" "))
                    btns.append(cap or b.get("name") or "")
            if t:
                self.navs[fname].append({"target": t, "kind": "form submit",
                                         "via": ", ".join([b for b in btns if b][:3]),
                                         "method": (f.get("method") or "get").upper()})
        for a in soup.find_all("a", href=True):
            t = tgt(a["href"])
            q = re.search(r"\?(.*)$", a["href"])
            cap = clean(a.get_text(" ")) or clean(a.get("title"))
            if q:
                for kv in re.split(r"[&;]", q.group(1)):
                    if "=" in kv:
                        k, v = kv.split("=", 1)
                        k = k.strip(); v = re.sub(r"\{\{.*?\}\}", "", v)
                        if k and v and not v.startswith("{"):
                            fi = FieldInfo(name=k, tag="a", label=cap, label_src="link caption",
                                           file=fname, actionable=True, rank=8, values={v: cap})
                            self._add(k, fi)
            if t:
                self.navs[fname].append({"target": t, "kind": "link", "via": cap, "method": "GET"})
        for m in re.finditer(r"(?:location(?:\.href)?|window\.open|location\.replace)\s*[=(]\s*['\"]([^'\"]+)['\"]",
                             str(soup)):
            t = tgt(m.group(1))
            if t:
                self.navs[fname].append({"target": t, "kind": "script", "via": "", "method": "GET"})

    def _index_placeholders(self, html, fname):
        """{$var}  {var}  <?php echo $var ?>  -> use surrounding text as description"""
        for m in re.finditer(r"\{\{[^}]*?\$(\w+)[^}]*\}\}|\{\$?(\w+)\}", html):
            name = m.group(1) or m.group(2)
            ctx = html[max(0, m.start() - 160): m.start()]
            ctx = clean(re.sub(r"[\s\S]*>", "", ctx), 80)
            after = clean(re.sub(r"^[^<]*", "", html[m.end(): m.end() + 80]), 0)
            self._add(name, FieldInfo(name=name, tag="placeholder", label=ctx or "", label_src="template placeholder",
                                      file=fname, rank=2))

    # ---- lookup ----
    def lookup(self, name: str, prefer_files=()) -> Optional[FieldInfo]:
        cands = self.fields.get(name) or self.fields.get(name.lower()) or []
        if not cands:
            low = {k.lower(): v for k, v in self.fields.items()}
            cands = low.get(name.lower(), [])
        if not cands:
            return None
        pf = set(prefer_files)

        def score(c: FieldInfo):
            return ((c.file in pf) * 100 + (1 if c.label else 0) * 20 + c.rank + (len(c.values) > 0))
        best = sorted(cands, key=score, reverse=True)
        res = FieldInfo(**{**best[0].__dict__, "values": {}})
        for c in best:                       # merge values from every occurrence
            for k, v in c.values.items():
                res.values.setdefault(k, v)
            if c.actionable:
                res.actionable = True
        return res


# --------------------------------------------------------------------------
# 4. Project: all php / html files of a folder
# --------------------------------------------------------------------------

SQL_RE = re.compile(r"^\s*\(?\s*(select|insert|update|delete|replace)\b", re.I)
REDIRECT_FN = re.compile(r"(redirect|forward|goto|location|navigate|jump|go_to|gotopage)", re.I)
CALL_SKIP = {"if", "while", "for", "foreach", "switch", "array", "list", "isset", "empty", "unset",
             "echo", "print", "return", "include", "require", "include_once", "require_once", "exit", "die"}


class Project:
    def __init__(self, root: Path, meanings: Optional[Dict[str, str]] = None, quiet=False):
        self.root = root
        self.php: Dict[str, dict] = {}
        self.html_files: Dict[str, Path] = {}
        self.functions: Dict[str, List[Stmt]] = {}
        self.index = HtmlIndex()
        self.meanings = {k.lower(): v for k, v in (meanings or {}).items()}
        self.quiet = quiet
        self._load()

    def _load(self):
        files = [p for p in self.root.rglob("*") if p.is_file()]
        for p in sorted(files):
            ext = p.suffix.lower()
            try:
                txt = p.read_text(encoding="utf-8", errors="replace")
            except OSError:
                continue
            if ext in (".php", ".php3", ".php4", ".php5", ".inc"):
                toks, cm = tokenize(txt)
                ps = Parser(toks, cm)
                stmts = ps.parse_all()
                self.php[p.name] = {"path": p, "stmts": stmts, "toks": toks, "comments": cm}
                self.functions.update(ps.functions)
                # inline html and html inside strings feed the meaning index
                html_bits = [t.text for t in toks if t.kind == "html"]
                html_bits += [t.text for t in toks if t.kind == "str" and "<" in t.text and
                              re.search(r"<\s*(input|select|textarea|button|a|td|label|form)\b", t.text, re.I)]
                if html_bits:
                    self.index.add_source(p.name, "\n".join(html_bits))
            elif ext in HTML_EXT:
                self.html_files[p.name] = p
                self.index.add_source(p.name, txt)
        # collect references for "called from"
        self.callers: Dict[str, set] = defaultdict(set)
        for name, info in self.php.items():
            for tgt in self._refs_of_php(info):
                self.callers[tgt].add(name)
        for hname, navs in self.index.navs.items():
            for nv in navs:
                self.callers[nv["target"]].add(hname)

    def _refs_of_php(self, info) -> set:
        out = set()
        for t in info["toks"]:
            if t.kind == "str" and not SQL_RE.match(t.text):
                for m in re.finditer(r"([\w\-./]+\.(?:php\d?|html?|phtml|tpl))\b", t.text, re.I):
                    out.add(os.path.basename(m.group(1)))
        return out

    # ---- page <-> html association ----
    def html_guess_for(self, php_name: str) -> List[str]:
        stem = Path(php_name).stem.lower()
        res = []
        for h in self.html_files:
            hs = Path(h).stem.lower()
            if hs == stem or stem.endswith("_" + hs) or hs.endswith("_" + stem) or stem.endswith(hs) and len(hs) > 5:
                res.append(h)
        return res

    def is_page_like(self, name: str) -> bool:
        """a php file that does something user-visible (not only function/config library)"""
        info = self.php.get(name)
        if not info:
            return False

        def interesting(stmts):
            for s in stmts:
                if s.kind in ("if", "switch", "loop"):
                    return True
                if s.kind == "html" and s.text.strip():
                    return True
                if s.kind == "block" and interesting(s.body):
                    return True
                if s.kind == "simple":
                    txt = " ".join(t.text for t in s.toks).lower()
                    if re.search(r"location|\bexit\b|\bdie\b|\becho\b|\bprint\b", txt):
                        return True
                    if any(t.kind == "str" and SQL_RE.match(t.text) for t in s.toks):
                        return True
            return False
        return interesting(info["stmts"])


# --------------------------------------------------------------------------
# 5. Condition text and meaning
# --------------------------------------------------------------------------

SUPERGLOBALS = {"_post", "_get", "_request", "_session", "_cookie", "_server", "_files",
                "http_post_vars", "http_get_vars", "http_session_vars", "globals"}


def toks_to_code(toks: List[Tok], keep_dollar=False) -> str:
    """Pretty-print tokens; collapse $_POST['x'] -> x ."""
    out: List[str] = []
    i = 0
    n = len(toks)
    while i < n:
        t = toks[i]
        if t.kind == "var" and t.text.lower() in SUPERGLOBALS and i + 3 < n + 0 and \
                toks[i + 1].text == "[" and i + 3 < n and toks[i + 3].text == "]":
            inner = toks[i + 2]
            nm = inner.text if inner.kind in ("str", "id", "num") else "$" + inner.text
            out.append(nm.strip("'\""))
            i += 4
            continue
        if t.kind == "var":
            out.append(("$" if keep_dollar else "") + t.text)
        elif t.kind == "str":
            out.append('"' + t.text + '"')
        else:
            out.append(t.text)
        i += 1
    s = ""
    for k, w in enumerate(out):
        if k and (re.match(r"[\w\"$]", w[0]) and re.match(r"[\w\"$)\]]", out[k - 1][-1])):
            s += " "
        elif w in ("&&", "||", "and", "or", "==", "===", "!=", "!==", "<>", "<", ">", "<=", ">=", "=", "xor") and k:
            s += " "
        elif k and out[k - 1] in ("&&", "||", "==", "===", "!=", "!==", "<>", "<", ">", "<=", ">=", "=", ","):
            s += " "
        s += w
    s = re.sub(r"\s+", " ", s).strip()
    return s


def split_top(expr: str, seps=("&&", "||", " and ", " or ")) -> List[Tuple[str, str]]:
    """Split on boolean operators at paren depth 0 -> [(clause, op_before)]"""
    parts, depth, cur, op_before, i = [], 0, "", "", 0
    low = expr.lower()
    while i < len(expr):
        c = expr[i]
        if c == "(":
            depth += 1
        elif c == ")":
            depth -= 1
        if depth == 0:
            hit = None
            for sp in seps:
                if low.startswith(sp, i):
                    hit = sp
                    break
            if hit:
                parts.append((cur.strip(), op_before))
                op_before = "AND" if hit.strip() in ("&&", "and") else "OR"
                cur = ""
                i += len(hit)
                continue
        cur += c
        i += 1
    parts.append((cur.strip(), op_before))
    return parts


def strip_parens(c: str) -> str:
    c = c.strip()
    while c.startswith("(") and c.endswith(")"):
        d = 0
        ok = True
        for k, ch in enumerate(c):
            d += ch == "("
            d -= ch == ")"
            if d == 0 and k < len(c) - 1:
                ok = False
                break
        if ok:
            c = c[1:-1].strip()
        else:
            break
    return c


OPS_ENGLISH = {"==": "is", "===": "is", "!=": "is not", "!==": "is not", "<>": "is not",
               "<": "is less than", ">": "is greater than", "<=": "is at most", ">=": "is at least"}


class Meaning:
    def __init__(self, project: Project, page: str, html_files: List[str]):
        self.pr = project
        self.page = page
        self.pref = [page] + list(html_files)
        self.sources: List[str] = []       # for glossary
        self.resolved = True
        self.last_table = ""
        self.notes: Dict[str, str] = {}

    def field_label(self, name: str) -> Tuple[str, Optional[FieldInfo]]:
        ov = self.pr.meanings.get(name.lower())
        if ov:
            self.sources.append(f"{name}: meanings.json")
            return ov, None
        fi = self.pr.index.lookup(name, self.pref)
        if not (fi and fi.label) and name in self.notes:
            self.sources.append(f"{name}: php code comment")
            return f"{humanize(name)} ({self.notes[name]})", fi
        if fi and fi.label:
            self.sources.append(f"{name}: {fi.file} <{fi.tag}{'/' + fi.typ if fi.typ else ''}> {fi.label_src}")
            return fi.label, fi
        self.resolved = False
        self.sources.append(f"{name}: not found in html")
        return humanize(name), fi

    def value_text(self, fi: Optional[FieldInfo], lit: str) -> str:
        if not fi:
            return ""
        lit_n = lit.strip("'\"")
        for k, v in fi.values.items():
            if k.strip() == lit_n and v and v != fi.label:
                return v
        return ""

    def clause(self, c: str) -> str:
        c = strip_parens(c)
        neg = False
        while c.startswith("!") and not c.startswith("!="):
            neg = not neg
            c = strip_parens(c[1:])
        m = re.fullmatch(r"(isset|empty|is_null|is_numeric|!empty)\s*\(\s*([\w$]+)[^)]*\)", c)
        if m:
            fn, var = m.group(1), m.group(2).lstrip("$")
            lab, _ = self.field_label(var)
            state = {"isset": "is submitted / set", "empty": "is empty", "is_null": "is empty",
                     "is_numeric": "is a number", "!empty": "is not empty"}[fn]
            if neg:
                state = {"is submitted / set": "is NOT submitted / set", "is empty": "is NOT empty",
                         "is a number": "is NOT a number", "is not empty": "is empty"}[state]
            return f"“{lab}” {state}"
        # row counts: mysql_num_rows($r) == 0 , count($rows) > 0 , $r->num_rows
        m = re.fullmatch(r"(?:\w*num_rows|rowCount|count|sizeof|mysql_num_rows|pg_num_rows)\s*\(\s*\$?[\w>\-\[\]'\"]*\s*\)\s*"
                         r"(===|==|!==|!=|<=|>=|<|>)\s*(\d+)", c)
        if not m:
            m = re.fullmatch(r"[\w>\-$]*num_rows\s*(===|==|!==|!=|<=|>=|<|>)\s*(\d+)", c)
            if m:
                m = re.match(r"(.*)", "")  # placeholder; handled below
        mm = re.search(r"(num_rows|rowCount|count|sizeof)\W.*?(===|==|!==|!=|<=|>=|<|>)\s*(\d+)\s*$", c)
        if mm and re.search(r"num_rows|rowcount|count|sizeof|rows", c, re.I) and "(" in c or (mm and "num_rows" in c):
            op, num = mm.group(2), mm.group(3)
            tbl = f" in table {self.last_table}" if self.last_table else ""
            txt = {"==": "= " + num, "===": "= " + num, "!=": "≠ " + num, "!==": "≠ " + num,
                   "<": "< " + num, ">": "> " + num, "<=": "≤ " + num, ">=": "≥ " + num}[op]
            if num == "0" and op in ("==", "==="):
                return ("No record found" + tbl) if not neg else "Record(s) found" + tbl
            if num == "0" and op in (">", "!=", "!=="):
                return ("Record(s) found" + tbl) if not neg else "No record found" + tbl
            return f"No. of rows{tbl} {txt}"
        m = re.fullmatch(r"([\w$]+)\s*(===|==|!==|!=|<>|<=|>=|<|>)\s*(.+)", c)
        rev = False
        if not m:
            m2 = re.fullmatch(r"(\"[^\"]*\"|'[^']*'|\d+(?:\.\d+)?|true|false|null)\s*(===|==|!==|!=|<>|<=|>=|<|>)\s*([\w$]+)", c, re.I)
            if m2:
                m = m2
                rev = True
        if m:
            if rev:
                lit, op, var = m.group(1), m.group(2), m.group(3)
            else:
                var, op, lit = m.group(1), m.group(2), m.group(3)
            var = var.lstrip("$")
            lit = lit.strip()
            if re.fullmatch(r"[\w$]+", lit) and not re.fullmatch(r"\d+|true|false|null", lit, re.I):
                # var compared to another var
                l1, _ = self.field_label(var)
                l2, _ = self.field_label(lit.lstrip("$"))
                return f"“{l1}” {OPS_ENGLISH[op]} “{l2}”"
            lab, fi = self.field_label(var)
            vt = self.value_text(fi, lit)
            if neg:
                op = {"==": "!=", "===": "!==", "!=": "==", "!==": "===", "<>": "==", "<": ">=", ">": "<=",
                      "<=": ">", ">=": "<"}[op]
            litc = lit.strip("'\"")
            if fi and fi.tag not in ("input", "select", "textarea", "button", "a") and fi.label \
                    and op in ("==", "===") and litc in ("1", "true"):
                return f"Message shown on page: “{lab}”"
            if fi and fi.tag not in ("input", "select", "textarea", "button", "a") and fi.label \
                    and op in ("==", "===") and litc in ("0", "false"):
                return f"No message: “{lab}” is not shown"
            if fi and fi.actionable and vt and op in ("==", "==="):
                return f"User clicked / chose “{vt}”"
            if fi and fi.actionable and vt and op in ("!=", "!==", "<>"):
                return f"User did NOT click / choose “{vt}”"
            if litc in ("1", "true") and not vt and op in ("==", "==="):
                return f"“{lab}” is ON / Yes (1)"
            if litc in ("0", "false") and not vt and op in ("==", "==="):
                return f"“{lab}” is OFF / No (0)"
            if litc.lower() == "null" or litc == "":
                return f"“{lab}” {'is' if op in ('==', '===') else 'is not'} empty"
            shown = f"“{vt}” ({litc})" if vt else f"{litc}"
            return f"“{lab}” {OPS_ENGLISH[op]} {shown}"
        m = re.fullmatch(r"[$]?(\w+)", c)
        if m:
            lab, fi = self.field_label(m.group(1))
            return f"“{lab}” is {'NOT ' if neg else ''}set / true"
        # fallback: replace known words
        def rep(mo):
            w = mo.group(0)
            if self.pr.index.lookup(w, self.pref) or w.lower() in self.pr.meanings:
                return "“" + self.field_label(w)[0] + "”"
            return w
        t = re.sub(r"(?<![\w“])[A-Za-z_]\w*(?![\w(])", rep, c)
        return ("NOT " if neg else "") + t

    def explain(self, cond: str, comment: str = "") -> Tuple[str, bool, List[str]]:
        self.sources = []
        self.resolved = True
        parts = split_top(cond)
        out = []
        for cl, op in parts:
            if not cl:
                continue
            text = self.clause(cl)
            out.append((op + " " if op else "") + text)
        meaning = " ".join(out)
        if comment and (not self.resolved):
            meaning += f"  [code comment: {comment}]"
        elif comment and not meaning:
            meaning = comment
        return meaning, self.resolved, list(dict.fromkeys(self.sources))


# --------------------------------------------------------------------------
# 6. Flow builder : AST -> nodes / edges
# --------------------------------------------------------------------------


@dataclass
class Node:
    id: str
    kind: str      # page target decision process sql display exit end loop
    label: str
    sub: str = ""          # second (italic) line: meaning
    note: str = ""
    line: int = 0
    extra: dict = field(default_factory=dict)


@dataclass
class Edge:
    src: str
    dst: str
    label: str = ""
    style: str = ""


class Flow:
    def __init__(self, project: Project, page: str, include_select=True, keep_dollar=False,
                 inline_functions=True):
        self.pr = project
        self.page = page
        self.nodes: List[Node] = []
        self.edges: List[Edge] = []
        self.glossary: List[dict] = []
        self.targets: "OrderedDict[str, str]" = OrderedDict()   # file -> how reached
        self.include_select = include_select
        self.keep_dollar = keep_dollar
        self.inline = inline_functions
        self.html_used: List[str] = []
        self._n = 0
        self.displayed = set()
        self.last_table = ""
        self.ctx_breaks: List[List] = []
        self.ctx_continues: List[List] = []
        self.ctx_returns: List[List] = []
        self.fn_stack: List[str] = []
        self.meaning: Optional[Meaning] = None
        self.sql_vars: Dict[str, str] = {}

    # -- node helpers --
    def new(self, kind, label, sub="", line=0, **extra) -> str:
        self._n += 1
        nid = f"n{self._n}"
        self.nodes.append(Node(nid, kind, label, sub, line=line, extra=extra))
        return nid

    def connect(self, pending, nid):
        for src, lab in pending:
            self.edges.append(Edge(src, nid, lab))

    def node(self, nid) -> Node:
        return next(x for x in self.nodes if x.id == nid)

    # -- build --
    def build(self) -> "Flow":
        info = self.pr.php[self.page]
        html_guess = self.pr.html_guess_for(self.page)
        self.html_used = list(html_guess)
        self.meaning = Meaning(self.pr, self.page, self.html_used)
        # discover html shown by this page, before building labels
        self._scan_html_used(info["stmts"])
        self.meaning.pref = [self.page] + self.html_used
        callers = sorted(self.pr.callers.get(self.page, []))
        head = self.page
        start = self.new("page", head, "\n".join(self.html_used),
                         called_from=", ".join(callers))
        pend = [(start, "")]
        pend = self.emit(info["stmts"], pend)
        if pend:
            e = self.new("end", "End of page")
            self.connect(pend, e)
        self._html_nav_edges(start)
        return self

    def _scan_html_used(self, stmts):
        for s in stmts:
            toks = s.toks if s.kind in ("simple", "if", "loop", "switch") else []
            for t in toks:
                if t.kind == "str":
                    for m in re.finditer(r"([\w\-./]+\.(?:html?|tpl|phtml|xhtml))\b", t.text, re.I):
                        b = os.path.basename(m.group(1))
                        if b not in self.html_used:
                            self.html_used.append(b)
            for sub in (s.body, s.orelse, *[c[1] for c in s.cases]):
                self._scan_html_used(sub)

    def _html_nav_edges(self, start):
        """Where can the user go from the html this page displays (form action / links)."""
        seen = set()
        files = [f for f in self.html_used if f not in self.displayed] + [self.page]
        for hf in files:
            for nv in self.pr.index.navs.get(hf, []):
                key = (nv["target"], nv["kind"], nv["via"])
                if key in seen or nv["target"] == self.page:
                    continue
                seen.add(key)
                tid = self.new("target", nv["target"], "", note=f"{nv['kind']}: {nv['via']}".strip(": "),
                               how="user")
                lab = f"{nv['kind']}" + (f" “{nv['via']}”" if nv["via"] else "")
                self.edges.append(Edge(start, tid, lab, "user"))
                self.targets.setdefault(nv["target"], "user")

    # -- statements --
    def emit(self, stmts: List[Stmt], pending):
        i = 0
        while i < len(stmts):
            if not pending:
                break
            s = stmts[i]
            if s.kind == "simple":
                a = self.classify(s)
                if a and a[0] == "assign":
                    group = [(s, a)]
                    while i + 1 < len(stmts) and stmts[i + 1].kind == "simple":
                        b = self.classify(stmts[i + 1])
                        if b and b[0] == "assign":
                            group.append((stmts[i + 1], b)); i += 1
                        else:
                            break
                    pending = self.emit_assign_group(group, pending)
                else:
                    pending = self.emit_simple(s, a, pending)
            elif s.kind == "html":
                pending = self.emit_html(s, pending)
            elif s.kind == "block":
                pending = self.emit(s.body, pending)
            elif s.kind == "if":
                pending = self.emit_if(s, pending)
            elif s.kind == "loop":
                pending = self.emit_loop(s, pending)
            elif s.kind == "switch":
                pending = self.emit_switch(s, pending)
            i += 1
        return pending

    # classification of a simple statement -> tuple
    def classify(self, s: Stmt):
        toks = s.toks
        if not toks:
            return None
        first = toks[0]
        fw = first.text.lower() if first.kind == "id" else ""
        txt = " ".join(t.text for t in toks)
        strs = [t for t in toks if t.kind == "str"]
        # exit / die / return / break / continue
        if fw in ("exit", "die"):
            msg = " ".join(t.text for t in strs)
            return ("exit", msg)
        if fw == "return":
            return ("return",)
        if fw == "break":
            return ("break",)
        if fw == "continue":
            return ("continue",)
        # include / require
        if fw in ("include", "include_once", "require", "require_once"):
            cands = []
            for t in toks:
                if t.kind == "str":
                    for m in re.finditer(r"([\w\-./]+\.(?:php\d?|html?|phtml|tpl|inc))\b", t.text, re.I):
                        cands.append(os.path.basename(m.group(1)))
            if cands:
                f = cands[-1]
                if f.lower().endswith(HTML_EXT) and not f.lower().endswith(".phtml"):
                    return ("display", f)
                return ("include", f)
            return None
        # header("Location: ...")
        for k, t in enumerate(toks):
            if t.kind == "id" and t.text.lower() == "header" and k + 1 < len(toks) and toks[k + 1].text == "(":
                body = "".join(x.text for x in toks[k + 2:] if x.kind == "str")
                if re.search(r"location\s*:", body, re.I):
                    m = re.search(r"([\w\-./]+\.(?:php\d?|html?))(\?[^\s'\"]*)?", body)
                    if m:
                        return ("redirect", os.path.basename(m.group(1)), (m.group(2) or "")[:60])
                    return ("redirect", "(dynamic URL)", "")
        # redirect style helper functions / javascript
        for k, t in enumerate(toks):
            if t.kind == "id" and REDIRECT_FN.search(t.text) and k + 1 < len(toks) and toks[k + 1].text == "(":
                body = "".join(x.text for x in toks[k + 2:] if x.kind == "str")
                m = re.search(r"([\w\-./]+\.(?:php\d?|html?))", body)
                if m:
                    return ("redirect", os.path.basename(m.group(1)), "")
        for t in strs:
            m = re.search(r"(?:location(?:\.href)?\s*=|location\.replace\(|window\.location\s*=|"
                          r"http-equiv=[\"']?refresh[^>]*url=)\s*[\"']?([\w\-./]+\.(?:php\d?|html?))",
                          t.text, re.I)
            if m:
                return ("redirect", os.path.basename(m.group(1)), "")
        # SQL
        sqltxt = self._sql_text(toks)
        if sqltxt:
            return ("sql",) + sqltxt
        # display template via smarty / readfile ...
        for t in strs:
            m = re.search(r"([\w\-./]+\.(?:html?|tpl|xhtml))\b", t.text, re.I)
            if m and "<" not in t.text:
                return ("display", os.path.basename(m.group(1)))
        # echo / print html
        if fw in ("echo", "print"):
            body = " ".join(t.text for t in strs)
            if "<form" in body.lower() or "<input" in body.lower() or "<table" in body.lower():
                return ("output", "HTML output (inline form / table)", "html")
            plain = clean(re.sub(r"<[^>]+>", " ", body), 70)
            if plain:
                return ("output", f"Print: “{plain}”", "text")
            return None
        # literal assignment  $x = 1;
        if len(toks) >= 3 and toks[0].kind == "var" and toks[1].text == "=":
            rest = toks[2:]
            if len(rest) == 1 and rest[0].kind in ("num", "str") or \
                    (len(rest) == 1 and rest[0].kind == "id" and rest[0].text.lower() in ("true", "false", "null")):
                v = rest[0].text if rest[0].kind != "str" else f"'{rest[0].text}'"
                return ("assign", toks[0].text, v)
            if len(rest) == 2 and rest[0].text == "-" and rest[1].kind == "num":
                return ("assign", toks[0].text, "-" + rest[1].text)
        if len(toks) >= 6 and toks[0].kind == "var" and toks[0].text.lower() in SUPERGLOBALS \
                and toks[1].text == "[" and toks[3].text == "]" and toks[4].text == "=" and len(toks) == 6 \
                and toks[5].kind in ("num", "str"):
            v = toks[5].text if toks[5].kind != "str" else f"'{toks[5].text}'"
            return ("assign", toks[2].text.strip("'\""), v)
        # user-defined function call
        if self.inline:
            for k, t in enumerate(toks):
                if t.kind == "id" and k + 1 < len(toks) and toks[k + 1].text == "(" \
                        and t.text.lower() in self.pr.functions and t.text.lower() not in CALL_SKIP:
                    if t.text.lower() not in self.fn_stack:
                        return ("call", t.text)
        return None

    def _sql_text(self, toks):
        joined = ""
        found = False
        for t in toks:
            if t.kind == "str":
                if SQL_RE.match(t.text) or (found and joined):
                    found = found or bool(SQL_RE.match(t.text))
                    joined += t.text
            elif found and t.kind == "var":
                joined += "{" + t.text + "}"
            elif found and t.kind == "op" and t.text == ",":
                break
        if not found:
            return None
        sql = re.sub(r"\s+", " ", joined).strip()
        m = re.match(r"(?is)\s*(insert|replace)\s+(?:ignore\s+)?into\s+[`\"\[]?([\w.{}$]+)", sql)
        if m:
            return ("INSERT", m.group(2), sql)
        m = re.match(r"(?is)\s*update\s+[`\"\[]?([\w.{}$]+)", sql)
        if m:
            return ("UPDATE", m.group(1), sql)
        m = re.match(r"(?is)\s*delete\s+from\s+[`\"\[]?([\w.{}$]+)", sql)
        if m:
            return ("DELETE", m.group(1), sql)
        m = re.match(r"(?is)\s*select\s.*?\sfrom\s+[`\"\[]?([\w.{}$]+)", sql)
        if m:
            return ("SELECT", m.group(1), sql)
        return None

    # -- emitters --
    def emit_simple(self, s, a, pending):
        if not a:
            return pending
        kind = a[0]
        if kind == "exit":
            n = self.new("exit", "exit" + (f"\n“{clean(a[1], 40)}”" if a[1] else ""), line=s.line)
            self.connect(pending, n)
            return []
        if kind == "return":
            if self.ctx_returns:
                self.ctx_returns[-1].extend(pending)
                return []
            n = self.new("exit", "return", line=s.line)
            self.connect(pending, n)
            return []
        if kind == "break":
            if self.ctx_breaks:
                self.ctx_breaks[-1].extend(pending)
            return []
        if kind == "continue":
            if self.ctx_continues:
                self.ctx_continues[-1].extend(pending)
            return []
        if kind == "include":
            f = a[1]
            if f == self.page:
                return pending
            if self.pr.is_page_like(f):
                n = self.new("target", f, "", note="include (runs this page / code)", how="include", line=s.line)
                self.targets.setdefault(f, "include")
                self.connect(pending, n)
                return [(n, "")]
            return pending            # library / config file: not a navigation step
        if kind == "display":
            f = a[1]
            if f not in self.html_used:
                self.html_used.append(f)
                self.meaning.pref.append(f)
            n = self.new("display", f, "Display html page", line=s.line)
            self.displayed.add(f)
            self.connect(pending, n)
            self._html_nav_for_display(n, f)
            return [(n, "")]
        if kind == "output":
            n = self.new("process", a[1], line=s.line)
            self.connect(pending, n)
            return [(n, "")]
        if kind == "redirect":
            f = a[1]
            lab = f + (f"\n{a[2]}" if len(a) > 2 and a[2] else "")
            n = self.new("target", lab if f.startswith("(") else f, "", note="redirect", how="redirect",
                         line=s.line, query=a[2] if len(a) > 2 else "")
            self.targets.setdefault(f, "redirect")
            self.connect(pending, n)
            return []
        if kind == "sql":
            op, table, sql = a[1], a[2], a[3]
            if op == "SELECT":
                self.last_table = table
                self.meaning.last_table = table
                if not self.include_select:
                    return pending
            verb = {"INSERT": "Insert record into", "UPDATE": "Update record in",
                    "DELETE": "Delete records from", "SELECT": "Read (SELECT) from"}[op]
            n = self.new("sql", f"{verb}\n{table}", s.comment if s.comment else "", line=s.line,
                         sql=sql, op=op)
            self.connect(pending, n)
            return [(n, "")]
        if kind == "call":
            fn = a[1].lower()
            self.fn_stack.append(fn)
            self.ctx_returns.append([])
            n0, e0 = len(self.nodes), len(self.edges)
            out = self.emit(self.pr.functions[fn], pending)
            rets = self.ctx_returns.pop()
            self.fn_stack.pop()
            if len(self.nodes) == n0:      # nothing interesting inside
                return pending
            if self.nodes[n0].extra.get("via_fn") is None:
                self.nodes[n0].extra["via_fn"] = a[1] + "()"
            return out + rets
        return pending

    def emit_assign_group(self, group, pending):
        names = [a[1] for _, a in group]
        vals = [a[2] for _, a in group]
        comment = next((s.comment for s, _ in group if s.comment), "")
        if len(set(vals)) == 1:
            vs = vals[0]
            shown = ", ".join(names[:8]) + (f", … (+{len(names) - 8})" if len(names) > 8 else "")
            if len(names) == 1:
                label = f"Set {names[0]} = {vs}"
            else:
                label = f"Set {len(names)} variables = {vs}\n{shown}"
        else:
            rows = [f"{n} = {v}" for n, v in zip(names, vals)]
            label = "Set\n" + "\n".join(rows[:8]) + (f"\n… (+{len(rows) - 8})" if len(rows) > 8 else "")
        meaning = comment
        if comment:
            for nm in names:
                self.meaning.notes.setdefault(nm, comment)
        if not meaning:
            labs = []
            for nm in names[:6]:
                fi = self.pr.index.lookup(nm, self.meaning.pref)
                if fi and fi.label:
                    labs.append(fi.label)
            if labs:
                meaning = "; ".join(labs[:4]) + ("…" if len(labs) > 4 else "")
        n = self.new("process", label, meaning, line=group[0][0].line)
        self.connect(pending, n)
        return [(n, "")]

    def emit_html(self, s, pending):
        txt = s.text
        if not re.search(r"<\s*(form|input|select|table|a\s|script|meta|button|body|html|div|p\b)", txt, re.I):
            return pending
        # inline html output -> display node
        forms = re.findall(r"<form[^>]*action\s*=\s*[\"']?([^\"'\s>]+)", txt, re.I)
        title = "Show page (inline HTML in php)"
        label = title + (f"\nform → {', '.join(os.path.basename(re.split('[?#]', f)[0]) for f in forms[:2])}"
                         if forms else "")
        n = self.new("display", label, "", line=s.line)
        self.connect(pending, n)
        # navigation from the inline html
        for nv in self.pr.index.navs.get(self.page, []):
            pass
        return [(n, "")]

    def _html_nav_for_display(self, nid, hfile):
        for nv in self.pr.index.navs.get(hfile, []):
            if nv["target"] == self.page:
                continue
            tid = self.new("target", nv["target"], "", note=f"{nv['kind']}: {nv['via']}".strip(": "), how="user")
            lab = nv["kind"] + (f" “{nv['via']}”" if nv["via"] else "")
            self.edges.append(Edge(nid, tid, lab, "user"))
            self.targets.setdefault(nv["target"], "user")

    def emit_if(self, s, pending):
        cond = toks_to_code(s.toks, self.keep_dollar)
        meaning, resolved, sources = self.meaning.explain(cond, s.comment)
        d = self.new("decision", cond, meaning, line=s.line, resolved=resolved)
        self.glossary.append({"page": self.page, "line": s.line, "condition": cond, "meaning": meaning,
                              "resolved": resolved, "sources": "; ".join(sources),
                              "comment": s.comment})
        self.connect(pending, d)
        t_pend = self.emit(s.body, [(d, "True")]) if s.body else [(d, "True")]
        if s.orelse:
            f_pend = self.emit(s.orelse, [(d, "False")])
        else:
            f_pend = [(d, "False")]
        return t_pend + f_pend

    def emit_loop(self, s, pending):
        hdr = toks_to_code(s.toks, self.keep_dollar)
        label = f"{s.loop_kind} ({hdr})" if s.loop_kind != "do-while" else f"do … while ({hdr})"
        meaning = s.comment or ""
        if s.loop_kind in ("while",) and hdr:
            m, _, _ = self.meaning.explain(hdr)
            meaning = meaning or m
        d = self.new("decision", label, meaning, line=s.line, loop=True)
        self.connect(pending, d)
        self.ctx_breaks.append([])
        self.ctx_continues.append([])
        body_out = self.emit(s.body, [(d, "each / True")])
        brk = self.ctx_breaks.pop()
        cont = self.ctx_continues.pop()
        for src, lab in body_out + cont:
            self.edges.append(Edge(src, d, lab, "back"))
        return [(d, "done / False")] + brk

    def emit_switch(self, s, pending):
        subj = toks_to_code(s.toks, self.keep_dollar)
        meaning, resolved, sources = self.meaning.explain(subj + " == 1") if False else ("", True, [])
        self.meaning.sources = []
        lab, fi = self.meaning.field_label(subj) if re.fullmatch(r"\w+", subj) else (subj, None)
        if fi and fi.actionable:
            sub = f"Which button / link the user clicked ({subj})"
        else:
            sub = f"switch on “{lab}”" if re.fullmatch(r"\w+", subj) else (s.comment or "")
        d = self.new("decision", f"switch ({subj})", sub, line=s.line, resolved=True, switch=True)
        self.glossary.append({"page": self.page, "line": s.line, "condition": f"switch ({subj})",
                              "meaning": sub, "resolved": bool(fi and fi.label), "sources": "; ".join(self.meaning.sources),
                              "comment": s.comment})
        self.connect(pending, d)
        self.ctx_breaks.append([])
        outs: List = []
        carry: List = []
        has_default = False
        for labels, body, _ in s.cases:
            names = []
            for lb in labels:
                if lb == ["default"] or lb == "default":
                    names.append("default"); has_default = True
                else:
                    names.append(toks_to_code(lb, self.keep_dollar))
            lab_txt = " / ".join(names)
            vt = ""
            if fi and names and names[0] != "default":
                vt = self.meaning.value_text(fi, names[0])
            elab = (f"== {lab_txt}" if lab_txt != "default" else "default") + (f"\n{vt}" if vt else "")
            if not body:
                carry = carry + [(d, elab)]
                continue
            out = self.emit(body, carry + [(d, elab)])
            carry = []
            outs.extend(out)
        brk = self.ctx_breaks.pop()
        res = outs + brk + carry
        if not has_default:
            res.append((d, "no match"))
        return res


# --------------------------------------------------------------------------
# 7. Renderers : DOT / Mermaid / Graphviz
# --------------------------------------------------------------------------


def esc(s: str) -> str:
    return (s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace('"', "&quot;"))


def wrap(s: str, width: int) -> List[str]:
    out = []
    for ln in s.split("\n"):
        out.extend(textwrap.wrap(ln, width=width, break_long_words=True, break_on_hyphens=False) or [""])
    return out


def html_label(lines_main: List[str], sub_lines: List[str] = (), note_lines: List[str] = (),
               bold=False, main_color="#1f2937") -> str:
    parts = []
    for ln in lines_main:
        t = esc(ln)
        parts.append(f'<B>{t}</B>' if bold else t)
    s = "<BR/>".join(parts)
    if sub_lines:
        s += '<BR/><FONT POINT-SIZE="9" COLOR="#7c3aed"><I>' + "<BR/>".join(esc(x) for x in sub_lines) + "</I></FONT>"
    if note_lines:
        s += '<BR/><FONT POINT-SIZE="9" COLOR="#6b7280">' + "<BR/>".join(esc(x) for x in note_lines) + "</FONT>"
    return "<" + s + ">"


def to_dot(flow: Flow, title: str, show_meaning=True) -> str:
    L = ['digraph G {',
         '  graph [rankdir=TB, fontname="Helvetica", nodesep=0.55, ranksep=0.55, pad=0.3, labelloc=t, '
         f'label=<<B>{esc(title)}</B>>, fontsize=18, splines=ortho];',
         '  node [fontname="Helvetica", fontsize=11, margin="0.18,0.1"];',
         '  edge [fontname="Helvetica", fontsize=10, arrowsize=0.8, color="#2F5597"];']
    out_edges: Dict[str, List[Edge]] = defaultdict(list)
    for e in flow.edges:
        out_edges[e.src].append(e)
    for n in flow.nodes:
        k = n.kind
        if k == "page":
            lines = [n.label] + ([x for x in n.sub.split("\n") if x] if n.sub else [])
            note = [f"called from: {n.extra['called_from']}"] if n.extra.get("called_from") else []
            lab = html_label(wrap(n.label, 40), [], [], bold=True)
            if n.sub:
                lab = "<" + "<B>" + esc(n.label) + "</B>" + "".join(
                    f'<BR/><FONT COLOR="#1d4ed8">{esc(x)}</FONT>' for x in n.sub.split("\n") if x) + \
                    ('<BR/><FONT POINT-SIZE="9" COLOR="#6b7280">' + esc(note[0]) + "</FONT>" if note else "") + ">"
            elif note:
                lab = "<" + "<B>" + esc(n.label) + "</B>" + '<BR/><FONT POINT-SIZE="9" COLOR="#6b7280">' + esc(note[0]) + "</FONT>" + ">"
            L.append(f'  {n.id} [shape=box, style="filled", fillcolor="#DDEBF7", color="#2F5597", penwidth=1.6, label={lab}];')
        elif k == "target":
            note = [n.note] if n.note else []
            lab = html_label(wrap(n.label, 38), [], note, bold=True)
            L.append(f'  {n.id} [shape=box, style="filled,rounded", fillcolor="#FFFFFF", color="#2F5597", penwidth=1.4, label={lab}];')
        elif k == "decision":
            sub = wrap(n.sub, 30) if (show_meaning and n.sub) else []
            lab = html_label(wrap(n.label, 28), sub)
            col = "#B45309" if n.extra.get("loop") else "#2F5597"
            L.append(f'  {n.id} [shape=diamond, style="filled", fillcolor="#FFF8E1", color="{col}", margin="0.05,0.05", label={lab}];')
        elif k == "sql":
            sub = wrap(n.sub, 30) if n.sub else []
            lab = html_label(wrap(n.label, 30), sub)
            L.append(f'  {n.id} [shape=cylinder, style="filled", fillcolor="#E2F0D9", color="#548235", label={lab}];')
        elif k == "display":
            lab = html_label(wrap(n.label, 34), wrap(n.sub, 34) if n.sub else [])
            L.append(f'  {n.id} [shape=box, style="filled", fillcolor="#EDE7F6", color="#7c3aed", label={lab}];')
        elif k in ("exit", "end"):
            lab = html_label(wrap(n.label, 24))
            L.append(f'  {n.id} [shape=ellipse, style="filled", fillcolor="#F3F4F6", color="#6b7280", label={lab}];')
        else:   # process
            note = []
            if n.extra.get("via_fn"):
                note = [f"in {n.extra['via_fn']}"]
            lab = html_label(wrap(n.label, 34), wrap(n.sub, 34) if (show_meaning and n.sub) else [], note)
            L.append(f'  {n.id} [shape=box, style="filled", fillcolor="#FFFFFF", color="#2F5597", label={lab}];')
    for e in flow.edges:
        attrs = []
        lab = e.label
        outs = out_edges[e.src]
        src_node = flow.node(e.src)
        if lab:
            col = "#15803d" if lab.startswith("True") or lab.startswith("each") else \
                "#b91c1c" if lab.startswith("False") or lab.startswith("done") or lab == "no match" else "#1f2937"
            attrs.append(f'label=<<B>{esc(lab).replace(chr(10), "<BR/>")}</B>>')
            attrs.append(f'fontcolor="{col}"')
        if e.style == "back":
            attrs += ['style=dashed', 'constraint=false']
        elif e.style == "user":
            attrs += ['style=dashed', 'color="#7c3aed"']
        if src_node.kind == "decision" and not src_node.extra.get("switch"):
            if lab.startswith("True") or lab.startswith("each"):
                attrs.append("tailport=e")
            elif lab.startswith("False") or lab.startswith("done"):
                attrs.append("tailport=s")
        L.append(f'  {e.src} -> {e.dst} [{", ".join(attrs)}];')
    L.append("}")
    return "\n".join(L)


def to_mermaid(flow: Flow) -> str:
    def q(s):
        return '"' + s.replace('"', "'").replace("\n", "<br/>") + '"'
    L = ["flowchart TD"]
    for n in flow.nodes:
        text = n.label + (("\n" + n.sub) if n.sub else "")
        if n.kind == "decision":
            L.append(f"  {n.id}{{{q(text)}}}")
        elif n.kind == "sql":
            L.append(f"  {n.id}[({q(text)})]")
        elif n.kind in ("exit", "end"):
            L.append(f"  {n.id}([{q(text)}])")
        elif n.kind in ("page", "target", "display"):
            L.append(f"  {n.id}[[{q(text)}]]")
        else:
            L.append(f"  {n.id}[{q(text)}]")
    for e in flow.edges:
        arrow = "-.->" if e.style in ("back", "user") else "-->"
        if e.label:
            L.append(f"  {e.src} {arrow}|{q(e.label)}| {e.dst}")
        else:
            L.append(f"  {e.src} {arrow} {e.dst}")
    return "\n".join(L)


def render(dot_src: str, out_base: Path, formats=("png", "svg")) -> List[Path]:
    out_base.with_suffix(".dot").write_text(dot_src, encoding="utf-8")
    made = []
    if not shutil.which("dot"):
        print("  ! Graphviz 'dot' not found - only .dot/.mmd written. Install graphviz to get PNG/SVG.")
        return made
    for fmt in formats:
        p = out_base.with_suffix("." + fmt)
        args = ["dot", f"-T{fmt}", str(out_base.with_suffix(".dot")), "-o", str(p)]
        if fmt == "png":
            args.insert(1, "-Gdpi=130")
        r = subprocess.run(args, capture_output=True, text=True)
        if r.returncode != 0:
            print("  ! dot failed:", r.stderr.strip()[:300])
        else:
            made.append(p)
    return made



# --------------------------------------------------------------------------
# 7b. Navigation-only reduction + "which condition leads to which page" table
# --------------------------------------------------------------------------


def reduce_nav(flow: Flow) -> Flow:
    """Keep only: start page, decisions that influence where the user goes, and the
    destination pages (redirect / include / re-display of html).  Everything else
    (assignments, DB steps, prints, exits) is bypassed."""
    nodes = {n.id: n for n in flow.nodes}
    order = [n.id for n in flow.nodes]
    edges = [Edge(e.src, e.dst, e.label, e.style) for e in flow.edges]
    start = order[0]
    keep = {"page", "decision", "target", "display"}

    def outs(i):
        return [e for e in edges if e.src == i]

    def ins(i):
        return [e for e in edges if e.dst == i]

    def bypass(nid):
        nonlocal edges
        ie, oe = ins(nid), outs(nid)
        edges = [e for e in edges if e.src != nid and e.dst != nid]
        for a in ie:
            for b in oe:
                if a.src == nid or b.dst == nid or a.src == b.dst:
                    continue
                edges.append(Edge(a.src, b.dst, a.label or b.label, a.style or b.style))
        nodes.pop(nid, None)

    # 1. drop non-navigation nodes
    for nid in list(order):
        if nid in nodes and nodes[nid].kind not in keep:
            bypass(nid)
    # html links of an html page that is only re-displayed are not repeated here
    leaf_kinds = {"target", "display"}
    edges = [e for e in edges if not (nodes.get(e.src) and nodes[e.src].kind == "display")]

    def dedupe():
        nonlocal edges
        seen, out = set(), []
        for e in edges:
            k = (e.src, e.dst, e.label, e.style)
            if k not in seen and e.src != e.dst:
                seen.add(k); out.append(e)
        edges = out

    changed = True
    while changed:
        changed = False
        dedupe()
        # 2. merge identical destination boxes
        first = {}
        for nid in order:
            n = nodes.get(nid)
            if n and n.kind in leaf_kinds:
                key = (n.kind, n.label, n.note, n.sub)
                if key in first:
                    for e in edges:
                        if e.dst == nid:
                            e.dst = first[key]
                    nodes.pop(nid); changed = True
                else:
                    first[key] = nid
        dedupe()
        # 3. remove nodes that cannot reach any destination
        alive = {i for i, n in nodes.items() if n.kind in leaf_kinds}
        grow = True
        while grow:
            grow = False
            for e in edges:
                if e.dst in alive and e.src not in alive and e.src in nodes:
                    alive.add(e.src); grow = True
        for nid in list(nodes):
            if nid not in alive and nid != start:
                nodes.pop(nid); changed = True
        edges = [e for e in edges if e.src in nodes and e.dst in nodes]
        # 4. a decision whose every branch ends in the same place decides nothing
        for nid in list(order):
            n = nodes.get(nid)
            if n and n.kind == "decision":
                oe = [e for e in outs(nid) if e.style != "back"]
                if oe and len({e.dst for e in oe}) == 1:
                    dst = oe[0].dst
                    ie = ins(nid)
                    edges = [e for e in edges if e.src != nid and e.dst != nid]
                    for a in ie:
                        if a.src != dst:
                            edges.append(Edge(a.src, dst, a.label, a.style))
                    nodes.pop(nid); changed = True
    dedupe()
    flow.nodes = [nodes[i] for i in order if i in nodes]
    flow.edges = edges
    keep_lines = {n.line for n in flow.nodes if n.kind == "decision"}
    flow.glossary = [g for g in flow.glossary if g["line"] in keep_lines]
    for n in flow.nodes:           # nicer wording for destination boxes
        if n.kind == "display":
            n.sub = "stay on this page – show form again"
    return flow


def _negate(code: str) -> str:
    c = code.strip()
    if "&&" in c or "||" in c or re.search(r"\s(and|or)\s", c, re.I):
        return f"NOT ({c})"
    for a, b in (("===", "!=="), ("!==", "==="), ("==", "!="), ("!=", "=="), (">=", "<"), ("<=", ">"),
                 ("<>", "==")):
        if a in c:
            return c.replace(a, b, 1)
    if re.fullmatch(r"!\s*\(?[\w$ ()]+\)?", c):
        return c.lstrip("! ").strip()
    return f"NOT ({c})"


def nav_paths(flow: Flow) -> List[dict]:
    """Every route from the page start to a destination, with the conditions on the way."""
    nodes = {n.id: n for n in flow.nodes}
    adj: Dict[str, List[Edge]] = defaultdict(list)
    for e in flow.edges:
        if e.style != "back":
            adj[e.src].append(e)
    rows: List[dict] = []

    def cond_text(n: Optional[Node], label: str):
        if n is None:                              # user clicked something in the html
            return label, "User action on the html page"
        lab = label.split("\n")
        first = lab[0]
        m = re.match(r"switch \((.*)\)$", n.label)
        if m:
            subj = m.group(1)
            if first.startswith("=="):
                code = f"{subj} {first}"
                meaning = lab[1] if len(lab) > 1 else f"{n.sub}: {first[2:].strip()}"
            elif first == "default":
                code, meaning = f"{subj} is any other value", n.sub
            else:
                code, meaning = f"{subj} matches no case", n.sub
            return code, meaning
        if first.startswith(("True", "each")):
            return n.label, n.sub or ""
        return _negate(n.label), ("NOT: " + n.sub) if n.sub else ""

    def dfs(nid, conds, seen):
        if len(rows) > 3000:
            return
        n = nodes[nid]
        if n.kind in ("target", "display"):
            rows.append({"node": n, "conds": conds})
            return
        for e in adj[nid]:
            if e.dst in seen:
                continue
            c = conds
            if n.kind == "decision":
                c = conds + [cond_text(n, e.label)]
            elif e.style == "user":
                c = conds + [cond_text(None, e.label)]
            dfs(e.dst, c, seen | {e.dst})

    if flow.nodes:
        dfs(flow.nodes[0].id, [], {flow.nodes[0].id})
    out, seen = [], set()
    for r in rows:
        n = r["node"]
        codes = list(dict.fromkeys(c for c, _ in r["conds"]))
        means = list(dict.fromkeys(m for _, m in r["conds"] if m))
        if n.kind == "display":
            nxt, how = (n.label + " (same page)"), "show the form again"
        else:
            nxt = n.label.split("\n")[0]
            how = n.note or "redirect"
        key = (nxt, how, tuple(codes))
        if key in seen:
            continue
        seen.add(key)
        out.append({"page": flow.page, "next": nxt, "how": how,
                    "when_code": "  AND  ".join(codes) if codes else "always (no condition)",
                    "when_meaning": "  AND  ".join(means)})
    return out


# --------------------------------------------------------------------------
# 8. Word document
# --------------------------------------------------------------------------


def write_docx(path: Path, title: str, sections: List[dict], sitemap: Optional[Path]):
    try:
        from docx import Document
        from docx.shared import Inches, Pt, RGBColor
        from docx.enum.section import WD_ORIENT
        from docx.oxml.ns import qn
        from docx.oxml import OxmlElement
    except ImportError:
        print("  ! python-docx missing (pip install python-docx) - skipping .docx")
        return

    doc = Document()
    st = doc.styles["Normal"]
    st.font.name = "Calibri"
    st.font.size = Pt(10)
    sec = doc.sections[0]
    sec.left_margin = sec.right_margin = Inches(0.7)
    sec.top_margin = sec.bottom_margin = Inches(0.7)
    doc.add_heading(title, 0)

    def shade(cell, color):
        tcPr = cell._tc.get_or_add_tcPr()
        shd = OxmlElement("w:shd")
        shd.set(qn("w:val"), "clear"); shd.set(qn("w:color"), "auto"); shd.set(qn("w:fill"), color)
        tcPr.append(shd)

    if sitemap and sitemap.exists():
        doc.add_heading("Page navigation map", 1)
        doc.add_picture(str(sitemap), width=Inches(6.6))

    for s in sections:
        doc.add_page_break()
        doc.add_heading(s["page"], 1)
        p = doc.add_paragraph()
        p.add_run("HTML shown: ").bold = True
        p.add_run(", ".join(s["html"]) or "—")
        if s["called_from"]:
            p = doc.add_paragraph()
            p.add_run("Called from: ").bold = True
            p.add_run(", ".join(s["called_from"]))
        if s["png"] and Path(s["png"]).exists():
            from PIL import Image
            with Image.open(s["png"]) as im:
                w, h = im.size
            max_w, max_h = 6.9, 8.6
            wi = max_w
            if h / w * wi > max_h:
                wi = max_h * w / h
            doc.add_picture(str(s["png"]), width=Inches(wi))
            doc.paragraphs[-1].alignment = 1
            doc.add_paragraph("(Full-size PNG / SVG are saved next to this document.)").runs[0].italic = True
        if s.get("nav") is not None:
            doc.add_heading("When does the user go to the next page?", 2)
            t = doc.add_table(rows=1, cols=4)
            t.style = "Table Grid"
            for i, h in enumerate(("Next page", "How", "Condition (code)", "Meaning (from HTML)")):
                c = t.rows[0].cells[i]
                c.text = ""
                r = c.paragraphs[0].add_run(h); r.bold = True
                shade(c, "DDEBF7")
            for g in s["nav"]:
                row = t.add_row().cells
                row[0].text = g["next"]; row[1].text = g["how"]
                row[2].text = g["when_code"]; row[3].text = g["when_meaning"]
            for row in t.rows:
                for c, w in zip(row.cells, (1.6, 0.9, 2.4, 2.1)):
                    c.width = Inches(w)
                    for pp in c.paragraphs:
                        for rr in pp.runs:
                            rr.font.size = Pt(9)
        elif s["glossary"]:
            doc.add_heading("Conditions and their meaning", 2)
            t = doc.add_table(rows=1, cols=4)
            t.style = "Table Grid"
            for i, h in enumerate(("Line", "Condition (code)", "Meaning (from HTML)", "Taken from")):
                c = t.rows[0].cells[i]
                c.text = ""
                r = c.paragraphs[0].add_run(h); r.bold = True
                shade(c, "DDEBF7")
            for g in s["glossary"]:
                row = t.add_row().cells
                row[0].text = str(g["line"])
                row[1].text = g["condition"]
                row[2].text = g["meaning"]
                row[3].text = g["sources"]
                if not g["resolved"]:
                    shade(row[2], "FFF2CC")
            for row in t.rows:
                for c, w in zip(row.cells, (0.5, 2.0, 2.6, 1.9)):
                    c.width = Inches(w)
                    for pp in c.paragraphs:
                        for rr in pp.runs:
                            rr.font.size = Pt(9)
            doc.add_paragraph("Yellow = no description found in the HTML; the name was humanised. "
                              "Add it to meanings.json to override.").runs[0].italic = True
        if s["targets"] and s.get("nav") is None:
            doc.add_heading("Next pages reached from this page", 2)
            t = doc.add_table(rows=1, cols=2)
            t.style = "Table Grid"
            t.rows[0].cells[0].text = "Page"
            t.rows[0].cells[1].text = "How it is reached"
            for c in t.rows[0].cells:
                shade(c, "DDEBF7")
                for r in c.paragraphs[0].runs:
                    r.bold = True
            for f, how in s["targets"].items():
                row = t.add_row().cells
                row[0].text = f
                row[1].text = {"redirect": "header(Location) / redirect", "include": "include / require (runs inside this page)",
                               "user": "user clicks a link / submits the form in the html"}.get(how, how)
    doc.save(str(path))


# --------------------------------------------------------------------------
# 9. Driver
# --------------------------------------------------------------------------


def site_map_dot(pr: Project, pages: List[str]) -> str:
    L = ['digraph M {', '  graph [rankdir=LR, fontname="Helvetica", labelloc=t, label=<<B>Page navigation map</B>>, fontsize=18, pad=0.3];',
         '  node [shape=box, style="filled,rounded", fillcolor="#DDEBF7", color="#2F5597", fontname="Helvetica", fontsize=11];',
         '  edge [color="#2F5597", fontname="Helvetica", fontsize=9, arrowsize=0.7];']
    ids = {}
    def nid(f):
        if f not in ids:
            ids[f] = f"p{len(ids)}"
            col = "#DDEBF7" if f in pr.php else "#FFFFFF"
            L.append(f'  {ids[f]} [label="{f}", fillcolor="{col}"];')
        return ids[f]
    seen = set()
    for pg in pages:
        a = nid(pg)
        fl = pr._flow_cache[pg]
        for f, how in fl.targets.items():
            if (pg, f) in seen:
                continue
            seen.add((pg, f))
            style = {"user": "dashed", "include": "dotted"}.get(how, "solid")
            L.append(f'  {a} -> {nid(f)} [style={style}, label="{how}"];')
    L.append("}")
    return "\n".join(L)


def main(argv=None):
    ap = argparse.ArgumentParser(description="Generate PHP page-flow charts with condition meanings from HTML.")
    ap.add_argument("path", help="a .php file, or a folder containing php + html files")
    ap.add_argument("--entry", action="append", help="php file(s) to chart when `path` is a folder")
    ap.add_argument("--depth", type=int, default=1, help="also chart pages reached from the entry page (default 1)")
    ap.add_argument("--max-pages", type=int, default=15)
    ap.add_argument("--out", help="output folder (default: ./flow_output)")
    ap.add_argument("--meanings", help="JSON {variable: 'meaning'} to override / add condition meanings")
    ap.add_argument("--no-select", action="store_true", help="hide SELECT queries")
    ap.add_argument("--no-meaning", action="store_true", help="do not print meaning inside diamonds (still in the table)")
    ap.add_argument("--keep-dollar", action="store_true", help="show $ in conditions")
    ap.add_argument("--no-inline-functions", action="store_true")
    ap.add_argument("--full", action="store_true",
                    help="full flow (DB steps, assignments, prints ...) instead of navigation-only")
    ap.add_argument("--no-docx", action="store_true")
    ap.add_argument("--formats", default="png,svg")
    a = ap.parse_args(argv)

    p = Path(a.path).resolve()
    root = p.parent if p.is_file() else p
    entries = a.entry or ([p.name] if p.is_file() else [])
    out = Path(a.out) if a.out else Path.cwd() / "flow_output"
    out.mkdir(parents=True, exist_ok=True)

    meanings = {}
    for cand in (a.meanings, root / "meanings.json"):
        if cand and Path(cand).exists():
            meanings.update(json.loads(Path(cand).read_text(encoding="utf-8")))
    pr = Project(root, meanings)
    pr._flow_cache = {}
    print(f"Folder: {root}\n  php files: {len(pr.php)}   html files: {len(pr.html_files)}")

    if not entries:       # root pages: not referenced by anybody
        entries = [n for n in pr.php if not pr.callers.get(n) and pr.is_page_like(n)] or \
                  [n for n in pr.php if pr.is_page_like(n)]
        print("  no --entry given, charting root pages:", ", ".join(entries))
    for e in entries:
        if e not in pr.php:
            sys.exit(f"Entry file {e} not found in {root}")

    order: List[str] = []
    level = {e: 0 for e in entries}
    queue = list(entries)
    while queue and len(order) < a.max_pages:
        cur = queue.pop(0)
        if cur in order:
            continue
        order.append(cur)
        fl = Flow(pr, cur, include_select=not a.no_select, keep_dollar=a.keep_dollar,
                  inline_functions=not a.no_inline_functions).build()
        if not a.full:
            fl.full_targets = dict(fl.targets)
            reduce_nav(fl)
        pr._flow_cache[cur] = fl
        if level[cur] < a.depth:
            for f in fl.targets:
                if f in pr.php and f not in level and pr.is_page_like(f):
                    level[f] = level[cur] + 1
                    queue.append(f)

    fmts = tuple(x.strip() for x in a.formats.split(",") if x.strip())
    sections = []
    all_gloss = []
    all_nav = []
    for pg in order:
        fl = pr._flow_cache[pg]
        base = out / f"flow_{Path(pg).stem}"
        dot = to_dot(fl, f"{pg}", show_meaning=not a.no_meaning)
        made = render(dot, base, fmts)
        base.with_suffix(".mmd").write_text(to_mermaid(fl), encoding="utf-8")
        png = base.with_suffix(".png")
        print(f"  {pg}: {len(fl.nodes)} nodes, {len(fl.edges)} edges, {len(fl.glossary)} conditions -> {base.name}.*")
        callers = sorted(pr.callers.get(pg, []))
        nav = None if a.full else nav_paths(fl)
        if nav:
            all_nav.extend(nav)
        sections.append({"page": pg, "html": fl.html_used, "called_from": callers, "nav": nav,
                         "png": png if png.exists() else None, "glossary": fl.glossary, "targets": fl.targets})
        all_gloss.extend(fl.glossary)

    with open(out / "condition_glossary.csv", "w", newline="", encoding="utf-8-sig") as f:
        w = csv.DictWriter(f, fieldnames=["page", "line", "condition", "meaning", "resolved", "sources", "comment"])
        w.writeheader()
        w.writerows(all_gloss)

    if all_nav:
        with open(out / "navigation_table.csv", "w", newline="", encoding="utf-8-sig") as f:
            w = csv.DictWriter(f, fieldnames=["page", "next", "how", "when_code", "when_meaning"])
            w.writeheader(); w.writerows(all_nav)
        print(f"  navigation table: {out / 'navigation_table.csv'}  ({len(all_nav)} routes)")
    sitemap_png = None
    if len(order) >= 1:
        sm = site_map_dot(pr, order)
        r = render(sm, out / "page_map", ("png",))
        sitemap_png = out / "page_map.png" if r else None

    if not a.no_docx:
        name = f"FormFlow_{Path(entries[0]).stem}.docx" if len(entries) == 1 else "FormFlow.docx"
        write_docx(out / name, f"Form flow – {', '.join(entries)}", sections, sitemap_png)
        print(f"  Word document: {out / name}")
    unresolved = [g for g in all_gloss if not g["resolved"]]
    print(f"Done. Output in {out}\n  conditions: {len(all_gloss)}  (without HTML description: {len(unresolved)})")
    return 0


if __name__ == "__main__":
    sys.exit(main())
